fun main() {
   val a =Aun()
//   print("请输入你要的咖啡与数量：")
//   a.w = readln()
//   print("请输入你要的${a.w}的数量：")
//
//   a.h = readln().toInt()
   a.print()
}
