class Monster {

}