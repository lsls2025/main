fun main(){
    val xi = Game()
    xi.run()
}