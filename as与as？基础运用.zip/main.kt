fun main(){
    val data: Any = "hello"
    val aa= data as? Int
    print(aa)

}