class Aun {
    var name : String = ""
    var nl :Int = 0
    var sg :Int = 0
    var tz :Int = 0
    var ss = 0
    fun hello() {
        println("hello")
    }
    fun run(){
        repeat(10){
            println("Running")
        }
    }
}
