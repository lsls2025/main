fun main() {
    val a : m = m()
    a.ww()
}