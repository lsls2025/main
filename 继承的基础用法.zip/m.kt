class m :  w() {
}