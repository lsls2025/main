open class w {
    fun ww() {
        print("你好")
    }
}