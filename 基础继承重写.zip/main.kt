fun main () {
    val a = Rabbit()
    a.printInfo("老牛")
}