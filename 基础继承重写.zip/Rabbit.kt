open class Rabbit : Animal(){
    override fun printInfo(name: String) {
        println("这是一只兔子，名字叫${name}")
    }
}