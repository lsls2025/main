open class Animal () {
    open fun printInfo(name: String){
        println("这是一只动物，名字叫${name}")
    }
}
