class NormalLine {
    //普通人
    fun normalLine() {

    }
}