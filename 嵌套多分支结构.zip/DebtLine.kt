class DebtLine {
    //负二代
    fun debtline(){

    }
}