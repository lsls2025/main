class RichLine {
    //富二代
    fun richline(){
        print("")

    }
}