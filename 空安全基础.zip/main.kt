fun main(){
    val name : String? = null
    val result = name?.uppercase()?:1
    println(result)
}