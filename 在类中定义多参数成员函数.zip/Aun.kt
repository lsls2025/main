class Ass {
    fun bri(a: String,b:Int){
            println("起床")
            println("走到咖啡机旁")
            println("按下${b}次 “${a}” 按钮")
            println("等待${b}杯${a}制作完成")
            println("拿起${b}杯${a}")
            println("把${b}杯${a}送到主管那里")
            println("将${b}杯${a}放在桌上")
            println("返回工作岗位")

    }
}