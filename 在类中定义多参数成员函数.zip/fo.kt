fun main () {
   val a = Ass()
      a.bri("咖啡",3)
}