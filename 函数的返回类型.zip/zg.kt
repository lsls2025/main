class Dis(
    var name : String,
    var age: Int) {

    fun tak(e:Assistant) {
        e.bringCoffee(name)
    }
}