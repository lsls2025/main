fun main() {
   var a =Aun()
   a.print()
}
