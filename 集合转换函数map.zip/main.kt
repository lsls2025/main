fun main (){
    val scores = listOf(85, 72, 93, 45, 68, 90)
    val passed = scores.filter{it >= 60}
    val formatted = passed.map { passed -> "分数：${passed}" }
    println(formatted)
}