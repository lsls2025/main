var i = 0
while (i < 100){
    println(1+i)
    i++
}

