fun main() {
   val rec = Aun(size = 100)
   rec.rec()
}
