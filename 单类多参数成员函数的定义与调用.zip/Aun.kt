class Ass {
    fun bri(name: String,Brand: String,Size: Int,Price: Int){
        print("商品名称:$name\n品牌名：${Brand}\n尺码：${Size}\n价格：${Price}\n")
    }
}