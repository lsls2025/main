package com.aurora.chat

/**
 * 本地标记为成人内容的帖子 ID 缓存。
 * 发帖时勾选了"标注为成人内容"但后端可能未支持 is_adult 字段时，
 * 通过此缓存确保详情页能正确拦截显示。
 */
object AdultPostCache {
    private val adultPostIds = mutableSetOf<Long>()
    private val agreedPostIds = mutableSetOf<Long>()

    fun markAdult(postId: Long) { adultPostIds.add(postId) }
    fun isAdult(postId: Long): Boolean = adultPostIds.contains(postId)
    fun hasAgreed(postId: Long): Boolean = agreedPostIds.contains(postId)
    fun agree(postId: Long) { agreedPostIds.add(postId) }
}
