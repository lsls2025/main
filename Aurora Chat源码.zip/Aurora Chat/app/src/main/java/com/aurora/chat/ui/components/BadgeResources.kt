﻿package com.aurora.chat.ui.components

import com.aurora.chat.R

/**
 * 徽章资源单一数据源。
 *
 * 原项目在 7 个文件中重复定义了相同的徽章 drawable 数组 / 名称数组 / BadgeInfo 列表，
 * 既违反 DRY，又容易出现「改了一处漏了另一处」。这里统一收口：
 *  - [allBadgeResIds]：全部 15 个徽章的 drawable 资源 ID，顺序固定为 badgeId 1..15 对应项
 *    （bazaar_1..12，随后 member_1 / member_3 / member_2 —— 与后端授予的会员等级一致）
 *  - [bazaarBadgeResIds]：仅开发/官方类徽章（bazaar_1..10），用于社区页等只展示开发徽章的入口
 *  - [badgeNames]：badgeId 1..15 对应的名称
 *  - [badgeInfos]：带名称 + 资源 + 描述的富信息列表（与 [allBadgeResIds] 顺序一致）
 */
object BadgeResources {

    /** 全部 15 个徽章的 drawable 资源 ID（顺序即 badgeId 顺序） */
    val allBadgeResIds = intArrayOf(
        R.drawable.badge_bazaar_1, R.drawable.badge_bazaar_2, R.drawable.badge_bazaar_3,
        R.drawable.badge_bazaar_4, R.drawable.badge_bazaar_5, R.drawable.badge_bazaar_6,
        R.drawable.badge_bazaar_7, R.drawable.badge_bazaar_8, R.drawable.badge_bazaar_9,
        R.drawable.badge_bazaar_10, R.drawable.badge_bazaar_11, R.drawable.badge_bazaar_12,
        R.drawable.badge_member_1, R.drawable.badge_member_3, R.drawable.badge_member_2
    )

    /** 仅开发/官方类徽章（bazaar_1..10） */
    val bazaarBadgeResIds = intArrayOf(
        R.drawable.badge_bazaar_1, R.drawable.badge_bazaar_2, R.drawable.badge_bazaar_3,
        R.drawable.badge_bazaar_4, R.drawable.badge_bazaar_5, R.drawable.badge_bazaar_6,
        R.drawable.badge_bazaar_7, R.drawable.badge_bazaar_8, R.drawable.badge_bazaar_9,
        R.drawable.badge_bazaar_10
    )

    /** badgeId 1..15 对应的名称 */
    val badgeNames = arrayOf(
        "一级开发徽章", "二级开发徽章", "三级开发徽章", "始祖徽章", "凤凰徽章",
        "Alsay官方限定徽章", "LS工作室徽章", "一级VIP徽章", "二级VIP徽章", "VDS官方限定徽章",
        "一级管理员", "二级管理员", "普通会员徽章", "高级会员徽章", "尊享会员徽章"
    )

    /** 全部 15 个徽章的富信息（名称 + 资源 + 描述），顺序与 [allBadgeResIds] 一致 */
    val badgeInfos = listOf(
        BadgeInfo("一级开发徽章", R.drawable.badge_bazaar_1, "对本应用提供较大贡献且提供了技术支持即可获得本徽章"),
        BadgeInfo("二级开发徽章", R.drawable.badge_bazaar_2, "对应用提供较大贡献且开发并上架了使用的工具或软件即可获得本徽章"),
        BadgeInfo("三级开发徽章", R.drawable.badge_bazaar_3, "对本应用提供贡献且保持开发活跃即可获得本徽章"),
        BadgeInfo("始祖徽章", R.drawable.badge_bazaar_4, "在本平台活跃且在开发阶段就已存在的内测用户可获得此徽章"),
        BadgeInfo("凤凰徽章", R.drawable.badge_bazaar_5, "被官方认可获得此徽章"),
        BadgeInfo("Alsay官方限定徽章", R.drawable.badge_bazaar_6, "Alsay官方限定徽章"),
        BadgeInfo("LS工作室徽章", R.drawable.badge_bazaar_7, "在QQ官方群123456789持续保持活跃即可获得徽章"),
        BadgeInfo("一级VIP徽章", R.drawable.badge_bazaar_8, "活跃度高的用户即可获得"),
        BadgeInfo("二级VIP徽章", R.drawable.badge_bazaar_9, "社区贡献高的用户即可获得"),
        BadgeInfo("VDS官方限定徽章", R.drawable.badge_bazaar_10, "VDS官方限定徽章"),
        BadgeInfo("一级管理员", R.drawable.badge_bazaar_11, "由平台授权的管理员，权限较高"),
        BadgeInfo("二级管理员", R.drawable.badge_bazaar_12, "由平台授权的管理员身份，拥有管理权力"),
        BadgeInfo("普通会员徽章", R.drawable.badge_member_1, "开通普通会员即可获得，佩戴展示您的会员身份"),
        BadgeInfo("高级会员徽章", R.drawable.badge_member_3, "开通高级会员即可获得，彰显更高会员等级"),
        BadgeInfo("尊享会员徽章", R.drawable.badge_member_2, "开通尊享会员尊享专属身份标识"),
    )

    /** 按 badgeId（从 1 开始）取资源 ID，越界回退到默认开发徽章 */
    fun resIdForBadgeId(badgeId: Int): Int =
        if (badgeId in 1..allBadgeResIds.size) allBadgeResIds[badgeId - 1] else R.drawable.badge_bazaar_1

    /** 按 badgeId 取名称，越界回退到「徽章N」 */
    fun nameForBadgeId(badgeId: Int): String =
        if (badgeId in 1..badgeNames.size) badgeNames[badgeId - 1] else "徽章$badgeId"
}
