package com.aurora.chat.data.local

import android.content.Context
import com.aurora.chat.CryptoUtil
import com.aurora.chat.data.api.MessageInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * 聊天消息本地持久化存储（SharedPreferences + 文件双重保障）
 * 每条消息按对话分组，不因清除缓存而丢失
 */
object LocalMessageStore {

    private fun getFile(ctx: Context, friendId: Long): File {
        val dir = File(ctx.filesDir, "messages")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "${friendId}.json")
    }

    /** 保存加载到的消息到本地（追加，去重） */
    fun saveMessages(ctx: Context, friendId: Long, messages: List<MessageInfo>) {
        try {
            // 读取已有
            val existing = loadMessages(ctx, friendId).toMutableList()
            val existingIds = existing.map { it.id }.toSet()
            // 追加不在已有的
            var changed = false
            for (m in messages) {
                if (m.id !in existingIds) {
                    existing.add(m)
                    changed = true
                }
            }
            if (!changed) return

            // 序列化并写入 SP + 文件
            val arr = JSONArray()
            existing.forEach { m ->
                arr.put(JSONObject().apply {
                    put("id", m.id); put("fromUserId", m.fromUserId)
                    put("fromUserName", m.fromUserName); put("content", CryptoUtil.encryptLocal(m.content))
                    put("createdAt", m.createdAt); put("mediaType", m.mediaType)
                    put("mediaUrl", m.mediaUrl); put("isRevoked", m.isRevoked)
                    put("replyToText", m.replyToText); put("replyToSender", m.replyToSender)
                    put("replyToId", m.replyToId); put("flashDuration", m.flashDuration)
                    put("toUserId", m.toUserId); put("wornBadge", m.wornBadge)
                })
            }
            val json = arr.toString()
            // 仅写文件：避免 SharedPreferences 单值 ~1MB 上限导致长对话保存失败/静默丢消息
            getFile(ctx, friendId).writeText(json)
        } catch (_: Exception) {}
    }

    /** 从本地加载聊天消息（优先文件，无 1MB 上限；SP 仅兜底兼容旧数据） */
    fun loadMessages(ctx: Context, friendId: Long): List<MessageInfo> {
        // 优先读文件：长对话安全，不受 SharedPreferences 单值大小上限约束
        try {
            val f = getFile(ctx, friendId)
            if (f.exists()) return parseMessages(ctx, f.readText())
        } catch (_: Exception) {}
        // 兜底：旧版本曾将整段对话存于 SP
        try {
            val sp = ctx.getSharedPreferences("msg_store", Context.MODE_PRIVATE)
                .getString("msg_$friendId", null)
            if (sp != null) return parseMessages(ctx, sp)
        } catch (_: Exception) {}
        return emptyList()
    }

    private fun parseMessages(ctx: Context, json: String): List<MessageInfo> {
        val arr = JSONArray(json)
        return (0 until arr.length()).map { i ->
            val obj = arr.getJSONObject(i)
            MessageInfo(
                id = obj.getLong("id"),
                fromUserId = obj.getLong("fromUserId"),
                fromUserName = obj.optString("fromUserName", ""),
                content = CryptoUtil.decryptLocal(obj.optString("content", "")),
                createdAt = obj.optLong("createdAt"),
                mediaType = obj.optString("mediaType", ""),
                mediaUrl = obj.optString("mediaUrl", ""),
                isRevoked = obj.optInt("isRevoked", 0),
                replyToText = obj.optString("replyToText", ""),
                replyToSender = obj.optString("replyToSender", ""),
                replyToId = obj.optLong("replyToId", 0),
                flashDuration = obj.optInt("flashDuration", 0),
                toUserId = obj.optLong("toUserId", 0),
                wornBadge = obj.optInt("wornBadge", 0)
            )
        }
    }
}
