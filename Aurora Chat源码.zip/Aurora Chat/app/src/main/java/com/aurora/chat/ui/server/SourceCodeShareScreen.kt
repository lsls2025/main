﻿package com.aurora.chat.ui.server

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.data.api.CommentInfo
import com.aurora.chat.data.api.CommentListResponse
import com.aurora.chat.data.local.LocalStorage
import com.aurora.chat.data.repository.ChatRepository
import com.aurora.chat.ui.community.CommentRow
import com.aurora.chat.ui.community.SharePostDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

private val ScPurple = Color(0xFF1A237E)
private val ScPurpleLight = Color(0xFF1A237E).copy(alpha = 0.12f)

/** 从 content:// 或 file:// URI 取出可读的文件名 */
private fun getUriDisplayName(context: Context, uri: Uri): String? {
    return try {
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
            }
        } else {
            uri.lastPathSegment
        }
    } catch (_: Exception) { null }
}

@Composable
fun SourceCodeShareScreen(onBack: () -> Unit, initialShareId: Long = 0L) {
    var view by remember { mutableStateOf(if (initialShareId > 0) "detail" else "feed") }
    var selectedId by remember { mutableStateOf(initialShareId) }
    var feedVersion by remember { mutableStateOf(0) }

    // 拦截系统返回手势（左右滑退出），按视图层级退回：
    // 详情/上传 → 回到列表；列表 → 关闭整个 Dialog，而不是直接退出工具板块
    BackHandler {
        if (view == "feed") onBack() else view = "feed"
    }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        AnimatedVisibility(
            visible = view == "feed",
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(150))
        ) {
            SourceCodeFeed(
                refreshKey = feedVersion,
                onBack = onBack,
                onUpload = { view = "upload" },
                onOpenDetail = { id ->
                    selectedId = id
                    view = "detail"
                }
            )
        }
        AnimatedVisibility(
            visible = view == "upload",
            enter = slideInHorizontally(tween(300)) { it },
            exit = slideOutHorizontally(tween(300)) { it }
        ) {
            SourceCodeUploadScreen(
                onBack = { view = "feed" },
                onSubmitted = {
                    feedVersion++
                    view = "feed"
                }
            )
        }
        AnimatedVisibility(
            visible = view == "detail",
            enter = slideInHorizontally(tween(300)) { it },
            exit = slideOutHorizontally(tween(300)) { it }
        ) {
            SourceCodeDetail(
                shareId = selectedId,
                onBack = { view = "feed" }
            )
        }
    }
}

// ===================== 筛选抽屉 =====================

@Composable
private fun SourceCodeFilterSheet(
    initialIsFree: String,
    initialMinTokens: Long,
    initialMaxTokens: Long,
    initialSort: String,
    onApply: (String, Long, Long, String) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    var localFree by remember { mutableStateOf(initialIsFree) }
    var localMin by remember { mutableStateOf(initialMinTokens) }
    var localMax by remember { mutableStateOf(initialMaxTokens) }
    var localSort by remember { mutableStateOf(initialSort) }
    var customOpen by remember {
        mutableStateOf(
            initialMinTokens > 0 && initialMaxTokens > 0 &&
                !listOf(5000L, 10000L, 100000L).contains(initialMaxTokens)
        )
    }

    val ranges = listOf(
        "0~5000" to (0L to 5000L),
        "5000~1万" to (5000L to 10000L),
        "1万~10万" to (10000L to 100000L)
    )

    Column(
        Modifier.fillMaxWidth().wrapContentHeight().background(Color.White)
            .clickable(enabled = false) {}
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("筛选", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            Text("完成", fontSize = 14.sp, color = ScPurple, fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onApply(localFree, localMin, localMax, localSort) })
        }
        Spacer(Modifier.height(12.dp))

        Text("类型", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipItem("全部", localFree == "") { localFree = "" }
            FilterChipItem("免费", localFree == "1") { localFree = "1" }
            FilterChipItem("收费", localFree == "0") { localFree = "0" }
        }

        Spacer(Modifier.height(14.dp))

        Text("Token 价格区间", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ranges.forEach { (label, pair) ->
                val active = localMin == pair.first && localMax == pair.second
                FilterChipItem(label, active) { localMin = pair.first; localMax = pair.second; customOpen = false }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChipItem("自定义", customOpen) { customOpen = true; localMin = 0; localMax = 0 }
            if (customOpen) {
                TokensInput(localMin, { localMin = it }, "最小")
                Text("~", Modifier.padding(horizontal = 4.dp), color = Color(0xFF9CA3AF))
                TokensInput(localMax, { localMax = it }, "最大")
            }
        }

        Spacer(Modifier.height(14.dp))

        Text("排序", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipItem("最新", localSort == "time") { localSort = "time" }
            FilterChipItem("下载量最高", localSort == "download") { localSort = "download" }
        }

        Spacer(Modifier.height(14.dp))

        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFF3F4F6))
                .clickable { onReset() }.padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("重置筛选", fontSize = 13.sp, color = Color(0xFF6B7280), fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun FilterChipItem(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) ScPurpleLight else Color(0xFFF3F4F6)
    val fg = if (selected) ScPurple else Color(0xFF6B7280)
    Box(
        Modifier.clip(RoundedCornerShape(16.dp)).background(bg).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(label, fontSize = 13.sp, color = fg, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun TokensInput(value: Long, onValueChange: (Long) -> Unit, placeholder: String) {
    var text by remember(value) { mutableStateOf(if (value > 0) value.toString() else "") }
    BasicTextField(
        value = text,
        onValueChange = {
            text = it.filter { c -> c.isDigit() }
            onValueChange(text.toLongOrNull() ?: 0L)
        },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.width(90.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFF3F4F6))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp, color = Color(0xFF1F2937)),
        cursorBrush = SolidColor(ScPurple),
        decorationBox = { inner -> if (text.isEmpty()) Text(placeholder, color = Color(0xFF9CA3AF), fontSize = 13.sp); inner() }
    )
}

// ===================== Feed =====================

@Composable
private fun SourceCodeFeed(
    refreshKey: Int,
    onBack: () -> Unit,
    onUpload: () -> Unit,
    onOpenDetail: (Long) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val serverUrl = remember { AuroraApi.serverUrl }

    var keyword by remember { mutableStateOf("") }
    var searchText by remember { mutableStateOf("") }
    var shares by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    var filterIsFree by remember { mutableStateOf("") }
    var filterMinTokens by remember { mutableStateOf(0L) }
    var filterMaxTokens by remember { mutableStateOf(0L) }
    var sortBy by remember { mutableStateOf("time") }
    var showFilter by remember { mutableStateOf(false) }

    val isDeveloper = remember {
        LocalStorage.isDeveloper(AuroraApi.currentUserQQ, AuroraApi.currentUserEmail)
    }
    val currentUserId = AuroraApi.currentUserId
    var shareTarget by remember { mutableStateOf<JSONObject?>(null) }

    fun deleteShare(shareId: Long) {
        scope.launch {
            try {
                val r = AuroraApi.deleteSourceCode(shareId)
                if (r.success) {
                    shares = shares.filter { it.optLong("id", 0) != shareId }
                    Toast.makeText(context, "已删除", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, r.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, e.localizedMessage ?: "删除失败", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun load(
        forceIsFree: String = filterIsFree,
        forceMin: Long = filterMinTokens,
        forceMax: Long = filterMaxTokens,
        forceSort: String = sortBy
    ) {
        isLoading = true
        errorMsg = null
        scope.launch {
            try {
                val r = AuroraApi.getSourceCodeList(
                    keyword = keyword,
                    page = 1,
                    limit = 40,
                    isFree = forceIsFree,
                    minTokens = forceMin,
                    maxTokens = forceMax,
                    sort = forceSort
                )
                if (r.success && r.data != null) {
                    val arr = r.data.optJSONArray("shares")
                    val list = (0 until (arr?.length() ?: 0)).map { arr!!.getJSONObject(it) }
                    shares = list
                } else {
                    errorMsg = r.message
                }
            } catch (e: Exception) {
                errorMsg = e.localizedMessage ?: "加载失败"
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(refreshKey) { load() }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null,
                    modifier = Modifier.size(24.dp).clickable { onBack() },
                    tint = Color(0xFF1F2937))
                Spacer(Modifier.width(8.dp))
                Text("源码分享", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    Modifier.clickable { showFilter = true }.padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.FilterList, contentDescription = null, tint = ScPurple, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("筛选", fontSize = 13.sp, color = ScPurple, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF3F4F6)).padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Search, contentDescription = null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    TextField(
                        value = searchText,
                        onValueChange = { searchText = it },
                        placeholder = { Text("搜索内容", fontSize = 14.sp, color = Color(0xFF9CA3AF)) },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            cursorColor = ScPurple
                        ),
                        modifier = Modifier.weight(1f),
                        textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
                    )
                    if (searchText.isNotEmpty()) {
                        Icon(Icons.Filled.Clear, contentDescription = null, tint = Color(0xFF9CA3AF),
                            modifier = Modifier.size(18.dp).clickable { searchText = ""; keyword = ""; load() })
                    }
                    Text("搜索", fontSize = 13.sp, color = ScPurple, fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable {
                            keyword = searchText.trim()
                            load()
                        })
                }
            }

            Spacer(Modifier.height(8.dp))

            Box(Modifier.fillMaxSize()) {
                if (isLoading) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(Modifier.size(28.dp), color = ScPurple, strokeWidth = 3.dp)
                    }
                } else if (errorMsg != null) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(errorMsg!!, color = Color(0xFFDC2626), fontSize = 14.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("重试", color = ScPurple, fontWeight = FontWeight.Medium,
                                modifier = Modifier.clickable { load() })
                        }
                    }
                } else if (shares.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            if (keyword.isNotEmpty()) "未找到相关源码" else "还没有人分享源码，点击右下角 + 成为第一个吧",
                            color = Color(0xFF9CA3AF), fontSize = 14.sp, textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 88.dp)
                    ) {
                        items(shares) { share ->
                            SourceCodeCard(
                                share = share,
                                serverUrl = serverUrl,
                                isDeveloper = isDeveloper,
                                currentUserId = currentUserId,
                                onClick = {
                                    onOpenDetail(share.optLong("id", 0))
                                },
                                onDelete = { deleteShare(share.optLong("id", 0)) },
                                onShare = { shareTarget = it }
                            )
                        }
                    }
                }

                FloatingActionButton(
                    onClick = onUpload,
                    containerColor = ScPurple,
                    contentColor = Color.White,
                    modifier = Modifier.align(Alignment.BottomEnd)
                        .navigationBarsPadding()
                        .padding(end = 20.dp, bottom = 64.dp)
                        .size(56.dp)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "上传", modifier = Modifier.size(28.dp))
                }

                shareTarget?.let { st ->
                    SharePostDialog(
                        postTitle = st.optString("title", ""),
                        postContent = st.optString("description", ""),
                        postId = st.optLong("id", 0),
                        postUserId = st.optLong("user_id", 0),
                        postUsername = st.optString("username", ""),
                        postType = "",
                        titlePrefix = "分享源码",
                        idKey = "source_code_id",
                        onDismiss = { shareTarget = null }
                    )
                }
            }
        }

        AnimatedVisibility(visible = showFilter, enter = fadeIn(tween(200)), exit = fadeOut(tween(200))) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)).clickable { showFilter = false })
        }
        AnimatedVisibility(
            visible = showFilter,
            enter = slideInVertically(tween(280)) { -it },
            exit = slideOutVertically(tween(280)) { -it }
        ) {
            SourceCodeFilterSheet(
                initialIsFree = filterIsFree,
                initialMinTokens = filterMinTokens,
                initialMaxTokens = filterMaxTokens,
                initialSort = sortBy,
                onApply = { isFree, min, max, s ->
                    filterIsFree = isFree
                    filterMinTokens = min
                    filterMaxTokens = max
                    sortBy = s
                    showFilter = false
                    load(forceIsFree = isFree, forceMin = min, forceMax = max, forceSort = s)
                },
                onReset = {
                    filterIsFree = ""
                    filterMinTokens = 0
                    filterMaxTokens = 0
                    sortBy = "time"
                    showFilter = false
                    load(forceIsFree = "", forceMin = 0, forceMax = 0, forceSort = "time")
                },
                onDismiss = { showFilter = false }
            )
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun SourceCodeCard(
    share: JSONObject,
    serverUrl: String,
    isDeveloper: Boolean,
    currentUserId: Long,
    onClick: () -> Unit,
    onDelete: (Long) -> Unit,
    onShare: (JSONObject) -> Unit
) {
    val id = share.optLong("id", 0)
    val ownerId = share.optLong("user_id", 0)
    val canDelete = isDeveloper || ownerId == currentUserId
    var showMenu by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }

    val title = share.optString("title", "")
    val isFree = share.optInt("is_free", 1) == 1
    val price = share.optLong("price_tokens", 0)
    val downloadCount = share.optInt("download_count", 0)
    val fileSize = share.optLong("file_size", 0)
    val sizeText = formatFileSize(fileSize)
    val screenshots = try {
        val arr = share.optJSONArray("screenshots")
        (0 until (arr?.length() ?: 0)).mapNotNull { arr?.optString(it) }.filter { it.isNotEmpty() }
    } catch (_: Exception) { emptyList() }
    val firstSs = if (screenshots.isNotEmpty()) "$serverUrl/api/source_code/screenshot/$id/${screenshots[0]}" else ""

    Box(Modifier.wrapContentSize(Alignment.TopStart)) {
        Card(
            modifier = Modifier.fillMaxWidth().combinedClickable(
                onClick = onClick,
                onLongClick = { showMenu = true }
            ),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(Modifier.fillMaxWidth()) {
                Box(
                    Modifier.fillMaxWidth().height(150.dp)
                        .background(if (firstSs.isEmpty()) ScPurpleLight else Color(0xFFF3F4F6)),
                    contentAlignment = Alignment.Center
                ) {
                    if (firstSs.isNotEmpty()) {
                        AsyncImage(model = firstSs, contentDescription = null,
                            modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                    } else {
                        Icon(Icons.Filled.Code, contentDescription = null, tint = ScPurple, modifier = Modifier.size(32.dp))
                    }
                }
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937),
                        maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Download, contentDescription = null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("$downloadCount", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                        Spacer(Modifier.width(6.dp))
                        Text(sizeText, fontSize = 11.sp, color = Color(0xFF9CA3AF))
                        Spacer(Modifier.weight(1f))
                        Box(
                            Modifier.clip(RoundedCornerShape(6.dp))
                                .background(if (isFree) Color(0xFF059669).copy(alpha = 0.12f) else Color(0xFFD97706).copy(alpha = 0.14f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                if (isFree) "免费" else "${price}token",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isFree) Color(0xFF059669) else Color(0xFFD97706)
                            )
                        }
                    }
                }
            }
        }

        DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false }
        ) {
            DropdownMenuItem(
                text = { Text("分享") },
                onClick = {
                    showMenu = false
                    onShare(share)
                }
            )
            if (canDelete) {
                DropdownMenuItem(
                    text = { Text("删除", color = Color(0xFFDC2626)) },
                    onClick = {
                        showMenu = false
                        showConfirm = true
                    }
                )
            }
        }
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确认删除") },
            text = { Text("删除后该分享将无法恢复，确定要删除吗？") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    onDelete(id)
                }) { Text("删除", color = Color(0xFFDC2626)) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("取消") }
            }
        )
    }
}

// ===================== 上传 =====================

@Composable
private fun SourceCodeUploadScreen(onBack: () -> Unit, onSubmitted: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val density = LocalDensity.current
    val navBottomPx = WindowInsets.navigationBars.getBottom(density)
    val safeBottom = with(density) { navBottomPx.toDp() }.coerceAtLeast(36.dp)

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var isFree by remember { mutableStateOf(true) }
    var priceTokensStr by remember { mutableStateOf("") }

    // 上传的文件 URI 列表
    var fileUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var fileNames by remember { mutableStateOf<List<String>>(emptyList()) }
    var screenshotUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val names = uris.mapNotNull { getUriDisplayName(context, it) }
            fileUris = uris
            fileNames = names
        }
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            val uris = mutableListOf<Uri>()
            val names = mutableListOf<String>()
            val rootDir = DocumentFile.fromTreeUri(context, uri)
            if (rootDir != null) {
                fun collectFiles(dir: DocumentFile) {
                    val files = dir.listFiles()
                    for (f in files) {
                        if (f.isDirectory) {
                            collectFiles(f)
                        } else if (f.isFile && f.uri != null) {
                            uris.add(f.uri)
                            names.add(f.name ?: "unknown")
                        }
                    }
                }
                collectFiles(rootDir)
            }
            if (uris.isNotEmpty()) {
                fileUris = uris
                fileNames = names
            }
        }
    }
    val screenshotLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        val remaining = 2 - screenshotUris.size
        if (remaining > 0) screenshotUris = screenshotUris + uris.take(remaining)
    }

    Column(Modifier.fillMaxSize().background(Color.White).imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = Color(0xFF1F2937),
                modifier = Modifier.size(24.dp).clickable { onBack() })
            Spacer(Modifier.width(8.dp))
            Text("上传源码", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        }

        Column(
            Modifier.weight(1f).fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // 上传文件
            Text("上传源码文件", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // 选择文件
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(ScPurpleLight)
                    .clickable { fileLauncher.launch(arrayOf("*/*")) }
                    .padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.InsertDriveFile, contentDescription = null, tint = ScPurple, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("选择文件", fontSize = 13.sp, color = ScPurple, fontWeight = FontWeight.Medium)
                    }
                }
                // 选择文件夹
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(ScPurpleLight)
                    .clickable { folderLauncher.launch(null) }
                    .padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = ScPurple, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("选择文件夹", fontSize = 13.sp, color = ScPurple, fontWeight = FontWeight.Medium)
                    }
                }
            }
            if (fileNames.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("已选 ${fileNames.size} 个文件：${fileNames.joinToString(", ")}", fontSize = 11.sp, color = Color(0xFF6B7280), maxLines = 2, overflow = TextOverflow.Ellipsis)
            }

            Spacer(Modifier.height(14.dp))
            Text("标题 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp), placeholder = { Text("给这段源码起个名字", fontSize = 13.sp) })

            Spacer(Modifier.height(10.dp))
            Text("说明（可选）", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = description, onValueChange = { description = it }, modifier = Modifier.fillMaxWidth().height(72.dp), shape = RoundedCornerShape(10.dp), placeholder = { Text("补充这段源码的功能、亮点…", fontSize = 13.sp) })

            Spacer(Modifier.height(12.dp))
            // 截图上传
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("截图（最多2张）", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                Spacer(Modifier.weight(1f))
                if (screenshotUris.size < 2) TextButton(onClick = { screenshotLauncher.launch("image/*") }) { Text("添加", fontSize = 12.sp, color = ScPurple) }
            }
            if (screenshotUris.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF9FAFB))
                    .clickable { screenshotLauncher.launch("image/*") }, contentAlignment = Alignment.Center) {
                    Text("点击添加截图（可选）", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    screenshotUris.forEachIndexed { idx, uri ->
                        Box(Modifier.size(80.dp)) {
                            AsyncImage(model = uri, contentDescription = "截图$idx", modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                            Box(Modifier.align(Alignment.TopEnd).size(20.dp).clip(CircleShape).background(Color.Red.copy(alpha = 0.8f))
                                .clickable { screenshotUris = screenshotUris.toMutableList().apply { removeAt(idx) } }, contentAlignment = Alignment.Center) {
                                Text("X", fontSize = 10.sp, color = Color.White)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            // 免费 / 收费
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("获取方式", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                if (!isFree) {
                    Spacer(Modifier.width(8.dp))
                    Text("虚假宣传将导致封号", fontSize = 11.sp, color = Color(0xFFDC2626))
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (isFree) ScPurple else Color(0xFFF3F4F6))
                    .clickable { isFree = true }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    Text("免费", fontSize = 14.sp, fontWeight = if (isFree) FontWeight.Bold else FontWeight.Normal,
                        color = if (isFree) Color.White else Color(0xFF6B7280))
                }
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (!isFree) ScPurple else Color(0xFFF3F4F6))
                    .clickable { isFree = false }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    Text("收费（token）", fontSize = 14.sp, fontWeight = if (!isFree) FontWeight.Bold else FontWeight.Normal,
                        color = if (!isFree) Color.White else Color(0xFF6B7280))
                }
            }
            if (!isFree) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = priceTokensStr, onValueChange = { priceTokensStr = it.filter { c -> c.isDigit() } },
                    modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp),
                    placeholder = { Text("用户下载你的源码，将把收费的 token 发送至你的账户。", fontSize = 13.sp) },
                    trailingIcon = { Text("token", fontSize = 13.sp, color = Color(0xFF9CA3AF)) })
            }

            Spacer(Modifier.height(12.dp))
            errorMsg?.let { Text(it, fontSize = 13.sp, color = Color(0xFFDC2626)); Spacer(Modifier.height(8.dp)) }

            Spacer(Modifier.height(16.dp))
        }

        Button(
            onClick = {
                if (title.isBlank()) { errorMsg = "请填写标题"; return@Button }
                if (fileUris.isEmpty()) { errorMsg = "请选择要上传的源码文件"; return@Button }
                if (!isFree && priceTokensStr.toLongOrNull() ?: 0 <= 0) { errorMsg = "收费内容需设置有效的 token 数量"; return@Button }
                isSubmitting = true; errorMsg = null
                scope.launch {
                    try {
                        val fileBytesList = fileUris.mapNotNull { uri ->
                            withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } }
                        }
                        val ssBytes = screenshotUris.mapNotNull { uri ->
                            withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } }
                        }
                        val result = AuroraApi.submitSourceCode(
                            title = title.trim(),
                            description = description.trim(),
                            isFree = isFree,
                            priceTokens = priceTokensStr.toLongOrNull() ?: 0,
                            fileBytesList = fileBytesList,
                            screenshotBytesList = ssBytes
                        )
                        isSubmitting = false
                        if (result.success) {
                            Toast.makeText(context, "提交成功", Toast.LENGTH_SHORT).show()
                            onSubmitted()
                        } else {
                            errorMsg = result.message
                        }
                    } catch (e: Exception) {
                        isSubmitting = false
                        errorMsg = e.localizedMessage ?: "提交失败"
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 12.dp, bottom = safeBottom).height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ScPurple), enabled = !isSubmitting
        ) {
            if (isSubmitting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            else Text("提交分享", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

// ===================== 详情 =====================

@Composable
private fun SourceCodeDetail(shareId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val serverUrl = remember { AuroraApi.serverUrl }

    var detail by remember { mutableStateOf<JSONObject?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var buying by remember { mutableStateOf(false) }

    fun incDownload() {
        scope.launch { try { AuroraApi.incSourceCodeDownload(shareId) } catch (_: Exception) {} }
    }

    fun load() {
        isLoading = true; errorMsg = null
        scope.launch {
            var lastErr: String? = null
            repeat(3) { attempt ->
                try {
                    val r = AuroraApi.getSourceCodeDetail(shareId)
                    if (r.success && r.data != null) {
                        detail = r.data
                        lastErr = null
                        isLoading = false
                        return@launch
                    } else {
                        lastErr = r.message
                    }
                } catch (e: Exception) {
                    lastErr = e.localizedMessage ?: "加载失败"
                }
                if (attempt < 2) delay(800)
            }
            errorMsg = lastErr ?: "加载失败"
            isLoading = false
        }
    }
    LaunchedEffect(shareId) { load() }

    var commentCount by remember { mutableStateOf(0L) }
    var showComments by remember { mutableStateOf(false) }

    // 下载到本地
    val downloadLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            val filePath = detail?.optString("file_path", "") ?: ""
            scope.launch(Dispatchers.IO) {
                try {
                    // 从服务器下载 zip 文件
                    val downloadUrl = "$serverUrl/api/source_code/file/$shareId/$filePath"
                    val req = okhttp3.Request.Builder().url(downloadUrl).build()
                    com.aurora.chat.data.api.HttpClient.client.newCall(req).execute().use { resp ->
                        val inputStream = resp.body?.byteStream() ?: throw java.io.IOException("空响应")
                        context.contentResolver.openOutputStream(uri)?.use { os ->
                            inputStream.copyTo(os)
                        }
                    }
                    withContext(Dispatchers.Main) {
                        incDownload()
                        Toast.makeText(context, "已保存到所选位置", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "保存失败：${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = Color(0xFF1F2937),
                    modifier = Modifier.size(24.dp).clickable { onBack() })
                Spacer(Modifier.width(8.dp))
                Text("源码详情", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.width(8.dp))
                Text("如被骗请进入QQ官方群:123456789维权", fontSize = 11.sp, color = Color(0xFFDC2626))
            }

            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(28.dp), color = ScPurple, strokeWidth = 3.dp)
                }
            } else if (errorMsg != null || detail == null) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(errorMsg ?: "加载失败", color = Color(0xFFDC2626), fontSize = 14.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(16.dp))
                        Box(
                            Modifier.clip(RoundedCornerShape(10.dp)).background(ScPurple)
                                .clickable { load() }.padding(horizontal = 28.dp, vertical = 10.dp)
                        ) {
                            Text("重试", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            } else {
                val d = detail!!
                commentCount = d.optLong("comment_count", 0)
                val userId = d.optLong("user_id", 0)
                val title = d.optString("title", "")
                val username = d.optString("username", "匿名")
                val desc = d.optString("description", "")
                val isFree = d.optInt("is_free", 1) == 1
                val price = d.optLong("price_tokens", 0)
                val purchased = d.optBoolean("purchased", false)
                val viewCount = d.optLong("view_count", 0)
                val downloadCount = d.optLong("download_count", 0)
                val fileSize = d.optLong("file_size", 0)
                val sizeText = formatFileSize(fileSize)
                val screenshots = try {
                    val arr = d.optJSONArray("screenshots")
                    (0 until (arr?.length() ?: 0)).mapNotNull { arr?.optString(it) }.filter { it.isNotEmpty() }
                } catch (_: Exception) { emptyList() }

                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().imePadding().padding(horizontal = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(36.dp).clip(CircleShape).background(ScPurple), contentAlignment = Alignment.Center) {
                            Text(username.firstOrNull()?.toString() ?: "?", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            AsyncImage(model = "$serverUrl/api/avatar/$userId", contentDescription = null,
                                modifier = Modifier.fillMaxSize().clip(CircleShape),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(username, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                            Text(if (isFree) "免费分享" else "收费 · ${price} token", fontSize = 12.sp, color = if (isFree) Color(0xFF059669) else Color(0xFFD97706))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                    if (desc.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(desc, fontSize = 13.sp, color = Color(0xFF6B7280), lineHeight = 18.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFF3F4F6)).padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatItem(Modifier.weight(1f), "文件大小", sizeText)
                        Box(Modifier.width(1.dp).height(28.dp).background(Color(0xFFE5E7EB)))
                        StatItem(Modifier.weight(1f), "浏览量", "$viewCount")
                        Box(Modifier.width(1.dp).height(28.dp).background(Color(0xFFE5E7EB)))
                        StatItem(Modifier.weight(1f), "下载量", "$downloadCount")
                        Box(Modifier.width(1.dp).height(28.dp).background(Color(0xFFE5E7EB)))
                        StatItem(Modifier.weight(1f), "评论", "$commentCount", onClick = { showComments = true })
                    }
                    if (screenshots.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            screenshots.forEach { file ->
                                AsyncImage(model = "$serverUrl/api/source_code/screenshot/$shareId/$file", contentDescription = null,
                                    modifier = Modifier.size(120.dp, 200.dp).clip(RoundedCornerShape(10.dp)),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFF0F0F0)))
                    Spacer(Modifier.height(12.dp))

                    if (!isFree && !purchased) {
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFFF8FAFC))
                            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp)).padding(16.dp)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.Lock, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(28.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("付费内容", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                                Text("购买后可下载源码", fontSize = 12.sp, color = Color(0xFF6B7280))
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        buying = true
                                        scope.launch {
                                            try {
                                                val r = AuroraApi.buySourceCode(shareId)
                                                buying = false
                                                if (r.success) {
                                                    Toast.makeText(context, "购买成功", Toast.LENGTH_SHORT).show()
                                                    load()
                                                } else {
                                                    Toast.makeText(context, r.message, Toast.LENGTH_LONG).show()
                                                }
                                            } catch (e: Exception) {
                                                buying = false
                                                Toast.makeText(context, e.localizedMessage ?: "购买失败", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(42.dp), shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)), enabled = !buying
                                ) {
                                    if (buying) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                    else Text("购买 · ${price} token", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                    if (isFree || purchased) {
                        Button(
                            onClick = {
                                incDownload()
                                val filePath = d.optString("file_path", "")
                                if (filePath.isBlank()) {
                                    Toast.makeText(context, "文件不存在", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                downloadLauncher.launch("source_code_$shareId.zip")
                            },
                            modifier = Modifier.fillMaxWidth().height(46.dp), shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ScPurple)
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("下载源码", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }

        AnimatedVisibility(
            visible = showComments,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(200))
        ) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).clickable { showComments = false })
        }
        AnimatedVisibility(
            visible = showComments,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300))
        ) {
            SourceCodeCommentDrawer(
                shareId = shareId,
                onCommentAdded = { commentCount++ },
                onDismiss = { showComments = false }
            )
        }
    }
}

@Composable
private fun StatItem(modifier: Modifier, label: String, value: String, onClick: (() -> Unit)? = null) {
    Column(
        modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 11.sp, color = Color(0xFF9CA3AF))
    }
}

private fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "—"
    return when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format("%.1f KB", bytes / 1024f)
        bytes < 1024 * 1024 * 1024 -> String.format("%.2f MB", bytes / (1024f * 1024f))
        else -> String.format("%.2f GB", bytes / (1024f * 1024f * 1024f))
    }
}

// ===================== 评论抽屉 =====================

@Composable
private fun SourceCodeCommentDrawer(
    shareId: Long,
    onCommentAdded: () -> Unit,
    onDismiss: () -> Unit,
    onUserClick: (Long) -> Unit = {}
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var allComments by remember { mutableStateOf<List<CommentInfo>>(emptyList()) }
    var total by remember { mutableStateOf(0) }
    var isLoading by remember { mutableStateOf(true) }
    var replyingTo by remember { mutableStateOf("") }
    var replyingToId by remember { mutableStateOf(0L) }
    var expandedReplies by remember { mutableStateOf(setOf<Long>()) }
    var showCommentDialog by remember { mutableStateOf(false) }
    var dialogInputText by remember { mutableStateOf("") }
    var mutedUntil by remember { mutableStateOf(0L) }
    val muteRemainingText = remember(mutedUntil) {
        if (mutedUntil <= 0L) ""
        else {
            val remainSec = (mutedUntil - System.currentTimeMillis() / 1000).coerceAtLeast(0)
            if (remainSec <= 0) ""
            else {
                val days = remainSec / 86400; val hours = (remainSec % 86400) / 3600
                val mins = (remainSec % 3600) / 60
                when { days > 0 -> "${days}天${hours}小时"; hours > 0 -> "${hours}小时${mins}分钟"
                    mins > 0 -> "${mins}分钟"; else -> "${remainSec}秒" }
            }
        }
    }
    val isMuted = mutedUntil > 0L && muteRemainingText.isNotEmpty()
    LaunchedEffect(Unit) {
        try {
            val r = AuroraApi.adminCheckMuteStatus(AuroraApi.currentUserId)
            if (r.success && r.data != null && r.data.has("expires_at")) {
                mutedUntil = r.data.optLong("expires_at", 0L)
            }
        } catch (_: Exception) { }
    }

    val commentById = allComments.associateBy { it.id }
    fun rootIdOfId(id: Long): Long {
        var curId = id
        var guard = 0
        while (guard < 50) {
            val c = commentById[curId] ?: break
            if (c.parent_id <= 0L) break
            curId = c.parent_id
            guard++
        }
        return curId
    }
    val topLevelComments = allComments.filter { it.parent_id == 0L }
    val repliesByRoot = allComments.filter { it.parent_id > 0L }.groupBy { rootIdOfId(it.id) }
    val parentUsernameMap = allComments.associate { it.id to it.username }
    val parentUserIdMap = allComments.associate { it.id to it.user_id }

    LaunchedEffect(shareId) {
        val result = AuroraApi.getSourceCodeComments(shareId)
        if (result.success && result.data != null) {
            allComments = result.data!!.comments
            total = result.data!!.total
        }
        isLoading = false
    }

    val listState = rememberLazyListState()
    var dragFraction by remember { mutableFloatStateOf(0.55f) }
    var isDragging by remember { mutableStateOf(false) }

    Box(
        Modifier.fillMaxSize(),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(dragFraction)
                .background(Color.White, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .clickable(enabled = false) {}
                .systemBarsPadding()
        ) {
            // 顶部：拖拽条单独一行（不跟文字并排）
        Box(
            modifier = Modifier
                .fillMaxWidth().padding(top = 6.dp)
                .height(20.dp)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { isDragging = true },
                        onDragEnd = { isDragging = false },
                        onDragCancel = { isDragging = false }
                    ) { _, dragAmount ->
                        dragFraction = (dragFraction - dragAmount / 3000f).coerceIn(0.2f, 0.9f)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .width(40.dp).height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFFD1D5DB).copy(alpha = 0.5f))
            )
        }
        // 第二行：标题 + 评论按钮 + 关闭
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("评论 ($total)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("评论", fontSize = 14.sp, color = ScPurple, fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable {
                            dialogInputText = ""
                            showCommentDialog = true
                        }.padding(end = 16.dp))
                    Text("关闭", fontSize = 14.sp, color = ScPurple, modifier = Modifier.clickable { onDismiss() })
                }
            }
            Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))

            if (isLoading) {
                Box(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                    Text("加载中...", fontSize = 14.sp, color = Color(0xFF9CA3AF), modifier = Modifier.padding(top = 20.dp))
                }
            } else if (topLevelComments.isEmpty()) {
                Box(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                    Text("暂无评论，快来抢沙发吧", fontSize = 14.sp, color = Color(0xFF9CA3AF), modifier = Modifier.padding(top = 20.dp))
                }
            } else {
                LazyColumn(modifier = Modifier.weight(1f).padding(horizontal = 16.dp), state = listState) {
                    items(topLevelComments, key = { it.id }) { comment ->
                        val replyList = repliesByRoot[comment.id] ?: emptyList()
                        CommentRow(
                            comment = comment,
                            isExpanded = comment.id in expandedReplies,
                            replyCount = replyList.size,
                            replies = replyList,
                            parentUsernameMap = parentUsernameMap,
                            parentUserIdMap = parentUserIdMap,
                            onUserClick = onUserClick,
                            onReplyClick = { id ->
                                replyingTo = parentUsernameMap[id] ?: ""
                                replyingToId = id
                            },
                            onToggleExpand = {
                                expandedReplies = if (comment.id in expandedReplies) expandedReplies - comment.id else expandedReplies + comment.id
                            }
                        )
                    }
                }
            }

            Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))

            if (isMuted) {
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFFEF3C7))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(text = "你已被禁言，$muteRemainingText", fontSize = 13.sp, color = Color(0xFF92400E), fontWeight = FontWeight.Medium)
                }
            }

            }
    }

    // ── 评论输入对话框 ──
    if (showCommentDialog) {
        AlertDialog(
            onDismissRequest = { showCommentDialog = false },
            title = {
                Text(
                    if (replyingTo.isNotEmpty()) "回复 $replyingTo" else "发表评论",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    if (isMuted) {
                        Text("你已被禁言，$muteRemainingText", fontSize = 13.sp, color = Color(0xFF92400E))
                        Spacer(Modifier.height(8.dp))
                    }
                    OutlinedTextField(
                        value = dialogInputText,
                        onValueChange = { if (!isMuted) dialogInputText = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text(if (isMuted) "禁言中" else "输入评论内容...", fontSize = 14.sp) },
                        singleLine = false,
                        minLines = 3,
                        maxLines = 6,
                        enabled = !isMuted,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val text = dialogInputText.trim()
                        if (text.isBlank() || isMuted) return@TextButton
                        scope.launch {
                            val parentId = replyingToId
                            val result = AuroraApi.addSourceCodeComment(shareId, text, parentId)
                            if (result.success) {
                                dialogInputText = ""
                                replyingTo = ""
                                val refreshed = AuroraApi.getSourceCodeComments(shareId)
                                if (refreshed.success && refreshed.data != null) {
                                    allComments = refreshed.data!!.comments
                                    total = refreshed.data!!.total
                                }
                                replyingToId = 0L
                                onCommentAdded()
                                if (parentId > 0L) expandedReplies = expandedReplies + rootIdOfId(parentId)
                                showCommentDialog = false
                            } else {
                                Toast.makeText(ctx, result.message, Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    enabled = dialogInputText.isNotBlank() && !isMuted
                ) {
                    Text("发送", color = ScPurple, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCommentDialog = false }) {
                    Text("取消", color = Color(0xFF6B7280))
                }
            }
        )
    }
}