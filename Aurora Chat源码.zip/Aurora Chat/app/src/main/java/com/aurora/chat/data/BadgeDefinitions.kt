package com.aurora.chat.data

/**
 * 硬编码徽章定义（所有可用徽章预定义在此，开发者选择赠送）
 */
data class HardcodedBadge(
    val id: Long,
    val name: String,
    val color: Long, // ARGB 颜色值
    val displaySize: String = "medium"
)

object BadgeDefinitions {
    val allBadges = listOf(
        HardcodedBadge(101, "至尊", 0xFFFFD700),
        HardcodedBadge(102, "达人", 0xFF1E40AF),
        HardcodedBadge(103, "元老", 0xFFDC2626),
        HardcodedBadge(104, "贡献者", 0xFF10B981),
        HardcodedBadge(105, "管理", 0xFF8B5CF6),
        HardcodedBadge(106, "新秀", 0xFFF59E0B),
        HardcodedBadge(107, "铁粉", 0xFFEC4899),
        HardcodedBadge(108, "大佬", 0xFF6366F1),
        HardcodedBadge(109, "活跃", 0xFF14B8A6),
        HardcodedBadge(110, "专属", 0xFFF97316)
    )

    /** 根据 ID 获取徽章定义 */
    fun getById(id: Long): HardcodedBadge? = allBadges.find { it.id == id }

    /** 根据 ID 获取颜色 */
    fun getColor(id: Long): Long = getById(id)?.color ?: 0xFF6B7280

    /** 根据 ID 获取名称 */
    fun getName(id: Long): String = getById(id)?.name ?: "未知"

    /** 根据 ID 获取显示尺寸 */
    fun getDisplaySize(id: Long): String = getById(id)?.displaySize ?: "medium"
}
