package com.aurora.chat.data.local

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * 服务器离线缓存：将服务器数据备份到本地文件
 * 无网络时自动使用缓存，联网后自动同步
 */
object ServerCache {

    private fun cacheDir(ctx: Context): File {
        val dir = File(ctx.filesDir, "server_cache")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun serverDir(ctx: Context, serverId: Long): File {
        val dir = File(cacheDir(ctx), serverId.toString())
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    // ── 网络检测 ──
    fun isOnline(ctx: Context): Boolean {
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val nw = cm.activeNetwork ?: return false
            val cap = cm.getNetworkCapabilities(nw) ?: return false
            return cap.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) { return false }
    }

    // ── 服务器信息缓存 ──
    fun saveMyServer(ctx: Context, serverId: Long, jsonData: String) {
        try { File(serverDir(ctx, serverId), "server_info.json").writeText(jsonData) } catch (_: Exception) {}
    }

    fun loadMyServer(ctx: Context, serverId: Long): String? {
        val f = File(serverDir(ctx, serverId), "server_info.json")
        return if (f.exists()) f.readText() else null
    }

    fun saveLoggedInServers(ctx: Context, jsonData: String) {
        try { File(cacheDir(ctx), "logged_in_servers.json").writeText(jsonData) } catch (_: Exception) {}
    }

    fun loadLoggedInServers(ctx: Context): String? {
        val f = File(cacheDir(ctx), "logged_in_servers.json")
        return if (f.exists()) f.readText() else null
    }

    // ── 文件列表缓存 ──
    fun saveFileList(ctx: Context, serverId: Long, folderId: Long, jsonData: String) {
        try { File(serverDir(ctx, serverId), "files_${folderId}.json").writeText(jsonData) } catch (_: Exception) {}
    }

    fun loadFileList(ctx: Context, serverId: Long, folderId: Long): String? {
        val f = File(serverDir(ctx, serverId), "files_${folderId}.json")
        return if (f.exists()) f.readText() else null
    }

    // ── 清理 ──
    fun clearAll(ctx: Context) {
        try { cacheDir(ctx).deleteRecursively() } catch (_: Exception) {}
    }

    fun clearServer(ctx: Context, serverId: Long) {
        try { serverDir(ctx, serverId).deleteRecursively() } catch (_: Exception) {}
    }
}
