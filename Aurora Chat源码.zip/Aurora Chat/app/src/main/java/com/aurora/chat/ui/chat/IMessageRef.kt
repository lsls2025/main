package com.aurora.chat.ui.chat

/**
 * 消息引用通用接口 — ChatMsg 和 StoreMessageRef 都实现此接口，
 * 允许 MessageBubbleItem 使用统一类型。
 */
interface IMessageRef {
    val id: Long
    val text: String
    val isMine: Boolean
    val fromUserId: Long
    val senderName: String
    val wornBadge: Int
    val time: Long
    val isNew: Boolean
    val createdAt: Long
    val isRevoked: Int      // 0=正常, 1=已撤回
    val isSystemNotice: Boolean
    val replyToText: String
    val replyToSender: String
    val replyToId: Long
    val mediaType: String
    val mediaUrl: String
    val isUploading: Boolean
    val toUserId: Long
    val targetName: String
    val flashDuration: Int
    val reasoningText: String get() = ""
}
