﻿package com.aurora.chat.ui.chat

import com.aurora.chat.ui.server.AiChatShareBridge

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import com.aurora.chat.ui.chat.media.ChatMedia
import com.aurora.chat.ui.chat.media.MediaStore
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.platform.LocalView
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush


import androidx.compose.foundation.Canvas
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.chat.R
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.ui.components.MemberGateDialog
import com.aurora.chat.data.api.MessageInfo
import com.aurora.chat.data.store.MessageData
import com.aurora.chat.data.store.MessageStoreAdapter
import com.aurora.chat.data.store.StoreMessageRef
import com.aurora.chat.data.local.LocalStorage
import com.aurora.chat.data.repository.ChatRepository
import com.aurora.chat.ui.components.AnimationMode
import com.aurora.chat.ui.components.GroupAvatar
import com.aurora.chat.ui.profile.CropPreviewDialog
import com.aurora.chat.ui.profile.OnlineTimeTracker
import com.aurora.chat.ui.components.UserAvatar
import com.aurora.chat.ui.components.BadgeInfoDialog
import coil.imageLoader
import coil.request.CachePolicy
import coil.request.ImageRequest
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.util.Log
import android.view.TextureView
import android.widget.TextView
import org.json.JSONObject
import androidx.compose.ui.viewinterop.AndroidView
import com.aurora.chat.ui.text.UrlText
import com.aurora.chat.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.zIndex
import com.aurora.chat.ui.chat.ChatMsg
import com.aurora.chat.ui.chat.HotCacheEntry
import com.aurora.chat.ui.chat.messageHotCache
import com.aurora.chat.ui.chat.HOT_CACHE_TTL_MS











/** 跨组合期持久化聊天数据（LRU 淘汰，最多保留 5 个对话 ≈ 750KB） */
private val companionMessageCache = object : LinkedHashMap<Long, List<IMessageRef>>(16, 0.75f, true) {
    override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, List<IMessageRef>>?): Boolean {
        return size > 5
    }
}

/** 导入时占位符→人物名称 的映射项（占位符不可编辑，目标名可改，checked 控制是否应用） */
data class ImportMapItem(val placeholder: String, var target: String, var checked: Boolean)

/**
 * 构造与「导出对话」「导入对话」完全一致的官方 JSON（供 AI 对话分享的「直接获取当前对话」/「覆盖到当前对话」使用）。
 * 这样上传内容与从设备导出的文件是同一格式，覆盖时直接走导入的 JSON 解析逻辑，无需另行排版。
 */
private fun buildShareJson(
    messages: List<IMessageRef>,
    currentUserId: Long,
    friendId: Long,
    currentUserName: String,
    friendName: String
): String {
    val root = org.json.JSONObject()
    root.put("app", "AuroraChat")
    root.put("type", "conversation")
    root.put("version", 1)
    root.put("exported_at", System.currentTimeMillis())
    root.put("friend_id", friendId)
    val meta = org.json.JSONObject()
    meta.put("user_name", currentUserName)
    meta.put("ai_name", friendName)
    root.put("meta", meta)
    val arr = org.json.JSONArray()
    for (m in messages) {
        val o = org.json.JSONObject()
        o.put("text", m.text)
        o.put("is_mine", m.isMine)
        o.put("from_user_id", m.fromUserId)
        o.put("sender_name", m.senderName)
        o.put("created_at", m.createdAt)
        o.put("media_type", m.mediaType)
        o.put("media_url", m.mediaUrl)
        o.put("reply_to_text", m.replyToText)
        o.put("reply_to_sender", m.replyToSender)
        o.put("reply_to_id", m.replyToId)
        o.put("revoked", m.isRevoked)
        o.put("worn_badge", m.wornBadge)
        o.put("flash_duration", m.flashDuration)
        o.put("reasoning_text", m.reasoningText)
        arr.put(o)
    }
    root.put("messages", arr)
    return root.toString()
}

// 好友（服务端）对话导入的本地兜底：服务端不会保存导入的历史，重载后会丢失，
// 故把导入消息单独存一份，加载好友对话时合并进来（不往服务端发送、不骚扰对方）。
private fun importedMessagesFile(ctx: android.content.Context, currentUserId: Long, friendId: Long): java.io.File =
    java.io.File(ctx.cacheDir, "imported_${friendId}_${currentUserId}.json")

private fun saveImportedMessages(ctx: android.content.Context, currentUserId: Long, friendId: Long, msgs: List<ChatMsg>) {
    try {
        val arr = org.json.JSONArray()
        for (m in msgs) {
            val obj = org.json.JSONObject()
            obj.put("id", m.id)
            obj.put("text", m.text)
            obj.put("is_mine", m.isMine)
            obj.put("from_user_id", m.fromUserId)
            obj.put("sender_name", m.senderName)
            obj.put("created_at", m.createdAt)
            obj.put("media_type", m.mediaType)
            obj.put("media_url", m.mediaUrl)
            obj.put("revoked", m.isRevoked)
            arr.put(obj)
        }
        importedMessagesFile(ctx, currentUserId, friendId).writeText(arr.toString())
    } catch (_: Exception) {}
}

private fun loadImportedMessages(ctx: android.content.Context, currentUserId: Long, friendId: Long): List<MessageData> {
    val f = importedMessagesFile(ctx, currentUserId, friendId)
    if (!f.exists()) return emptyList()
    return try {
        val arr = org.json.JSONArray(f.readText())
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            MessageData(
                id = o.getLong("id"),
                fromUserId = o.optLong("from_user_id", 0),
                toUserId = currentUserId,
                content = o.optString("text", ""),
                createdAt = o.optLong("created_at", 0),
                isMine = o.optBoolean("is_mine", false),
                senderName = o.optString("sender_name", ""),
                isRevoked = o.optInt("revoked", 0) != 0,
                isSystemNotice = o.optInt("revoked", 0) == 1,
                mediaType = o.optString("media_type", ""),
                mediaUrl = o.optString("media_url", "")
            )
        }
    } catch (_: Exception) { emptyList() }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatConversationScreen(
    currentUserId: Long = 0,
    currentUserName: String = "",
    friendId: Long = 0,
    friendName: String = "",
    onBack: () -> Unit,
    onOpenJoinRequestFullScreen: (org.json.JSONArray, Long) -> Unit = { _, _ -> },
    onOpenPostDetail: (Long) -> Unit = {},
    onOpenAiChatDetail: (Long) -> Unit = {},
    onOpenGroupDetail: (Long) -> Unit = {},
    onOpenSourceCodeDetail: (Long) -> Unit = {},
    onOpenNewChat: (Long, String) -> Unit = { _, _ -> },
    onOpenAiSandbox: () -> Unit = {},
    onMemberSubscribe: () -> Unit = {},
    onRechargeToken: () -> Unit = {},
    onGoCheckIn: () -> Unit = {},
    onTokenExhausted: () -> Unit = {}
) {
    var inputText by rememberSaveable { mutableStateOf("") }
    val ctx = LocalContext.current
    // 「人物对换 / 历史反转」：AI 视角反转（头像/对话左右互换，并让 AI 以我方身份续聊）。
    // 声明在顶层，确保对话列表、AI 发送、AI 设置等各嵌套块都能捕获到。
    var reverseHistory by remember(currentUserId) { mutableStateOf(LocalStorage.getReverseHistory(ctx, currentUserId)) }
    val draftKey = "draft_${currentUserId}_${friendId}"
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    // 官方 API 实时用量：与「使用」面板共享，流式回复过程中实时刷新，避免只能等对话结束后才更新。
    // 值为 Pair(今日已用, 剩余)；剩余即余额，扣到 0 才截止。
    val aiUsageState = remember(currentUserId) {
        mutableStateOf(AiChatManager.getOfficialUsage(ctx, currentUserId))
    }
    // 是否停留在列表底部：流式输出时仅在用户已在底部时才自动跟随，用户上滑看历史时绝不抢夺滚动
    val atBottomState = remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()
            last == null || last.index >= info.totalItemsCount - 1
        }
    }
    // 用户是否主动离开过底部（意图锁存）：流式输出只在“用户仍在底部”时自动跟随。
    // 用户主动上滑后即停止跟随，即使 AI 内容增长把位置顶回末尾也不抢滚动；
    // 仅当用户再次主动滚动贴回到底部时才恢复自动跟随。
    var userScrolledAway by remember { mutableStateOf(false) }
    LaunchedEffect(listState) {
        snapshotFlow {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index
            last to info.totalItemsCount
        }.collect { (lastIdx, total) ->
            if (listState.isScrollInProgress && lastIdx != null) {
                if (lastIdx >= total - 1) userScrolledAway = false
                else if (total > 0) userScrolledAway = true
            }
        }
    }
    var badgeDialogId by remember { mutableStateOf(0) }
    // 官方 API 被管理员暂停时的明确提示对话框：拦截时弹窗告知，避免用户误以为发送 bug
    var apiSuspendedDialog by remember { mutableStateOf(false) }
    var profileWornBadge by remember { mutableIntStateOf(0) }
    var wornBadge by remember { mutableIntStateOf(0) }
    var groupMemberNames by remember { mutableStateOf<Set<String>>(emptySet()) }
    var groupMemberIdMap by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var isLoadingMessages by remember { mutableStateOf(true) }
    var scrollReady by remember { mutableStateOf(false) }
    // 逐消息上传进度：messageId -> progress (0.0~1.0)
    val uploadProgressMap = remember { mutableStateMapOf<Long, Float>() }
    val replyToMsg = remember { mutableStateOf<IMessageRef?>(null) } // 引用功能：当前正在回复的消息

    // Plus按钮弹窗状态
    var showPlusDialog by remember { mutableStateOf(false) }
    // 转账弹窗状态
    var showTransferDialog by remember { mutableStateOf(false) }
    // 红包：发送弹窗 / 详情全屏 / 实时状态
    var showRedPacketDialog by remember { mutableStateOf(false) }
    var redPacketDetailId by remember { mutableStateOf(0L) }
    val redpacketStatus = remember { mutableStateMapOf<Long, RedPacketStatus>() }
    // 相机拍摄状态
    var showCamera by remember { mutableStateOf(false) }
    // 位置请求触发状态
    var showLocationRequest by remember { mutableStateOf(false) }
    // 隐私控制面板
    var showPrivacyPanel by remember { mutableStateOf(false) }
    // 禁言状态：禁言截止时间戳（0=未禁言）
    var mutedUntil by remember { mutableStateOf(0L) }
    var showLocationConfirm by remember { mutableStateOf(false) }

    // ── AI 对话专属：时间点 / 确认发言 ──（提升到顶层，让 InputBar 等兄弟块可见）
    var showTimePointDialog by remember { mutableStateOf(false) }
    var showConfirmSpeechDialog by remember { mutableStateOf(false) }
    var confirmSpeechEnabled by remember(currentUserId) { mutableStateOf(AiChatManager.getConfirmSpeech(ctx, currentUserId)) }
    var currentTimePoint by remember(currentUserId) { mutableStateOf(AiChatManager.getTimePoint(ctx, currentUserId)) }
    // 是否有待确认的消息（用户发送后 AI 未回复的消息）
    var confirmSpeechPending by remember { mutableStateOf(false) }
    // 当前展开思考过程的消息 ID（仅最新 AI 消息展开，其余收起）
    var expandedReasoningMsgId by remember { mutableStateOf(0L) }
    // ── 隐私控制：加载对方设置并应用 FLAG_SECURE（禁止截图 / 禁止录屏） ──
    var privacyRefreshKey by remember { mutableStateOf(0) }
    // 记录是否是由隐私设置触发的 Activity 重建（避免无限循环）
    val wasRecreatedForPrivacy = remember { mutableStateOf(false) }
    LaunchedEffect(friendId, privacyRefreshKey) {
        if (friendId <= 0) return@LaunchedEffect
        try {
            val fr = AuroraApi.getFriendPrivacySettings(friendId)
            if (fr.success && fr.data != null) {
                val s = fr.data!!
                val noScreenshot = s.optBoolean("no_screenshot", false)
                val noRecording = s.optBoolean("no_recording", false)
                val needFlagSecure = noScreenshot || noRecording
                val act = ctx as? android.app.Activity
                val hasFlagSecure = (act?.window?.attributes?.flags
                    ?.and(android.view.WindowManager.LayoutParams.FLAG_SECURE) ?: 0) != 0
                if (needFlagSecure && !hasFlagSecure) {
                    // 对方开启了禁止截图/录屏 → 设置 FLAG_SECURE
                    act?.runOnUiThread {
                        act.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
                    }
                } else if (!needFlagSecure && hasFlagSecure && !wasRecreatedForPrivacy.value) {
                    // 对方没开启，但 FLAG_SECURE 还挂着（来自上个对话）→ 重建 Activity 清掉
                    wasRecreatedForPrivacy.value = true
                    act?.runOnUiThread {
                        act.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
                        // 真正清除 FLAG_SECURE 需要重建 Activity
                        act.recreate()
                    }
                } else if (needFlagSecure && hasFlagSecure) {
                    wasRecreatedForPrivacy.value = false
                }
            }
        } catch (_: Exception) {}
    }

    // 消息列表 — 支持 StoreMessageRef (adapter) 和 ChatMsg (旧加载路径) 共存
    val adapter = remember(friendId) { MessageStoreAdapter() }
    //  从 companion cache 恢复已销毁组件的数据（切对话零加载）
    //   remember(friendId) 确保切换对话时重建列表，同时恢复该对话的缓存
    val messages = remember(friendId) {
        val saved = companionMessageCache.remove(friendId)
        if (saved != null) mutableStateListOf<IMessageRef>().also { it.addAll(saved) }
        else mutableStateListOf<IMessageRef>()
    }
    /** 安全替换全部消息（去重：后出现的覆盖先出现的，避免 LazyColumn 因重复 key 闪退） */
    fun MutableList<IMessageRef>.replaceAllUnique(elements: List<IMessageRef>) {
        clear()
        val seen = mutableSetOf<Long>()
        elements.forEach { if (seen.add(it.id)) add(it) }
    }

    /** 安全追加单个消息（若 ID 已存在则跳过） */
    fun MutableList<IMessageRef>.addUnique(element: IMessageRef): Boolean {
        if (any { it.id == element.id }) return false
        return add(element)
    }

    /** 安全批量插入到指定位置（跳过已存在的 ID） */
    fun MutableList<IMessageRef>.addAllUnique(index: Int = -1, elements: List<IMessageRef>) {
        val existingIds = mapTo(mutableSetOf()) { it.id }
        val toAdd = elements.filter { existingIds.add(it.id) }
        if (toAdd.isNotEmpty()) {
            if (index < 0) addAll(toAdd) else addAll(index, toAdd)
        }
    }

    /** 将 adapter 的 indices 同步到 SnapshotStateList。 */
    fun syncMessages() {
        val snapshot = adapter.indices.toList() // 快照防止 ConcurrentModificationException
        val refs = snapshot.map { adapter.refAt(it) }
        messages.replaceAllUnique(refs)
    }

    // ==================== 消息修改（长按 → 修改：编辑思考部分与实际输出，保存后写回本地） ====================
    // 声明在 onConfirmReply 之前，以便确认发言 / 直接发送两个入口都能读取 editTargetMsgId（补回被编辑消息到上下文）
    var showEditDialog by remember { mutableStateOf(false) }
    var editTargetMsgId by remember { mutableStateOf(0L) }
    var editReasoningText by remember { mutableStateOf("") }
    var editOutputText by remember { mutableStateOf("") }
    // 订单详情：点击通知卡片「查看订单」后弹出
    var viewOrderId by remember { mutableStateOf<Long?>(null) }

    // 确认发言：用户点击"确认发言"按钮后触发 AI 回复（定义在 messages 之后，避免前向引用）
    val onConfirmReply: () -> Unit = {
        // 先记录是否有一条"待确认"的用户消息（来自上一次发送），再清除待确认标记
        val hadPending = confirmSpeechPending
        confirmSpeechPending = false
        scope.launch {
            //  隔离判断：确认发言必须锚定在"用户反馈"上。
            //   - 输入框有文字 → 作为一条用户消息追加进上下文（用户确实做了反馈）
            //   - 没有输入但有"待确认"用户消息（hadPending）→ 正常基于那条消息回复
            //   - 没有任何新反馈（hadPending=false 且输入框为空）→ 不静默、也不自言自语，
            //     而是标记 syntheticNoFeedback：交给 AI 自己决定——它"知道"用户这次什么都没说，
            //     可以去质问用户、或说点别的，而不是拿自己上一条回复续写。
            var syntheticNoFeedback = false
            // 提前声明："用户无反馈"时的合成用户回合文本及其角色（用于 system 提示与 history 末尾）。
            // 必须在用到它的地方（官方模式 estInput、history 构造）之前声明，避免 Kotlin 局部变量前向引用失败。
            val noFeedbackUserText = "（用户这次没有输入任何内容，也没有做出任何反应，只是又点了一次确认发言。）"
            val pendingUserText = inputText.trim()
            if (pendingUserText.isNotBlank()) {
                // 输入框有文字→作为一条用户消息追加进上下文（用户确实做了反馈）
                messages.add(ChatMsg.create(text = pendingUserText, isMine = true, fromUserId = currentUserId, isNew = true))
                inputText = ""
                ctx.getSharedPreferences("aurora_drafts", Context.MODE_PRIVATE)
                    .edit().remove(draftKey).apply()
            } else if (!hadPending) {
                syntheticNoFeedback = true
            }
            // 收回旧的思考过程：清理未完成的"思考中"占位气泡，
            // 并收起已展开的思考内容，避免上一轮的思考过程残留干扰
            val pendingThinking = messages.filter { it.text == AI_THINKING }
            if (pendingThinking.isNotEmpty()) messages.removeAll(pendingThinking)
            expandedReasoningMsgId = 0L
            val aiContextCap = 40
            val chatCandidates = messages.filter { !it.isSystemNotice && it.text.isNotBlank() && it.text != AI_THINKING }
            val chatContext = if (chatCandidates.size > aiContextCap) {
                // 被编辑过的那条消息（含其最新文本）必须始终进入上下文，
                // 否则一旦该消息落在截断窗口之外，编辑就对 AI 无效（AI 仍按原历史作答）
                val truncated = chatCandidates.take(1) + chatCandidates.takeLast(aiContextCap - 1)
                val edited = editTargetMsgId.takeIf { it != 0L }?.let { tid -> chatCandidates.firstOrNull { it.id == tid } }
                if (edited != null && truncated.none { it.id == edited.id }) listOf(edited) + truncated else truncated
            } else chatCandidates
            val mode = AiChatManager.getMode(ctx, currentUserId)
            var estInput = 0L
            val baseUsed: Long
            var poolAtStart = 0L
            if (mode == "official") {
                // 发送前强制拉取服务器最新余额，避免因本地缓存过期导致「余额=0 时还能发一次」
                AiChatManager.syncServerLimit(ctx, currentUserId)
                val (used, remaining) = AiChatManager.getOfficialUsage(ctx, currentUserId)
                aiUsageState.value = Pair(used, remaining)
                baseUsed = used
                poolAtStart = remaining
                estInput = chatContext.sumOf { AiChatManager.estimateTokens(it.text).toLong() }
                    .let { if (syntheticNoFeedback) it + AiChatManager.estimateTokens(noFeedbackUserText).toLong() else it }
                // 余额判定以「服务器真实 token_balance」为准（不受开发者无限额度影响）：
                // 余额=0 时弹卡片；开发者仍放行（无限额度），普通用户则拦截发送。
                val rawBal = AiChatManager.getServerTokenBalance(ctx, currentUserId)
                if (rawBal <= 0L) {
                    onTokenExhausted()
                    if (!AiChatManager.isDeveloper(ctx, currentUserId)) return@launch
                }
            } else {
                baseUsed = aiUsageState.value.first
            }
            val systemText = buildString {
                if (AiChatManager.getUltraSave(ctx, currentUserId)) {
                    append(AiChatManager.ULTRA_SAVE_CONSTRAINT)
                } else {
                    append(AiChatManager.buildPersonaSystemPrompt(AiChatManager.getTraits(ctx, currentUserId), AiChatManager.getCustomTraits(ctx, currentUserId)))
                    if (AiChatManager.getSaveToken(ctx, currentUserId)) append("\n\n").append(AiChatManager.SAVE_TOKEN_CONSTRAINT)
                    if (AiChatManager.getPersonaSwitch(ctx, currentUserId)) append("\n\n").append(AiChatManager.PERSONA_SWITCH_RELEASE)
                }
            }
            val reversed = friendId == AI_CHAT_ID && reverseHistory
            val reverseNote = if (reversed) "\n\n【重要设定】本次对话的聊天记录是「反转」的：原本由用户（我方）发送的消息，现在代表「对方」；原本由你（AI）发送的回复，现在代表「我（用户）」。请你以用户（我方）的视角和身份，继续与对方自然对话，不要提及这是反转设定，也不要点破角色互换。" else ""
            val systemFinal = buildString {
                append(systemText)
                if (!AiChatManager.getUltraSave(ctx, currentUserId)) {
                    append(AiChatManager.buildAdvancedSystemPrompt(ctx, currentUserId))
                    append(AiChatManager.multiOutputConstraint(ctx, currentUserId))
                }
                if (reverseNote.isNotBlank()) append(reverseNote)
                if (currentTimePoint.isNotBlank()) append("\n\n【当前时间】$currentTimePoint")
            }
            if (AiChatManager.getPersonaSwitch(ctx, currentUserId)) AiChatManager.setPersonaSwitch(ctx, currentUserId, false)
            // 无新反馈时：在 system 里明确告诉 AI"用户这次什么都没说"，并让 AI 自己决定如何回应
            val systemForHistory = buildString {
                append(systemFinal)
                if (syntheticNoFeedback) append(
                    "\n\n【场景提示】用户刚刚又点击了一次「确认发言」，但本次没有输入任何内容、也没有发送新消息——也就是说用户这一次没有任何新反馈。" +
                    "请不要把自己的上一句回复当成用户在说话，也不要无脑续写、自顾自地聊；你可以主动反问用户、引导话题，或表达在等待用户的回应，话题请承接已有上下文。"
                )
            }
            // 无新反馈时，在末尾补一条"用户侧"回合，明确用户什么都没说，
            // 使模型以 assistant 身份回应（质问/闲聊），而不是续写自己上一条回复
            // （noFeedbackUserText 已在隔离判断处提前声明，此处只取对应角色）
            // 无新反馈时，在末尾补一条"用户侧"回合，明确用户什么都没说，
            // 使模型以 assistant 身份回应（质问/闲聊），而不是续写自己上一条回复
            // （noFeedbackUserText 已在隔离判断处提前声明，此处只取对应角色）
            val noFeedbackRole = if (true != reversed) "user" else "assistant"
            // 用 mutableListOf 累加，避免多行 + 链类型推断陷阱（之前报 unaryPlus）
            val history = mutableListOf<Pair<String, String>>()
            if (systemForHistory.isNotBlank()) history.add("system" to systemForHistory)
            chatContext.map { (if (it.isMine != reversed) "user" else "assistant") to it.text }
                .forEach { history.add(it) }
            if (syntheticNoFeedback) history.add(noFeedbackRole to noFeedbackUserText)
            val aiMsgId = System.currentTimeMillis() * 10000L + (0..9999).random()
            expandedReasoningMsgId = aiMsgId
            val initText = if (AiChatManager.getShowReasoning(ctx, currentUserId)) "" else AI_THINKING
            messages.add(ChatMsg.create(
                serverId = aiMsgId, text = initText, isMine = false, fromUserId = AI_CHAT_ID,
                senderName = AiNameState.name ?: "DeepSeek", isNew = true, createdAt = System.currentTimeMillis() / 1000
            ))
            try {
                val info = listState.layoutInfo
                val lastIndex = info.totalItemsCount - 1
                if (lastIndex >= 0) {
                    listState.scrollToItem(lastIndex, (info.viewportEndOffset - info.viewportStartOffset - (info.visibleItemsInfo.lastOrNull()?.size ?: 0)))
                }
            } catch (_: Exception) {}
            AiChatManager.streamChat(
                ctx = ctx, userId = currentUserId, history = history,
                onReasoningDelta = { reasoning ->
                    if (AiChatManager.getShowReasoning(ctx, currentUserId)) {
                        val idx = messages.indexOfFirst { m -> m.id == aiMsgId }
                        if (idx >= 0) messages[idx] = (messages[idx] as ChatMsg).copy(reasoningText = reasoning)
                    }
                    if (atBottomState.value && !userScrolledAway) { scope.launch { try { listState.scrollToItem(messages.size - 1, Int.MAX_VALUE) } catch (_: Exception) {} } }
                    // 思考过程中实时更新用量：输入已消耗，输出尚未产生，先显示输入部分
                    if (mode == "official" && poolAtStart > 0L) {
                        val liveUsed = baseUsed + estInput
                        val liveRemaining = (poolAtStart - estInput).coerceAtLeast(0)
                        aiUsageState.value = Pair(liveUsed, liveRemaining)
                    }
                },
                onDelta = { cur ->
                    val idx = messages.indexOfFirst { m -> m.id == aiMsgId }
                    if (idx >= 0) {
                        val msg = messages[idx] as ChatMsg
                        val keepReasoning = if (AiChatManager.getShowReasoning(ctx, currentUserId)) msg.reasoningText else ""
                        messages[idx] = msg.copy(text = cur.replace(AiChatManager.MULTI_OUTPUT_SPLIT, ""), reasoningText = keepReasoning)
                    }
                    if (atBottomState.value && !userScrolledAway) { scope.launch { try { listState.scrollToItem(messages.size - 1, Int.MAX_VALUE) } catch (_: Exception) {} } }
                    if (mode == "official" && poolAtStart > 0L) {
                        val inc = estInput + AiChatManager.estimateTokens(cur)
                        aiUsageState.value = Pair(baseUsed + inc, (poolAtStart - inc).coerceAtLeast(0))
                    }
                },
                onDone = { usage, full ->
                    val idx = messages.indexOfFirst { m -> m.id == aiMsgId }
                    val finalReasoning = if (idx >= 0 && AiChatManager.getShowReasoning(ctx, currentUserId)) (messages[idx] as ChatMsg).reasoningText else ""
                    val multi = AiChatManager.getMultiOutput(ctx, currentUserId)
                    if (multi && full.contains(AiChatManager.MULTI_OUTPUT_SPLIT)) {
                        if (idx >= 0) messages.removeAt(idx)
                        val segs = full.split(AiChatManager.MULTI_OUTPUT_SPLIT).map { it.trim() }.filter { it.isNotBlank() }
                        var pos = idx.coerceAtLeast(0)
                        var firstText = ""
                        for (seg in segs) {
                            if (firstText.isEmpty()) firstText = seg.take(60)
                            messages.add(pos, ChatMsg.create(
                                serverId = System.currentTimeMillis() * 10000L + (0..9999).random(), text = seg,
                                isMine = false, fromUserId = AI_CHAT_ID, senderName = AiNameState.name ?: "DeepSeek",
                                isNew = true, createdAt = System.currentTimeMillis() / 1000, reasoningText = finalReasoning
                            ))
                            pos++
                        }
                        if (firstText.isNotEmpty()) ChatViewModel.updateConversationPreview(friendId, firstText, System.currentTimeMillis() / 1000)
                    } else {
                        if (idx >= 0) messages[idx] = (messages[idx] as ChatMsg).copy(text = full, reasoningText = finalReasoning)
                        if (full.isNotBlank()) ChatViewModel.updateConversationPreview(friendId, full.take(60), System.currentTimeMillis() / 1000)
                    }
                    saveLocalChatMessages(ctx, currentUserId, "ai", messages.filter { !it.isSystemNotice })
                    // 同步到 AI 对话分享桥接：供「AI对话分享 → 直接获取当前对话」使用（官方 JSON 格式）
                    AiChatShareBridge.currentConversation = buildShareJson(
                        messages.filter { !it.isSystemNotice && it.text.isNotBlank() && it.text != AI_THINKING },
                        currentUserId, friendId, currentUserName, friendName
                    )
                    if (mode == "official" && usage > 0) {
                        AiChatManager.addOfficialUsage(ctx, currentUserId, usage)
                        // 对话完成：基于发送前的 poolAtStart 减去真实消耗，与服务端余额解耦，避免跳变
                        val finalUsed = baseUsed + usage
                        val finalRemaining = (poolAtStart - usage).coerceAtLeast(0)
                        aiUsageState.value = Pair(finalUsed, finalRemaining)
                        // 后台静默刷新服务端余额，下次打开面板时自动显示最新值
                        scope.launch {
                            AiChatManager.syncServerLimit(ctx, currentUserId)
                        }
                    }
                },
                onError = { err ->
                    val idx = messages.indexOfFirst { m -> m.id == aiMsgId }
                    if (idx >= 0) messages.removeAt(idx)
                    if (err.contains("已被管理员暂停")) {
                        apiSuspendedDialog = true
                    } else {
                        android.widget.Toast.makeText(ctx, err, android.widget.Toast.LENGTH_LONG).show()
                    }
                },
                onTokenInsufficient = onTokenExhausted
            )
        }
    }

    // 进入时从 SharedPreferences 恢复草稿
    LaunchedEffect(Unit) {
        val saved = ctx.getSharedPreferences("aurora_drafts", Context.MODE_PRIVATE)
            .getString(draftKey, "") ?: ""
        inputText = saved
    }

    // 平台头像（所有对话共用）
    var myAvatarBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    // AI 对话专用自定义头像（与平台头像完全隔离）
    var aiMyAvatarBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }

    // AI 对话分享「覆盖到当前对话」：content 为官方导出 JSON（与「导入对话」同一格式），解析后直接覆盖当前 AI 对话并存入本地
    LaunchedEffect(AiChatShareBridge.pendingImport) {
        val imported = AiChatShareBridge.pendingImport
        if (imported.isNotEmpty()) {
            AiChatShareBridge.pendingImport = ""
            try {
                val root = org.json.JSONObject(imported)
                val arr = root.optJSONArray("messages")
                if (arr == null) {
                    Toast.makeText(ctx, "对话内容格式无效", Toast.LENGTH_SHORT).show()
                } else {
                    val parsed = mutableListOf<ChatMsg>()
                    var nextId = 1L
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val isMine = o.optBoolean("is_mine", false)
                        // 替换 fromUserId：自己的消息用当前用户 ID，AI 消息用 AI_CHAT_ID
                        // 避免导入后显示上传者的平台头像
                        val fromUserId = if (isMine) currentUserId else AI_CHAT_ID
                        parsed.add(
                            ChatMsg.create(
                                serverId = nextId++,
                                text = o.optString("text", ""),
                                isMine = isMine,
                                fromUserId = fromUserId,
                                isNew = false,
                                senderName = o.optString("sender_name", ""),
                                createdAt = o.optLong("created_at", 0L),
                                mediaType = o.optString("media_type", ""),
                                mediaUrl = o.optString("media_url", ""),
                                replyToText = o.optString("reply_to_text", ""),
                                replyToSender = o.optString("reply_to_sender", ""),
                                replyToId = o.optLong("reply_to_id", 0L),
                                isRevoked = o.optInt("revoked", 0),
                                wornBadge = o.optInt("worn_badge", 0),
                                flashDuration = o.optInt("flash_duration", 0),
                                reasoningText = o.optString("reasoning_text", "")
                            )
                        )
                    }
                    if (parsed.isNotEmpty()) {
                        // 覆盖：清空当前并载入（与「导入对话」同原理，只是这里整体替换而非追加）
                        messages.clear()
                        messages.addAll(parsed)
                        saveLocalChatMessages(ctx, currentUserId, "ai", messages.filter { !it.isSystemNotice })
                        // 处理 meta 中的头像 base64 和场景信息
                        // 覆盖前先清除本地头像缓存，避免导入的对话没有头像时还显示旧头像
                        try {
                            val meta = root.optJSONObject("meta")
                            if (meta != null) {
                                // 先清除所有自定义头像，再按需写入
                                withContext(Dispatchers.IO) {
                                    try { LocalStorage.getAiAvatarFile(ctx).delete() } catch (_: Exception) {}
                                    try { LocalStorage.getAiMyAvatarFile(ctx, currentUserId).delete() } catch (_: Exception) {}
                                }
                                AiAvatarState.bitmap = null
                                aiMyAvatarBitmap = null

                                // 头像 base64 解码保存
                                val aiAvatarData = meta.optString("ai_avatar_data", "")
                                if (aiAvatarData.isNotEmpty()) {
                                    withContext(Dispatchers.IO) {
                                        try {
                                            val bytes = android.util.Base64.decode(aiAvatarData, android.util.Base64.DEFAULT)
                                            val file = LocalStorage.getAiAvatarFile(ctx)
                                            java.io.FileOutputStream(file).use { it.write(bytes) }
                                            AiAvatarState.bitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath)
                                        } catch (_: Exception) {}
                                    }
                                }
                                val myAvatarData = meta.optString("my_avatar_data", "")
                                if (myAvatarData.isNotEmpty()) {
                                    withContext(Dispatchers.IO) {
                                        try {
                                            val bytes = android.util.Base64.decode(myAvatarData, android.util.Base64.DEFAULT)
                                            val file = LocalStorage.getAiMyAvatarFile(ctx, currentUserId)
                                            java.io.FileOutputStream(file).use { it.write(bytes) }
                                            aiMyAvatarBitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath)
                                        } catch (_: Exception) {}
                                    }
                                }
                                // 场景信息
                                val sceneInfo = meta.optJSONObject("scene_info")
                                if (sceneInfo != null) {
                                    val scenario = sceneInfo.optString("scenario", "")
                                    val aiRole = sceneInfo.optString("ai_role", "")
                                    val myRole = sceneInfo.optString("my_role", "")
                                    val traitsArr = sceneInfo.optJSONArray("traits")
                                    val customsArr = sceneInfo.optJSONArray("custom_traits")
                                    if (scenario.isNotEmpty()) AiChatManager.setScenario(ctx, currentUserId, scenario)
                                    if (aiRole.isNotEmpty()) AiChatManager.setAiRole(ctx, currentUserId, aiRole)
                                    if (myRole.isNotEmpty()) AiChatManager.setMyRole(ctx, currentUserId, myRole)
                                    if (traitsArr != null && traitsArr.length() == 5) {
                                        val traits = (0 until 5).map { traitsArr.optDouble(it, 0.0).toFloat() }
                                        AiChatManager.saveTraits(ctx, currentUserId, traits)
                                    }
                                    if (customsArr != null && customsArr.length() > 0) {
                                        val customs = mutableListOf<com.aurora.chat.ui.chat.CustomTrait>()
                                        for (j in 0 until customsArr.length()) {
                                            val co = customsArr.optJSONObject(j)
                                            if (co != null) {
                                                customs.add(com.aurora.chat.ui.chat.CustomTrait(
                                                    text = co.optString("text", ""),
                                                    pct = co.optDouble("pct", 50.0).toFloat()
                                                ))
                                            }
                                        }
                                        AiChatManager.saveCustomTraits(ctx, currentUserId, customs)
                                    }
                                }
                            }
                        } catch (_: Exception) {}
                        Toast.makeText(ctx, "已覆盖到当前对话（${parsed.size} 条）", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(ctx, "对话内容为空", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "对话解析失败：${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    // 离开时保存草稿 + 缓存消息数据（让再次进入零延迟） + 触发 GC
    DisposableEffect(Unit) {
        onDispose {
            ctx.getSharedPreferences("aurora_drafts", Context.MODE_PRIVATE)
                .edit().putString(draftKey, inputText).apply()
            //  保存当前消息列表到顶层缓存，组件销毁后数据不丢
            if (messages.isNotEmpty() && !isLocalChat(friendId)) {
                companionMessageCache[friendId] = messages.map { msg ->
                    if (msg is com.aurora.chat.data.store.StoreMessageRef) {
                        ChatMsg(
                            id = msg.id, text = msg.text, isMine = msg.isMine,
                            fromUserId = msg.fromUserId, senderName = msg.senderName,
                            wornBadge = msg.wornBadge, createdAt = msg.createdAt,
                            isRevoked = msg.isRevoked, isSystemNotice = msg.isSystemNotice,
                            replyToText = msg.replyToText, replyToSender = msg.replyToSender,
                            replyToId = msg.replyToId, mediaType = msg.mediaType,
                            mediaUrl = msg.mediaUrl, isUploading = msg.isUploading,
                            toUserId = msg.toUserId, targetName = msg.targetName,
                            flashDuration = msg.flashDuration
                        )
                    } else msg as ChatMsg
                }
            }
            com.aurora.chat.GcUtil.gcNow()
        }
    }
    // 已销毁的闪照消息 ID（本地 + 服务端双重记录，防清缓存重看）
    var destroyedFlashIds by remember {
        mutableStateOf(
            try {
                val flashFile = java.io.File(ctx.filesDir, "flash_destroyed_${currentUserId}.json")
                if (flashFile.exists()) {
                    val arr = org.json.JSONArray(flashFile.readText())
                    val set = mutableSetOf<Long>()
                    for (i in 0 until arr.length()) set.add(arr.getLong(i))
                    set
                } else emptySet()
            } catch (_: Exception) { emptySet() }
        )
    }
    // 加载服务端的闪照查看记录（防清缓存重看）
    LaunchedEffect(currentUserId) {
        try {
            val serverIds = com.aurora.chat.data.api.AuroraApi.getViewedFlashIds()
            if (serverIds.success && serverIds.data != null) {
                destroyedFlashIds = destroyedFlashIds + serverIds.data.toSet()
                // 同步到本地文件
                try {
                    val flashFile = java.io.File(ctx.filesDir, "flash_destroyed_${currentUserId}.json")
                    val arr = org.json.JSONArray(destroyedFlashIds.toList())
                    flashFile.writeText(arr.toString())
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }
    // 保存已销毁闪照 ID 到文件 + 服务端双写
    fun saveDestroyedFlash(id: Long) {
        destroyedFlashIds = destroyedFlashIds + id
        try {
            val flashFile = java.io.File(ctx.filesDir, "flash_destroyed_${currentUserId}.json")
            val arr = org.json.JSONArray(destroyedFlashIds.toList())
            flashFile.writeText(arr.toString())
        } catch (_: Exception) {}
        // 同步到服务端（防止清缓存重看）
        scope.launch {
            try { com.aurora.chat.data.api.AuroraApi.recordFlashView(id) } catch (_: Exception) {}
        }
    }

    // 【Fix 2】点击 "+" 时延迟后平滑滚动到底部
    LaunchedEffect(showPlusDialog) {
        if (showPlusDialog && messages.isNotEmpty()) {
            try {
                delay(110)
                val lastIdx = messages.size - 1
                listState.animateScrollToItem(lastIdx)
                delay(50)
                listState.dispatchRawDelta(1f)
            } catch (_: Exception) { }
        }
    }

    // 当前打开弹窗的消息 ID（0 表示无弹窗），用于全局关闭
    var openMenuMsgId by remember { mutableStateOf(0L) }
    // 点击空白区域时递增，用于通知所有气泡退出选择模式
    var clearSelectionKey by remember { mutableStateOf(0) }
    // 高亮消息 ID（点击引用胶囊后滚动到目标消息时闪烁）
    var highlightedMsgId by remember { mutableStateOf(0L) }
    // 图片全屏预览
    var imagePreviewUrl by remember { mutableStateOf("") }
    var videoPlayUrl by remember { mutableStateOf("") }  // 应用内视频播放

    // 引用恢复：服务端返回的消息若无引用字段，从旧本地消息中按 ID 恢复
    val restoreReplyInfo: (List<IMessageRef>) -> List<IMessageRef> = { fromServer ->
        val oldById = messages.associateBy { it.id }
        fromServer.map { newMsg ->
            if (newMsg.replyToText.isNotEmpty()) return@map newMsg
            oldById[newMsg.id]?.let { old ->
                if (old.replyToText.isNotEmpty())
                    return@map ChatMsg(
                        id = old.id, text = newMsg.text, isMine = newMsg.isMine,
                        fromUserId = newMsg.fromUserId, senderName = newMsg.senderName,
                        wornBadge = newMsg.wornBadge, createdAt = newMsg.createdAt,
                        isRevoked = newMsg.isRevoked, isSystemNotice = newMsg.isSystemNotice,
                        replyToText = old.replyToText, replyToSender = old.replyToSender,
                        replyToId = old.replyToId, mediaType = newMsg.mediaType,
                        mediaUrl = newMsg.mediaUrl, flashDuration = newMsg.flashDuration,
                        toUserId = newMsg.toUserId, targetName = newMsg.targetName
                    )
            }
            newMsg
        }
    }


    var deleteConfirmMsgId by remember { mutableStateOf(0L) }

    // 已删除消息 ID 集合（持久化到文件，避免 SP 大字符串读写）
    var deletedMessageIds by remember { mutableStateOf(
        try {
            val delFile = java.io.File(ctx.filesDir, "deleted_msgs_${currentUserId}.json")
            if (delFile.exists()) {
                val arr = org.json.JSONArray(delFile.readText())
                val set = mutableSetOf<Long>()
                for (i in 0 until arr.length()) set.add(arr.getLong(i))
                set
            } else emptySet()
        } catch (_: Exception) { emptySet() }
    ) }
    val focusManager = LocalFocusManager.current
    val view = androidx.compose.ui.platform.LocalView.current
    var showGroupSettings by remember { mutableStateOf(false) }
    var showFriendSettings by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    var profileUserId by remember { mutableStateOf(0L) }
    var profileUserName by remember { mutableStateOf("") }
    var showAiUsage by remember { mutableStateOf(false) }
    // AI 设置弹窗状态（合并「上传/恢复头像」与「设置/恢复名称」）
    var showAiSettingsDialog by remember { mutableStateOf(false) }
    var showReverseInfo by remember { mutableStateOf(false) }
    var showPlaceholderConvert by remember { mutableStateOf(false) }
    var showAiNameInput by remember { mutableStateOf(false) }
    var aiNameInput by remember { mutableStateOf("") }

    // AI 自定义头像：选取图片并保存到本地文件，替换对话中的 AI 头像
    val aiAvatarLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                withContext(Dispatchers.IO) {
                    try {
                        val file = LocalStorage.getAiAvatarFile(ctx)
                        ctx.contentResolver.openInputStream(uri)?.use { input ->
                            java.io.FileOutputStream(file).use { output -> input.copyTo(output) }
                        }
                        AiAvatarState.bitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath)
                    } catch (_: Exception) {}
                }
            }
        }
    }

    // 我方自定义头像（DeepSeek 对话专用）：选取图片并保存到本地，在 DeepSeek 对话中替换用户头像
    // 使用 getAiMyAvatarFile 路径，与平台头像隔离，不污染 UserAvatar 组件
    var myCropUri by remember { mutableStateOf<Uri?>(null) }
    var showMyCrop by remember { mutableStateOf(false) }
    val myAvatarLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            myCropUri = uri
            showMyCrop = true
        }
    }

    // 裁剪弹窗：选图后弹出，裁剪完成再保存
    if (showMyCrop && myCropUri != null) {
        CropPreviewDialog(
            imageUri = myCropUri!!, context = ctx,
            onCropConfirm = { cropped ->
                showMyCrop = false
                myCropUri = null
                aiMyAvatarBitmap = cropped
                scope.launch {
                    withContext(Dispatchers.IO) {
                        try {
                            val file = LocalStorage.getAiMyAvatarFile(ctx, currentUserId)
                            java.io.FileOutputStream(file).use { out ->
                                cropped.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
                            }
                        } catch (_: Exception) {}
                    }
                }
            },
            onDismiss = { showMyCrop = false; myCropUri = null }
        )
    }

    // 好友资料返回：先回对话，不直接退出聊天板块（补充缺失的 BackHandler）
    BackHandler(enabled = showFriendSettings) { showFriendSettings = false }
    // 群设置返回：先回对话，不直接跳到聊天板块
    BackHandler(enabled = showGroupSettings) { showGroupSettings = false }
    // 用户资料返回：先回对话，不直接跳到聊天板块
    BackHandler(enabled = showProfile && profileUserId > 0) { showProfile = false }

    val animPrefs = LocalStorage.getChatPrefs(ctx)
    val animMode by remember {
        derivedStateOf { AnimationMode.entries[animPrefs.getInt("animation_mode", 2)] }
    }
    val advancedAnim by remember {
        derivedStateOf { animPrefs.getBoolean("advanced_anim", false) }
    }

    // 带时间戳的最近发送文本集合（防止 TCP/polling 触发 loadMessages 时重复添加自己发出的消息）
    // 用时间戳确保：消息发送后 30 秒内不被服务端同步重复添加
    val recentlySentMessages = remember { mutableMapOf<String, Long>() }

    // ── 入群申请相关状态（提升到 Column 外部，避免 AnimatedVisibility 内引用不到）──
    var isAdminOrOwner by remember { mutableStateOf(false) }
    var pendingCount by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        withContext(kotlinx.coroutines.Dispatchers.IO) {
            // 平台头像（所有对话共用）
            val platformFile = LocalStorage.getMyAvatarFile(ctx, currentUserId)
            if (platformFile.exists()) {
                myAvatarBitmap = android.graphics.BitmapFactory.decodeFile(platformFile.absolutePath)
            }
            // AI 对话专用自定义头像（完全隔离）
            val aiCustomFile = LocalStorage.getAiMyAvatarFile(ctx, currentUserId)
            if (aiCustomFile.exists()) {
                aiMyAvatarBitmap = android.graphics.BitmapFactory.decodeFile(aiCustomFile.absolutePath)
            }
            // AI 自定义头像：存在则载入全局状态，替换默认 AI 头像
            val aiFile = LocalStorage.getAiAvatarFile(ctx)
            if (aiFile.exists()) {
                AiAvatarState.bitmap = android.graphics.BitmapFactory.decodeFile(aiFile.absolutePath)
            }
        }
    }

    // 加载禁言状态
    LaunchedEffect(currentUserId, friendId) {
        withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val result = com.aurora.chat.data.api.AuroraApi.checkMuteStatus()
                if (result.success && result.data != null) {
                    val expiresAt = result.data.optLong("expires_at", 0L)
                    val muteType = result.data.optInt("mute_type", 0)
                    if (expiresAt > 0 && (muteType == 2 || muteType == 3)) {
                        mutedUntil = expiresAt
                    } else {
                        mutedUntil = 0L
                    }
                }
            } catch (_: Exception) {
                mutedUntil = 0L
            }
        }
    }

    // ── 消息加载（初始加载不限量，由服务端返回全部；滚动到顶部继续追加）──
    val pageSize = 200  // 每批次加载量（非总上限）
    var hasMoreMessages by remember { mutableStateOf(true) }
    var loadMoreProgress by remember { mutableIntStateOf(0) } // 0=空闲, 1=加载中, 2=无更多

        // 加载消息（热缓存 + 网络刷新）
    val selfChatRefresh by com.aurora.chat.ui.viewmodel.ChatViewModel.selfChatRefreshKey.collectAsState()
    LaunchedEffect(friendId, selfChatRefresh) {
        if (isLocalChat(friendId)) {
            // 本地对话（自己 / AI）：从 JSON 文件加载，消息 ID 为时间戳*10000+随机，重启不丢失
            val key = localChatKey(friendId)
            isLoadingMessages = true
            val list = mutableListOf<ChatMsg>()
            // 仅自己对话首屏显示本地提示，AI 保持空白
            if (friendId == 0L) {
                val noticeShown = java.io.File(ctx.cacheDir, "self_chat_notice_${currentUserId}.txt").exists()
                if (!noticeShown) {
                    list.add(ChatMsg.create(
                        text = "此对话为本地个人对话，对话内容全部存在本地，清理数据后此对话内的数据也会随之清理",
                        isMine = false, fromUserId = 0, isSystemNotice = true, isNew = false
                    ))
                    try { java.io.File(ctx.cacheDir, "self_chat_notice_${currentUserId}.txt").writeText("1") } catch (_: Exception) {}
                }
            }
            val arr = loadLocalChatMessages(ctx, currentUserId, key)
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    try {
                        // 单条消息损坏（缺字段 / 非对象）则跳过，绝不因一条坏数据让整屏崩溃
                        val obj = arr.optJSONObject(i) ?: continue
                        val msgId = obj.optLong("id", 0L)
                        // 统一用 deletedMessageIds 过滤（跟其他对话一样）
                        if (obj.optBoolean("revoked", false)) continue
                        if (msgId in deletedMessageIds) continue
                        val isMine = obj.optBoolean("is_mine", msgId == 0L)
                        val fromUserId = obj.optLong("from_user_id", if (isMine) currentUserId else friendId)
                        val senderName = obj.optString("sender_name", if (isMine) currentUserName else friendName)
                        list.add(ChatMsg.create(
                            serverId = msgId,
                            text = obj.optString("text", ""),
                            isMine = isMine,
                            fromUserId = fromUserId,
                            isNew = false,
                            senderName = senderName,
                            createdAt = obj.optLong("created_at", 0),
                            mediaType = obj.optString("media_type", ""),
                            mediaUrl = obj.optString("media_url", ""),
                            reasoningText = obj.optString("reasoning_text", "")
                        ))
                    } catch (_: Exception) {
                        // 跳过损坏的单条消息
                    }
                }
            }
            messages.clear()
            messages.addAll(list.sortedBy { if (it.createdAt == 0L) Long.MIN_VALUE else it.createdAt })
            // 进入 AI 对话即同步当前对话全文到分享桥接（供「AI对话分享 → 直接获取当前对话」），官方 JSON 格式
            if (friendId == AI_CHAT_ID) {
                AiChatShareBridge.currentConversation = buildShareJson(
                    messages.filter { !it.isSystemNotice && it.text.isNotBlank() && it.text != AI_THINKING },
                    currentUserId, friendId, currentUserName, friendName
                )
            }
            //  诊断：记录每条媒体消息的 mediaType/mediaUrl，定位「重进变空气泡」
            list.forEach { m ->
                if (m.mediaType.isNotEmpty()) {
                    val status = if (m.mediaUrl.isEmpty()) "URL为空(空气泡)" else "OK"
                    MediaDebug.log(ctx, "LOAD_LOCAL", "id=${m.id} mediaType=${m.mediaType} mediaUrl=${m.mediaUrl} -> $status")
                }
            }
            if (messages.isNotEmpty()) {
                try { listState.scrollToItem(messages.size - 1, Int.MAX_VALUE) } catch (_: Exception) {}
            }
            scrollReady = true
            isLoadingMessages = false
            return@LaunchedEffect
        }

        // 通知系统：从本地存储加载，并与服务端持久化历史合并（确保离线/后端重启后不丢失）
        if (isNotificationChat(friendId)) {
            isLoadingMessages = true
            val localList = loadNotificationMessages(ctx, currentUserId).filter { it.id !in deletedMessageIds }.toMutableList()
            // 进入即清除未读角标
            setNotificationUnread(ctx, currentUserId, 0)
            // 从服务端拉取持久化通知，合并到本地（防止离线/后端重启导致通知丢失）
            try {
                val r = com.aurora.chat.data.api.AuroraApi.getSystemNotices()
                if (r.success && r.data != null) {
                    val existingTexts = localList.map { it.text }.toMutableSet()
                    for (item in r.data!!) {
                        // 已删除的通知（即便服务端仍有记录）也跳过，避免重新进入又出现
                        if (item.id in deletedMessageIds) continue
                        val text = if (item.tag == "转账") com.aurora.chat.ui.chat.formatTransferNotice(item.desc)
                                   else com.aurora.chat.ui.chat.formatOrderNotice(item.title, item.desc, item.tag, item.orderId)
                        if (existingTexts.add(text)) {
                            localList.add(ChatMsg.create(
                                serverId = item.id, text = text, isMine = false, fromUserId = 0,
                                isSystemNotice = true, isNew = false, createdAt = item.createdAt
                            ))
                        }
                    }
                    // 合并后回写本地，确保即使后续离线也能看到完整历史
                    saveNotificationMessages(ctx, currentUserId, localList)
                }
            } catch (_: Exception) {}
            val list = localList
            if (list.isEmpty()) {
                list.add(ChatMsg.create(
                    text = "暂无通知",
                    isMine = false, fromUserId = 0, isSystemNotice = true, isNew = false
                ))
            }
            messages.clear()
            messages.addAll(list.sortedBy { if (it.createdAt == 0L) Long.MIN_VALUE else it.createdAt })
            if (messages.isNotEmpty()) {
                try { listState.scrollToItem(messages.size - 1, Int.MAX_VALUE) } catch (_: Exception) {}
            }
            scrollReady = true
            isLoadingMessages = false
            return@LaunchedEffect
        }

        // 第一步：群聊成员列表改为后台加载，不阻塞消息显示
        if (isGroupChat(friendId)) {
            launch {
                try {
                    val gid = -(friendId + 1000)
                    val membersResult = AuroraApi.getGroupMembers(gid)
                    if (membersResult.success && membersResult.data != null) {
                        val members = mutableSetOf<String>()
                        val memberIdMap = mutableMapOf<String, Long>()
                        for (i in 0 until membersResult.data!!.length()) {
                            val memberObj = membersResult.data!!.getJSONObject(i)
                            val userId = memberObj.optLong("user_id", 0)
                            val username = memberObj.optString("username", "")
                            if (username.isNotEmpty()) {
                                members.add(username)
                                memberIdMap[username] = userId
                            }
                        }
                        groupMemberNames = members
                        groupMemberIdMap = memberIdMap
                    }
                } catch (_: Exception) {}
            }
        }

        // 第二步：优先从热缓存显示（永不过期），再读磁盘，最后等网络

        val cacheKey = "$currentUserId:$friendId"
        val cached = messageHotCache[cacheKey]
        if (cached != null) {
            // 有热缓存 → 立即显示，零延迟
            messages.clear()
            messages.addAll(cached.messages as List<IMessageRef>)
            isLoadingMessages = false
            if (messages.isNotEmpty()) {
                listState.scrollToItem(messages.size - 1)
            }
            scrollReady = true
        } else {
            // 无热缓存 → 读磁盘缓存（1-2ms），直接加载到数组引擎，零 ChatMsg 分配
            val diskMsgs = com.aurora.chat.data.repository.LocalMessageStore.loadMessages(ctx, friendId)
            if (diskMsgs.isNotEmpty()) {
                val diskData = diskMsgs.map { m ->
                    MessageData(
                        id = m.id, fromUserId = m.fromUserId, toUserId = m.toUserId,
                        content = m.content, createdAt = m.createdAt,
                        isMine = m.fromUserId == currentUserId,
                        senderName = m.fromUserName, wornBadge = m.wornBadge,
                        isRevoked = m.isRevoked != 0,
                        // 还原系统通知标记：优先用落盘字段；旧磁盘数据无此字段时，用文案兜底
                        // （召回/拍一拍通知内容特征明显），避免冷启动/缓存失效时先当气泡、后被 syncMessages 矫正的闪烁
                        isSystemNotice = m.isSystemNotice
                            || m.content.contains("撤回了一条消息")
                            || m.content.contains("拍了拍"),
                        replyToText = m.replyToText, replyToSender = m.replyToSender,
                        replyToId = m.replyToId, mediaType = m.mediaType,
                        mediaUrl = resolveMediaUrl(m.mediaUrl), flashDuration = m.flashDuration
                    )
                }
                adapter.loadAll(diskData)
                MediaStore.seed(diskMsgs.map { it.id to (it.mediaType to resolveMediaUrl(it.mediaUrl)) })
                syncMessages()
                //  诊断：磁盘缓存重载后扫描媒体消息
                messages.forEach { m ->
                    if (m.mediaType.isNotEmpty()) {
                        val status = if (m.mediaUrl.isEmpty()) "URL为空(空气泡)" else "OK"
                        MediaDebug.log(ctx, "LOAD_DISK", "id=${m.id} mediaType=${m.mediaType} mediaUrl=${m.mediaUrl} -> $status")
                    }
                }
                isLoadingMessages = false
                if (messages.isNotEmpty()) {
                    listState.scrollToItem(messages.size - 1)
                }
                scrollReady = true
            } else {
                isLoadingMessages = true
            }
        }

        // 第三步：网络刷新（同步在线时间 + 拉取最新消息）
        try {
            val ot = OnlineTimeTracker.getCurrentTotalSeconds(ctx)
            AuroraApi.syncUserStats(ot, 0)
        } catch (_: Exception) {}
        val result = if (isGroupChat(friendId)) {
            com.aurora.chat.data.repository.ChatRepository.getGroupMessages(friendId, 0, 0)
        } else {
            com.aurora.chat.data.repository.ChatRepository.getMessages(currentUserId, friendId, 0, 0)
        }
        if (result.success && result.data != null) {
            //  使用 MessageStoreAdapter 数组引擎加载，零 ChatMsg 对象分配
            val serverData = result.data!!
            // 用当前已显示消息（磁盘/缓存）里的非空 mediaUrl 回填服务器可能返回的空值，
            // 防御旧后端 / 旧缓存把空 mediaUrl 直接当空气泡的问题（send 时已把可用 URL 落盘）
            val existingMediaByMsgId = messages.filter { it.mediaType.isNotEmpty() && it.mediaUrl.isNotEmpty() }
                .associate { it.id to it.mediaUrl }
            withContext(kotlinx.coroutines.Dispatchers.Default) {
                adapter.loadAll(serverData.map { m ->
                    val isRevoked = m.isRevoked
                    val isSystemNotice = isRevoked == 1
                    val text = when {
                        isSystemNotice -> {
                            val sender = if (m.fromUserId == currentUserId) currentUserName else m.fromUserName
                            "$sender 撤回了一条消息"
                        }
                        m.flashDuration == -1 -> parsePokeText(m, currentUserId, currentUserName)
                        else -> m.content
                    }
                    // 服务器返回空 mediaUrl 时，优先用本地已验证可用的完整 URL 回填；否则做相对/内网 host 解析
                    val finalMediaUrl = if (m.mediaUrl.isEmpty()) (existingMediaByMsgId[m.id] ?: "") else resolveMediaUrl(m.mediaUrl)
                    MessageData(
                        id = m.id, fromUserId = m.fromUserId, toUserId = m.toUserId,
                        content = text, createdAt = m.createdAt, isMine = m.fromUserId == currentUserId,
                        senderName = m.fromUserName, wornBadge = m.wornBadge,
                        isRevoked = isRevoked != 0, isSystemNotice = isSystemNotice || m.flashDuration == -1,
                        replyToText = m.replyToText, replyToSender = m.replyToSender, replyToId = m.replyToId,
                        mediaType = m.mediaType, mediaUrl = finalMediaUrl, flashDuration = m.flashDuration
                    )
                })
            }
            // 用 loadAll 后 messages 里已回填(finalMediaUrl)的权威媒体 URL 喂给 MediaStore，
            // 不再用原始 serverData 重新解析（避免服务端返回空时漏填，与 loadAll 保持单一事实来源一致）
            MediaStore.seed(messages.filter { it.mediaType.isNotEmpty() && it.mediaUrl.isNotEmpty() }
                .map { it.id to (it.mediaType to it.mediaUrl) })
            // 始终同步：网络数据是权威源（磁盘缓存可能缺 mediaType/mediaUrl 等字段）
            // 即使用户量级一致也要同步，避免因本地缓存字段缺失导致空气泡
            syncMessages()
            // 把修正后的消息（含完整 mediaUrl）覆盖写入本地磁盘（filesDir/local_messages/），
            // 彻底消除"旧缓存空 mediaUrl + 早退优化冻结"导致的空气泡，并支持离线查看图片
            try {
                val infos = messages.filterIsInstance<com.aurora.chat.data.store.StoreMessageRef>().map { ref ->
                    com.aurora.chat.data.api.MessageInfo(
                        id = ref.id, fromUserId = ref.fromUserId, toUserId = ref.toUserId,
                        content = ref.text, createdAt = ref.createdAt, fromUserName = ref.senderName,
                        wornBadge = ref.wornBadge, isRevoked = ref.isRevoked, isSystemNotice = ref.isSystemNotice, replyToText = ref.replyToText,
                        replyToSender = ref.replyToSender, replyToId = ref.replyToId, mediaType = ref.mediaType,
                        mediaUrl = ref.mediaUrl, flashDuration = ref.flashDuration, targetName = ref.targetName
                    )
                }
                if (infos.isNotEmpty()) {
                    com.aurora.chat.data.repository.LocalMessageStore.saveMessages(ctx, friendId, infos)
                }
            } catch (_: Exception) { }
            // 自愈：媒体消息 URL 为空时，尝试从 /api/messages/info 恢复（后端已补 media_type/media_url 字段）。
            // 覆盖"旧缓存空 URL + 服务端列表也恰好空"的极端场景，彻底杜绝重进对话后图片变空气泡。
            val emptyMediaMsgs = messages.filter { it.mediaType.isNotEmpty() && it.mediaUrl.isEmpty() && it.id > 0 }
            if (emptyMediaMsgs.isNotEmpty()) {
                scope.launch {
                    for (m in emptyMediaMsgs) {
                        try {
                            val info = com.aurora.chat.data.api.AuroraApi.getMessageInfo(m.id)
                            if (info.success && info.data != null) {
                                val recoveredUrl = info.data!!.optString("media_url", "")
                                val recoveredType = info.data!!.optString("media_type", "")
                                if (recoveredUrl.isNotEmpty()) {
                                    MediaStore.put(m.id, ChatMedia(recoveredType.ifEmpty { m.mediaType }, resolveMediaUrl(recoveredUrl)))
                                }
                            }
                        } catch (_: Exception) {}
                    }
                }
            }
            // 合并导入的消息（好友对话服务端不保存导入历史，重载会丢失，故本地合并；不往服务端发送、不骚扰对方）
            if (!isLocalChat(friendId)) {
                val importedMsgs = loadImportedMessages(ctx, currentUserId, friendId)
                if (importedMsgs.isNotEmpty()) {
                    val existingKeys = messages.map { it.createdAt to it.text }.toSet()
                    val toAdd = importedMsgs.filter { (it.createdAt to it.content) !in existingKeys }
                    if (toAdd.isNotEmpty()) {
                        messages.addAll(toAdd.map { md ->
                            ChatMsg.create(
                                text = md.content, isMine = md.isMine, fromUserId = md.fromUserId,
                                senderName = md.senderName, createdAt = md.createdAt,
                                isRevoked = if (md.isRevoked) 1 else 0,
                                isSystemNotice = md.isSystemNotice,
                                mediaType = md.mediaType, mediaUrl = md.mediaUrl,
                                serverId = md.id
                            ) as IMessageRef
                        })
                        messages.sortBy { if (it.createdAt == 0L) Long.MAX_VALUE else it.createdAt }
                    }
                }
            }
            //  诊断：网络刷新后扫描媒体消息
            messages.forEach { m ->
                if (m.mediaType.isNotEmpty()) {
                    val status = if (m.mediaUrl.isEmpty()) "URL为空(空气泡)" else "OK"
                    MediaDebug.log(ctx, "LOAD_NET", "id=${m.id} mediaType=${m.mediaType} mediaUrl=${m.mediaUrl} -> $status")
                }
            }
            // 同步设置滚动位置，与消息赋值在同一个 snapshot 中，消除闪屏
            if (messages.isNotEmpty()) {
                listState.scrollToItem(messages.size - 1)
            }
            // 自动标记对方消息为已读（批量，避免并发请求压垮数据库）
            ChatViewModel.backgroundScope.launch {
                val ids = serverData.filter { it.fromUserId != currentUserId }.map { it.id }
                if (ids.isNotEmpty()) {
                    com.aurora.chat.data.api.AuroraApi.markMessagesReadBatch(ids)
                }
            }
        }
        isLoadingMessages = false
        scrollReady = true
        // 加载失败且没有缓存数据时提示用户
        if (!result.success && messages.isEmpty()) {
            Toast.makeText(ctx, "消息加载失败，请检查网络", Toast.LENGTH_SHORT).show()
            Log.w("ChatConv", "初始加载失败: ${result.message}")
        }
    }
    // 加载更多历史消息（无限滚动，始终保留最新 pageSize 条在内存中用于展示）
    fun triggerLoadMore(offset: Int) {
        scope.launch {
            if (loadMoreProgress != 0) return@launch
            loadMoreProgress = 1
            if (isLocalChat(friendId)) { loadMoreProgress = 0; return@launch }
            val result = if (isGroupChat(friendId)) {
                com.aurora.chat.data.repository.ChatRepository.getGroupMessages(friendId, pageSize, offset)
            } else {
                com.aurora.chat.data.repository.ChatRepository.getMessages(currentUserId, friendId, pageSize, offset)
            }
            if (result.success && result.data != null && result.data!!.isNotEmpty()) {
                val older: List<IMessageRef> = withContext(kotlinx.coroutines.Dispatchers.Default) {
                    result.data!!.map { m -> ChatMsg.create(text = m.content, isMine = m.fromUserId == currentUserId,
                        fromUserId = m.fromUserId, serverId = m.id, isNew = false, senderName = m.fromUserName,
                        wornBadge = m.wornBadge, createdAt = m.createdAt, isRevoked = m.isRevoked,
                        isSystemNotice = m.isRevoked == 1, replyToText = m.replyToText,
                        replyToSender = m.replyToSender, replyToId = m.replyToId, mediaType = m.mediaType,
                        mediaUrl = m.mediaUrl, flashDuration = m.flashDuration, toUserId = m.toUserId, targetName = "") as IMessageRef
                    }
                }
                // 在列表顶部插入历史消息（智能缓存：超出上限淘汰最旧的）
                val MAX_CACHED = 500
                if (older.size < pageSize) hasMoreMessages = false
                val idx = messages.indexOfFirst { it.id == older.last().id }
                if (idx < 0) {
                    messages.addAll(0, older)
                    // 仅当总数超出上限时淘汰最旧的消息（不会影响刚加载的历史")
                    if (messages.size > MAX_CACHED) {
                        val excess = messages.size - MAX_CACHED
                        messages.removeRange(0, excess)
                    }
                }
            } else {
                hasMoreMessages = false
            }
            loadMoreProgress = 0
        }
    }
    // 滚动到顶部时加载更多
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .collect { index ->
                if (index == 0 && hasMoreMessages && loadMoreProgress == 0 && !isLoadingMessages && messages.isNotEmpty()) {
                    triggerLoadMore(messages.size)
                }
            }
    }
    // （scrollReady 已在初始加载 LaunchedEffect 中设置，独立 LaunchedEffect 已移除避免滚动竞争）
    // 等 LazyColumn 布局完成后滚动到底部，同时支持缓存回填
    // （已合并到消息加载 LaunchedEffect 中，避免独立 LaunchedEffect 造成的闪屏）


    //  滑动停止 3 秒后主动 GC：把"下次滑动的 STW 卡顿"转移到"用户看屏幕不动时"
    LaunchedEffect(listState.isScrollInProgress) {
        if (!listState.isScrollInProgress) {
            kotlinx.coroutines.delay(3000L)
            if (!listState.isScrollInProgress) {
                com.aurora.chat.GcUtil.gcNow()
            }
        }
    }

    // TCP 推送触发即时刷新 — 使用 adapter.mergeServerMessages 增量更新
    LaunchedEffect(Unit) {
            ChatViewModel.newMessageReceived.collect {
            delay(200L) // 等 200ms 让服务端写入完成
            if (isLocalChat(friendId) || isNotificationChat(friendId)) return@collect
            val result = if (isGroupChat(friendId)) {
                com.aurora.chat.data.repository.ChatRepository.getGroupMessages(friendId, 0, 0)
            } else {
                com.aurora.chat.data.repository.ChatRepository.getMessages(currentUserId, friendId, 0, 0)
            }
            if (result.success && result.data != null && result.data!!.isNotEmpty()) {
                val serverData = result.data!!
                // O(1) 快速无变化检测
                if (serverData.size == messages.size &&
                    serverData.isNotEmpty() && messages.isNotEmpty() &&
                    serverData.last().id == messages.last().id) return@collect
                // 在 IO 线程转换 MessageData
                val dataList = withContext(kotlinx.coroutines.Dispatchers.Default) {
                    serverData.map { m ->
                        val isRevoked = m.isRevoked
                        val isSystemNotice = isRevoked == 1 || m.flashDuration == -1
                        MessageData(
                            id = m.id, fromUserId = m.fromUserId, toUserId = m.toUserId,
                            content = m.content, createdAt = m.createdAt,
                            isMine = m.fromUserId == currentUserId, senderName = m.fromUserName,
                            wornBadge = m.wornBadge, isRevoked = isRevoked != 0,
                            isSystemNotice = isSystemNotice, replyToText = m.replyToText,
                            replyToSender = m.replyToSender, replyToId = m.replyToId,
                            mediaType = m.mediaType, mediaUrl = m.mediaUrl,
                            flashDuration = m.flashDuration
                        )
                    }
                }
                val hasNew = adapter.mergeServerMessages(dataList, currentUserId, currentUserName)
                if (hasNew) {
                    syncMessages()
                }
                // 从 TCP 推送数据更新对话列表预览（支持双向实时）
                val lastServerMsg = serverData.lastOrNull()
                if (lastServerMsg != null) {
                    val preview = if (lastServerMsg.isRevoked > 0) {
                        "${lastServerMsg.fromUserName} 撤回了一条消息"
                    } else if (lastServerMsg.flashDuration == -1) {
                        parsePokeText(lastServerMsg, currentUserId, currentUserName)
                    } else if (lastServerMsg.content.isNotEmpty()) {
                        lastServerMsg.content
                    } else when (lastServerMsg.mediaType) {
                        "image" -> "[图片]"
                        "video", "mp4" -> "[视频]"
                        "file" -> "[文件]"
                        else -> "[消息]"
                    }
                    ChatViewModel.updateConversationPreview(friendId, preview, lastServerMsg.createdAt)
                }
                // 自动标记对方发来的消息为已读（批量）
                ChatViewModel.backgroundScope.launch {
                    val ids = serverData.filter { it.fromUserId != currentUserId }.map { it.id }
                    if (ids.isNotEmpty()) {
                        com.aurora.chat.data.api.AuroraApi.markMessagesReadBatch(ids)
                    }
                }
                // 用户靠近底部时自动滚动到最新消息
                if (messages.isNotEmpty()) {
                    val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                    val total = listState.layoutInfo.totalItemsCount
                    if (total <= 0 || lastVisible >= total - 3) {
                        delay(50)
                        listState.scrollToItem(messages.size - 1)
                    }
                }
            }
        }
    }

    // 即时处理消息撤回 — 使用 adapter.markRevoked 原地更新数组
    LaunchedEffect(Unit) {
        while (true) {
            delay(200L)
            if (com.aurora.chat.PendingMessageRecalled.hasUpdate) {
                com.aurora.chat.PendingMessageRecalled.hasUpdate = false
                val msgId = com.aurora.chat.PendingMessageRecalled.messageId
                val senderName = com.aurora.chat.PendingMessageRecalled.senderName
                if (msgId > 0L) {
                    if (isLocalChat(friendId)) {
                        // 本地/AI 对话：消息以 ChatMsg 直接存于 messages，不经过 adapter。
                        // 直接原地移除该条，避免 syncMessages() 用空 adapter 覆盖清空整个列表
                        // （否则会出现「列表整屏消失 + 撤回后继续聊上下文全部丢失」的问题）
                        val idx = messages.indexOfFirst { it.id == msgId }
                        if (idx >= 0) messages.removeAt(idx)
                    } else {
                        adapter.markRevoked(msgId, senderName, currentUserName)
                        syncMessages()
                    }
                }
            }
        }
    }

    // 键盘弹起时：若用户本就在底部，则把视角重新贴到底部（长消息也不跳到顶部，且不打扰上滑看历史的用户）
    val imeBottom = WindowInsets.ime.getBottom(LocalDensity.current)
    LaunchedEffect(imeBottom) {
        if (imeBottom > 0 && messages.isNotEmpty() && atBottomState.value) {
            try { listState.scrollToItem(messages.size - 1, Int.MAX_VALUE) } catch (_: Exception) {}
        }
    }

    // 判断是否需要显示"滚动到底部"按钮
    // 智能逻辑：只有用户往上面滑到一定距离后，再往下滑（判定想返回底部）才显示
    var scrollDirectionIsDown by remember { mutableStateOf(false) } // true=正在往下滑, false=正在往上滑
    var lastTrackedIndex by remember { mutableStateOf(0) }
    LaunchedEffect(listState) {
        snapshotFlow {
            listState.firstVisibleItemIndex
        }.collect { index ->
            val delta = index - lastTrackedIndex
            if (delta > 0) scrollDirectionIsDown = true  // 正在下滑
            else if (delta < 0) scrollDirectionIsDown = false // 正在上滑
            lastTrackedIndex = index
        }
    }
    val shouldShowScrollDown = remember {
        derivedStateOf {
            val lastVisibleItem = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val totalItems = listState.layoutInfo.totalItemsCount
            // 条件：离开底部超过 12 项 + 且当前正在往下滑（判定用户想返回底部）
            totalItems > 0 && lastVisibleItem < totalItems - 12 && scrollDirectionIsDown
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        // 在 Final 阶段消费所有未被子组件处理的事件，
                        // 防止点击空白区域穿透到外层遮罩导致退出聊天
                        awaitPointerEvent(PointerEventPass.Final)
                    }
                }
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFEDEDED))
                .imePadding() // 整体内容避开键盘
        ) {
            // 顶栏
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF9FAFB))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // ← 用固定小尺寸 Box 限制触摸区域，防止覆盖标题
                    Box(
                        modifier = Modifier.size(28.dp)
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() }
                            ) { onBack() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("←", fontSize = 20.sp, color = Color(0xFF1E40AF), fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    // 读取备注
                    val remarkPrefs = ctx.getSharedPreferences("aurora_friend_settings", Context.MODE_PRIVATE)
                    val remarkKey = if (friendId < 0 && friendId != AI_CHAT_ID && friendId != NOTIFICATION_CHAT_ID)
                        "remark_group_${-(friendId + 1000)}" else "remark_$friendId"
                    var chatRemark by remember(remarkKey) { mutableStateOf(remarkPrefs.getString(remarkKey, "") ?: "") }
                    LaunchedEffect(remarkKey) { chatRemark = remarkPrefs.getString(remarkKey, "") ?: "" }
                    val chatTitle = if (friendId == AI_CHAT_ID) (AiNameState.name ?: "DeepSeek") else chatRemark.ifEmpty { friendName }.ifEmpty { "聊天" }
                    Text(
                        text = chatTitle,
                        fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1F2937), maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    // 右上角三横杠菜单（群聊→群设置，私信→下拉菜单含隐私控制）
                    var showSelfChatInfo by remember { mutableStateOf(false) }
                    var showChatMenu by remember { mutableStateOf(false) }
                    if (!isNotificationChat(friendId)) {
                        Spacer(Modifier.width(8.dp))
                        Box {
                            Box(
                                modifier = Modifier.size(28.dp).clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() }
                                ) {
                                    if (friendId == AI_CHAT_ID) {
                                        showAiUsage = true
                                    } else if (friendId == 0L) {
                                        showSelfChatInfo = true
                                    } else if (isGroupChat(friendId)) {
                                        showGroupSettings = true
                                    } else {
                                        showChatMenu = true
                                    }
                                },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("☰", fontSize = 22.sp, color = Color(0xFF1F2937))
                            }
                            if (showChatMenu) {
                                DropdownMenu(
                                    expanded = showChatMenu,
                                    onDismissRequest = { showChatMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("好友资料", fontSize = 14.sp) },
                                        onClick = { showChatMenu = false; showFriendSettings = true }
                                    )
                                }
                            }
                        }
                    }
                    // 个人对话介绍弹窗
                    if (showSelfChatInfo) {
                        Dialog(
                            onDismissRequest = { showSelfChatInfo = false },
                            properties = DialogProperties(usePlatformDefaultWidth = false)
                        ) {
                            Box(Modifier.fillMaxSize().background(Color(0x60000000)).clickable(
                                indication = null, interactionSource = remember { MutableInteractionSource() }
                            ) { showSelfChatInfo = false }, contentAlignment = Alignment.Center) {
                                Column(
                                    Modifier.fillMaxWidth(0.85f).background(Color.White, RoundedCornerShape(14.dp))
                                        .padding(horizontal = 24.dp, vertical = 28.dp)
                                ) {
                                    Text("个人对话", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1F2937))
                                    Spacer(Modifier.height(12.dp))
                                    Text("• 这是个人对话（类似文件传输助手），仅你可见", fontSize = 14.sp, color = Color(0xFF6B7280))
                                    Spacer(Modifier.height(6.dp))
                                    Text("• 发出的消息只保存在本地，不会发送到服务器", fontSize = 14.sp, color = Color(0xFF6B7280))
                                    Spacer(Modifier.height(6.dp))
                                    Text("• 卸载应用或清理数据后，此对话内的所有消息将永久丢失", fontSize = 14.sp, color = Color(0xFF6B7280))
                                    Spacer(Modifier.height(6.dp))
                                    Text("• 删除消息后无法恢复，请谨慎操作", fontSize = 14.sp, color = Color(0xFF6B7280))
                                    Spacer(Modifier.height(20.dp))
                                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                        Text("我知道了", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1E40AF),
                                            modifier = Modifier.clickable { showSelfChatInfo = false }.padding(horizontal = 16.dp, vertical = 8.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 开启新对话确认弹窗状态
            var showNewChatConfirm by remember { mutableStateOf(false) }

            // ── AI 对话「使用」面板（从右侧滑出：顶部 API 选择 + 中部性格调试）──
            if (showAiUsage) {
                // 把面板状态提升到 Dialog 之前，便于「离开即保存」
                var selMode by remember(currentUserId) { mutableStateOf(AiChatManager.getMode(ctx, currentUserId)) }
                val personal = AiChatManager.getPersonalConfig(ctx, currentUserId)
                var pKey by remember(currentUserId) { mutableStateOf(personal.first) }
                var pUrl by remember(currentUserId) { mutableStateOf(personal.second) }
                var pModel by remember(currentUserId) { mutableStateOf(personal.third) }
                var saveToken by remember(currentUserId) { mutableStateOf(AiChatManager.getSaveToken(ctx, currentUserId)) }
                var ultraSave by remember(currentUserId) { mutableStateOf(AiChatManager.getUltraSave(ctx, currentUserId)) }
                val traitLabels = AiChatManager.TRAIT_LABELS
                val traits = remember(currentUserId) {
                    mutableStateListOf<Float>().apply { addAll(AiChatManager.getTraits(ctx, currentUserId)) }
                }
                // 自定义性格设定（5 条维度之外额外添加的一条，按字面意思注入，不绑定任何维度）
                val customs = remember(currentUserId) {
                    mutableStateListOf<CustomTrait>().apply { addAll(AiChatManager.getCustomTraits(ctx, currentUserId)) }
                }
                var showCustomDialog by remember { mutableStateOf(false) }
                var customDialogText by remember { mutableStateOf("") }
                // 高级选项：场景 / 角色设定 / AI 多次输出（离开面板即保存）
                var advScenario by remember(currentUserId) { mutableStateOf(AiChatManager.getScenario(ctx, currentUserId)) }
                var advMyRole by remember(currentUserId) { mutableStateOf(AiChatManager.getMyRole(ctx, currentUserId)) }
                var advAiRole by remember(currentUserId) { mutableStateOf(AiChatManager.getAiRole(ctx, currentUserId)) }
                var advMulti by remember(currentUserId) { mutableStateOf(AiChatManager.getMultiOutput(ctx, currentUserId)) }
                var showReasoning by remember(currentUserId) { mutableStateOf(AiChatManager.getShowReasoning(ctx, currentUserId)) }
                var showAdvancedOptions by remember { mutableStateOf(false) }
                // 会员等级（0=非会员，1=普通会员，2=高级会员，3=尊享会员）：高级选项限会员使用
                var memberLevel by remember { mutableIntStateOf(0) }
                // 会员过期时间戳（0=永久）。isMember 为"有效期内的有效会员"：会员过期后即使 memberLevel>0 也视为非会员，
                // 从而让会员效益（导入/导出等）随会员到期自动消失。后端 respondMemberStatus 已算好 is_member。
                var memberExpiresAt by remember { mutableStateOf(0L) }
                var isMember by remember { mutableStateOf(false) }
                var showMemberGate by remember { mutableStateOf(false) }
                // ── 对话导出 / 导入 ──
                var showExportDialog by remember { mutableStateOf(false) }
                var expUserAvatar by remember { mutableStateOf(true) }
                var expAiAvatar by remember { mutableStateOf(true) }
                var expName by remember { mutableStateOf(true) }
                // 导出前全文替换（隐私保护）：勾选后在下方填写「被替换名称 → 占位符」
                var expReplace by remember { mutableStateOf(false) }
                // 导出场景信息（场景 + 角色设定）
                var expScene by remember { mutableStateOf(true) }
                // 左侧默认：人物1/人物2（新增续人物3…）；右侧默认：男主/女主（新增续 X1、X2…）
                val replaceFroms = remember { mutableStateListOf("人物1", "人物2") }
                val replaceTos = remember { mutableStateListOf("男主", "女主") }
                // 普通用户体验次数（各 2 次，按 userId 持久化）；会员不受限
                var exportUsed by remember(currentUserId) { mutableIntStateOf(LocalStorage.getExportUsedCount(ctx, currentUserId)) }
                var importUsed by remember(currentUserId) { mutableIntStateOf(LocalStorage.getImportUsedCount(ctx, currentUserId)) }
                var showTrialDialog by remember { mutableStateOf(false) }
                var trialAction by remember { mutableStateOf("export") } // "export" 或 "import"
                // 导入预览弹窗：选完文件后展示文件名/大小，并可设置人物对换与占位符还原
                var showImportDialog by remember { mutableStateOf(false) }
                var pendingImportUri by remember { mutableStateOf<android.net.Uri?>(null) }
                var importFileName by remember { mutableStateOf("") }
                var importFileSize by remember { mutableStateOf(0L) }
                var importSwap by remember { mutableStateOf(false) }
                var importMaps by remember { mutableStateOf(listOf<ImportMapItem>()) }
                // 导入场景信息（场景 + 角色设定）：勾选后替换当前设置，不勾选则保持现有设置
                var importScene by remember { mutableStateOf(true) }

                // ── AI 对话专属：时间点 / 确认发言 ──（已提升到 ChatConversationScreen 顶层，此处不再重复声明）


                // 上传头像到服务器，返回完整可访问 URL；失败返回空串（导出仍继续，不阻断）
                val tryUploadAvatar: suspend (Boolean, android.graphics.Bitmap?) -> String = { userCustom, bitmap ->
                    try {
                        val bytes: ByteArray? = if (userCustom) {
                            val f = LocalStorage.getMyAvatarFile(ctx, currentUserId)
                            if (f.exists()) f.readBytes() else null
                        } else {
                            bitmap?.let { bmp ->
                                val out = java.io.ByteArrayOutputStream()
                                bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
                                out.toByteArray()
                            }
                        }
                        if (bytes == null) {
                            if (userCustom) resolveMediaUrl("/api/avatar/$currentUserId") else ""
                        } else {
                            val res = com.aurora.chat.data.api.AuroraApi.uploadChatMedia(
                                bytes,
                                if (userCustom) "user_avatar.jpg" else "ai_avatar.png",
                                if (userCustom) "image/jpeg" else "image/png"
                            )
                            if (res.success && res.data != null) resolveMediaUrl(res.data!!.optString("url")) else ""
                        }
                    } catch (_: Exception) { "" }
                }

                // 从导入文件还原消息并追加到当前对话；swap=人物对换，maps=占位符→人物名称（仅勾选项生效）
                // swap 不再用于反转底层 isMine，改由确认导入时开启 reverseHistory 统一处理视角
                // swap：人物对换仅在导入时翻转本批消息数据（isMine + fromUserId 一起交换），不碰全局 reverseHistory
                val importConversationFromUri: suspend (android.net.Uri, Boolean, List<ImportMapItem>) -> Unit = { uri, swap, maps ->
                    run doImport@{
                        val jsonText: String? = try {
                            ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        } catch (e: Exception) {
                            null
                        }
                        if (jsonText == null) {
                            Toast.makeText(ctx, "读取文件失败", Toast.LENGTH_SHORT).show()
                            return@doImport
                        }
                        try {
                            val root = org.json.JSONObject(jsonText)
                            val arr = root.optJSONArray("messages")
                            if (arr == null) {
                                Toast.makeText(ctx, "文件内容无效", Toast.LENGTH_SHORT).show()
                                return@doImport
                            }
                            // 占位符→人物名称 还原映射（仅勾选且目标非空）
                            // 勾选框已移除：占位符与名称都非空即参与还原
                            val rev = maps.filter { it.placeholder.isNotBlank() && it.target.isNotBlank() }.associate { it.placeholder to it.target }
                            var nextId = (messages.maxOfOrNull { it.id } ?: 0L) + 1
                            val imported = mutableListOf<ChatMsg>()
                            for (i in 0 until arr.length()) {
                                val o = arr.getJSONObject(i)
                                var text = o.optString("text", "")
                                for ((ph, name) in rev) text = text.replace(ph, name)
                                var replyToText = o.optString("reply_to_text", "")
                                for ((ph, name) in rev) replyToText = replyToText.replace(ph, name)
                                val origIsMine = o.optBoolean("is_mine", false)
                                val origFrom = o.optLong("from_user_id", 0L)
                                // 人物对换：导入时直接翻转底层数据（isMine 与 fromUserId 同步交换）。
                                // 头像按 fromUserId 取、左右按 isMine 取，二者一起翻才不会"双方都是我的头像"；
                                // 且只影响本批导入消息，不碰全局 reverseHistory，避免污染整段对话/卡死。
                                val newIsMine = if (swap) !origIsMine else origIsMine
                                val newFrom = if (swap) (if (origFrom == currentUserId) friendId else currentUserId) else origFrom
                                val newSender = if (swap) (if (origFrom == currentUserId) friendName else currentUserName) else o.optString("sender_name", "")
                                imported.add(ChatMsg.create(
                                    serverId = nextId++,
                                    text = text,
                                    isMine = newIsMine,
                                    fromUserId = newFrom,
                                    isNew = false,
                                    senderName = newSender,
                                    createdAt = o.optLong("created_at", 0L),
                                    mediaType = o.optString("media_type", ""),
                                    mediaUrl = o.optString("media_url", ""),
                                    replyToText = replyToText,
                                    replyToSender = o.optString("reply_to_sender", ""),
                                    replyToId = o.optLong("reply_to_id", 0L),
                                    isRevoked = o.optInt("revoked", 0),
                                    wornBadge = o.optInt("worn_badge", 0),
                                    flashDuration = o.optInt("flash_duration", 0),
                                    reasoningText = o.optString("reasoning_text", "")
                                ))
                            }
                            messages.addAll(imported.sortedBy { if (it.createdAt == 0L) Long.MAX_VALUE else it.createdAt })
                            saveLocalChatMessages(ctx, currentUserId, localChatKey(friendId), messages.filter { !it.isSystemNotice })
                            // 好友（服务端）对话：导入的消息服务端不会保存，重载会丢失，额外存到本地兜底
                            if (!isLocalChat(friendId)) {
                                saveImportedMessages(ctx, currentUserId, friendId, imported.toList())
                            }

                            // ── 导入头像：从 JSON meta 读取头像 URL，下载到临时文件并覆盖 AiAvatarState.bitmap ──
                            // 每次导入生成一个唯一 ID，临时头像文件以 import_avatar_<uuid>.png 命名（cacheDir），
                            // 不覆盖用户的正式 AI 头像（LocalStorage.getAiAvatarFile）。用户后续手动修改 AI 头像后
                            // 这个临时头像自然被废弃（AiAvatarState.bitmap 被用户新头像替换），旧临时文件不会被删除，
                            // 但不再被引用，最终会被系统清理。
                            try {
                                val meta = root.optJSONObject("meta")
                                if (meta != null) {
                                    val avatarUrl = meta.optString("ai_avatar_url", "")
                                    if (avatarUrl.isNotEmpty()) {
                                        scope.launch {
                                            try {
                                                val bytes = com.aurora.chat.data.api.HttpClient.downloadBytes(avatarUrl)
                                                val bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                                if (bmp != null) {
                                                    val importAvatarId = java.util.UUID.randomUUID().toString()
                                                    val tempFile = java.io.File(ctx.cacheDir, "import_avatar_${importAvatarId}.png")
                                                    tempFile.outputStream().use { os -> bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, os) }
                                                    AiAvatarState.bitmap = bmp
                                                }
                                            } catch (_: Exception) {}
                                        }
                                    }
                                }
                            } catch (_: Exception) {}

                            // ── 导入场景信息：勾选后替换当前设置，不勾选则保持现有设置 ──
                            if (importScene) {
                                try {
                                    val meta = root.optJSONObject("meta")
                                    if (meta != null) {
                                        val sceneInfo = meta.optJSONObject("scene_info")
                                        if (sceneInfo != null) {
                                            val scene = sceneInfo.optString("scenario", "")
                                            val myRole = sceneInfo.optString("my_role", "")
                                            val aiRole = sceneInfo.optString("ai_role", "")
                                            if (scene.isNotEmpty()) {
                                                AiChatManager.setScenario(ctx, currentUserId, scene)
                                                advScenario = scene
                                            }
                                            if (myRole.isNotEmpty()) {
                                                AiChatManager.setMyRole(ctx, currentUserId, myRole)
                                                advMyRole = myRole
                                            }
                                            if (aiRole.isNotEmpty()) {
                                                AiChatManager.setAiRole(ctx, currentUserId, aiRole)
                                                advAiRole = aiRole
                                            }
                                        }
                                    }
                                } catch (_: Exception) {}
                            }

                            Toast.makeText(ctx, "已导入 ${imported.size} 条消息", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "导入失败：${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                // 读取导入文件中的占位符映射（导出时写入 meta.replace_map），用于导入时还原为人物名称
                fun readReplaceMap(c: android.content.Context, uri: android.net.Uri): List<ImportMapItem> {
                    return try {
                        val text = c.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return emptyList()
                        val root = org.json.JSONObject(text)
                        val meta = root.optJSONObject("meta") ?: return emptyList()
                        val mapArr = meta.optJSONArray("replace_map") ?: return emptyList()
                        val list = mutableListOf<ImportMapItem>()
                        for (i in 0 until mapArr.length()) {
                            val m = mapArr.getJSONObject(i)
                            val from = m.optString("from", "")
                            val to = m.optString("to", "")
                            if (to.isNotEmpty()) list.add(ImportMapItem(placeholder = to, target = from, checked = true))
                        }
                        list
                    } catch (_: Exception) {
                        emptyList()
                    }
                }

                // 全文替换：把文本中所有「被替换名称」依次替换为对应占位符（隐私保护）
                fun applyReplace(text: String): String {
                    var t = text
                    for (i in replaceFroms.indices) {
                        val f = replaceFroms[i].trim()
                        if (f.isNotEmpty()) t = t.replace(f, replaceTos[i])
                    }
                    return t
                }

                // 构建导出 JSON：对话始终导出；头像按需上传服务器，文件只存服务器 URL
                val buildExportJson: suspend () -> String = {
                    val root = org.json.JSONObject()
                    root.put("app", "AuroraChat")
                    root.put("type", "conversation")
                    root.put("version", 1)
                    root.put("exported_at", System.currentTimeMillis())
                    root.put("friend_id", AI_CHAT_ID)
                    val meta = org.json.JSONObject()
                    if (expName) {
                        val uname = com.aurora.chat.data.api.AuroraApi.currentUserName
                        val aname = AiNameState.name ?: "DeepSeek"
                        meta.put("user_name", if (expReplace) applyReplace(uname) else uname)
                        meta.put("ai_name", if (expReplace) applyReplace(aname) else aname)
                    }
                    if (expUserAvatar) {
                        val url = tryUploadAvatar(true, null)
                        if (url.isNotEmpty()) meta.put("user_avatar_url", url)
                    }
                    if (expAiAvatar) {
                        val url = tryUploadAvatar(false, AiAvatarState.bitmap)
                        if (url.isNotEmpty()) meta.put("ai_avatar_url", url)
                    }
                    if (expScene) {
                        val scene = advScenario.trim()
                        val myRole = advMyRole.trim()
                        val aiRole = advAiRole.trim()
                        val sceneObj = org.json.JSONObject()
                        if (scene.isNotEmpty()) sceneObj.put("scenario", scene)
                        if (myRole.isNotEmpty()) sceneObj.put("my_role", myRole)
                        if (aiRole.isNotEmpty()) sceneObj.put("ai_role", aiRole)
                        if (sceneObj.length() > 0) meta.put("scene_info", sceneObj)
                    }
                    // 导出替换映射，便于导入时一键还原为人物名称
                    if (expReplace) {
                        val rm = org.json.JSONArray()
                        for (i in replaceFroms.indices) {
                            val f = replaceFroms[i].trim()
                            if (f.isNotEmpty()) {
                                rm.put(org.json.JSONObject().apply {
                                    put("from", f)
                                    put("to", replaceTos[i])
                                })
                            }
                        }
                        if (rm.length() > 0) meta.put("replace_map", rm)
                    }
                    root.put("meta", meta)
                    val arr = org.json.JSONArray()
                    for (m in messages) {
                        val o = org.json.JSONObject()
                        o.put("id", m.id)
                        o.put("text", if (expReplace) applyReplace(m.text) else m.text)
                        o.put("is_mine", m.isMine)
                        o.put("from_user_id", m.fromUserId)
                        o.put("sender_name", if (expReplace) applyReplace(m.senderName) else m.senderName)
                        o.put("created_at", m.createdAt)
                        o.put("media_type", m.mediaType)
                        o.put("media_url", m.mediaUrl)
                        o.put("reply_to_text", if (expReplace) applyReplace(m.replyToText) else m.replyToText)
                        o.put("reply_to_sender", if (expReplace) applyReplace(m.replyToSender) else m.replyToSender)
                        o.put("reply_to_id", m.replyToId)
                        o.put("revoked", m.isRevoked)
                        o.put("worn_badge", m.wornBadge)
                        o.put("flash_duration", m.flashDuration)
                        o.put("reasoning_text", m.reasoningText)
                        arr.put(o)
                    }
                    root.put("messages", arr)
                    root.toString()
                }

                val exportSaver = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.CreateDocument("application/json")
                ) { uri ->
                    if (uri != null) {
                        scope.launch {
                            try {
                                val json = buildExportJson()
                                ctx.contentResolver.openOutputStream(uri)?.use { os ->
                                    os.write(json.toByteArray(Charsets.UTF_8))
                                }
                                Toast.makeText(ctx, "对话已导出到本地", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "导出失败：${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
                val importPicker = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument()
                ) { uri ->
                    if (uri != null) {
                        var name = "对话文件.json"
                        var size = 0L
                        try {
                            ctx.contentResolver.query(
                                uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME, android.provider.OpenableColumns.SIZE), null, null, null
                            )?.use { c ->
                                if (c.moveToFirst()) {
                                    val ni = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                                    val si = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                                    if (ni >= 0) name = c.getString(ni) ?: name
                                    if (si >= 0) size = c.getLong(si)
                                }
                            }
                        } catch (_: Exception) {}
                        importFileName = name
                        importFileSize = size
                        importSwap = false
                        importScene = true
                        importMaps = readReplaceMap(ctx, uri)
                        pendingImportUri = uri
                        showImportDialog = true
                    }
                }

                // 点击导出/导入入口：会员直接放行；普通用户走体验次数 / 会员专享弹窗
                // 必须在 importPicker 声明之后定义，否则 Kotlin 标记 unresolved reference
                fun requestUse(action: String) {
                    if (isMember) {
                        if (action == "export") showExportDialog = true
                        else importPicker.launch(arrayOf("application/json", "*/*"))
                    } else {
                        val used = if (action == "export") exportUsed else importUsed
                        val limit = if (action == "export") LocalStorage.getExportTrialLimit() else LocalStorage.getImportTrialLimit()
                        if (used >= limit) {
                            showMemberGate = true
                        } else {
                            trialAction = action
                            showTrialDialog = true
                        }
                    }
                }

                LaunchedEffect(Unit) {
                    scope.launch {
                        try {
                            val res = AuroraApi.memberStatus()
                            if (res.success && res.data != null) {
                                val d = if (res.data!!.has("data")) res.data!!.optJSONObject("data") ?: res.data!! else res.data!!
                                memberLevel = d.optInt("member_level", 0)
                                memberExpiresAt = d.optLong("member_expires_at", 0L)
                                // 后端已根据 member_expires_at 计算好是否仍有效：过期会员 is_member=false
                                isMember = d.optBoolean("is_member", false)
                            }
                        } catch (_: Exception) {}
                    }
                }

                // 实时用量：与对话流式过程共享 aiUsageState，AI 边输出边刷新（不再等对话结束）
                val (used, remaining) = aiUsageState.value
                // 打开面板时动态从服务器拉取最新余额，保证「剩余」是最新值
                LaunchedEffect(Unit) {
                    scope.launch {
                        AiChatManager.syncServerLimit(ctx, currentUserId)
                        aiUsageState.value = AiChatManager.getOfficialUsage(ctx, currentUserId)
                    }
                }

                // 离开面板即保存全部设置，并弹出提示；仅当性格确有修改时标记下一条请求注入新性格
                val saveAiUsageAndClose: () -> Unit = {
                    val stored = AiChatManager.getTraits(ctx, currentUserId)
                    val traitsChanged = stored.zip(traits) { a, b -> a != b }.any { it }
                    AiChatManager.saveTraits(ctx, currentUserId, traits)
                    AiChatManager.saveCustomTraits(ctx, currentUserId, customs)
                    AiChatManager.setMode(ctx, currentUserId, selMode)
                    if (selMode == "personal" && pKey.isNotBlank()) {
                        AiChatManager.savePersonalConfig(ctx, currentUserId, pKey, pUrl, pModel)
                    }
                    if (traitsChanged) AiChatManager.setPersonaSwitch(ctx, currentUserId, true)
                    // 高级选项：离开面板即保存（按用户填写的设定运行）
                    AiChatManager.setScenario(ctx, currentUserId, advScenario)
                    AiChatManager.setMyRole(ctx, currentUserId, advMyRole)
                    AiChatManager.setAiRole(ctx, currentUserId, advAiRole)
                    AiChatManager.setMultiOutput(ctx, currentUserId, advMulti)
                    AiChatManager.setShowReasoning(ctx, currentUserId, showReasoning)
                    android.widget.Toast.makeText(ctx, "已保存设置", android.widget.Toast.LENGTH_SHORT).show()
                    showAiUsage = false
                }

                Dialog(
                    onDismissRequest = { saveAiUsageAndClose() },
                    properties = DialogProperties(usePlatformDefaultWidth = false)
                ) {
                    // 让该 Dialog 窗口不拦截系统栏 insets，使 Compose 能读到状态栏/导航栏/圆角真实高度
                    val view = LocalView.current
                    LaunchedEffect(Unit) {
                        // 在 effect 内实时查找 Dialog 窗口（组合期 LocalView 可能尚未挂到 DialogWindowProvider，导致 remember 缓存到 null）
                        val dlg = generateSequence<android.view.View>(view) { it.parent as? android.view.View }
                            .filterIsInstance<DialogWindowProvider>().firstOrNull()
                        dlg?.window?.let { w ->
                            // 清掉半透明 flag，否则状态栏/导航栏会透出系统默认灰色
                            w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                            w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
                            WindowCompat.setDecorFitsSystemWindows(w, false)
                            // 强制状态栏/导航栏渲染为白色（覆盖系统默认灰色），并让图标为深色以在白底上可见
                            w.statusBarColor = android.graphics.Color.WHITE
                            w.navigationBarColor = android.graphics.Color.WHITE
                            WindowCompat.getInsetsController(w, view)?.apply {
                                isAppearanceLightStatusBars = true
                                isAppearanceLightNavigationBars = true
                            }
                        }
                    }
                    Box(Modifier.fillMaxSize()) {
                        // 全屏「使用」界面：从右侧滑入，覆盖整个屏幕（不再是大弹窗）
                        androidx.compose.animation.AnimatedVisibility(
                            visible = true,
                            modifier = Modifier.align(Alignment.CenterEnd),
                            enter = slideInHorizontally(initialOffsetX = { it }),
                            exit = slideOutHorizontally(targetOffsetX = { it })
                        ) {
                            Column(Modifier.fillMaxSize().background(Color.White).safeDrawingPadding().imePadding()) {
                                // 顶部固定栏：标题 + 关闭
                                Row(
                                    Modifier.fillMaxWidth().padding(top = 20.dp, start = 20.dp, end = 20.dp, bottom = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("DeepSeek 使用", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1F2937), modifier = Modifier.weight(1f))
                                    Text("✕", fontSize = 20.sp, color = Color(0xFF6B7280),
                                        modifier = Modifier.clickable { saveAiUsageAndClose() }.padding(4.dp))
                                }
                                HorizontalDivider(color = Color(0xFFE5E7EB))

                                // 中部可滚动内容
                                Column(
                                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp)
                                ) {
                                    // 官方 API
                                    Row(
                                        Modifier.fillMaxWidth().clickable { selMode = "official" }.padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(selected = selMode == "official", onClick = { selMode = "official" })
                                        Column(Modifier.weight(1f)) {
                                            Text("使用官方 API", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                                            val isDev = AiChatManager.isDeveloper(ctx, currentUserId)
                                            if (isDev) {
                                                Text("剩余 无限（开发者）", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                                Text("今日已用 $used tokens", fontSize = 12.sp, color = Color(0xFF6B7280))
                                            } else {
                                                val realRemaining = if (remaining >= 0L) (remaining - used).coerceAtLeast(0) else -1L
                                                val remainTxt = if (realRemaining >= 0L) "$realRemaining tokens" else "加载中…"
                                                Text("剩余 $remainTxt", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                                Text("今日已用 $used tokens", fontSize = 12.sp, color = Color(0xFF6B7280))
                                            }
                                        }
                                    }

                                    // 个人 API
                                    Row(
                                        Modifier.fillMaxWidth().clickable { selMode = "personal" }.padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(selected = selMode == "personal", onClick = { selMode = "personal" })
                                        Column(Modifier.weight(1f)) {
                                            Text("使用个人 API", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                                            Text("用自己的密钥，不受额度限制", fontSize = 12.sp, color = Color(0xFF6B7280))
                                        }
                                    }

                                    if (selMode == "personal") {
                                        Spacer(Modifier.height(10.dp))
                                        OutlinedTextField(
                                            value = pKey, onValueChange = { pKey = it },
                                            label = { Text("API Key") }, singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = pUrl, onValueChange = { pUrl = it },
                                            label = { Text("Base URL（如 https://api.deepseek.com/v1）") }, singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = pModel, onValueChange = { pModel = it },
                                            label = { Text("模型名（如 deepseek-chat）") }, singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    Spacer(Modifier.height(16.dp))

                                    // 节省 Token 模式
                                    val toggleSaveToken: (Boolean) -> Unit = { on ->
                                        saveToken = on
                                        AiChatManager.setSaveToken(ctx, currentUserId, on)
                                        // 切换时记录下一条请求要注入的指令：开启→约束，关闭→解除
                                        AiChatManager.setSaveTokenCmd(ctx, currentUserId, if (on) "constraint" else "release")
                                    }
                                    Row(
                                        Modifier.fillMaxWidth().clickable { toggleSaveToken(!saveToken) }.padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text("节省 Token 模式", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                                            Text(
                                                if (saveToken) "已开启：要求 AI 精简输出、减少冗余" else "关闭：正常输出，不强制精简",
                                                fontSize = 12.sp, color = Color(0xFF6B7280)
                                            )
                                        }
                                        Switch(checked = saveToken, onCheckedChange = toggleSaveToken)
                                    }

                                    Spacer(Modifier.height(8.dp))

                                    // 极致节省模式
                                    val toggleUltraSave: (Boolean) -> Unit = { on ->
                                        ultraSave = on
                                        AiChatManager.setUltraSave(ctx, currentUserId, on)
                                        // 开启时清除性格相关状态，确保下一条请求按「恢复正常」注入
                                        if (on) {
                                            AiChatManager.setPersonaCmd(ctx, currentUserId, "")
                                            AiChatManager.setPersonaApplied(ctx, currentUserId, false)
                                        }
                                    }
                                    Row(
                                        Modifier.fillMaxWidth().clickable { toggleUltraSave(!ultraSave) }.padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text("极致节省模式", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                                            Text(
                                                if (ultraSave) "已开启：性格调试关闭，去除所有指令" else "关闭：性格调试正常运行，不干扰使用",
                                                fontSize = 12.sp, color = Color(0xFF6B7280)
                                            )
                                        }
                                        Switch(checked = ultraSave, onCheckedChange = toggleUltraSave)
                                    }

                                    // 高级选项（所有人可展开查看；非会员控件锁定，点击开关弹会员提示）
                                    Row(
                                        Modifier.fillMaxWidth().clickable { showAdvancedOptions = !showAdvancedOptions }.padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("高级选项", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                                        Spacer(Modifier.weight(1f))
                                        if (memberLevel < 1) {
                                            Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFFEF3C7)) {
                                                Text("会员", fontSize = 11.sp, color = Color(0xFFB45309), modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                            }
                                            Spacer(Modifier.width(6.dp))
                                        }
                                        Text(if (showAdvancedOptions) "收起" else "展开", fontSize = 12.sp, color = Color(0xFF6B7280))
                                        Icon(
                                            imageVector = if (showAdvancedOptions) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                                            contentDescription = null, tint = Color(0xFF6B7280), modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    if (showAdvancedOptions) {
                                        Column(
                                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                                .background(Color(0xFFF9FAFB)).padding(12.dp)
                                        ) {
                                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                                Text("场景", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                                                Spacer(Modifier.weight(1f))
                                                TextButton(onClick = {
                                                    advScenario = ""
                                                    AiChatManager.setScenario(ctx, currentUserId, "")
                                                }) {
                                                    Text("清空", fontSize = 11.sp, color = Color(0xFF6B7280))
                                                }
                                            }
                                            Spacer(Modifier.height(4.dp))
                                            Box(Modifier.fillMaxWidth()) {
                                                OutlinedTextField(
                                                    value = advScenario, onValueChange = { advScenario = it },
                                                    enabled = true,
                                                    placeholder = { Text("例如：你们在一艘太空飞船上", color = Color(0xFF9CA3AF)) },
                                                    singleLine = false, modifier = Modifier.fillMaxWidth().height(72.dp)
                                                )
                                            }
                                            Spacer(Modifier.height(10.dp))
                                            Text("你的角色设定", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                                Text("你在对话中扮演的身份（用户本人）", fontSize = 11.sp, color = Color(0xFF6B7280))
                                                Spacer(Modifier.weight(1f))
                                                TextButton(onClick = {
                                                    advMyRole = ""
                                                    AiChatManager.setMyRole(ctx, currentUserId, "")
                                                }) {
                                                    Text("清空", fontSize = 11.sp, color = Color(0xFF6B7280))
                                                }
                                            }
                                            Spacer(Modifier.height(4.dp))
                                            Box(Modifier.fillMaxWidth()) {
                                                OutlinedTextField(
                                                    value = advMyRole, onValueChange = { advMyRole = it },
                                                    enabled = true,
                                                    placeholder = { Text("例如：一名舰长", color = Color(0xFF9CA3AF)) },
                                                    singleLine = false, modifier = Modifier.fillMaxWidth().height(72.dp)
                                                )
                                            }
                                            Spacer(Modifier.height(10.dp))
                                            Text("AI 的角色设定", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                                Text("让 AI 扮演的身份", fontSize = 11.sp, color = Color(0xFF6B7280))
                                                Spacer(Modifier.weight(1f))
                                                TextButton(onClick = {
                                                    advAiRole = ""
                                                    AiChatManager.setAiRole(ctx, currentUserId, "")
                                                }) {
                                                    Text("清空", fontSize = 11.sp, color = Color(0xFF6B7280))
                                                }
                                            }
                                            Spacer(Modifier.height(4.dp))
                                            Box(Modifier.fillMaxWidth()) {
                                                OutlinedTextField(
                                                    value = advAiRole, onValueChange = { advAiRole = it },
                                                    enabled = true,
                                                    placeholder = { Text("例如：飞船的人工智能助手", color = Color(0xFF9CA3AF)) },
                                                    singleLine = false, modifier = Modifier.fillMaxWidth().height(72.dp)
                                                )
                                            }
                                            Spacer(Modifier.height(12.dp))
                                            Row(
                                                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(Modifier.weight(1f)) {
                                                    Text("AI 多次输出", fontSize = 14.sp, color = Color(0xFF1F2937))
                                                    Text("开启后 AI 可自行决定是否分多条短消息回复（如追问、分段），而非一次输出一大段", fontSize = 11.sp, color = Color(0xFF6B7280))
                                                }
                                                Spacer(Modifier.width(12.dp))
                                                Switch(checked = advMulti, onCheckedChange = { advMulti = it })
                                            }
                                            Spacer(Modifier.height(8.dp))
                                            Row(
                                                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(Modifier.weight(1f)) {
                                                    Text("显示思考过程", fontSize = 14.sp, color = Color(0xFF1F2937))
                                                    Text("开启后 AI 在思考时实时显示思考内容，可折叠收起不占空间", fontSize = 11.sp, color = Color(0xFF6B7280))
                                                }
                                                Spacer(Modifier.width(12.dp))
                                                Switch(checked = showReasoning, onCheckedChange = {
                                                    showReasoning = it
                                                    AiChatManager.setShowReasoning(ctx, currentUserId, it)
                                                })
                                            }
                                        }
                                        Spacer(Modifier.height(4.dp))
                                    }

                                    Spacer(Modifier.height(16.dp))

                                    // 高峰期提示（不添加分割线）
                                    Text(
                                        "模型高峰期：9:00-12:00、14:00-18:00。建议在此时间段之外使用；如需在高峰期使用，建议开启「节省 Token 模式」。",
                                        fontSize = 12.sp, color = Color(0xFF6B7280),
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp)
                                    )
                                    Spacer(Modifier.height(12.dp))

                                    // 开启新对话：动态渐变（同下载悬浮窗蓝粉流动效果），位于节省模式与性格调试之间
                                    val floatTrans = rememberInfiniteTransition()
                                    val floatT by floatTrans.animateFloat(
                                        initialValue = 0f, targetValue = 1f,
                                        animationSpec = infiniteRepeatable(
                                            animation = tween(durationMillis = 4000, easing = LinearEasing),
                                            repeatMode = RepeatMode.Restart
                                        )
                                    )
                                    val floatColors = listOf(
                                        0xFF38BDF8.toInt(), 0xFFEC4899.toInt(),
                                        0xFFF9A8D4.toInt(), 0xFF7DD3FC.toInt(), 0xFF38BDF8.toInt()
                                    )
                                    fun lerpFloatColor(tt: Float): Int {
                                        val seg = (floatColors.size - 1) * tt
                                        val i = seg.toInt().coerceIn(0, floatColors.size - 2)
                                        val f = seg - i
                                        val c1 = floatColors[i]; val c2 = floatColors[i + 1]
                                        val r = ((c1 shr 16 and 0xFF) * (1 - f) + (c2 shr 16 and 0xFF) * f).toInt()
                                        val g = ((c1 shr 8 and 0xFF) * (1 - f) + (c2 shr 8 and 0xFF) * f).toInt()
                                        val b = ((c1 and 0xFF) * (1 - f) + (c2 and 0xFF) * f).toInt()
                                        return 0xFF shl 24 or (r shl 16) or (g shl 8) or b
                                    }
                                    val g1 = Color(lerpFloatColor(floatT))
                                    val g2 = Color(lerpFloatColor((floatT + 0.5f) % 1f))
                                    // 同一行：左侧「开启新对话」+ 右侧「AI 沙盒」
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier.weight(1f)
                                                .background(Brush.linearGradient(colors = listOf(g1, g2)), RoundedCornerShape(50))
                                                .clickable { showNewChatConfirm = true }
                                                .padding(vertical = 9.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("开启新对话", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        }
                                        Box(
                                            modifier = Modifier.weight(1f)
                                                .background(Brush.linearGradient(colors = listOf(g1, g2)), RoundedCornerShape(50))
                                                .clickable { showAiUsage = false; onOpenAiSandbox() }
                                                .padding(vertical = 9.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("AI 沙盒", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                    Spacer(Modifier.height(12.dp))

                                    // AI 设置（左）+ 会员订阅（右）：合并原「上传/恢复头像」入口
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier.weight(1f)
                                                .background(Brush.linearGradient(colors = listOf(g1, g2)), RoundedCornerShape(50))
                                                .clickable { showAiSettingsDialog = true }
                                                .padding(vertical = 9.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("AI 设置", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        }
                                        Box(
                                            modifier = Modifier.weight(1f)
                                                .background(Brush.linearGradient(colors = listOf(g1, g2)), RoundedCornerShape(50))
                                                .clickable { onMemberSubscribe() }
                                                .padding(vertical = 9.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("会员订阅", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                    Spacer(Modifier.height(12.dp))

                                    // 对话导入 / 导出
                                    Text("对话管理", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1F2937))
                                    Spacer(Modifier.height(8.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier.weight(1f)
                                                .background(Brush.linearGradient(colors = listOf(g1, g2)), RoundedCornerShape(50))
                                                .clickable { requestUse("export") }
                                                .padding(vertical = 9.dp),
                                            contentAlignment = Alignment.Center
                                        ) { Text("导出对话", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
                                        Box(
                                            modifier = Modifier.weight(1f)
                                                .background(Brush.linearGradient(colors = listOf(g1, g2)), RoundedCornerShape(50))
                                                .clickable { requestUse("import") }
                                                .padding(vertical = 9.dp),
                                            contentAlignment = Alignment.Center
                                        ) { Text("导入对话", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
                                    }
                                    Spacer(Modifier.height(16.dp))

                                    if (showMemberGate) {
                                        MemberGateDialog(
                                            onDismiss = { showMemberGate = false },
                                            onSubscribe = onMemberSubscribe
                                        )
                                    }

                                    // 体验次数弹窗：普通用户点击导出/导入且仍有剩余次数时弹出
                                    if (showTrialDialog) {
                                        val isExport = trialAction == "export"
                                        val used = if (isExport) exportUsed else importUsed
                                        val limit = if (isExport) LocalStorage.getExportTrialLimit() else LocalStorage.getImportTrialLimit()
                                        val remaining = (limit - used).coerceAtLeast(0)
                                        AlertDialog(
                                            onDismissRequest = { showTrialDialog = false },
                                            containerColor = Color.White,
                                            title = {
                                                Text("会员专享体验", fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                                            },
                                            text = {
                                                Text(
                                                    "普通用户可使用此功能 $limit 次，您当前还剩 $remaining 次。\n升级会员后可无限制使用。",
                                                    fontSize = 14.sp, color = Color(0xFF374151)
                                                )
                                            },
                                            confirmButton = {
                                                TextButton(onClick = {
                                                    showTrialDialog = false
                                                    if (isExport) {
                                                        exportUsed += 1
                                                        LocalStorage.setExportUsedCount(ctx, currentUserId, exportUsed)
                                                        showExportDialog = true
                                                    } else {
                                                        importUsed += 1
                                                        LocalStorage.setImportUsedCount(ctx, currentUserId, importUsed)
                                                        importPicker.launch(arrayOf("application/json", "*/*"))
                                                    }
                                                }) {
                                                    Text(if (isExport) "确认导出" else "确认导入", color = Color(0xFF1E40AF), fontWeight = FontWeight.Medium)
                                                }
                                            },
                                            dismissButton = {
                                                TextButton(onClick = { showTrialDialog = false }) {
                                                    Text("取消", color = Color(0xFF6B7280))
                                                }
                                            }
                                        )
                                    }


                                    // 导出对话弹窗：勾选要附带的内容（对话记录始终导出）
                                    if (showExportDialog) {
                                        Dialog(onDismissRequest = { showExportDialog = false }) {
                                            Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                                                Column(
                                                    Modifier
                                                        .padding(20.dp)
                                                        .verticalScroll(rememberScrollState())
                                                ) {
                                                    Text("导出对话", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1F2937))
                                                    Spacer(Modifier.height(10.dp))
                                                    Text("对话记录始终导出，可选择是否附带以下内容：", fontSize = 13.sp, color = Color(0xFF6B7280))
                                                    Spacer(Modifier.height(8.dp))
                                                    // 第一排：用户头像 + AI 头像 同行
                                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Row(
                                                            Modifier.weight(1f).clickable { expUserAvatar = !expUserAvatar }.padding(vertical = 6.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Checkbox(checked = expUserAvatar, onCheckedChange = { expUserAvatar = it })
                                                            Spacer(Modifier.width(6.dp))
                                                            Text("用户头像", fontSize = 14.sp, color = Color(0xFF1F2937))
                                                        }
                                                        Row(
                                                            Modifier.weight(1f).clickable { expAiAvatar = !expAiAvatar }.padding(vertical = 6.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Checkbox(checked = expAiAvatar, onCheckedChange = { expAiAvatar = it })
                                                            Spacer(Modifier.width(6.dp))
                                                            Text("AI 头像", fontSize = 14.sp, color = Color(0xFF1F2937))
                                                        }
                                                    }
                                                    // 第二排：名字 + 场景信息 同行
                                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Row(
                                                            Modifier.weight(1f).clickable { expName = !expName }.padding(vertical = 6.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Checkbox(checked = expName, onCheckedChange = { expName = it })
                                                            Spacer(Modifier.width(6.dp))
                                                            Text("名字", fontSize = 14.sp, color = Color(0xFF1F2937))
                                                        }
                                                        Row(
                                                            Modifier.weight(1f).clickable { expScene = !expScene }.padding(vertical = 6.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Checkbox(checked = expScene, onCheckedChange = { expScene = it })
                                                            Spacer(Modifier.width(6.dp))
                                                            Text("场景信息", fontSize = 14.sp, color = Color(0xFF1F2937))
                                                        }
                                                    }
                                                    // 第三排：全文替换（单独一行）
                                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Row(
                                                            Modifier.weight(1f).clickable { expReplace = !expReplace }.padding(vertical = 6.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Checkbox(checked = expReplace, onCheckedChange = { expReplace = it })
                                                            Spacer(Modifier.width(6.dp))
                                                            Text("全文替换", fontSize = 14.sp, color = Color(0xFF1F2937))
                                                        }
                                                    }
                                                    // 全文替换：每行「被替换名称 → 占位符」，可增删
                                                    if (expReplace) {
                                                        Spacer(Modifier.height(10.dp))
                                                        Text("隐私保护：导出前将全文中的名称替换为占位符", fontSize = 12.sp, color = Color(0xFF6B7280))
                                                        Spacer(Modifier.height(6.dp))
                                                        // 占位符不可重复：找出出现次数 > 1 的非空占位符
                                                        val toTrimmed = replaceTos.map { it.trim() }
                                                        val dupTos = toTrimmed
                                                            .filter { it.isNotEmpty() }
                                                            .groupingBy { it }.eachCount()
                                                            .filter { it.value > 1 }.keys
                                                        val idxList = replaceFroms.indices.toList()
                                                        idxList.forEach { i ->
                                                            Row(
                                                                Modifier.fillMaxWidth(),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                            ) {
                                                                OutlinedTextField(
                                                                    value = replaceFroms[i],
                                                                    onValueChange = { replaceFroms[i] = it },
                                                                    placeholder = { Text("名称", fontSize = 12.sp) },
                                                                    singleLine = true,
                                                                    modifier = Modifier.weight(1f)
                                                                )
                                                                Text("→", fontSize = 13.sp, color = Color(0xFF6B7280))
                                                                val toVal = replaceTos[i].trim()
                                                                OutlinedTextField(
                                                                    value = replaceTos[i],
                                                                    onValueChange = { replaceTos[i] = it },
                                                                    placeholder = { Text("占位符", fontSize = 12.sp) },
                                                                    singleLine = true,
                                                                    isError = toVal.isNotEmpty() && toVal in dupTos,
                                                                    modifier = Modifier.weight(1f)
                                                                )
                                                                if (replaceFroms.size > 1) {
                                                                    Text(
                                                                        "✕",
                                                                        fontSize = 14.sp,
                                                                        color = Color(0xFFDC2626),
                                                                        modifier = Modifier.clickable {
                                                                            replaceFroms.removeAt(i)
                                                                            replaceTos.removeAt(i)
                                                                        }.padding(4.dp)
                                                                    )
                                                                }
                                                            }
                                                            Spacer(Modifier.height(6.dp))
                                                        }
                                                        if (dupTos.isNotEmpty()) {
                                                            Text("⚠ 占位符不能重复，否则所有人将合并成同一个名字，请修改后再导出", fontSize = 12.sp, color = Color(0xFFDC2626))
                                                            Spacer(Modifier.height(6.dp))
                                                        }
                                                        TextButton(onClick = {
                                                            replaceFroms.add("人物" + (replaceFroms.size + 1))
                                                            replaceTos.add("X" + (replaceTos.size - 1))
                                                        }) {
                                                            Text("+ 添加替换项", color = Color(0xFF1E40AF), fontSize = 13.sp)
                                                        }
                                                    }
                                                    Spacer(Modifier.height(16.dp))
                                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                                        TextButton(onClick = { showExportDialog = false }) { Text("取消") }
                                                        Spacer(Modifier.width(8.dp))
                                                        Button(onClick = {
                                                            if (expReplace) {
                                                                val tos = replaceTos.map { it.trim() }.filter { it.isNotEmpty() }
                                                                if (tos.size != tos.toSet().size) {
                                                                    Toast.makeText(ctx, "占位符不能重复，请修改后再导出", Toast.LENGTH_SHORT).show()
                                                                    return@Button
                                                                }
                                                            }
                                                            showExportDialog = false
                                                            exportSaver.launch("aurora_chat_${System.currentTimeMillis()}.json")
                                                        }) { Text("确认导出") }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // 导入对话预览弹窗：显示文件名/大小，可选择人物对换与占位符还原
                                    if (showImportDialog) {
                                        Dialog(onDismissRequest = { showImportDialog = false }) {
                                            Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                                                Column(
                                                    Modifier
                                                        .padding(20.dp)
                                                        .verticalScroll(rememberScrollState())
                                                ) {
                                                    Text("导入对话", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1F2937))
                                                    Spacer(Modifier.height(10.dp))
                                                    // 文件名
                                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                                        Text("文件：", fontSize = 13.sp, color = Color(0xFF6B7280))
                                                        Text(importFileName, fontSize = 14.sp, color = Color(0xFF1F2937), modifier = Modifier.weight(1f))
                                                    }
                                                    Spacer(Modifier.height(4.dp))
                                                    // 文件大小
                                                    val sizeTxt = when {
                                                        importFileSize < 1024 -> "${importFileSize} B"
                                                        importFileSize < 1024 * 1024 -> String.format("%.1f KB", importFileSize / 1024f)
                                                        else -> String.format("%.2f MB", importFileSize / 1024f / 1024f)
                                                    }
                                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                                        Text("大小：", fontSize = 13.sp, color = Color(0xFF6B7280))
                                                        Text(sizeTxt, fontSize = 14.sp, color = Color(0xFF1F2937))
                                                    }
                                                    Spacer(Modifier.height(10.dp))
                                                    // 人物对换
                                                    Row(
                                                        Modifier.fillMaxWidth().clickable { importSwap = !importSwap }.padding(vertical = 6.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Checkbox(checked = importSwap, onCheckedChange = { importSwap = it })
                                                        Spacer(Modifier.width(8.dp))
                                                        Column(Modifier.weight(1f)) {
                                                            Text("人物对换", fontSize = 14.sp, color = Color(0xFF1F2937))
                                                            Text("勾选后将导入的对话以对方视角呈现", fontSize = 12.sp, color = Color(0xFF6B7280))
                                                        }
                                                    }
                                                    // 场景信息导入
                                                    Spacer(Modifier.height(8.dp))
                                                    Row(
                                                        Modifier.fillMaxWidth().clickable { importScene = !importScene }.padding(vertical = 6.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Checkbox(checked = importScene, onCheckedChange = { importScene = it })
                                                        Spacer(Modifier.width(8.dp))
                                                        Column(Modifier.weight(1f)) {
                                                            Text("场景信息", fontSize = 14.sp, color = Color(0xFF1F2937))
                                                            Text("勾选后将导入文件中的场景和角色设定，替换当前设置", fontSize = 12.sp, color = Color(0xFF6B7280))
                                                        }
                                                    }
                                                    // 占位符转回人物名称（可多选、可增删；左侧占位符，右侧真实姓名）
                                                    Spacer(Modifier.height(8.dp))
                                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                                        Text("占位符转回人物名称", fontSize = 13.sp, color = Color(0xFF1F2937), modifier = Modifier.weight(1f))
                                                        TextButton(onClick = { importMaps = importMaps + ImportMapItem("", "", true) }) {
                                                            Text("+ 添加", fontSize = 12.sp, color = Color(0xFF1E40AF))
                                                        }
                                                    }
                                                    Spacer(Modifier.height(6.dp))
                                                    if (importMaps.isEmpty()) {
                                                        Text("点击「+ 添加」：左侧填占位符，右侧填要替换成的人物名称", fontSize = 12.sp, color = Color(0xFF6B7280))
                                                    } else {
                                                        importMaps.forEachIndexed { idx, item ->
                                                            Row(
                                                                Modifier.fillMaxWidth(),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                            ) {
                                                                OutlinedTextField(
                                                                    value = item.placeholder,
                                                                    onValueChange = { importMaps = importMaps.toMutableList().apply { this[idx] = this[idx].copy(placeholder = it) } },
                                                                    placeholder = { Text("占位符", fontSize = 12.sp) },
                                                                    singleLine = true,
                                                                    modifier = Modifier.width(88.dp)
                                                                )
                                                                Text("→", fontSize = 13.sp, color = Color(0xFF6B7280))
                                                                OutlinedTextField(
                                                                    value = item.target,
                                                                    onValueChange = { importMaps = importMaps.toMutableList().apply { this[idx] = this[idx].copy(target = it) } },
                                                                    placeholder = { Text("人物", fontSize = 12.sp) },
                                                                    singleLine = true,
                                                                    modifier = Modifier.weight(1f)
                                                                )
                                                                TextButton(onClick = { importMaps = importMaps.toMutableList().apply { removeAt(idx) } }) {
                                                                    Text("删除", fontSize = 12.sp, color = Color(0xFFDC2626))
                                                                }
                                                            }
                                                            Spacer(Modifier.height(6.dp))
                                                        }
                                                    }
                                                    Spacer(Modifier.height(16.dp))
                                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                                        TextButton(onClick = { showImportDialog = false }) { Text("取消") }
                                                        Spacer(Modifier.width(8.dp))
                                                        Button(onClick = {
                                                            showImportDialog = false
                                                            // 人物对换改为「导入时翻转本批消息数据」（见 importConversationFromUri），
                                                            // 不再开启全局 reverseHistory，避免它卡死并污染其他对话。
                                                            // 这里统一关掉全局反转，确保导入显示不被多余的显示层翻转干扰。
                                                            reverseHistory = false
                                                            LocalStorage.setReverseHistory(ctx, currentUserId, false)
                                                            val uri = pendingImportUri
                                                            if (uri != null) scope.launch {
                                                                importConversationFromUri(uri, importSwap, importMaps.toList())
                                                            }
                                                        }) { Text("确认导入") }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // 性格调试
                                    Text("性格调试", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1F2937))
                                    Spacer(Modifier.height(4.dp))
                                    Text("滑动调节 AI 的性格倾向（5 个维度总和不超过 100%，拖动一个会自动压缩其余维度，离开面板自动保存）", fontSize = 12.sp, color = Color(0xFF6B7280))
                                    Spacer(Modifier.height(4.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        val used = traits.sum().toInt()
                                        Text("已分配 $used% / 100%", fontSize = 12.sp,
                                            color = if (used > 100) Color(0xFFDC2626) else Color(0xFF6B7280))
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    traitLabels.forEachIndexed { i, label ->
                                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                            Text(label, fontSize = 14.sp, color = Color(0xFF374151), modifier = Modifier.width(48.dp))
                                            Slider(
                                                value = traits[i],
                                                onValueChange = { newVal ->
                                                    // 5 维总和上限 100：超出时按比例压缩其余维度
                                                    val old = traits[i]
                                                    val othersSum = traits.sum() - old
                                                    val v = newVal.coerceIn(0f, 100f)
                                                    if (v + othersSum <= 100f) {
                                                        traits[i] = v
                                                    } else if (othersSum > 0f) {
                                                        val scale = (100f - v) / othersSum
                                                        for (j in traits.indices) if (j != i) traits[j] = traits[j] * scale
                                                        traits[i] = v
                                                    } else {
                                                        traits[i] = 100f
                                                    }
                                                },
                                                valueRange = 0f..100f,
                                                modifier = Modifier.weight(1f),
                                                // 自定义轨道铺满整条，消除圆球左右默认留白（不能用负 padding，否则闪退）
                                                track = { positions ->
                                                    Box(
                                                        Modifier
                                                            .fillMaxWidth()
                                                            .height(6.dp)
                                                            .clip(RoundedCornerShape(3.dp))
                                                            .background(Color(0xFFE5E7EB))
                                                    ) {
                                                        Box(
                                                            Modifier
                                                                .fillMaxWidth((positions.value / 100f).coerceIn(0f, 1f))
                                                                .height(6.dp)
                                                                .clip(RoundedCornerShape(3.dp))
                                                                .background(Color(0xFF1E40AF))
                                                        )
                                                    }
                                                },
                                                thumb = {
                                                    Box(
                                                        Modifier
                                                            .size(22.dp)
                                                            .clip(CircleShape)
                                                            .background(Color(0xFF1E40AF))
                                                    )
                                                }
                                            )
                                        Text("${traits[i].toInt()}%", fontSize = 13.sp, color = Color(0xFF374151),
                                            modifier = Modifier.width(44.dp).padding(start = 4.dp))
                                        }
                                        Spacer(Modifier.height(10.dp))
                                    }
                                    // 极端（最后一条性格设定）下方：自定义入口，仅此一处，不绑定任何维度
                                    Text("＋ 自定义设定（在 5 条调试之外额外添加）", fontSize = 12.sp, color = Color(0xFF1E40AF),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { showCustomDialog = true; customDialogText = "" }
                                            .padding(vertical = 6.dp))
                                    Spacer(Modifier.height(8.dp))
                                    // 自定义设定列表（按字面意思注入，可调节权重）
                                    if (customs.isNotEmpty()) {
                                        Spacer(Modifier.height(8.dp))
                                        Text("已添加的自定义设定", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1F2937))
                                        Text("按字面意思注入，右侧可调节权重，点击 ✕ 删除", fontSize = 11.sp, color = Color(0xFF6B7280))
                                        Spacer(Modifier.height(8.dp))
                                        customs.forEachIndexed { ci, c ->
                                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Column(Modifier.weight(1f)) {
                                                    Text(c.text, fontSize = 13.sp, color = Color(0xFF374151))
                                                }
                                                Slider(
                                                    value = c.pct,
                                                    onValueChange = { customs[ci] = c.copy(pct = it) },
                                                    valueRange = 0f..100f,
                                                    modifier = Modifier.weight(1f),
                                                    track = { positions ->
                                                        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFFE5E7EB))) {
                                                            Box(Modifier.fillMaxWidth((positions.value / 100f).coerceIn(0f, 1f)).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF1E40AF))) {}
                                                        }
                                                    },
                                                    thumb = { Box(Modifier.size(22.dp).clip(CircleShape).background(Color(0xFF1E40AF))) {} }
                                                )
                                                Text("${c.pct.toInt()}%", fontSize = 12.sp, color = Color(0xFF374151),
                                                    modifier = Modifier.width(40.dp))
                                                Text("✕", fontSize = 14.sp, color = Color(0xFFDC2626),
                                                    modifier = Modifier.clickable { customs.removeAt(ci) }.padding(start = 4.dp, end = 2.dp))
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                }


                            }
                        }
                    }
                }

                // 自定义性格设定输入弹窗（位于 showAiUsage 块内，可访问 customs / showCustomDialog）
                if (showCustomDialog) {
                    AlertDialog(
                        onDismissRequest = { showCustomDialog = false; customDialogText = "" },
                        containerColor = Color.White,
                        title = { Text("自定义设定", fontWeight = FontWeight.Bold) },
                        text = {
                            OutlinedTextField(
                                value = customDialogText,
                                onValueChange = { customDialogText = it },
                                label = { Text("输入自定义内容（按字面意思注入）") },
                                placeholder = { Text("例如：回答时先给结论再展开") },
                                singleLine = false,
                                modifier = Modifier.fillMaxWidth().height(120.dp)
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                val txt = customDialogText.trim()
                                if (txt.isNotBlank()) customs.add(CustomTrait(txt, 50f))
                                showCustomDialog = false; customDialogText = ""
                            }) { Text("添加", color = Color(0xFF1E40AF)) }
                        },
                        dismissButton = {
                            TextButton(onClick = { showCustomDialog = false; customDialogText = "" }) { Text("取消", color = Color(0xFF6B7280)) }
                        }
                    )
                }
            }

            // ── AI 时间点弹窗（位于主聊天界面，不在 DeepSeek使用 面板内）──
            if (showTimePointDialog) {
                var customHour by remember { mutableStateOf("") }
                var customMinute by remember { mutableStateOf("00") }
                Dialog(onDismissRequest = { showTimePointDialog = false }) {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                        Column(Modifier.padding(20.dp).widthIn(min = 280.dp)) {
                            Text("设置时间点", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1F2937))
                            Spacer(Modifier.height(12.dp))
                            Text("快捷选择", fontSize = 14.sp, color = Color(0xFF6B7280))
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("早上 6:00" to "06:00", "中午 11:00" to "11:00", "晚上 18:00" to "18:00").forEach { (label, time) ->
                                    Box(
                                        Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(Color(0xFFF3F4F6))
                                            .clickable {
                                                showTimePointDialog = false
                                                currentTimePoint = "当前时间设定为：$time"
                                                AiChatManager.setTimePoint(ctx, currentUserId, "当前时间设定为：$time")
                                                val timeText = "设定时间点：$time"
                                                val timeMsg = ChatMsg.create(
                                                    serverId = System.currentTimeMillis() * 10000L + (0..9999).random(),
                                                    text = timeText, isMine = false, fromUserId = 0L,
                                                    isSystemNotice = true, isNew = true,
                                                    createdAt = System.currentTimeMillis() / 1000
                                                )
                                                messages.add(timeMsg)
                                                saveLocalChatMessages(ctx, currentUserId, "ai", messages.filter { !it.isSystemNotice })
                                                ChatViewModel.updateConversationPreview(friendId, timeText, System.currentTimeMillis() / 1000)
                                            }.padding(vertical = 10.dp, horizontal = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) { Text(label, fontSize = 13.sp, color = Color(0xFF1F2937)) }
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                            HorizontalDivider()
                            Spacer(Modifier.height(12.dp))
                            Text("自定义时间", fontSize = 14.sp, color = Color(0xFF6B7280))
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = customHour, onValueChange = { v -> if (v.all { it.isDigit() } && v.length <= 2) customHour = v },
                                    placeholder = { Text("时", fontSize = 13.sp) }, singleLine = true,
                                    modifier = Modifier.width(60.dp)
                                )
                                Text(" : ", fontSize = 16.sp, color = Color(0xFF1F2937))
                                OutlinedTextField(
                                    value = customMinute, onValueChange = { v -> if (v.all { it.isDigit() } && v.length <= 2) customMinute = v },
                                    placeholder = { Text("分", fontSize = 13.sp) }, singleLine = true,
                                    modifier = Modifier.width(60.dp)
                                )
                                Spacer(Modifier.width(12.dp))
                                Button(onClick = {
                                    val h = customHour.padStart(2, '0').take(2)
                                    val m = customMinute.padStart(2, '0').take(2)
                                    if (h.toIntOrNull() != null && h.toInt() in 0..23 && m.toIntOrNull() != null && m.toInt() in 0..59) {
                                        showTimePointDialog = false
                                        val time = "$h:$m"
                                        currentTimePoint = "当前时间设定为：$time"
                                        AiChatManager.setTimePoint(ctx, currentUserId, "当前时间设定为：$time")
                                        val timeText = "设定时间点：$time"
                                        val timeMsg = ChatMsg.create(
                                            serverId = System.currentTimeMillis() * 10000L + (0..9999).random(),
                                            text = timeText, isMine = false, fromUserId = 0L,
                                            isSystemNotice = true, isNew = true,
                                            createdAt = System.currentTimeMillis() / 1000
                                        )
                                        messages.add(timeMsg)
                                        saveLocalChatMessages(ctx, currentUserId, "ai", messages.filter { !it.isSystemNotice })
                                        ChatViewModel.updateConversationPreview(friendId, timeText, System.currentTimeMillis() / 1000)
                                    } else {
                                        android.widget.Toast.makeText(ctx, "请输入有效时间（0-23时，0-59分）", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }) { Text("确认", fontSize = 13.sp) }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { showTimePointDialog = false }) { Text("取消", color = Color(0xFF6B7280)) }
                            }
                        }
                    }
                }
            }

            // ── AI 确认发言弹窗（位于主聊天界面，不在 DeepSeek使用 面板内）──
            if (showConfirmSpeechDialog) {
                Dialog(onDismissRequest = { showConfirmSpeechDialog = false }) {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                        Column(Modifier.padding(20.dp).widthIn(min = 260.dp)) {
                            Text("确认发言", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1F2937))
                            Spacer(Modifier.height(12.dp))
                            Text(if (confirmSpeechEnabled) "当前已开启确认发言模式，AI 不会自动回复" else "开启后，AI 不会自动回复，需要手动确认后才回复",
                                fontSize = 14.sp, color = Color(0xFF6B7280))
                            Spacer(Modifier.height(16.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                TextButton(onClick = { showConfirmSpeechDialog = false }) { Text("取消", color = Color(0xFF6B7280)) }
                                if (confirmSpeechEnabled) {
                                    Button(onClick = {
                                        confirmSpeechEnabled = false
                                        AiChatManager.setConfirmSpeech(ctx, currentUserId, false)
                                        showConfirmSpeechDialog = false
                                        android.widget.Toast.makeText(ctx, "已关闭确认发言模式", android.widget.Toast.LENGTH_SHORT).show()
                                    }) { Text("关闭", color = Color.White) }
                                } else {
                                    Button(onClick = {
                                        confirmSpeechEnabled = true
                                        AiChatManager.setConfirmSpeech(ctx, currentUserId, true)
                                        showConfirmSpeechDialog = false
                                        android.widget.Toast.makeText(ctx, "已开启确认发言模式，AI 将不再自动回复", android.widget.Toast.LENGTH_SHORT).show()
                                    }) { Text("开启", color = Color.White) }
                                }
                            }
                        }
                    }
                }
            }

            // 开启新对话确认弹窗（清空 AI 对话全部记录）
            if (showNewChatConfirm) {
                AlertDialog(
                    onDismissRequest = { showNewChatConfirm = false },
                    containerColor = Color.White,
                    title = { Text("开启新对话", fontWeight = FontWeight.Bold) },
                    text = { Text("将清空当前 AI 对话的全部记录且无法恢复，确定要开启新对话吗？") },
                    confirmButton = {
                        TextButton(onClick = {
                            showNewChatConfirm = false
                            // 实际丢弃：清内存列表 + 覆盖本地文件为空 + 清缓存 + 重置预览 + 关闭面板
                            messages.clear()
                            companionMessageCache.remove(AI_CHAT_ID)
                            saveLocalChatMessages(ctx, currentUserId, "ai", emptyList())
                            ChatViewModel.updateConversationPreview(AI_CHAT_ID, "", 0)
                            showAiUsage = false
                            android.widget.Toast.makeText(ctx, "已开启新对话", android.widget.Toast.LENGTH_SHORT).show()
                        }) { Text("确定", color = Color(0xFFDC2626), fontWeight = FontWeight.SemiBold) }
                    },
                    dismissButton = {
                        TextButton(onClick = { showNewChatConfirm = false }) { Text("取消", color = Color(0xFF6B7280)) }
                    }
                )
            }

            // ── 入群申请横幅（仅群聊且是管理员/群主）──
            if (isGroupChat(friendId)) {
                // 合并到一个 LaunchedEffect：先获取角色，再启动监听和轮询
                LaunchedEffect(friendId) {
                    // 1. 获取当前用户在该群的角色
                    try {
                        val gid = -(friendId + 1000)
                        val info = AuroraApi.getGroupInfo(gid)
                        if (info.success && info.data != null) {
                            val role = info.data!!.optString("user_role", "")
                            val creatorId = info.data!!.optLong("creator_id", 0)
                            isAdminOrOwner = role == "owner" || role == "admin" || AuroraApi.currentUserId == 1L || creatorId == AuroraApi.currentUserId
                        }
                    } catch (_: Exception) {}

                    if (!isAdminOrOwner) return@LaunchedEffect

                    // 2. 首次加载申请数量
                    try {
                        val gid = -(friendId + 1000)
                        val r = AuroraApi.getJoinRequestCount(gid)
                        if (r.success && r.data != null) {
                            pendingCount = r.data!!.optInt("count", 0)
                        }
                    } catch (_: Exception) {}

                    // 3. 事件驱动监听：PendingJoinRequests 由 TCP 推送设置，不再轮询
                    launch {
                        // 仅通过 TCP 推送触发刷新，初始计数已在步骤 2 拉取
                        // 使用 3 秒间隔的轻量级标记检查（不调用 API）
                        while (true) {
                            delay(3000)
                            if (com.aurora.chat.PendingJoinRequests.hasUpdate &&
                                com.aurora.chat.PendingJoinRequests.groupConvId == friendId) {
                                com.aurora.chat.PendingJoinRequests.hasUpdate = false
                                try {
                                    val gid = -(friendId + 1000)
                                    val r = AuroraApi.getJoinRequestCount(gid)
                                    if (r.success && r.data != null) {
                                        pendingCount = r.data!!.optInt("count", 0)
                                    }
                                } catch (_: Exception) {}
                            }
                        }
                    }
                }

                if (isAdminOrOwner && pendingCount > 0) {
                    Box(Modifier.fillMaxWidth().background(Color(0xFFFFF3CD)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("有 $pendingCount 条入群申请", fontSize = 13.sp, color = Color(0xFF856404), modifier = Modifier.weight(1f))
                            Text("查看", fontSize = 13.sp, color = Color(0xFF1E40AF), fontWeight = FontWeight.Medium,
                                modifier = Modifier.clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() }
                                ) {
                                    scope.launch {
                                        try {
                                            val gid = -(friendId + 1000)
                                            val r = AuroraApi.getJoinRequests(gid)
                                            if (r.success && r.data != null) {
                                                onOpenJoinRequestFullScreen(r.data, gid)
                                            }
                                        } catch (_: Exception) {}
                                    }
                                }.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                    }
                }

                // ── 入群申请审批面板 ──
            }

            // 消息列表（用 Box + weight 避免 weight 直接放 LazyColumn 上导致 infinity 崩溃）
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(if (scrollReady || messages.isEmpty()) 1f else 0f) // 滚到底部前隐藏，防止闪现顶部；空列表/加载时仍需显示
                    .pointerInput(Unit) {
                        detectTapGestures {
                            // 点击空白区域关闭所有弹窗
                            openMenuMsgId = 0L
                            focusManager.clearFocus()
                            clearSelectionKey++
                            val imm = ctx.getSystemService(

                                android.content.Context.INPUT_METHOD_SERVICE
                            ) as android.view.inputmethod.InputMethodManager
                            imm.hideSoftInputFromWindow(view.windowToken, 0)
                        }
                    },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Box(
                            Modifier.fillMaxWidth().padding(vertical = 120.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isLoadingMessages) {
                                androidx.compose.foundation.layout.Column(
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    androidx.compose.material3.CircularProgressIndicator(
                                        strokeWidth = 3.dp,
                                        modifier = Modifier.size(32.dp),
                                        color = Color(0xFF9CA3AF)
                                    )
                                    Spacer(Modifier.height(12.dp))
                                    Text(
                                        "加载中...",
                                        fontSize = 14.sp, color = Color(0xFF9CA3AF)
                                    )
                                }
                            } else {
                                Text(
                                    "暂无消息",
                                    fontSize = 14.sp, color = Color(0xFF9CA3AF)
                                )
                            }
                        }
                    }
                } else {
                    itemsIndexed(
                        messages,
                        key = { _, msg -> msg.id },
                        contentType = { _, msg ->
                            val m = if (reverseHistory && !msg.isSystemNotice) (msg as ChatMsg).copy(
                                isMine = !msg.isMine,
                            ) else msg
                            if (m.isSystemNotice) "notice"
                            else if (m.isMine) "mine"
                            else "other"
                        }
                    ) { index, msg ->
                        // 人物对换：显示时整体反转（左右位置互换），不改变底层数据
                        // 注意：只翻 isMine（消息左右位置），不翻 fromUserId/senderName，
                        // 这样头像仍然跟着真正发消息的人走，只是两人座位互换。
                        val rmsg = if (reverseHistory && !msg.isSystemNotice) (msg as ChatMsg).copy(
                            isMine = !msg.isMine,
                        ) else msg
                        if (msg.id in deletedMessageIds) return@itemsIndexed
                        // 红包卡片（不居中，对齐到发送者头像侧；点击进入全屏领取界面）
                        if (msg.mediaType == "redpacket" || isRedPacketMessage(msg.text)) {
                            val rp = parseRedPacketMessage(msg.text)
                            if (rp != null) {
                                val senderAvatarMod = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp))
                                val myAvatar = if (friendId == AI_CHAT_ID) aiMyAvatarBitmap else myAvatarBitmap
                                @Composable
                                fun RedPacketSenderAvatar() {
                                    if (rp.fromUserId == currentUserId && myAvatar != null) {
                                        Image(bitmap = myAvatar.asImageBitmap(), contentDescription = null, modifier = senderAvatarMod, contentScale = ContentScale.Fit)
                                    } else {
                                        UserAvatar(userId = rp.fromUserId, userName = rp.fromName.ifEmpty { "?" }, size = 42.dp, modifier = senderAvatarMod)
                                    }
                                }
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = if (msg.isMine) Arrangement.End else Arrangement.Start
                                ) {
                                    if (!msg.isMine) {
                                        RedPacketSenderAvatar()
                                        Spacer(Modifier.width(6.dp))
                                    }
                                    RedPacketCardWithStatus(
                                        data = rp,
                                        isMine = msg.isMine,
                                        statusMap = redpacketStatus,
                                        onClick = { redPacketDetailId = rp.packetId }
                                    )
                                    if (msg.isMine) {
                                        Spacer(Modifier.width(6.dp))
                                        RedPacketSenderAvatar()
                                    }
                                }
                                return@itemsIndexed
                            }
                        }
                        // 转账卡片（群聊/私聊统一渲染，视角由 data 现算）
                        // 用正文前缀判断而非 mediaType，避免不同解析路径 media_type 丢失导致显示原文
                        if (msg.mediaType == "transfer" || isTransferMessage(msg.text)) {
                            val t = parseTransferMessage(msg.text)
                            if (t != null) {
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    TransferCard(data = t, currentUserId = currentUserId)
                                }
                                return@itemsIndexed
                            }
                        }
                        if (msg.isSystemNotice) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 10.dp)
                                    .combinedClickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null,
                                        onClick = {},
                                        onLongClick = { deleteConfirmMsgId = msg.id }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                val transferNotice = parseTransferNotice(msg.text)
                                if (transferNotice != null) {
                                    TransferNoticeCard(desc = transferNotice)
                                } else {
                                    val order = parseOrderNotice(msg.text)
                                    if (order != null) {
                                        OrderNoticeCard(data = order, onViewOrder = { viewOrderId = it })
                                    } else {
                                        Text(
                                            text = msg.text,
                                            fontSize = 12.sp,
                                            color = Color(0xFF9CA3AF),
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            maxLines = 2
                                        )
                                    }
                                }
                            }
                            return@itemsIndexed
                        }
                        //  LazyColumn 只 Compose 可见项，所有 Compose 出来的项都加载媒体
                        //   不用 layoutInfo — 避免快滑时每帧全量重组风暴
                        val loadMedia = msg.mediaUrl.isNotEmpty()
                        val showAbove = (messages.size - index) <= 3
                        //  图片预加载：LazyColumn 已保证只有近屏项才进入此块
                        if (loadMedia) {
                            LaunchedEffect(msg.mediaUrl) {
                                ctx.imageLoader.enqueue(
                                    ImageRequest.Builder(ctx)
                                        .data(resolveMediaUrl(msg.mediaUrl))
                                        .memoryCachePolicy(CachePolicy.ENABLED)
                                        .diskCachePolicy(CachePolicy.ENABLED)
                                        .size(720)
                                        .build()
                                )
                            }
                        }
                        val prevBubbleMsg = messages.getOrNull(index - 1)
                        val rprev = prevBubbleMsg?.let { if (reverseHistory && !it.isSystemNotice) (it as ChatMsg).copy(
                            isMine = !it.isMine,
                        ) else it }
                        val senderChanged = rprev != null
                            && !rprev.isSystemNotice && !rmsg.isSystemNotice
                            && rprev.isMine != rmsg.isMine
                        if (senderChanged) Spacer(Modifier.height(10.dp))
                        MessageBubbleItem(
                            msg = rmsg,
                            loadMedia = loadMedia,
                            myAvatar = if (friendId == AI_CHAT_ID) aiMyAvatarBitmap else myAvatarBitmap,
                            currentUserId = currentUserId,
                            currentUserName = currentUserName,
                            friendId = friendId,
                            friendName = friendName,
                            animMode = animMode,
                            advancedAnim = advancedAnim,
                            onOpenPostDetail = onOpenPostDetail,
                            onOpenAiChatDetail = onOpenAiChatDetail,
                            onOpenGroupDetail = onOpenGroupDetail,
                            onOpenSourceCodeDetail = onOpenSourceCodeDetail,
                            isMenuOpen = openMenuMsgId == msg.id,
                            onMenuOpen = { openMenuMsgId = msg.id },
                            onMenuClose = { openMenuMsgId = 0L },
                            onAvatarClick = { uid, name ->
                                if (isGroupChat(friendId) && uid == friendId) {
                                    // 点击群系统消息头像 → 打开群设置
                                    showGroupSettings = true
                                } else {
                                    profileUserId = uid
                                    profileUserName = if (isGroupChat(friendId)) "" else name
                                    profileWornBadge = if (isGroupChat(friendId) && uid == friendId) 0 else wornBadge
                                    showProfile = true
                                }
                            },
                            onBadgeClick = { bid -> badgeDialogId = bid },
                            onDeleteMessage = { msgId -> deleteConfirmMsgId = msgId },
                            onCopyMessage = { text ->
                                try {
                                    val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("消息", text))
                                    Toast.makeText(ctx, "复制成功", Toast.LENGTH_SHORT).show()
                                } catch (_: Exception) {
                                    Toast.makeText(ctx, "复制失败", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onReplyTo = { replyToMsg.value = msg },
                            onEditMessage = { target ->
                                editTargetMsgId = target.id
                                editReasoningText = (target as? ChatMsg)?.reasoningText ?: ""
                                editOutputText = target.text
                                showEditDialog = true
                            },
                            clearSelectionKey = clearSelectionKey,
                            isHighlighted = msg.id == highlightedMsgId,
                            onCapsuleClick = { targetId ->
                                scope.launch {
                                    val targetIdx = messages.indexOfFirst { it.id == targetId }
                                    if (targetIdx >= 0) {
                                        listState.animateScrollToItem(targetIdx)
                                        // 等待滚动动画彻底完成后才开始闪烁
                                        while (listState.isScrollInProgress) {
                                            kotlinx.coroutines.delay(50)
                                        }
                                        kotlinx.coroutines.delay(100)
                                        highlightedMsgId = targetId
                                        kotlinx.coroutines.delay(1600)
                                        highlightedMsgId = 0L
                                    } else {
                                        android.widget.Toast.makeText(ctx, "未找到被引用的消息", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            destroyedFlashIds = destroyedFlashIds,
                            onFlashDestroy = { id -> saveDestroyedFlash(id) },
                            onAtMention = { userName ->
                                inputText += "@${userName} "
                                view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                            },
                            onAvatarLongPress = { uid, name ->
                                if (friendId > 0) {
                                    // 私信：长按对方头像粘贴名称（自己头像不做操作）
                                    if (uid != currentUserId) {
                                        inputText += name
                                        view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                                    }
                                } else {
                                    // 群聊：保持 @mention
                                    inputText += "@${name} "
                                    view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                                }
                            },
                            onAvatarDoubleTap = { uid, name ->
                                scope.launch {
                                    com.aurora.chat.data.repository.ChatRepository.sendPoke(uid)
                                }
                                val timeNow = System.currentTimeMillis()
                                val noticeText = if (uid == currentUserId) {
                                    "你拍了拍自己"
                                } else {
                                    "你拍了拍${name}"
                                }
                                val localId = 10000L + (timeNow % 900000) + 1
                                messages.add(ChatMsg(
                                    id = localId, text = noticeText, isMine = true,
                                    fromUserId = currentUserId, senderName = currentUserName.ifEmpty { "我" }, time = timeNow,
                                    isSystemNotice = true, isNew = true, createdAt = timeNow / 1000
                                ))
                            },
                            onAtMentionClick = { mentionedName ->
                                // 从群成员列表映射中查找被艾特的用户ID
                                val memberId = groupMemberIdMap[mentionedName]
                                if (memberId != null && memberId > 0) {
                                    profileUserId = memberId
                                    profileUserName = if (isGroupChat(friendId)) "" else mentionedName
                                    profileWornBadge = wornBadge
                                    showProfile = true
                                } else {
                                    // 回退：从消息列表中查找
                                    val found = messages.firstOrNull { it.senderName == mentionedName }
                                    if (found != null) {
                                        profileUserId = found.fromUserId
                                        profileUserName = if (isGroupChat(friendId)) "" else mentionedName
                                        profileWornBadge = wornBadge
                                        showProfile = true
                                    } else {
                                        Toast.makeText(ctx, "未找到该用户", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            isGroup = isGroupChat(friendId),
                            groupMemberNames = groupMemberNames,
                            onImageClick = { url ->
                                // 根据 mediaType 区分图片还是视频
                                val m = messages.find { msg -> msg.mediaUrl == url }
                                if (m?.mediaType == "video" || m?.mediaType == "mp4") {
                                    videoPlayUrl = url
                                } else {
                                    imagePreviewUrl = url
                                }
                            },
                            uploadProgressMap = uploadProgressMap,
                            onReasoningToggled = { expanded ->
                                if (expanded) {
                                    scope.launch {
                                        try { listState.scrollToItem(messages.size - 1, Int.MAX_VALUE) } catch (_: Exception) {}
                                    }
                                }
                            },
                            expandedReasoningMsgId = expandedReasoningMsgId
                        )

                    }
                }
            }

            // 删除确认弹窗
            if (deleteConfirmMsgId > 0L) {
                AlertDialog(
                    onDismissRequest = { deleteConfirmMsgId = 0L },
                    containerColor = Color.White,
                    title = { Text("确认删除", fontWeight = FontWeight.Bold) },
                    text = { Text(if (isNotificationChat(friendId)) "确认删除此条通知？删除后将从通知中心移除，且无法恢复。" else "确认删除此条消息，确认后将删除本地消息") },
                    confirmButton = {
                        TextButton(onClick = {
                            val targetId = deleteConfirmMsgId
                            // 本地对话额外：先删媒体文件
                            if (isLocalChat(friendId)) {
                                for (msg in messages) {
                                    if (msg.id == targetId && msg.mediaUrl.isNotEmpty()) {
                                        try { java.io.File(msg.mediaUrl.removePrefix("file://")).delete() } catch (_: Exception) {}
                                        break
                                    }
                                }
                            }
                            // === 所有对话统一用 deletedMessageIds（其他对话有效，self_chat 也一样） ===
                            val newDeleted = deletedMessageIds + targetId
                            deletedMessageIds = newDeleted
                            try {
                                val delFile = java.io.File(ctx.filesDir, "deleted_msgs_${currentUserId}.json")
                                val arr = org.json.JSONArray(newDeleted.toList())
                                delFile.writeText(arr.toString())
                            } catch (_: Exception) {}
                            if (isNotificationChat(friendId)) {
                                // 通知中心：从本地通知存储真正移除该条，避免重新进入又出现
                                try {
                                    val remaining = messages.filter { it.id != targetId }
                                    val toSave = remaining.map { m ->
                                        ChatMsg.create(
                                            serverId = m.id, text = m.text, isMine = m.isMine,
                                            isSystemNotice = m.isSystemNotice, createdAt = m.createdAt, isNew = false
                                        )
                                    }
                                    saveNotificationMessages(ctx, currentUserId, toSave)
                                } catch (_: Exception) {}
                            } else {
                                // 普通对话：更新会话列表预览（最后一条未删除消息）
                                val lastUndeleted = messages.lastOrNull { it.id !in newDeleted && (!it.isSystemNotice || it.flashDuration == -1) }
                                if (lastUndeleted != null) {
                                    val prev = when {
                                        lastUndeleted.mediaType == "image" || lastUndeleted.mediaType == "jpg" -> "[图片]"
                                        lastUndeleted.mediaType == "video" || lastUndeleted.mediaType == "mp4" -> "[视频]"
                                        lastUndeleted.mediaType == "file" -> "[文件]"
                                        lastUndeleted.mediaType == "voice" -> "[语音]"
                                        lastUndeleted.mediaType == "transfer" -> "[转账]"
                                        else -> lastUndeleted.text
                                    }
                                    ChatViewModel.updateConversationPreview(friendId, prev, lastUndeleted.createdAt)
                                }
                            }
                            deleteConfirmMsgId = 0L
                        }) { Text("删除", color = Color(0xFFDC2626), fontWeight = FontWeight.SemiBold) }
                    },
                    dismissButton = {
                        TextButton(onClick = { deleteConfirmMsgId = 0L }) { Text("取消", color = Color(0xFF6B7280)) }
                    }
                )
            }

            // 官方 API 被管理员暂停的明确提示：需要普通用户一眼看懂，避免误以为发送 bug
            if (apiSuspendedDialog) {
                AlertDialog(
                    onDismissRequest = { apiSuspendedDialog = false },
                    containerColor = Color.White,
                    title = { Text("官方 API 已暂停", fontWeight = FontWeight.Bold, color = Color(0xFFB45309)) },
                    text = { Text("管理员已暂停官方 AI 接口，本次消息未发送。\n\n你可以：\n· 在右上角「使用」中切换为个人 API；\n· 或等待管理员恢复后重试。", color = Color(0xFF374151)) },
                    confirmButton = {
                        TextButton(onClick = { apiSuspendedDialog = false }) { Text("知道了", color = Color(0xFF2563EB), fontWeight = FontWeight.SemiBold) }
                    }
                )
            }

            // ==================== 消息修改弹窗（长按 → 修改：编辑思考部分与实际输出，保存后写回本地） ====================
            if (showEditDialog) {
                AlertDialog(
                    onDismissRequest = { showEditDialog = false },
                    containerColor = Color.White,
                    title = { Text("修改消息", fontWeight = FontWeight.Bold) },
                    text = {
                        Column {
                            Text("思考内容", fontSize = 12.sp, color = Color(0xFF6B7280), fontWeight = FontWeight.Medium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                androidx.compose.material3.OutlinedTextField(
                                    value = editReasoningText,
                                    onValueChange = { editReasoningText = it },
                                    modifier = Modifier.weight(1f).heightIn(min = 80.dp, max = 140.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                                    placeholder = { Text("AI 的思考过程（可留空）", fontSize = 13.sp, color = Color(0xFF9CA3AF)) }
                                )
                                TextButton(onClick = { editReasoningText = "" }) { Text("清空", fontSize = 13.sp, color = Color(0xFFDC2626)) }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("实际输出", fontSize = 12.sp, color = Color(0xFF6B7280), fontWeight = FontWeight.Medium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                androidx.compose.material3.OutlinedTextField(
                                    value = editOutputText,
                                    onValueChange = { editOutputText = it },
                                    modifier = Modifier.weight(1f).heightIn(min = 100.dp, max = 180.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                                    placeholder = { Text("AI 回复的内容", fontSize = 13.sp, color = Color(0xFF9CA3AF)) }
                                )
                                TextButton(onClick = { editOutputText = "" }) { Text("清空", fontSize = 13.sp, color = Color(0xFFDC2626)) }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val targetId = editTargetMsgId
                            val idx = messages.indexOfFirst { it.id == targetId }
                            if (idx >= 0 && messages[idx] is ChatMsg) {
                                val updated = (messages[idx] as ChatMsg).copy(
                                    reasoningText = editReasoningText,
                                    text = editOutputText
                                )
                                messages[idx] = updated
                                // 写回本地存储（AI 对话 / 自己对话 / 系统通知都走对应持久化）
                                try {
                                    if (isLocalChat(friendId)) {
                                        val key = localChatKey(friendId)
                                        saveLocalChatMessages(ctx, currentUserId, key, messages.filter { !it.isSystemNotice })
                                    } else if (isNotificationChat(friendId)) {
                                        saveNotificationMessages(ctx, currentUserId, messages.filterIsInstance<ChatMsg>())
                                    }
                                } catch (_: Exception) {}
                                ChatViewModel.updateConversationPreview(friendId, editOutputText.take(60), updated.createdAt)
                                Toast.makeText(ctx, "已修改", Toast.LENGTH_SHORT).show()
                            }
                            showEditDialog = false
                        }) { Text("保存", color = Color(0xFF2563EB), fontWeight = FontWeight.SemiBold) }
                    },
                    dismissButton = {
                        TextButton(onClick = { showEditDialog = false }) { Text("取消", color = Color(0xFF6B7280)) }
                    }
                )
            }

            // 订单详情弹窗：从通知中心「查看订单」进入，展示与开发者管理一致的订单信息
            viewOrderId?.let { oid ->
                OrderDetailView(orderId = oid, onDismiss = { viewOrderId = null })
            }

            }


            // 引用预览条（固定在输入框正上方，绝不跑位）
            replyToMsg.value?.let { reply ->
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFDBEAFE)).padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${reply.senderName}:${if (reply.text.isNotEmpty()) reply.text else when (reply.mediaType) { "image" -> "[图片]"; "video", "mp4" -> "[视频]"; "file" -> "[文件]"; "voice" -> "[语音]"; "transfer" -> "[转账]"; else -> "[消息]" }}",
                        fontSize = 12.sp, color = Color(0xFF6B7280),
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Box(Modifier.size(20.dp).clickable { replyToMsg.value = null }, contentAlignment = Alignment.Center) {
                        Text("✕", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                    }
                }
            }

            // 底部输入栏（在 Column 内部、LazyColumn 下方；严格位于消息区以下）
            // 通知系统：用户不可发消息，隐藏输入栏
            if (!isNotificationChat(friendId)) {
            InputBar(
                inputText = inputText,
                onInputChange = { inputText = it },
                friendId = friendId,
                showPlusDialog = showPlusDialog,
                onTogglePlus = { showPlusDialog = !showPlusDialog },
                onClosePlus = { showPlusDialog = false },
                    onOpenCamera = { showCamera = true },
                    onRequestLocation = { showLocationConfirm = true },
                    onSecretClick = { showPrivacyPanel = true },
                    onTransfer = { showTransferDialog = true },
                    onRedPacket = { showRedPacketDialog = true },
                    mutedUntil = mutedUntil,
                    isAiChat = friendId == AI_CHAT_ID,
                    onTimePoint = { showTimePointDialog = true },
                    onConfirmSpeech = { showConfirmSpeechDialog = true },
                    confirmSpeechEnabled = confirmSpeechEnabled,
                    onConfirmReply = onConfirmReply,
                    onSend = {
                    if (inputText.isNotBlank()) {
                        val text = inputText.trim()
                        inputText = ""
                        // 清除草稿
                        ctx.getSharedPreferences("aurora_drafts", Context.MODE_PRIVATE)
                            .edit().remove(draftKey).apply()
                        // 第0关：发送前检查本地存储的用户名是否为"注销用户"
                        val loginPrefs = ctx.getSharedPreferences("aurora_login", android.content.Context.MODE_PRIVATE)
                        if (loginPrefs.getString("username", "") == "注销用户") {
                            android.widget.Toast.makeText(ctx, "您的账号已被注销，无法发送消息", android.widget.Toast.LENGTH_SHORT).show()
                            scope.launch { ChatRepository.checkAndLogoutCurrentUser(ctx, currentUserId) }
                        } else {
                        // 记录到最近发送集合（30 秒内防重，即使 onSuccess 后 loadMessages 触发也不会重复添加）
                        recentlySentMessages[text] = System.currentTimeMillis()
                        // 先把消息加到本地并开启动画，保证即时显示
                        val replyText = replyToMsg.value?.let { msg ->
                            if (msg.text.isNotEmpty()) msg.text else when (msg.mediaType) {
                                "image" -> "[图片]"
                                "video", "mp4" -> "[视频]"
                                "file" -> "[文件]"
                                "voice" -> "[语音]"
                                "transfer" -> "[转账]"
                                else -> "[消息]"
                            }
                        } ?: ""
                        val replySender = replyToMsg.value?.senderName ?: ""
                        val replyToId = replyToMsg.value?.id ?: 0L
                        replyToMsg.value = null   // 发送后清除引用
                        if (!isLocalChat(friendId)) {
                            messages.add(ChatMsg.create(text = text, isMine = true, fromUserId = currentUserId, isNew = true, replyToText = replyText, replyToSender = replySender, replyToId = replyToId))
                        }
                        scope.launch {
                            if (messages.isNotEmpty()) {
                                listState.scrollToItem(messages.size - 1, Int.MAX_VALUE)
                            }
                        }
                        // 统计发言字数
                        com.aurora.chat.ui.profile.WordCountTracker.addChars(ctx, text.length)

                        if (isLocalChat(friendId)) {
                            val key = localChatKey(friendId)
                            val selfMsgId = System.currentTimeMillis() * 10000 + (0..9999).random()
                            messages.add(ChatMsg.create(
                                serverId = selfMsgId, text = text, isMine = true,
                                fromUserId = currentUserId, isNew = true,
                                replyToText = replyText, replyToSender = replySender, replyToId = replyToId,
                                createdAt = System.currentTimeMillis() / 1000))
                            saveLocalChatMessages(ctx, currentUserId, key, messages.filter { !it.isSystemNotice })
                            ChatViewModel.updateConversationPreview(friendId, text, System.currentTimeMillis() / 1000)

                            // 优化：上下文过长时仅保留最近 N 条（并保留首条作为种子），
                            // 避免每次小请求都携带全量历史消耗官方额度
                            val aiContextCap = 40
                            val chatCandidates = messages.filter { !it.isSystemNotice && it.text.isNotBlank() && it.text != AI_THINKING }
                            val chatContext = if (chatCandidates.size > aiContextCap) {
                                // 被编辑过的那条消息（含其最新文本）必须始终进入上下文，
                                // 否则一旦该消息落在截断窗口之外，编辑就对 AI 无效（AI 仍按原历史作答）
                                val truncated = chatCandidates.take(1) + chatCandidates.takeLast(aiContextCap - 1)
                                val edited = editTargetMsgId.takeIf { it != 0L }?.let { tid -> chatCandidates.firstOrNull { it.id == tid } }
                                if (edited != null && truncated.none { it.id == edited.id }) listOf(edited) + truncated else truncated
                            } else chatCandidates

                            // AI 对话：本地存用户消息后调用接口流式回复
                            if (friendId == AI_CHAT_ID) {
                                // 确认发言模式：跳过 AI 自动回复，标记有待确认消息
                                if (confirmSpeechEnabled) {
                                    confirmSpeechPending = true
                                } else {
                                val mode = AiChatManager.getMode(ctx, currentUserId)
                                val canCall: Boolean
                                val quotaMsg: String?
                            // 本次请求相关：baseUsed=发送前今日已用，poolAtStart=发送前剩余余额，estInput=本次输入估算
                            var estInput = 0L
                            val baseUsed: Long
                            var poolAtStart = 0L
                            if (mode == "official") {
                                // 余额只来自服务器：remaining 仅可为服务器真实值或 -1（未加载）。
                                // 仅当服务器明确返回 0 才拦截；未加载(-1)交由服务器裁决，不本地封顶。
                                // 发送前强制拉取最新余额（站A的同步刷新已修），站B因在同步块里不能直接调 suspend，
                                // 这里改为同步路径先读缓存余额判断，后续在下方 scope.launch 中强制刷新一次。
                                val (used, remaining) = AiChatManager.getOfficialUsage(ctx, currentUserId)
                                aiUsageState.value = Pair(used, remaining)
                                baseUsed = used
                                poolAtStart = remaining
                                estInput = chatContext.sumOf { AiChatManager.estimateTokens(it.text).toLong() }
                                canCall = remaining != 0L
                                quotaMsg = when {
                                    remaining == 0L ->
                                        "官方 API 余额已用完，可在右上角「使用」切换个人 API 或充值后继续使用"
                                    else -> null
                                }
                            } else {
                                    canCall = true
                                    quotaMsg = null
                                    baseUsed = aiUsageState.value.first
                                }

                                if (!canCall) {
                                    onTokenExhausted()
                                } else {
                                    scope.launch {
                                        // 发送前再强制刷新一次服务器余额，并以「服务器真实 token_balance」为准判定，
                                        // 不受开发者无限额度影响；余额确为 0 时弹卡片，普通用户直接拦截、开发者仍放行。
                                    if (mode == "official") {
                                        AiChatManager.syncServerLimit(ctx, currentUserId)
                                        val rawBal = AiChatManager.getServerTokenBalance(ctx, currentUserId)
                                        if (rawBal <= 0L) {
                                            onTokenExhausted()
                                            if (!AiChatManager.isDeveloper(ctx, currentUserId)) return@launch
                                        }
                                    }
                                    // 构造上下文（排除系统提示与思考占位）
                                    // 性格：模型无状态，每次请求都必须把【当前性格设定】写入 system 提示，
                                    // 否则 AI 在没有性格指令时会回退到默认友好语气（这是之前"设定不生效"的根因）。
                                    // 因此不再用"事件驱动仅注入一次"，改为每次发送都携带最新性格设定。
                                    // 极致节省模式优先级最高：开启时不注入任何性格，改为用猛措辞强制恢复正常语气并阻断上下文干扰。
                                    val systemText = buildString {
                                        if (AiChatManager.getUltraSave(ctx, currentUserId)) {
                                            append(AiChatManager.ULTRA_SAVE_CONSTRAINT)
                                        } else {
                                            append(AiChatManager.buildPersonaSystemPrompt(AiChatManager.getTraits(ctx, currentUserId), AiChatManager.getCustomTraits(ctx, currentUserId)))
                                            // 节省 Token：按当前开关状态附加精简约束（同样每次注入以保证生效）
                                            if (AiChatManager.getSaveToken(ctx, currentUserId)) {
                                                append("\n\n").append(AiChatManager.SAVE_TOKEN_CONSTRAINT)
                                            }
                                            // 性格刚被修改：注入切换声明，强制模型丢弃历史中的旧语气、按新设定走，避免被上下文带偏
                                            if (AiChatManager.getPersonaSwitch(ctx, currentUserId)) {
                                                append("\n\n").append(AiChatManager.PERSONA_SWITCH_RELEASE)
                                            }
                                        }
                                    }
                                    // 高级选项（场景 / 角色设定 / AI 多次输出）：仅在非极致节省模式下注入
                                    // 人物对换 / 历史反转：仅 AI 对话生效
                                    val reversed = friendId == AI_CHAT_ID && reverseHistory
                                    val reverseNote = if (reversed) {
                                        "\n\n【重要设定】本次对话的聊天记录是「反转」的：原本由用户（我方）发送的消息，现在代表「对方」；" +
                                        "原本由你（AI）发送的回复，现在代表「我（用户）」。请你以用户（我方）的视角和身份，" +
                                        "继续与对方自然对话，不要提及这是反转设定，也不要点破角色互换。"
                                    } else ""
                                    val systemFinal = buildString {
                                        append(systemText)
                                        if (!AiChatManager.getUltraSave(ctx, currentUserId)) {
                                            append(AiChatManager.buildAdvancedSystemPrompt(ctx, currentUserId))
                                            append(AiChatManager.multiOutputConstraint(ctx, currentUserId))
                                        }
                                        if (reverseNote.isNotEmpty()) append(reverseNote)
                                        if (currentTimePoint.isNotBlank()) append("\n\n【当前时间】$currentTimePoint")
                                    }
                                    if (AiChatManager.getPersonaSwitch(ctx, currentUserId)) {
                                        AiChatManager.setPersonaSwitch(ctx, currentUserId, false)
                                    }
                                    val history = (if (systemFinal.isNotBlank()) listOf("system" to systemFinal) else emptyList()) + chatContext.map { (if (it.isMine != reversed) "user" else "assistant") to it.text }
                                        val aiMsgId = System.currentTimeMillis() * 10000 + (0..9999).random()
                                        expandedReasoningMsgId = aiMsgId
                                        // 开启"显示思考过程"时，初始占位用空文本，稍后由 onReasoningDelta 填充思考内容
                                        val initText = if (AiChatManager.getShowReasoning(ctx, currentUserId)) "" else AI_THINKING
                                        messages.add(ChatMsg.create(
                                            serverId = aiMsgId, text = initText, isMine = false,
                                            fromUserId = AI_CHAT_ID, senderName = AiNameState.name ?: "DeepSeek", isNew = true,
                                            createdAt = System.currentTimeMillis() / 1000
                                        ))
                                        try {
                                            val info = listState.layoutInfo
                                            val lastIndex = info.totalItemsCount - 1
                                            if (lastIndex >= 0) {
                                                val h = info.visibleItemsInfo.lastOrNull()?.size ?: 0
                                                val vpH = info.viewportEndOffset - info.viewportStartOffset
                                                listState.scrollToItem(lastIndex, (vpH - h))
                                            }
                                        } catch (_: Exception) {}
                                        AiChatManager.streamChat(
                                            ctx = ctx, userId = currentUserId, history = history,
                                            onReasoningDelta = { reasoning ->
                                                if (AiChatManager.getShowReasoning(ctx, currentUserId)) {
                                                    val idx = messages.indexOfFirst { m -> m.id == aiMsgId }
                                                    if (idx >= 0) {
                                                        messages[idx] = (messages[idx] as ChatMsg).copy(reasoningText = reasoning)
                                                    }
                                                }
                                                // 思考过程输出时自动滚动到底部，与对话文本输出体验一致
                                                if (atBottomState.value && !userScrolledAway) {
                                                    scope.launch {
                                                        try { listState.scrollToItem(messages.size - 1, Int.MAX_VALUE) } catch (_: Exception) {}
                                                    }
                                                }
                                                // 思考过程中实时更新用量：输入已消耗，输出尚未产生，先显示输入部分
                                                if (mode == "official" && poolAtStart > 0L) {
                                                    val liveUsed = baseUsed + estInput
                                                    val liveRemaining = (poolAtStart - estInput).coerceAtLeast(0)
                                                    aiUsageState.value = Pair(liveUsed, liveRemaining)
                                                }
                                            },
                                            onDelta = { cur ->
                                                val idx = messages.indexOfFirst { m -> m.id == aiMsgId }
                                                if (idx >= 0) {
                                                    val msg = messages[idx] as ChatMsg
                                                    val keepReasoning = if (AiChatManager.getShowReasoning(ctx, currentUserId)) msg.reasoningText else ""
                                                    messages[idx] = msg.copy(text = cur.replace(AiChatManager.MULTI_OUTPUT_SPLIT, ""), reasoningText = keepReasoning)
                                                }
                                                // 流式输出时仅在用户已停在底部才自动跟随；用户上滑看历史时不抢占，不阻止其操作
                                                if (atBottomState.value && !userScrolledAway) {
                                                    scope.launch {
                                                        try { listState.scrollToItem(messages.size - 1, Int.MAX_VALUE) } catch (_: Exception) {}
                                                    }
                                                }
                                                // 实时预估：以发送前服务器余额(poolAtStart)为基准，边输出边递减展示。
                                                // 仅当服务器余额已加载(>0)才做本地预估；未加载(-1)或已 0 时不预估，等服务器裁决。
                                                if (mode == "official" && poolAtStart > 0L) {
                                                    val inc = estInput + AiChatManager.estimateTokens(cur)
                                                    val liveRemaining = (poolAtStart - inc).coerceAtLeast(0)
                                                    val liveUsed = baseUsed + inc
                                                    aiUsageState.value = Pair(liveUsed, liveRemaining)
                                                }
                                            },
                                            onDone = { usage, full ->
                                                val idx = messages.indexOfFirst { m -> m.id == aiMsgId }
                                                // 取出最终 reasoningText（仅开启时保留）
                                                val finalReasoning = if (idx >= 0 && AiChatManager.getShowReasoning(ctx, currentUserId)) (messages[idx] as ChatMsg).reasoningText else ""
                                                val multi = AiChatManager.getMultiOutput(ctx, currentUserId)
                                                if (multi && full.contains(AiChatManager.MULTI_OUTPUT_SPLIT)) {
                                                    // 按 [[SPLIT]] 拆分为多条短消息（仅 AI 主动使用分隔符时才拆，不强行拆分）
                                                    if (idx >= 0) messages.removeAt(idx)
                                                    val segs = full.split(AiChatManager.MULTI_OUTPUT_SPLIT)
                                                        .map { it.trim() }.filter { it.isNotBlank() }
                                                    var pos = idx.coerceAtLeast(0)
                                                    var firstText = ""
                                                    for (seg in segs) {
                                                        if (firstText.isEmpty()) firstText = seg.take(60)
                                                        messages.add(pos, ChatMsg.create(
                                                            serverId = System.currentTimeMillis() * 10000L + (0..9999).random(),
                                                            text = seg, isMine = false, fromUserId = AI_CHAT_ID,
                                                            senderName = AiNameState.name ?: "DeepSeek", isNew = true,
                                                            createdAt = System.currentTimeMillis() / 1000,
                                                            reasoningText = finalReasoning
                                                        ))
                                                        pos++
                                                    }
                                                    if (firstText.isNotEmpty()) ChatViewModel.updateConversationPreview(friendId, firstText, System.currentTimeMillis() / 1000)
                                                } else {
                                                    if (idx >= 0) messages[idx] = (messages[idx] as ChatMsg).copy(text = full, reasoningText = finalReasoning)
                                                    if (full.isNotBlank()) {
                                                        ChatViewModel.updateConversationPreview(friendId, full.take(60), System.currentTimeMillis() / 1000)
                                                    }
                                                }
                                                saveLocalChatMessages(ctx, currentUserId, "ai", messages.filter { !it.isSystemNotice })
                                                if (mode == "official" && usage > 0) {
                                                    // 记账（仅累加本地「今日已用」计数）
                                                    AiChatManager.addOfficialUsage(ctx, currentUserId, usage)
                                                    // 余额只来自服务器：重新拉取权威余额后再刷新面板，不本地扣减
                                                    scope.launch {
                                                        AiChatManager.syncServerLimit(ctx, currentUserId)
                                                        aiUsageState.value = AiChatManager.getOfficialUsage(ctx, currentUserId)
                                                    }
                                                }
                                            },
                                            onError = { err ->
                                                val idx = messages.indexOfFirst { m -> m.id == aiMsgId }
                                                if (idx >= 0) messages.removeAt(idx)
                                                if (err.contains("已被管理员暂停")) {
                                                    apiSuspendedDialog = true
                                                } else {
                                                    android.widget.Toast.makeText(ctx, err, android.widget.Toast.LENGTH_LONG).show()
                                                }
                                            },
                                            onTokenInsufficient = onTokenExhausted
                                        )
                                    }
                                }
                            }
                            }
                        } else {
                        ChatViewModel.sendMessage(
                            currentUserId = currentUserId,
                            friendId = friendId,
                            text = text,
                            replyTo = replyToId,
                            onSuccess = { serverMsgId ->
                                // 服务端已确认消息，不替换 ID 避免 LazyColumn key 变更导致闪烁
                                // 轮询会自然用服务端消息覆盖本地占位
                                ChatViewModel.updateConversationPreview(friendId, text, System.currentTimeMillis() / 1000)
                                scope.launch {
                                    kotlinx.coroutines.delay(50)
                                    if (messages.isNotEmpty()) {
                                        listState.scrollToItem(messages.size - 1)
                                    }
                                }
                            },
                            onError = { msg ->
                                val displayMsg = when {
                                    msg.contains("您的账号异常") && msg.contains("410") -> {
                                        scope.launch { ChatRepository.checkAndLogoutCurrentUser(ctx, currentUserId) }
                                        "发送失败: 您的账号异常，操作已禁止"
                                    }
                                    msg.contains("对方账号异常") -> "对方账号异常，无法发送消息"
                                    msg.contains("连接") || msg.contains("超时") || msg.contains("网络") -> "发送失败，请检查网络"
                                    msg.contains("账号异常，请重新登录") && msg.contains("401") -> {
                                        android.widget.Toast.makeText(ctx, "登录状态已过期，请重新登录", android.widget.Toast.LENGTH_LONG).show()
                                        scope.launch {
                                            ChatRepository.checkAndLogoutCurrentUser(ctx, currentUserId)
                                        }
                                        return@sendMessage
                                    }
                                    else -> "发送失败: $msg"
                                }
                                AuroraApi.showErrorToast(ctx, displayMsg)
                            },
                            context = ctx
                        )
                    } // end else (非注销用户 走 API)
                    } // end else (非注销用户发送逻辑)
                    }
                },
                onSendMedia = { uri, flashSec ->
                    com.aurora.chat.ui.viewmodel.ChatViewModel.backgroundScope.launch {
                        try {
                            val mimeType = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
                            val fileName = uri.lastPathSegment ?: "file"
                            val isImage = mimeType.startsWith("image/")
                            val isVideo = mimeType.startsWith("video/")

                            // 先添加占位消息（含 isUploading=true）
                            val extraType = if (isImage) "image" else if (isVideo) "video" else "file"
                            val placeholderMsg = ChatMsg.create(serverId = System.currentTimeMillis() * 10000 + (0..9999).random(), text = "", isMine = true, fromUserId = currentUserId, isNew = true, mediaType = extraType, mediaUrl = "", isUploading = true, flashDuration = flashSec)
                            messages.add(placeholderMsg)
                            uploadProgressMap[placeholderMsg.id] = 0f
                            scope.launch {
                                if (messages.isNotEmpty()) listState.scrollToItem(messages.size - 1)
                            }

                            // 读取文件内容（图片尝试压缩）
                            val inputStream = ctx.contentResolver.openInputStream(uri)
                            if (inputStream == null) {
                                AuroraApi.showErrorToast(ctx, "无法读取文件")
                                uploadProgressMap.remove(placeholderMsg.id)
                                messages.removeAll { it.id == placeholderMsg.id }
                                return@launch
                            }
                            val fileBytes = inputStream.readBytes()
                            inputStream.close()

                            // 图片简单压缩（>500KB 则压缩到 80% 质量）
                            val finalBytes = if (isImage) {
                                val bitmap = android.graphics.BitmapFactory.decodeByteArray(fileBytes, 0, fileBytes.size)
                                if (bitmap != null && fileBytes.size > 500 * 1024) {
                                    val out = java.io.ByteArrayOutputStream()
                                    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
                                    out.toByteArray()
                                } else fileBytes
                            } else fileBytes

                            // 上传到服务器
                            val uploadResult = AuroraApi.uploadChatMedia(finalBytes, fileName, mimeType)
                            if (!uploadResult.success || uploadResult.data == null) {
                                AuroraApi.showErrorToast(ctx, uploadResult.message)
                                uploadProgressMap.remove(placeholderMsg.id)
                                messages.removeAll { it.id == placeholderMsg.id }
                                return@launch
                            }
                            val rawMediaUrl = uploadResult.data!!.optString("url", "")
                            val rawMediaType = uploadResult.data!!.optString("media_type", "image")
                            if (rawMediaUrl.isEmpty()) {
                                AuroraApi.showErrorToast(ctx, "上传失败")
                                uploadProgressMap.remove(placeholderMsg.id)
                                messages.removeAll { it.id == placeholderMsg.id }
                                return@launch
                            }

                            // 标准化 mediaType
                            // 后端返回的是相对路径 /chat-media/xxx，必须 resolve 成客户端可达的完整 URL，
                            // 否则 Coil 用相对路径加载失败 → 显示「图片加载失败」；发送与本地存储也都会存坏值，
                            // 重进对话即表现为空气泡。（拍照路径 sendCameraFile 已做，这里补齐）
                            val mediaUrl = resolveMediaUrl(rawMediaUrl)
                            val mediaType = when {
                                rawMediaType.startsWith("video/") -> "video"
                                rawMediaType.startsWith("image/") -> "image"
                                rawMediaType == "video" || rawMediaType == "mp4" -> "video"
                                rawMediaType == "image" || rawMediaType == "jpg" || rawMediaType == "png" || rawMediaType == "gif" || rawMediaType == "jpeg" -> "image"
                                else -> rawMediaType
                            }

                            // 替换占位为真实消息
                            uploadProgressMap.remove(placeholderMsg.id)
                            val idxMsg = messages.indexOfFirst { it.id == placeholderMsg.id }
                            if (idxMsg >= 0) {
                                messages[idxMsg] = ChatMsg.create(text = "", isMine = true, fromUserId = currentUserId, isNew = true, mediaType = mediaType, mediaUrl = mediaUrl, flashDuration = flashSec)
                            }
                            // 占位替换为真实图片后高度可能变大，再次滚到底部确保完整可见
                            scope.launch {
                                delay(100)
                                if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
                            }

                            // 发送媒体消息到服务器
                            ChatViewModel.sendMessage(
                                currentUserId = currentUserId,
                                friendId = friendId,
                                text = "",
                                mediaType = mediaType,
                                mediaUrl = mediaUrl,
                                flashDuration = flashSec,
                                onSuccess = { serverMsgId ->
                                    // 把已验证可用的完整媒体 URL 落盘（按服务端 id），
                                    // 保证离开对话重进时即使服务器返回空/相对路径也能正常显示
                                    com.aurora.chat.ui.viewmodel.ChatViewModel.backgroundScope.launch {
                                        try {
                                            val info = com.aurora.chat.data.api.MessageInfo(
                                                id = serverMsgId, fromUserId = currentUserId, toUserId = friendId,
                                                content = "", createdAt = System.currentTimeMillis() / 1000,
                                                mediaType = mediaType, mediaUrl = mediaUrl, isRevoked = 0, flashDuration = flashSec
                                            )
                                            com.aurora.chat.data.repository.LocalMessageStore.mergeAndSave(ctx, friendId, listOf(info))
                                            // 把已验证可达的图片 URL 写入媒体权威表，防止重进对话后图片丢失
                                            MediaStore.put(serverMsgId, ChatMedia(mediaType, resolveMediaUrl(mediaUrl)))
                                        } catch (_: Exception) { }
                                    }
                                    // 不替换 ID 避免 LazyColumn key 变更导致闪烁
                                    // 发送成功后再次滚到底部，确保高图片不被截断
                                    scope.launch {
                                        delay(200)
                                        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
                                    }
                                    // 实时更新对话列表预览
                                    val previewText = when (mediaType) { "image" -> "[图片]"; "video" -> "[视频]"; "file" -> "[文件]"; "voice" -> "[语音]"; "transfer" -> "[转账]"; else -> "[消息]" }
                                    ChatViewModel.updateConversationPreview(friendId, previewText, System.currentTimeMillis() / 1000)
                                },
                                onError = { msg -> AuroraApi.showErrorToast(ctx, "发送失败: $msg") },
                                context = ctx
                            )
                        } catch (e: Exception) {
                            AuroraApi.showErrorToast(ctx, "发送失败: ${e.message}")
                        }
                    }
                }
            )
            }

        }

        // ===== 滚动到底部按钮（悬浮在输入栏上方，靠右对齐） =====
        AnimatedVisibility(
            visible = shouldShowScrollDown.value,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
            modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 56.dp, end = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color.White, CircleShape)
                    .border(1.dp, Color(0xFFD1D5DB), CircleShape)
                    .clickable {
                        scope.launch {
                            val target = (messages.size - 1).coerceAtLeast(0)
                            listState.scrollToItem(target)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(26.dp)) {
                    val c = center
                    val path = androidx.compose.ui.graphics.Path().apply {
                        moveTo(c.x - 10.5f, c.y - 5f)
                        lineTo(c.x, c.y + 6.5f)
                        lineTo(c.x + 10.5f, c.y - 5f)
                        close()
                    }
                    drawPath(path, Color(0xFF6B7280))
                }
            }
        }

        // 好友资料面板（从右侧滑入覆盖）
        if (friendId > 0) {
            AnimatedVisibility(
                visible = showFriendSettings,
                enter = slideInHorizontally(tween(300)) { it },
                exit = slideOutHorizontally(tween(300)) { it },
                modifier = Modifier.fillMaxSize()
            ) {
                Box(modifier = Modifier.fillMaxSize().background(Color.White)) {
                    com.aurora.chat.ui.components.EventBlocker()
                    FriendProfilePanel(
                        friendId = friendId,
                        friendName = friendName,
                        currentUserId = currentUserId,
                        onBack = { showFriendSettings = false },
                        onDeleteFriend = {
                            showFriendSettings = false
                            scope.launch {
                                val r = ChatRepository.deleteFriend(friendId)
                                if (r.success) {
                                    android.widget.Toast.makeText(ctx, "好友已删除", android.widget.Toast.LENGTH_SHORT).show()
                                    onBack()
                                } else {
                                    android.widget.Toast.makeText(ctx, "删除失败: ${r.message}", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                }
            }
        }

        // 群设置面板（从右侧滑入覆盖，始终保留在组合树中以确保退出动画播放）
        if (isGroupChat(friendId)) {
            val internalGroupId = -friendId - 1000
            AnimatedVisibility(
                visible = showGroupSettings,
                enter = slideInHorizontally(tween(300)) { it },
                exit = slideOutHorizontally(tween(300)) { it },
                modifier = Modifier.fillMaxSize()
            ) {
                Box(modifier = Modifier.fillMaxSize().background(Color.White)) {
                    com.aurora.chat.ui.components.EventBlocker()
                    GroupSettingsPanel(
                        internalGroupId = internalGroupId,
                        groupName = friendName,
                        onBack = { showGroupSettings = false },
                        onOpenProfile = { uid, name ->
                            profileUserId = uid
                            profileUserName = name
                            // 从群设置进入：尝试用现有 friendInfo / systemUserName
                            profileWornBadge = wornBadge
                            showProfile = true
                        },
                        onDissolved = onBack,
                        onOpenJoinRequestList = onOpenJoinRequestFullScreen
                    )
                }
            }
        }

        // 用户资料面板（从右侧滑入）
        AnimatedVisibility(
            visible = showProfile && profileUserId > 0,
            enter = slideInHorizontally(tween(300)) { it },
            exit = slideOutHorizontally(tween(300)) { it },
            modifier = Modifier.fillMaxSize()
        ) {
            Box(Modifier.fillMaxSize()) {
                com.aurora.chat.ui.components.EventBlocker()
                UserProfileCard(
                userId = profileUserId,
                userName = profileUserName,
                currentUserId = currentUserId,
                wornBadge = profileWornBadge,
                onBack = { showProfile = false },
                onBadgeClick = { badgeDialogId = it },
                onOpenChat = { uid, name ->
                    showProfile = false
                    showGroupSettings = false
                    showFriendSettings = false
                    if (uid != friendId) {
                        onOpenNewChat(uid, name)
                    }
                },
                onDeleteFriend = {
                    scope.launch {
                        val r = ChatRepository.deleteFriend(profileUserId)
                        if (r.success) {
                            android.widget.Toast.makeText(ctx, "已删除好友", android.widget.Toast.LENGTH_SHORT).show()
                            ChatViewModel.loadConversations(force = true)
                            showProfile = false
                        } else {
                            android.widget.Toast.makeText(ctx, "删除失败: ${r.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
            }
        }
    }

    // ═════════════════════════════════════════════════════
    // 隐私控制面板（从右侧滑入覆盖，显示双方隐私设置状态）
    // ═════════════════════════════════════════════════════
    if (friendId > 0) {
        AnimatedVisibility(
            visible = showPrivacyPanel,
            enter = slideInHorizontally(tween(300)) { it },
            exit = slideOutHorizontally(tween(300)) { it },
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize().background(Color.White)) {
                // 点击背景关闭
                Box(
                    modifier = Modifier.fillMaxSize().clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) { showPrivacyPanel = false }
                )
                PrivacySettingsPanel(
                    friendId = friendId,
                    currentUserId = currentUserId,
                    onClose = { showPrivacyPanel = false; privacyRefreshKey++ }
                )
            }
        }
    }

    // ── 相机拍摄覆盖层 ──
    if (showCamera) {
        Box(Modifier.fillMaxSize().zIndex(100f)) {
            com.aurora.chat.ui.components.EventBlocker()
            CameraCaptureScreen(
                onDismiss = { showCamera = false },
                onPhotoCaptured = { file ->
                    showCamera = false
                    // 直接用文件 URI 走上传流程
                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        ctx, "${ctx.packageName}.fileprovider", file
                    )
                    scope.launch {
                        sendCameraFile(uri, ctx, currentUserId, friendId, scope, messages, uploadProgressMap, listState) { newMessages -> messages.clear(); messages.addAll(newMessages) }
                    }
                },
                onVideoCaptured = { file, durationSec ->
                    showCamera = false
                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        ctx, "${ctx.packageName}.fileprovider", file
                    )
                    scope.launch {
                        sendCameraFile(uri, ctx, currentUserId, friendId, scope, messages, uploadProgressMap, listState) { newMessages -> messages.clear(); messages.addAll(newMessages) }
                    }
                }
            )
        }
    }

    // ── 转账弹窗 ──
    if (showTransferDialog) {
        TransferDialog(
            friendId = friendId,
            currentUserId = currentUserId,
            currentUserName = currentUserName,
            friendName = friendName,
            messages = messages,
            ctx = ctx,
            onDismiss = { showTransferDialog = false }
        )
    }

    // ── 红包发送弹窗 ──
    if (showRedPacketDialog) {
        RedPacketSendDialog(
            friendId = friendId,
            currentUserId = currentUserId,
            currentUserName = currentUserName,
            friendName = friendName,
            messages = messages,
            ctx = ctx,
            onDismiss = { showRedPacketDialog = false }
        )
    }

    // ── 红包详情全屏 ──
    if (redPacketDetailId > 0) {
        RedPacketDetailDialog(
            packetId = redPacketDetailId,
            currentUserId = currentUserId,
            statusMap = redpacketStatus,
            onDismiss = { redPacketDetailId = 0 }
        )
    }

    // ── 位置权限与发送 ──
    val locationPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        showLocationRequest = false
        if (granted) {
            scope.launch { sendLocationMessage(ctx, currentUserId, friendId) { newMessages -> messages.clear(); messages.addAll(newMessages) } }
        } else {
            // 权限被永久拒绝（勾选了"不再询问"），引导用户去设置页
            if (!ActivityCompat.shouldShowRequestPermissionRationale(ctx as android.app.Activity, Manifest.permission.ACCESS_FINE_LOCATION)) {
                Toast.makeText(ctx, "位置权限已被拒绝，请在设置中手动开启", Toast.LENGTH_LONG).show()
                try {
                    val intent = android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = android.net.Uri.fromParts("package", ctx.packageName, null)
                    }
                    ctx.startActivity(intent)
                } catch (_: Exception) {}
            } else {
                Toast.makeText(ctx, "需要位置权限才能分享位置", Toast.LENGTH_SHORT).show()
            }
        }
    }
    LaunchedEffect(showLocationRequest) {
        if (showLocationRequest) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                showLocationRequest = false
                scope.launch { sendLocationMessage(ctx, currentUserId, friendId) { newMessages -> messages.clear(); messages.addAll(newMessages) } }
            } else {
                locationPermLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
    }

    // ── 位置发送确认弹窗 ──
    if (showLocationConfirm) {
        AlertDialog(
            onDismissRequest = { showLocationConfirm = false },
            title = { Text("发送当前位置", fontWeight = FontWeight.Bold) },
            text = { Text("确认将您当前所在位置以卡片形式发送给好友？") },
            confirmButton = {
                TextButton(onClick = {
                    showLocationConfirm = false
                    showLocationRequest = true
                }) {
                    Text("确认发送", color = Color(0xFF1E40AF))
                }
            },
            dismissButton = {
                TextButton(onClick = { showLocationConfirm = false }) {
                    Text("取消", color = Color(0xFF6B7280))
                }
            }
        )
    }

    // 图片全屏预览时拦截返回键：左滑/返回只关预览，不退到聊天板块
    BackHandler(enabled = imagePreviewUrl.isNotEmpty()) { imagePreviewUrl = "" }

    // 图片全屏预览（在 Column 外部，覆盖整个屏幕包括顶部栏）
    if (imagePreviewUrl.isNotEmpty()) {
        val window = (ctx as android.app.Activity).window
        DisposableEffect(imagePreviewUrl) {
            // 注意：MainActivity 已 enableEdgeToEdge（decorFitsSystemWindows=false），
            // 这里【绝不能】再改 window 的 decorFits 标志，否则退出预览后主界面顶栏会被状态栏顶上去。
            // 只需临时隐藏系统栏即可全屏预览，退出时恢复显示。
            val controller = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
            controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            onDispose {
                val ctrl = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
                ctrl.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            }
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF000000))
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { imagePreviewUrl = "" },
            contentAlignment = Alignment.Center
        ) {
            var scale by remember { mutableFloatStateOf(1f) }
            var offset by remember { mutableStateOf(Offset.Zero) }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offset = Offset(
                                x = (offset.x + pan.x).coerceIn(
                                    -(scale - 1f) * size.width / 2f,
                                    (scale - 1f) * size.width / 2f
                                ),
                                y = (offset.y + pan.y).coerceIn(
                                    -(scale - 1f) * size.height / 2f,
                                    (scale - 1f) * size.height / 2f
                                )
                            )
                        }
                    }
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    },
                contentAlignment = Alignment.Center
            ) {
                coil.compose.AsyncImage(
                    model = imagePreviewUrl,
                    contentDescription = "图片预览",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }

    // ── 视频全屏播放器（TextureView + MediaPlayer，支持渐进加载/缓冲进度/下载速度）──
    BackHandler(enabled = videoPlayUrl.isNotEmpty()) { videoPlayUrl = "" }
    if (videoPlayUrl.isNotEmpty()) {
        val window = (ctx as android.app.Activity).window
        DisposableEffect(videoPlayUrl) {
            // 同图片预览：不改动 window 的 decorFits 标志，仅临时隐藏/恢复系统栏
            val controller = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
            controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            onDispose {
                val ctrl = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
                ctrl.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            }
        }

        // 缓冲百分比 0~100
        var bufferPercent by remember(videoPlayUrl) { mutableIntStateOf(0) }
        // 是否正在缓冲
        var isBuffering by remember(videoPlayUrl) { mutableStateOf(true) }
        // 下载速度文本（如 "2.3 MB/s"）
        var speedText by remember(videoPlayUrl) { mutableStateOf("") }
        // 是否已准备好播放
        var isPrepared by remember(videoPlayUrl) { mutableStateOf(false) }
        // 视频宽高比
        var videoAspectRatio by remember(videoPlayUrl) { mutableFloatStateOf(1f) }
        // 视频文件总大小（HEAD 请求缓存，0=未知）
        var totalFileSize by remember(videoPlayUrl) { mutableLongStateOf(0L) }
        // 计算下载速度的追踪变量
        var lastBytes by remember(videoPlayUrl) { mutableLongStateOf(0L) }
        var lastTimeMs by remember(videoPlayUrl) { mutableLongStateOf(0L) }

        // ── 播放控制状态 ──
        var isPaused by remember(videoPlayUrl) { mutableStateOf(false) }
        var showPlayPauseIcon by remember(videoPlayUrl) { mutableStateOf(false) }
        var currentPositionMs by remember(videoPlayUrl) { mutableLongStateOf(0L) }
        var videoDurationMs by remember(videoPlayUrl) { mutableLongStateOf(0L) }
        var mediaPlayerRef by remember(videoPlayUrl) { mutableStateOf<MediaPlayer?>(null) }
        // 是否正在拖拽进度条（拖拽时暂停位置跟踪定时器）
        var isSeeking by remember(videoPlayUrl) { mutableStateOf(false) }

        fun formatTime(ms: Long): String {
            val totalSec = (ms / 1000).coerceAtLeast(0)
            return "%d:%02d".format(totalSec / 60, totalSec % 60)
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF000000)),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { context ->
                    TextureView(context).apply {
                        var mediaPlayer: MediaPlayer? = null
                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(surface: android.graphics.SurfaceTexture, width: Int, height: Int) {
                                mediaPlayer = MediaPlayer().apply {
                                    mediaPlayerRef = this
                                    try {
                                        // 优先使用缓存视频
                                        val cacheUri = com.aurora.chat.data.local.MediaCache.getCachedVideoUri(ctx, videoPlayUrl)
                                        if (cacheUri != null) {
                                            setDataSource(ctx, cacheUri)
                                        } else {
                                            setDataSource(videoPlayUrl)
                                            // 异步缓存到本地
                                            kotlinx.coroutines.MainScope().launch(kotlinx.coroutines.Dispatchers.IO) {
                                                com.aurora.chat.data.local.MediaCache.downloadVideo(ctx, videoPlayUrl)
                                            }
                                        }
                                        setSurface(android.view.Surface(surface))

                                        setOnBufferingUpdateListener { _, percent ->
                                            bufferPercent = percent
                                            if (percent >= 5 && isPrepared && !isPaused && !isPlaying) {
                                                start()
                                            }
                                        }

                                        setOnInfoListener { _, what, _ ->
                                            when (what) {
                                                MediaPlayer.MEDIA_INFO_BUFFERING_START -> isBuffering = true
                                                MediaPlayer.MEDIA_INFO_BUFFERING_END -> isBuffering = false
                                                MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START -> isBuffering = false
                                            }
                                            false
                                        }

                                        setOnPreparedListener { mp ->
                                            videoAspectRatio = mp.videoWidth.toFloat() / mp.videoHeight.toFloat().coerceAtLeast(1f)
                                            videoDurationMs = mp.duration.toLong()
                                            isPrepared = true
                                            mp.isLooping = true
                                            mp.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT)
                                            if (bufferPercent >= 5) mp.start()
                                        }

                                        setOnErrorListener { _, what, extra ->
                                            Log.e("VideoPlayer", "播放错误: what=$what extra=$extra")
                                            isPrepared = false
                                            isBuffering = false
                                            true
                                        }

                                        setKeepScreenOn(true)
                                        prepareAsync()
                                    } catch (e: Exception) {
                                        Log.e("VideoPlayer", "初始化失败: ${e.message}")
                                    }
                                }
                            }

                            override fun onSurfaceTextureSizeChanged(s: android.graphics.SurfaceTexture, w: Int, h: Int) {}
                            override fun onSurfaceTextureDestroyed(s: android.graphics.SurfaceTexture): Boolean {
                                mediaPlayer?.release()
                                mediaPlayer = null
                                mediaPlayerRef = null
                                return true
                            }
                            override fun onSurfaceTextureUpdated(s: android.graphics.SurfaceTexture) {}
                        }
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            // ── 点击遮罩层：点击显示进度条，再次点击暂停/播放 ──
            var showControls by remember(videoPlayUrl) { mutableStateOf(false) }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) {
                        if (!showControls) {
                            // 首次点击：显示控制栏
                            showControls = true
                        } else {
                            // 已显示控制栏：切换暂停/播放
                            val mp = mediaPlayerRef
                            if (mp != null && isPrepared) {
                                if (mp.isPlaying) {
                                    mp.pause()
                                    isPaused = true
                                } else {
                                    mp.start()
                                    isPaused = false
                                }
                                showPlayPauseIcon = true
                            }
                        }
                    }
            )

            // ── Material 动画暂停/播放图标（仅控制栏显示时可见）──
            AnimatedVisibility(
                visible = showControls && showPlayPauseIcon,
                enter = scaleIn(animationSpec = tween(300)) + fadeIn(tween(200)),
                exit = scaleOut(animationSpec = tween(300)) + fadeOut(tween(200))
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = if (isPaused) "点击播放" else "点击暂停",
                        modifier = Modifier.size(40.dp),
                        tint = Color.White
                    )
                }
            }

            // ── 底部进度条和时间显示（默认隐藏，点击唤起，2秒自动淡出）──
            // 2秒无操作自动隐藏控制栏
            if (showControls) {
                LaunchedEffect(Unit) {
                    kotlinx.coroutines.delay(2000)
                    showControls = false
                    showPlayPauseIcon = false
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .align(Alignment.BottomCenter),
                contentAlignment = Alignment.BottomCenter
            ) {
                AnimatedVisibility(
                    visible = showControls,
                    enter = fadeIn(animationSpec = tween(300)),
                    exit = fadeOut(animationSpec = tween(300))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .background(Color(0x80000000), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                    // 进度条轨道（扩大触摸区域便于拖动）
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp) // 触摸区域
                            .clipToBounds()
                            .pointerInput(videoDurationMs) {
                                detectTapGestures { offset ->
                                    if (videoDurationMs > 0) {
                                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        val targetMs = (fraction * videoDurationMs).toLong()
                                        mediaPlayerRef?.seekTo(targetMs.toInt())
                                        currentPositionMs = targetMs
                                    }
                                }
                            }
                            .pointerInput(videoDurationMs) {
                                detectHorizontalDragGestures(
                                    onDragStart = { offset ->
                                        isSeeking = true
                                        if (videoDurationMs > 0) {
                                            val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                                            val targetMs = (fraction * videoDurationMs).toLong()
                                            mediaPlayerRef?.seekTo(targetMs.toInt())
                                            currentPositionMs = targetMs
                                        }
                                    },
                                    onDragEnd = {
                                        isSeeking = false
                                    },
                                    onDragCancel = {
                                        isSeeking = false
                                    }
                                ) { change, _ ->
                                    if (videoDurationMs > 0) {
                                        val fraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                                        val targetMs = (fraction * videoDurationMs).toLong()
                                        mediaPlayerRef?.seekTo(targetMs.toInt())
                                        currentPositionMs = targetMs
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        // 视觉进度条（4dp 细条）
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(Color(0x4DFFFFFF))
                        ) {
                            val progress = if (videoDurationMs > 0) {
                                (currentPositionMs.toFloat() / videoDurationMs).coerceIn(0f, 1f)
                            } else 0f
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(fraction = progress)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(Color.White)
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatTime(currentPositionMs), fontSize = 11.sp, color = Color(0xCCFFFFFF))
                        Text(formatTime(videoDurationMs), fontSize = 11.sp, color = Color(0xCCFFFFFF))
                    }
                }
            }
            }



            // ── 加载遮罩层（仅在缓冲或未准备好时显示）──
            if (isBuffering || !isPrepared) {
                if (totalFileSize == 0L) {
                    LaunchedEffect(Unit) {
                        try {
                            val len = com.aurora.chat.data.api.HttpClient.headContentLength(videoPlayUrl)
                            if (len > 0) totalFileSize = len
                        } catch (_: Exception) { totalFileSize = -1L }
                    }
                }

                LaunchedEffect(bufferPercent) {
                    if (bufferPercent > 0 && totalFileSize > 0) {
                        val nowMs = System.currentTimeMillis()
                        val currentBytes = (totalFileSize * bufferPercent) / 100L
                        if (lastBytes > 0) {
                            val elapsed = (nowMs - lastTimeMs).coerceAtLeast(1)
                            val deltaBytes = currentBytes - lastBytes
                            val bytesPerSec = (deltaBytes * 1000L) / elapsed
                            speedText = when {
                                bytesPerSec > 1_000_000 -> "${"%.1f".format(bytesPerSec / 1_000_000.0)} MB/s"
                                bytesPerSec > 1_000 -> "${"%.0f".format(bytesPerSec / 1_000.0)} KB/s"
                                else -> "$bytesPerSec B/s"
                            }
                        }
                        lastBytes = currentBytes
                        lastTimeMs = nowMs
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x80000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        androidx.compose.material3.CircularProgressIndicator(
                            modifier = Modifier.size(48.dp),
                            color = Color.White,
                            strokeWidth = 4.dp,
                            trackColor = Color(0x4DFFFFFF)
                        )
                        Spacer(Modifier.height(16.dp))
                        Text(
                            if (bufferPercent > 0) "缓冲中 ${bufferPercent}%" else "加载中...",
                            fontSize = 16.sp, color = Color.White, fontWeight = FontWeight.Medium
                        )
                        if (speedText.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Text(speedText, fontSize = 13.sp, color = Color(0xCCFFFFFF))
                        }
                        if (bufferPercent > 0) {
                            Spacer(Modifier.height(12.dp))
                            Box(
                                modifier = Modifier
                                    .width(200.dp).height(4.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(Color(0x4DFFFFFF))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(fraction = bufferPercent / 100f)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(Color.White)
                                )
                            }
                        }
                    }
                }
            }

            // ── 播放图标自动隐藏（2秒后）──
            LaunchedEffect(showPlayPauseIcon) {
                if (showPlayPauseIcon) {
                    delay(2000)
                    showPlayPauseIcon = false
                }
            }

            // ── 实时更新播放位置（拖拽进度条时跳过）──
            LaunchedEffect(isPaused, isPrepared) {
                while (isPrepared && !isPaused) {
                    if (!isSeeking) {
                        mediaPlayerRef?.let { mp ->
                            if (mp.isPlaying) currentPositionMs = mp.currentPosition.toLong()
                        }
                    }
                    delay(250)
                }
            }
        }
    }

    // ── 点击徽章弹出详情 ──
    if (badgeDialogId > 0) {
        BadgeInfoDialog(badgeId = badgeDialogId, onDismiss = { badgeDialogId = 0 })
    }

    // ── AI 设置弹窗（合并上传/恢复头像 + 设置/恢复名称）──
    if (showAiSettingsDialog) {
        Dialog(onDismissRequest = { showAiSettingsDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("AI 设置", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                    Spacer(Modifier.height(16.dp))
                    AiSettingsItem("上传 AI 头像") {
                        showAiSettingsDialog = false
                        aiAvatarLauncher.launch("image/*")
                    }
                    AiSettingsItem("恢复默认头像") {
                        try { LocalStorage.getAiAvatarFile(ctx).delete() } catch (_: Exception) {}
                        AiAvatarState.bitmap = null
                        showAiSettingsDialog = false
                        Toast.makeText(ctx, "已恢复默认头像", Toast.LENGTH_SHORT).show()
                    }
                    AiSettingsItem("设置 AI 名称") {
                        aiNameInput = AiNameState.name ?: ""
                        showAiNameInput = true
                        showAiSettingsDialog = false
                    }
                    AiSettingsItem("恢复 AI 名称") {
                        LocalStorage.resetAiName(ctx)
                        AiNameState.name = null
                        showAiSettingsDialog = false
                        Toast.makeText(ctx, "已恢复默认名称", Toast.LENGTH_SHORT).show()
                    }
                    AiSettingsItem("人物对换" + if (reverseHistory) "（已开启）" else "") {
                        showAiSettingsDialog = false
                        showReverseInfo = true
                    }
                    AiSettingsItem("上传我方头像") {
                        showAiSettingsDialog = false
                        myAvatarLauncher.launch("image/*")
                    }
                    AiSettingsItem("占位符转换") {
                        showAiSettingsDialog = false
                        showPlaceholderConvert = true
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(
                        onClick = { showAiSettingsDialog = false },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    ) {
                        Text("取消", color = Color(0xFF6B7280), fontSize = 15.sp)
                    }
                }
            }
        }
    }

    // ── 人物对换说明弹窗 ──
    if (showReverseInfo) {
        AlertDialog(
            onDismissRequest = { showReverseInfo = false },
            title = { Text("人物对换") },
            text = {
                Column {
                    Text(
                        "开启后：\n" +
                            "• 对话将整体反转——你与 AI 的左右位置互换、头像也互换；\n" +
                            "• 发给 AI 的上下文中会标注「聊天记录是反过来的」，让 AI 以你的身份（我方）继续与对方自然聊下去。\n\n" +
                            "适合你导入了别人的对话、想以对方视角接着聊的场景。",
                        fontSize = 14.sp, color = Color(0xFF374151)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    reverseHistory = !reverseHistory
                    LocalStorage.setReverseHistory(ctx, currentUserId, reverseHistory)
                    showReverseInfo = false
                    Toast.makeText(ctx, if (reverseHistory) "已开启人物对换" else "已关闭人物对换", Toast.LENGTH_SHORT).show()
                }) { Text(if (reverseHistory) "关闭" else "开启", color = Color(0xFF1E40AF)) }
            },
            dismissButton = {
                TextButton(onClick = { showReverseInfo = false }) { Text("取消", color = Color(0xFF6B7280)) }
            }
        )
    }

    // ── 占位符转换弹窗 ──
    if (showPlaceholderConvert) {
        val phFroms = remember { mutableStateListOf("男主", "女主") }
        val phTos = remember { mutableStateListOf("人物1", "人物2") }
        AlertDialog(
            onDismissRequest = { showPlaceholderConvert = false },
            containerColor = Color.White,
            title = { Text("占位符转换", fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.widthIn(max = 320.dp)) {
                    Text("设置名称与占位符的对应关系，将全文中的名称替换为占位符或反向还原", fontSize = 13.sp, color = Color(0xFF6B7280))
                    Spacer(Modifier.height(12.dp))
                    // 每行：名称 → 占位符，可增删
                    val dupTos = phTos.map { it.trim() }.filter { it.isNotEmpty() }.groupingBy { it }.eachCount().filter { it.value > 1 }.keys
                    phFroms.indices.forEach { i ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(
                                value = phFroms[i], onValueChange = { phFroms[i] = it },
                                placeholder = { Text("名称", fontSize = 12.sp) }, singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Text("→", fontSize = 13.sp, color = Color(0xFF6B7280))
                            val toVal = phTos[i].trim()
                            OutlinedTextField(
                                value = phTos[i], onValueChange = { phTos[i] = it },
                                placeholder = { Text("占位符", fontSize = 12.sp) }, singleLine = true,
                                isError = toVal.isNotEmpty() && toVal in dupTos,
                                modifier = Modifier.weight(1f)
                            )
                            if (phFroms.size > 1) {
                                Text("✕", fontSize = 14.sp, color = Color(0xFFDC2626),
                                    modifier = Modifier.clickable { phFroms.removeAt(i); phTos.removeAt(i) }.padding(4.dp))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    if (dupTos.isNotEmpty()) {
                        Text("⚠ 占位符不能重复，否则会合并成同一个名称", fontSize = 12.sp, color = Color(0xFFDC2626))
                        Spacer(Modifier.height(6.dp))
                    }
                    TextButton(onClick = { phFroms.add(""); phTos.add("") }) { Text("+ 添加替换项", color = Color(0xFF1E40AF), fontSize = 13.sp) }
                    Spacer(Modifier.height(4.dp))
                    Text("转换方向：点击确定后，全文中的「名称」将被替换为「占位符」；再次点击确定可将「占位符」还原回「名称」（修改对应关系后点确定即可反向操作）", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val tos = phTos.map { it.trim() }.filter { it.isNotEmpty() }
                    if (tos.size != tos.toSet().size) {
                        Toast.makeText(ctx, "占位符不能重复，请修改后再执行", Toast.LENGTH_SHORT).show()
                        return@TextButton
                    }
                    showPlaceholderConvert = false
                    scope.launch {
                        val newList = messages.map { msg ->
                            var text = msg.text
                            var sender = msg.senderName
                            var replyText = msg.replyToText
                            var replySender = msg.replyToSender
                            for (j in phFroms.indices) {
                                val f = phFroms[j].trim()
                                val t = phTos[j].trim()
                                if (f.isNotEmpty() && t.isNotEmpty()) {
                                    text = text.replace(f, t)
                                    sender = sender.replace(f, t)
                                    replyText = replyText.replace(f, t)
                                    replySender = replySender.replace(f, t)
                                }
                            }
                            (msg as? ChatMsg)?.copy(text = text, senderName = sender) ?: msg
                        }
                        messages.clear()
                        messages.addAll(newList)
                        saveLocalChatMessages(ctx, currentUserId, localChatKey(friendId), messages.filter { !it.isSystemNotice })
                        Toast.makeText(ctx, "占位符转换完成", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("确定", color = Color(0xFF1E40AF)) }
            },
            dismissButton = {
                TextButton(onClick = { showPlaceholderConvert = false }) { Text("取消", color = Color(0xFF6B7280)) }
            }
        )
    }

    // ── 设置 AI 名称输入框 ──
    if (showAiNameInput) {
        AlertDialog(
            onDismissRequest = { showAiNameInput = false },
            title = { Text("设置 AI 名称") },
            text = {
                OutlinedTextField(
                    value = aiNameInput,
                    onValueChange = { aiNameInput = it.take(20) },
                    placeholder = { Text("例如：小深") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = aiNameInput.trim()
                    if (n.isNotEmpty()) {
                        LocalStorage.setAiName(ctx, n)
                        AiNameState.name = n
                        Toast.makeText(ctx, "AI 名称已设为：$n", Toast.LENGTH_SHORT).show()
                    }
                    showAiNameInput = false
                }) { Text("确定", color = Color(0xFF1E40AF)) }
            },
            dismissButton = {
                TextButton(onClick = { showAiNameInput = false }) { Text("取消", color = Color(0xFF6B7280)) }
            }
        )
    }
}

/** AI 设置弹窗里的单行可点击项 */
@Composable
private fun AiSettingsItem(title: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 14.dp)
    ) {
        Text(title, fontSize = 15.sp, color = Color(0xFF374151))
    }
    Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFF0F1F3)))
}

// ═════════════════════════════════════════════════════
    // ── 转账弹窗 ──
    @Composable
    private fun TransferDialog(
        friendId: Long,
        currentUserId: Long,
        currentUserName: String,
        friendName: String,
        messages: androidx.compose.runtime.snapshots.SnapshotStateList<IMessageRef>,
        ctx: Context,
        onDismiss: () -> Unit
    ) {
        val isGroup = isGroupChat(friendId)
        var amountText by remember { mutableStateOf("") }
        var selectedId by remember { mutableStateOf(0L) }
        var selectedName by remember { mutableStateOf("") }
        var members by remember { mutableStateOf<List<Pair<Long, String>>>(emptyList()) }
        var loading by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()

        LaunchedEffect(Unit) {
            if (!isGroup) {
                selectedId = friendId
                selectedName = friendName
            } else {
                loading = true
                try {
                    val gid = -(friendId + 1000)
                    val r = AuroraApi.getGroupMembers(gid)
                    if (r.success && r.data != null) {
                        val list = mutableListOf<Pair<Long, String>>()
                        for (i in 0 until r.data!!.length()) {
                            val o = r.data!!.optJSONObject(i) ?: continue
                            val id = if (o.has("user_id")) o.optLong("user_id") else o.optLong("id")
                            val name = o.optString("username", "用户$id")
                            if (id != currentUserId && id > 0) list.add(id to name)
                        }
                        members = list
                    }
                } catch (_: Exception) { }
                loading = false
            }
        }

        Dialog(onDismissRequest = onDismiss) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .padding(20.dp)
            ) {
                Column {
                    Text("转账", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                    Spacer(Modifier.height(14.dp))
                    if (isGroup) {
                        Text("收款人", fontSize = 13.sp, color = Color(0xFF6B7280))
                        Spacer(Modifier.height(6.dp))
                        if (loading) {
                            Text("加载成员中...", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                        } else {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 180.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFFF3F4F6))
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Column {
                                    members.forEach { (id, name) ->
                                        Row(
                                            Modifier
                                                .fillMaxWidth()
                                                .clickable { selectedId = id; selectedName = name }
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(selected = selectedId == id, onClick = { selectedId = id; selectedName = name })
                                            Spacer(Modifier.width(8.dp))
                                            Text(name, fontSize = 14.sp, color = Color(0xFF1F2937))
                                        }
                                    }
                                    if (members.isEmpty()) {
                                        Text("群内暂无可转账成员", fontSize = 13.sp, color = Color(0xFF9CA3AF), modifier = Modifier.padding(12.dp))
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                    Text("转账金额（token）", fontSize = 13.sp, color = Color(0xFF6B7280))
                    Spacer(Modifier.height(6.dp))
                    BasicTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { c -> c.isDigit() }.take(12) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF3F4F6))
                            .padding(12.dp),
                        textStyle = TextStyle(fontSize = 16.sp, color = Color(0xFF1F2937)),
                        singleLine = true,
                        decorationBox = { inner ->
                            if (amountText.isEmpty()) Text("请输入数量", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                            else inner()
                        }
                    )
                    Spacer(Modifier.height(18.dp))
                    val amount = amountText.toLongOrNull() ?: 0
                    val canSend = amount > 0 && selectedId > 0 && selectedId != currentUserId
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (canSend) Color(0xFF1E40AF) else Color(0xFFD1D5DB))
                            .clickable(enabled = canSend) {
                                scope.launch {
                                    try {
                                        val r = AuroraApi.transfer(friendId, selectedId, selectedName, amount)
                                        if (r.success) {
                                            val senderName = currentUserName.ifEmpty {
                                                ctx.getSharedPreferences("aurora_login", android.content.Context.MODE_PRIVATE).getString("username", "") ?: ""
                                            }
                                            val content = buildTransferContent(currentUserId, senderName, selectedId, selectedName, amount)
                                            messages.add(ChatMsg.create(text = content, isMine = true, fromUserId = currentUserId, isNew = true, mediaType = "transfer", createdAt = System.currentTimeMillis() / 1000))
                                            ChatViewModel.updateConversationPreview(friendId, "[转账]", System.currentTimeMillis() / 1000)
                                            ChatViewModel.notifyNewMessage()
                                            android.widget.Toast.makeText(ctx, "转账成功", android.widget.Toast.LENGTH_SHORT).show()
                                            onDismiss()
                                        } else {
                                            android.widget.Toast.makeText(ctx, r.message, android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    } catch (e: Exception) {
                                        android.widget.Toast.makeText(ctx, "转账失败: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (amount > 0) "确认转账 $amount token" else "确认转账", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White)
                    }
                }
            }
        }
    }

    // 隐私控制面板组件 — 从右侧滑入，显示双方隐私设置
    // ═════════════════════════════════════════════════════
    @Composable
    private fun PrivacySettingsPanel(
    friendId: Long,
    currentUserId: Long,
    onClose: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var mySettings by remember { mutableStateOf<org.json.JSONObject?>(null) }
    var friendSettings by remember { mutableStateOf<org.json.JSONObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var showNoExitInfo by remember { mutableStateOf(false) }

    // 加载双方隐私设置
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            try {
                val myResult = AuroraApi.getPrivacySettings(friendId)
                mySettings = myResult.data
            } catch (_: Exception) {}
            try {
                // 查询对方对当前用户的隐私设置（禁止截图/录屏/退出）
                val fr = AuroraApi.getFriendPrivacySettings(friendId)
                friendSettings = fr.data
            } catch (_: Exception) {}
            loading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.White).padding(top = 48.dp)) {
        if (loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFF1E40AF))
            }
        } else {
            Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
                // 顶栏
                Text("隐私控制", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1F2937))
                Spacer(Modifier.height(20.dp))

                // ── 我的设置 ──
                Text("我的设置", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Color(0xFF1E40AF))
                Spacer(Modifier.height(12.dp))

                // 禁止退出（我方开启→我方锁定退出；双方都开启→双方都锁定；独立开关，无需对方同意）
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("禁止退出", fontSize = 14.sp, color = Color(0xFF374151), modifier = Modifier.weight(1f))
                    Text(
                        text = "?",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E40AF),
                        modifier = Modifier
                            .clickable { showNoExitInfo = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                    Switch(
                        checked = mySettings?.optBoolean("no_exit", false) ?: false,
                        onCheckedChange = { v ->
                            // 立即更新本地 UI（创建新对象触发 Compose 重组）
                            val newObj = org.json.JSONObject(mySettings?.toString() ?: "{}")
                            newObj.put("no_exit", v)
                            mySettings = newObj
                            scope.launch {
                                AuroraApi.updatePrivacySettings(friendId, false, v,
                                    mySettings?.optBoolean("no_screenshot", false) ?: false,
                                    mySettings?.optBoolean("no_recording", false) ?: false,
                                    mySettings?.optBoolean("detect_screenshot", false) ?: false,
                                    mySettings?.optBoolean("detect_recording", false) ?: false)
                                AuroraApi.sendPrivacyAlert(friendId, "no_exit_toggle", v)
                            }
                        }
                    )
                }

                PrivacySettingRow("禁止截图", mySettings?.optBoolean("no_screenshot", false) ?: false) { v ->
                    val newObj = org.json.JSONObject(mySettings?.toString() ?: "{}")
                    newObj.put("no_screenshot", v)
                    mySettings = newObj
                    scope.launch {
                        AuroraApi.updatePrivacySettings(friendId, false,
                            mySettings?.optBoolean("no_exit", false) ?: false, v,
                            mySettings?.optBoolean("no_recording", false) ?: false,
                            mySettings?.optBoolean("detect_screenshot", false) ?: false,
                            mySettings?.optBoolean("detect_recording", false) ?: false)
                        AuroraApi.sendPrivacyAlert(friendId, "no_screenshot_toggle", v)
                    }
                }
                PrivacySettingRow("禁止录屏", mySettings?.optBoolean("no_recording", false) ?: false) { v ->
                    val newObj = org.json.JSONObject(mySettings?.toString() ?: "{}")
                    newObj.put("no_recording", v)
                    mySettings = newObj
                    scope.launch {
                        AuroraApi.updatePrivacySettings(friendId, false,
                            mySettings?.optBoolean("no_exit", false) ?: false,
                            mySettings?.optBoolean("no_screenshot", false) ?: false, v,
                            mySettings?.optBoolean("detect_screenshot", false) ?: false,
                            mySettings?.optBoolean("detect_recording", false) ?: false)
                        AuroraApi.sendPrivacyAlert(friendId, "no_recording_toggle", v)
                    }
                }

                // ── 截图检测（不拦截，仅通知） ──
                PrivacySettingRow("截图检测", mySettings?.optBoolean("detect_screenshot", false) ?: false) { v ->
                    val newObj = org.json.JSONObject(mySettings?.toString() ?: "{}")
                    newObj.put("detect_screenshot", v)
                    mySettings = newObj
                    if (v) {
                        // 开启检测 → 启动后台服务运行 ScreenshotDetector
                        com.aurora.chat.PrivacyFloatingService.start(ctx, friendId)
                    }
                    scope.launch {
                        AuroraApi.updatePrivacySettings(friendId, false,
                            mySettings?.optBoolean("no_exit", false) ?: false,
                            mySettings?.optBoolean("no_screenshot", false) ?: false,
                            mySettings?.optBoolean("no_recording", false) ?: false, v,
                            mySettings?.optBoolean("detect_recording", false) ?: false)
                    }
                }
                // ── 录屏检测（不拦截，仅通知） ──
                PrivacySettingRow("录屏检测", mySettings?.optBoolean("detect_recording", false) ?: false) { v ->
                    val newObj = org.json.JSONObject(mySettings?.toString() ?: "{}")
                    newObj.put("detect_recording", v)
                    mySettings = newObj
                    if (v) {
                        com.aurora.chat.PrivacyFloatingService.start(ctx, friendId)
                    }
                    scope.launch {
                        AuroraApi.updatePrivacySettings(friendId, false,
                            mySettings?.optBoolean("no_exit", false) ?: false,
                            mySettings?.optBoolean("no_screenshot", false) ?: false,
                            mySettings?.optBoolean("no_recording", false) ?: false,
                            mySettings?.optBoolean("detect_screenshot", false) ?: false, v)
                    }
                }

                Spacer(Modifier.height(24.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE5E7EB)))
                Spacer(Modifier.height(24.dp))

                // ── 对方设置（只读显示） ──
                Text("对方设置", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Color(0xFF6B7280))
                Spacer(Modifier.height(12.dp))
                FriendSettingRow("禁止退出", friendSettings?.optBoolean("no_exit", false) ?: false)
                FriendSettingRow("禁止截图", friendSettings?.optBoolean("no_screenshot", false) ?: false)
                FriendSettingRow("禁止录屏", friendSettings?.optBoolean("no_recording", false) ?: false)
                FriendSettingRow("截图检测", friendSettings?.optBoolean("detect_screenshot", false) ?: false)
                FriendSettingRow("录屏检测", friendSettings?.optBoolean("detect_recording", false) ?: false)

                Spacer(Modifier.height(24.dp))
                Spacer(Modifier.weight(1f))

                // 关闭按钮
                Button(
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF))
                ) {
                    Text("关闭", color = Color.White, fontSize = 15.sp)
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }

    // 禁止退出帮助弹窗
    if (showNoExitInfo) {
        AlertDialog(
            onDismissRequest = { showNoExitInfo = false },
            title = { Text("禁止退出", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
            text = {
                Text(
                    "独立开关 + 协同生效：\n\n" +
                    "• 你开启 → 你无法退出（返回键被拦截）\n" +
                    "• 对方开启 → 对方无法退出\n" +
                    "• 双方都开启 → 双方都无法退出\n" +
                    "• 各自独立控制，无需对方同意\n" +
                    "• 需开启无障碍权限才能生效",
                    fontSize = 14.sp,
                    lineHeight = 22.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showNoExitInfo = false }) {
                    Text("我知道了", color = Color(0xFF1E40AF))
                }
            }
        )
    }
}

@Composable
private fun PrivacySettingRow(label: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 14.sp, color = Color(0xFF374151), modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}

@Composable
private fun FriendSettingRow(label: String, checked: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 14.sp, color = Color(0xFF6B7280), modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = null, enabled = false)
    }
}

// ==================== 订单详情（从通知中心「查看订单」进入） ====================

private val ORDER_LEVEL_NAMES = listOf("普通会员", "高级会员", "尊享会员")

@Composable
private fun OrderDetailView(orderId: Long, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var order by remember { mutableStateOf<com.aurora.chat.data.api.AuroraApi.UserOrderDetail?>(null) }
    var loading by remember { mutableStateOf(true) }
    var errMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(orderId) {
        loading = true
        errMsg = null
        order = null
        scope.launch {
            try {
                val r = com.aurora.chat.data.api.AuroraApi.getOrderById(orderId)
                if (r.success && r.data != null) order = r.data
                else errMsg = r.message
            } catch (e: Exception) {
                errMsg = e.localizedMessage ?: "加载失败"
            } finally {
                loading = false
            }
        }
    }

    val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
    fun ts(t: Long): String = if (t <= 0) "-" else fmt.format(java.util.Date(t * 1000))


    // 正常居中弹出：淡入 + 从中心轻微放大，避免默认对话框的异常位移动画
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        AnimatedVisibility(
            visible = true,
            enter = fadeIn(tween(160)) +
                scaleIn(tween(200), initialScale = 0.95f, transformOrigin = TransformOrigin(0.5f, 0.5f)),
            exit = fadeOut(tween(120)) +
                scaleOut(tween(140), targetScale = 0.95f, transformOrigin = TransformOrigin(0.5f, 0.5f))
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                tonalElevation = 0.dp
            ) {
                Column(
                    Modifier
                        .padding(16.dp)
                        .widthIn(min = 240.dp, max = 300.dp)
                ) {
                    Text("订单详情", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1F2937))
                    Spacer(Modifier.height(14.dp))
                    when {
                        loading -> Text("加载中...", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                        errMsg != null -> Text(errMsg ?: "加载失败", fontSize = 14.sp, color = Color(0xFFDC2626), lineHeight = 22.sp)
                        order != null -> {
                            val o = order!!
                            val statusText = when (o.status) {
                                "approved" -> "已通过"
                                "rejected" -> "已拒绝"
                                else -> "待审核"
                            }
                            val typeText = if (o.type == "recharge") {
                                "Token 充值 · ${o.tokens} Token"
                            } else {
                                "${ORDER_LEVEL_NAMES.getOrElse(o.level - 1) { "Lv.${o.level}" }} · ${o.durationDays} 天"
                            }
                            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                                OrderInfoRow("订单号", o.orderNo)
                                OrderInfoRow("类型", typeText)
                                OrderInfoRow("金额", "¥${o.amount}")
                                OrderInfoRow("提交时间", ts(o.createdAt))
                                OrderInfoRow("状态", statusText)
                                if (o.status == "rejected" && o.rejectReason.isNotBlank()) {
                                    OrderInfoRow("拒绝原因", o.rejectReason)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("关闭", color = Color(0xFF1E40AF)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun OrderInfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, fontSize = 13.sp, color = Color(0xFF9CA3AF), modifier = Modifier.width(76.dp))
        Text(value, fontSize = 13.sp, color = Color(0xFF1F2937), modifier = Modifier.weight(1f))
    }
}