package com.aurora.chat.ui.server

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*

import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow


import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.ui.chat.AiChatManager
import androidx.compose.ui.layout.ContentScale
import com.aurora.chat.data.api.CommentInfo
import com.aurora.chat.data.api.CommentListResponse
import com.aurora.chat.data.local.LocalStorage
import com.aurora.chat.data.repository.ChatRepository
import com.aurora.chat.ui.chat.loadAiConversationShareJson
import com.aurora.chat.ui.community.CommentRow
import com.aurora.chat.ui.community.SharePostDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private val ShareGreen = Color(0xFF059669)
private val ShareGreenLight = Color(0xFF059669).copy(alpha = 0.12f)

/** 从 content:// 或 file:// URI 取出可读的文件名（用于「从设备文件获取」后展示） */
private fun getUriDisplayName(context: Context, uri: Uri): String? {
    return try {
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
            }
        } else {
            uri.lastPathSegment
        }
    } catch (_: Exception) { null }
}

/**
 * AI 对话分享桥接：
 * - [currentConversation] 由 AI 对话界面注入（当前与 DeepSeek 的对话全文）。
 * - [pendingImport] 由导入功能设置，供 AI 对话界面读取后覆盖到当前对话。
 */
object AiChatShareBridge {
    /** 由 AI 对话界面注入：当前与 DeepSeek 的对话全文。 */
    var currentConversation: String = ""
    /** 后端返回的截图数量限制（默认 3），由 submitAiChat 成功后更新 */
    var maxScreenshots: Int = 3
    /** 由「覆盖到当前对话」设置（可观察状态）：供 AI 对话界面读取后解析并覆盖到当前对话。 */
    var pendingImport by mutableStateOf("")
}

@Composable
fun AiChatShareScreen(onBack: () -> Unit, initialShareId: Long = 0L) {
    var view by remember { mutableStateOf(if (initialShareId > 0) "detail" else "feed") } // feed | upload | detail
    var selectedId by remember { mutableStateOf(initialShareId) }
    var feedVersion by remember { mutableStateOf(0) } // 上传成功后 +1 触发刷新

    Box(Modifier.fillMaxSize().background(Color.White)) {
        AnimatedVisibility(
            visible = view == "feed",
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(150))
        ) {
            AiChatShareFeed(
                refreshKey = feedVersion,
                onBack = onBack,
                onUpload = { view = "upload" },
                onOpenDetail = { id ->
                    selectedId = id
                    view = "detail"
                }
            )
        }
        AnimatedVisibility(
            visible = view == "upload",
            enter = slideInHorizontally(tween(300)) { it },
            exit = slideOutHorizontally(tween(300)) { it }
        ) {
            AiChatUploadScreen(
                onBack = { view = "feed" },
                onSubmitted = {
                    feedVersion++
                    view = "feed"
                }
            )
        }
        AnimatedVisibility(
            visible = view == "detail",
            enter = slideInHorizontally(tween(300)) { it },
            exit = slideOutHorizontally(tween(300)) { it }
        ) {
            AiChatShareDetail(
                shareId = selectedId,
                onBack = { view = "feed" }
            )
        }
    }
}


// ===================== 筛选抽屉（从顶部向下划出） =====================

@Composable
private fun AiChatFilterSheet(
    initialIsFree: String,
    initialMinTokens: Long,
    initialMaxTokens: Long,
    initialSort: String,
    onApply: (String, Long, Long, String) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    var localFree by remember { mutableStateOf(initialIsFree) }
    var localMin by remember { mutableStateOf(initialMinTokens) }
    var localMax by remember { mutableStateOf(initialMaxTokens) }
    var localSort by remember { mutableStateOf(initialSort) }
    var customOpen by remember {
        mutableStateOf(
            initialMinTokens > 0 && initialMaxTokens > 0 &&
                !listOf(5000L, 10000L, 100000L).contains(initialMaxTokens)
        )
    }

    val ranges = listOf(
        "0~5000" to (0L to 5000L),
        "5000~1万" to (5000L to 10000L),
        "1万~10万" to (10000L to 100000L)
    )

    // 纯白色面板，无遮罩
    Column(
        Modifier.fillMaxWidth().wrapContentHeight().background(Color.White)
            .clickable(enabled = false) {}
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // 标题行
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("筛选", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            Text("完成", fontSize = 14.sp, color = ShareGreen, fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onApply(localFree, localMin, localMax, localSort) })
        }
        Spacer(Modifier.height(12.dp))

        // 类型
        Text("类型", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipItem("全部", localFree == "") { localFree = "" }
            FilterChipItem("免费", localFree == "1") { localFree = "1" }
            FilterChipItem("收费", localFree == "0") { localFree = "0" }
        }

        Spacer(Modifier.height(14.dp))

        // Token 价格区间
        Text("Token 价格区间", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ranges.forEach { (label, pair) ->
                val active = localMin == pair.first && localMax == pair.second
                FilterChipItem(label, active) { localMin = pair.first; localMax = pair.second; customOpen = false }
            }
            // 自定义放到第二排，不浪费空间
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChipItem("自定义", customOpen) { customOpen = true; localMin = 0; localMax = 0 }
            if (customOpen) {
                TokensInput(localMin, { localMin = it }, "最小")
                Text("~", Modifier.padding(horizontal = 4.dp), color = Color(0xFF9CA3AF))
                TokensInput(localMax, { localMax = it }, "最大")
            }
        }

        Spacer(Modifier.height(14.dp))

        // 排序
        Text("排序", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipItem("最新", localSort == "time") { localSort = "time" }
            FilterChipItem("下载量最高", localSort == "download") { localSort = "download" }
        }

        Spacer(Modifier.height(14.dp))

        // 重置
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFF3F4F6))
                .clickable { onReset() }.padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("重置筛选", fontSize = 13.sp, color = Color(0xFF6B7280), fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun FilterChipItem(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) ShareGreenLight else Color(0xFFF3F4F6)
    val fg = if (selected) ShareGreen else Color(0xFF6B7280)
    Box(
        Modifier.clip(RoundedCornerShape(16.dp)).background(bg).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(label, fontSize = 13.sp, color = fg, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun TokensInput(value: Long, onValueChange: (Long) -> Unit, placeholder: String) {
    var text by remember(value) { mutableStateOf(if (value > 0) value.toString() else "") }
    BasicTextField(
        value = text,
        onValueChange = {
            text = it.filter { c -> c.isDigit() }
            onValueChange(text.toLongOrNull() ?: 0L)
        },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.width(90.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFF3F4F6))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp, color = Color(0xFF1F2937)),
        cursorBrush = SolidColor(ShareGreen),
        decorationBox = { inner -> if (text.isEmpty()) Text(placeholder, color = Color(0xFF9CA3AF), fontSize = 13.sp); inner() }
    )
}
// ===================== Feed =====================

@Composable
private fun AiChatShareFeed(
    refreshKey: Int,
    onBack: () -> Unit,
    onUpload: () -> Unit,
    onOpenDetail: (Long) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val serverUrl = remember { AuroraApi.serverUrl }

    var keyword by remember { mutableStateOf("") }
    var searchText by remember { mutableStateOf("") }
    var shares by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    // 筛选条件：isFree "" 不限 / "1" 免费 / "0" 收费；token 区间；排序 time/download
    var filterIsFree by remember { mutableStateOf("") }
    var filterMinTokens by remember { mutableStateOf(0L) }
    var filterMaxTokens by remember { mutableStateOf(0L) }
    var sortBy by remember { mutableStateOf("time") }
    var showFilter by remember { mutableStateOf(false) }

    // 当前用户是否开发者（最高权限，可删任意卡片）；与后端 isDeveloperUser 判据一致
    val isDeveloper = remember {
        LocalStorage.isDeveloper(AuroraApi.currentUserQQ, AuroraApi.currentUserEmail)
    }
    val currentUserId = AuroraApi.currentUserId
    // 长按菜单「分享」选中的卡片（非 null 时弹出分享面板）
    var shareTarget by remember { mutableStateOf<JSONObject?>(null) }

    fun deleteShare(shareId: Long) {
        scope.launch {
            try {
                val r = AuroraApi.deleteAiChat(shareId)
                if (r.success) {
                    shares = shares.filter { it.optLong("id", 0) != shareId }
                    Toast.makeText(context, "已删除", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, r.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, e.localizedMessage ?: "删除失败", Toast.LENGTH_SHORT).show()
            }
        }
    }


    fun load(
        forceIsFree: String = filterIsFree,
        forceMin: Long = filterMinTokens,
        forceMax: Long = filterMaxTokens,
        forceSort: String = sortBy
    ) {
        isLoading = true
        errorMsg = null
        scope.launch {
            try {
                val r = AuroraApi.getAiChatList(
                    keyword = keyword,
                    page = 1,
                    limit = 40,
                    isFree = forceIsFree,
                    minTokens = forceMin,
                    maxTokens = forceMax,
                    sort = forceSort
                )
                if (r.success && r.data != null) {
                    val arr = r.data.optJSONArray("shares")
                    val list = (0 until (arr?.length() ?: 0)).map { arr!!.getJSONObject(it) }
                    shares = list
                } else {
                    errorMsg = r.message
                }
            } catch (e: Exception) {
                errorMsg = e.localizedMessage ?: "加载失败"
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(refreshKey) { load() }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
        // 顶栏
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.ArrowBack, contentDescription = null,
                modifier = Modifier.size(24.dp).clickable { onBack() },
                tint = Color(0xFF1F2937))
            Spacer(Modifier.width(8.dp))
            Text("AI 对话分享", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        }

        // 搜索 + 筛选 行
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 左侧「筛选」按钮
            Row(
                Modifier.clickable { showFilter = true }.padding(vertical = 8.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.FilterList, contentDescription = null, tint = ShareGreen, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("筛选", fontSize = 13.sp, color = ShareGreen, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.width(8.dp))
            // 搜索框（向右挤，腾出左侧空间）
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF3F4F6)).padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Search, contentDescription = null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                TextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    placeholder = { Text("搜索内容", fontSize = 14.sp, color = Color(0xFF9CA3AF)) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = ShareGreen
                    ),
                    modifier = Modifier.weight(1f),
                    textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
                )
                if (searchText.isNotEmpty()) {
                    Icon(Icons.Filled.Clear, contentDescription = null, tint = Color(0xFF9CA3AF),
                        modifier = Modifier.size(18.dp).clickable { searchText = ""; keyword = ""; load() })
                }
                Text("搜索", fontSize = 13.sp, color = ShareGreen, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable {
                        keyword = searchText.trim()
                        load()
                    })
            }
        }

        Spacer(Modifier.height(8.dp))

        Box(Modifier.fillMaxSize()) {
            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(28.dp), color = ShareGreen, strokeWidth = 3.dp)
                }
            } else if (errorMsg != null) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(errorMsg!!, color = Color(0xFFDC2626), fontSize = 14.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("重试", color = ShareGreen, fontWeight = FontWeight.Medium,
                            modifier = Modifier.clickable { load() })
                    }
                }
            } else if (shares.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        if (keyword.isNotEmpty()) "未找到相关 AI 对话" else "还没有人分享AI对话，点击 + 成为第一个吧",
                        color = Color(0xFF9CA3AF), fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(shares) { share ->
                        AiChatShareCard(
                            share = share,
                            serverUrl = serverUrl,
                            isDeveloper = isDeveloper,
                            currentUserId = currentUserId,
                            onClick = {
                                onOpenDetail(share.optLong("id", 0))
                            },
                            onDelete = { deleteShare(share.optLong("id", 0)) },
                            onShare = { shareTarget = it }
                        )
                    }
                }
            }

            // 右下角悬浮球（+）
            FloatingActionButton(
                onClick = onUpload,
                containerColor = ShareGreen,
                contentColor = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = 20.dp, bottom = 64.dp)
                    .size(56.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "上传", modifier = Modifier.size(28.dp))
            }

            // 长按菜单「分享」→ 分享到好友/群聊（标题固定为「分享AI对话」，链接到该对话详情）
            shareTarget?.let { st ->
                SharePostDialog(
                    postTitle = st.optString("title", ""),
                    postContent = st.optString("preview", st.optString("description", "")),
                    postId = st.optLong("id", 0),
                    postUserId = st.optLong("user_id", 0),
                    postUsername = st.optString("username", ""),
                    postType = "",
                    titlePrefix = "分享AI对话",
                    idKey = "ai_chat_id",
                    onDismiss = { shareTarget = null }
                )
            }
        }
        } // 关闭内层 Column

        // ── 筛选抽屉（遮罩仅做淡入淡出，白色面板做滑入/滑出） ──
        AnimatedVisibility(visible = showFilter, enter = fadeIn(tween(200)), exit = fadeOut(tween(200))) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)).clickable { showFilter = false })
        }
        AnimatedVisibility(
            visible = showFilter,
            enter = slideInVertically(tween(280)) { -it },
            exit = slideOutVertically(tween(280)) { -it }
        ) {
            AiChatFilterSheet(
                initialIsFree = filterIsFree,
                initialMinTokens = filterMinTokens,
                initialMaxTokens = filterMaxTokens,
                initialSort = sortBy,
                onApply = { isFree, min, max, s ->
                    filterIsFree = isFree
                    filterMinTokens = min
                    filterMaxTokens = max
                    sortBy = s
                    showFilter = false
                    load(forceIsFree = isFree, forceMin = min, forceMax = max, forceSort = s)
                },
                onReset = {
                    filterIsFree = ""
                    filterMinTokens = 0
                    filterMaxTokens = 0
                    sortBy = "time"
                    showFilter = false
                    load(forceIsFree = "", forceMin = 0, forceMax = 0, forceSort = "time")
                },
                onDismiss = { showFilter = false }
            )
        }
    } // 关闭根 Box
}


@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun AiChatShareCard(
    share: JSONObject,
    serverUrl: String,
    isDeveloper: Boolean,
    currentUserId: Long,
    onClick: () -> Unit,
    onDelete: (Long) -> Unit,
    onShare: (JSONObject) -> Unit
) {
    val id = share.optLong("id", 0)
    val ownerId = share.optLong("user_id", 0)
    val canDelete = isDeveloper || ownerId == currentUserId
    var showMenu by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }

    val title = share.optString("title", "")
    val isFree = share.optInt("is_free", 1) == 1
    val price = share.optLong("price_tokens", 0)
    val downloadCount = share.optInt("download_count", 0)
    val screenshots = try {
        val arr = share.optJSONArray("screenshots")
        (0 until (arr?.length() ?: 0)).mapNotNull { arr?.optString(it) }.filter { it.isNotEmpty() }
    } catch (_: Exception) { emptyList() }
    val firstSs = if (screenshots.isNotEmpty()) "$serverUrl/api/ai_chat/screenshot/$id/${screenshots[0]}" else ""

    Box(Modifier.wrapContentSize(Alignment.TopStart)) {
        Card(
            modifier = Modifier.fillMaxWidth().combinedClickable(
                onClick = onClick,
                onLongClick = { showMenu = true }
            ),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(Modifier.fillMaxWidth()) {
                // 截图预览区（放大，让图片多显示一点）
                Box(
                    Modifier.fillMaxWidth().height(150.dp)
                        .background(if (firstSs.isEmpty()) ShareGreenLight else Color(0xFFF3F4F6)),
                    contentAlignment = Alignment.Center
                ) {
                    if (firstSs.isNotEmpty()) {
                        AsyncImage(model = firstSs, contentDescription = null,
                            modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                    } else {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = ShareGreen, modifier = Modifier.size(32.dp))
                    }
                }
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937),
                        maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Download, contentDescription = null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("$downloadCount", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                        Spacer(Modifier.weight(1f))
                        // 免费/收费标签（移到下载次数右侧）
                        Box(
                            Modifier.clip(RoundedCornerShape(6.dp))
                                .background(if (isFree) Color(0xFF059669).copy(alpha = 0.12f) else Color(0xFFD97706).copy(alpha = 0.14f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                if (isFree) "免费" else "${price}token",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isFree) ShareGreen else Color(0xFFD97706)
                            )
                        }
                    }
                }
            }
        }

        // 长按弹出的小菜单：分享（所有人可见）；删除（仅本人或开发者）
        DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false }
        ) {
            DropdownMenuItem(
                text = { Text("分享") },
                onClick = {
                    showMenu = false
                    onShare(share)
                }
            )
            if (canDelete) {
                DropdownMenuItem(
                    text = { Text("删除", color = Color(0xFFDC2626)) },
                    onClick = {
                        showMenu = false
                        showConfirm = true
                    }
                )
            }
        }
    }

    // 删除二次确认，避免误删
    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确认删除") },
            text = { Text("删除后该分享将无法恢复，确定要删除吗？") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    onDelete(id)
                }) { Text("删除", color = Color(0xFFDC2626)) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("取消") }
            }
        )
    }
}

// ===================== 上传 =====================

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun AiChatUploadScreen(onBack: () -> Unit, onSubmitted: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // 自适应底部安全区：读取真实导航栏 inset，并保底到一个不小于手势条的高度，
    // 避免手势导航下按钮下沿被系统手势条切掉（固定底栏无法靠下拉看到）。
    val density = LocalDensity.current
    val navBottomPx = WindowInsets.navigationBars.getBottom(density)
    val safeBottom = with(density) { navBottomPx.toDp() }.coerceAtLeast(36.dp)

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var loadedMsgCount by remember { mutableIntStateOf(0) }
    // 「直接获取当前对话」时写入的本地临时导出文件，上传成功后自动删除（不删用户真正的 AI 对话存储）
    var pendingShareTempFile by remember { mutableStateOf<File?>(null) }
    // 「从设备文件获取」选中的文件名（展示在提示文字位置，再次点击可替换）
    var selectedShareFileName by remember { mutableStateOf<String?>(null) }
    var includeAvatar by remember { mutableStateOf(false) }
    var includeScene by remember { mutableStateOf(false) }
    var sceneText by remember { mutableStateOf("") }
    var sceneAiRole by remember { mutableStateOf("") }
    var sceneMyRole by remember { mutableStateOf("") }
    // 头像上传
    var aiAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var myAvatarUri by remember { mutableStateOf<Uri?>(null) }
    val aiAvatarLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) aiAvatarUri = uri }
    val myAvatarLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) myAvatarUri = uri }
    // 性格调试
    val sceneTraits = remember { mutableStateListOf<Float>() }
    val sceneCustomTraits = remember { mutableStateListOf<String>() }
    val sceneCustomPcts = remember { mutableStateListOf<Float>() }
    var showCustomDialog by remember { mutableStateOf(false) }
    var customDialogText by remember { mutableStateOf("") }
    var isFree by remember { mutableStateOf(true) }
    var priceTokensStr by remember { mutableStateOf("") }
    // 隐私替换：真实名称 -> 占位符（保护隐私，下载/查看时显示占位符而非真名）
    // 注意：必须用 mutableStateListOf，其 add/removeAt/set 会触发重组；
    // 若用 mutableStateOf(mutableListOf(...)) 则原地修改不触发重组，"添加/删除/输入"都会失效。
    val replaceFroms = remember { mutableStateListOf("") }
    val replaceTos = remember { mutableStateListOf("") }
    var screenshotUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val name = getUriDisplayName(context, uri)
            scope.launch(Dispatchers.IO) {
                try {
                    val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
                    withContext(Dispatchers.Main) {
                        content = text
                        selectedShareFileName = name
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "读取文件失败：${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
    val screenshotLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        val remaining = AiChatShareBridge.maxScreenshots - screenshotUris.size
        if (remaining > 0) screenshotUris = screenshotUris + uris.take(remaining)
    }

    Column(Modifier.fillMaxSize().background(Color.White).imePadding()) {
        // 顶栏（固定）
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = Color(0xFF1F2937),
                modifier = Modifier.size(24.dp).clickable { onBack() })
            Spacer(Modifier.width(8.dp))
            Text("上传 AI 对话", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        }

        // 可滚动内容区
        Column(
            Modifier.weight(1f).fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // 上传方式
            Text("上传方式", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(ShareGreenLight)
                    .clickable {
                        fileLauncher.launch("*/*")
                    }
                    .padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = ShareGreen, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        if (selectedShareFileName != null) {
                            Column {
                                Text(selectedShareFileName!!, fontSize = 13.sp, color = ShareGreen, fontWeight = FontWeight.Medium,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("点击重新选择文件", fontSize = 11.sp, color = Color(0xFF6B7280))
                            }
                        } else {
                            Text("从设备文件获取", fontSize = 13.sp, color = ShareGreen, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(ShareGreenLight)
                    .clickable {
                        // 直接获取当前对话：绕过内存桥接，直接从本地权威文件读取，避免「未检测到当前 AI 对话」
                        val uid = AuroraApi.currentUserId
                        // 优先读本地存储；极少数情况下本地暂无则回退到内存桥接
                        val json = loadAiConversationShareJson(context, uid) ?: AiChatShareBridge.currentConversation.ifBlank { null }
                        if (json.isNullOrBlank()) {
                            Toast.makeText(context, "未检测到当前 AI 对话，请手动粘贴或选择文件", Toast.LENGTH_LONG).show()
                        } else {
                            // 直接赋值 content，不再走临时文件（避免 IO 不稳定）
                            content = json
                            pendingShareTempFile?.delete()
                            pendingShareTempFile = null
                            selectedShareFileName = null
                            // 解析消息条数直接显示在按钮上
                            loadedMsgCount = try {
                                JSONObject(json).optJSONArray("messages")?.length() ?: 0
                            } catch (_: Exception) { 0 }
                        }
                    }
                    .padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = ShareGreen, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Column {
                            Text("直接获取当前对话", fontSize = 13.sp, color = ShareGreen, fontWeight = FontWeight.Medium)
                            if (loadedMsgCount > 0) {
                                Text("已获取 $loadedMsgCount 条消息，点击重新获取", fontSize = 10.sp, color = Color(0xFF6B7280))
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("标题 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp), placeholder = { Text("给这段对话起个名字", fontSize = 13.sp) })

            Spacer(Modifier.height(10.dp))
            Text("说明（可选）", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = description, onValueChange = { description = it }, modifier = Modifier.fillMaxWidth().height(72.dp), shape = RoundedCornerShape(10.dp), placeholder = { Text("补充这段对话的背景、亮点…", fontSize = 13.sp) })

            Spacer(Modifier.height(12.dp))
            // 隐私替换（保护隐私）
            Text("隐私替换", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Spacer(Modifier.height(4.dp))
            Text("保护隐私：分享后他人下载或查看时，名字将显示为占位符，不会暴露你的真实名称。", fontSize = 12.sp, color = Color(0xFF6B7280), lineHeight = 16.sp)
            Spacer(Modifier.height(8.dp))
            val dupTos = replaceTos.map { it.trim() }.filter { it.isNotEmpty() }.groupingBy { it }.eachCount().filter { it.value > 1 }.keys
            replaceFroms.indices.forEach { i ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = replaceFroms[i], onValueChange = { replaceFroms[i] = it }, placeholder = { Text("真实名称", fontSize = 12.sp) }, singleLine = true, modifier = Modifier.weight(1f))
                    Text("→", fontSize = 13.sp, color = Color(0xFF6B7280))
                    val toVal = replaceTos[i].trim()
                    OutlinedTextField(value = replaceTos[i], onValueChange = { replaceTos[i] = it }, placeholder = { Text("占位符", fontSize = 12.sp) }, singleLine = true, isError = toVal.isNotEmpty() && toVal in dupTos, modifier = Modifier.weight(1f))
                    if (replaceFroms.size > 1) {
                        Text("✕", fontSize = 14.sp, color = Color(0xFFDC2626),
                            modifier = Modifier.clickable {
                                replaceFroms.removeAt(i)
                                replaceTos.removeAt(i)
                            }.padding(4.dp))
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
            if (dupTos.isNotEmpty()) {
                Text("⚠ 占位符不能重复，否则所有人将合并成同一个名字，请修改后再提交", fontSize = 12.sp, color = Color(0xFFDC2626))
                Spacer(Modifier.height(6.dp))
            }
            TextButton(onClick = { replaceFroms.add(""); replaceTos.add("") }) { Text("+ 添加替换项", color = ShareGreen, fontSize = 13.sp) }

            Spacer(Modifier.height(12.dp))
            // 可上传内容选择（去掉"名字"标签）
            Text("可上传的内容", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ShareFieldChip("头像", includeAvatar) { includeAvatar = it }
                ShareFieldChip("场景信息", includeScene) { includeScene = it }
            }

            // ── 头像上传区（勾选后显示两个方形占位）──
            if (includeAvatar) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    // AI 头像
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(80.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (aiAvatarUri != null) Color.Transparent else Color(0xFFF3F4F6))
                                .border(if (aiAvatarUri == null) BorderStroke(1.dp, Color(0xFFD1D5DB)) else BorderStroke(0.dp, Color.Transparent), RoundedCornerShape(12.dp))
                                .clickable { aiAvatarLauncher.launch("image/*") },
                            contentAlignment = Alignment.Center
                        ) {
                            if (aiAvatarUri != null) {
                                AsyncImage(model = aiAvatarUri!!, contentDescription = "AI头像",
                                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop)
                            } else {
                                Icon(Icons.Filled.Add, contentDescription = null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(28.dp))
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("AI 的头像", fontSize = 11.sp, color = Color(0xFF6B7280))
                    }
                    // 我方头像
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(80.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (myAvatarUri != null) Color.Transparent else Color(0xFFF3F4F6))
                                .border(if (myAvatarUri == null) BorderStroke(1.dp, Color(0xFFD1D5DB)) else BorderStroke(0.dp, Color.Transparent), RoundedCornerShape(12.dp))
                                .clickable { myAvatarLauncher.launch("image/*") },
                            contentAlignment = Alignment.Center
                        ) {
                            if (myAvatarUri != null) {
                                AsyncImage(model = myAvatarUri!!, contentDescription = "我方头像",
                                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop)
                            } else {
                                Icon(Icons.Filled.Add, contentDescription = null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(28.dp))
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("我方头像", fontSize = 11.sp, color = Color(0xFF6B7280))
                    }
                }
            }

            // ── 场景信息输入区（勾选后显示三个输入框，右侧各带读取按钮，底部有读取全部）──
            if (includeScene) {
                // 读取全部按钮
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = {
                        val ctx = context
                        val uid = AuroraApi.currentUserId
                        sceneText = AiChatManager.getScenario(ctx, uid)
                        sceneAiRole = AiChatManager.getAiRole(ctx, uid)
                        sceneMyRole = AiChatManager.getMyRole(ctx, uid)
                        Toast.makeText(ctx, "已读取全部场景设定", Toast.LENGTH_SHORT).show()
                    }) { Text("读取全部数据", color = ShareGreen, fontSize = 12.sp) }
                }
                Spacer(Modifier.height(2.dp))

                // 场景
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("场景", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151), modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        sceneText = AiChatManager.getScenario(context, AuroraApi.currentUserId)
                    }) { Text("读取当前数据", color = ShareGreen, fontSize = 11.sp) }
                }
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(value = sceneText, onValueChange = { sceneText = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp), placeholder = { Text("例如：太空飞船上的冒险", fontSize = 13.sp) })
                Spacer(Modifier.height(8.dp))

                // AI 的角色设定
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("AI 的角色设定", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151), modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        sceneAiRole = AiChatManager.getAiRole(context, AuroraApi.currentUserId)
                    }) { Text("读取当前数据", color = ShareGreen, fontSize = 11.sp) }
                }
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(value = sceneAiRole, onValueChange = { sceneAiRole = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp), placeholder = { Text("例如：飞船的 AI 助手", fontSize = 13.sp) })
                Spacer(Modifier.height(8.dp))

                // 我方角色设定
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("我方角色设定", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151), modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        sceneMyRole = AiChatManager.getMyRole(context, AuroraApi.currentUserId)
                    }) { Text("读取当前数据", color = ShareGreen, fontSize = 11.sp) }
                }
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(value = sceneMyRole, onValueChange = { sceneMyRole = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp), placeholder = { Text("例如：一位勇敢的舰长", fontSize = 13.sp) })

                // ── 性格调试 ──
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("性格调试", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = {
                        // 读取当前 AI 对话的性格数据
                        val ctx = context
                        val uid = AuroraApi.currentUserId
                        val traits = AiChatManager.getTraits(ctx, uid)
                        val customs = AiChatManager.getCustomTraits(ctx, uid)
                        // 填充到本地状态
                        sceneTraits.clear()
                        sceneTraits.addAll(traits)
                        sceneCustomTraits.clear()
                        sceneCustomPcts.clear()
                        customs.forEach {
                            sceneCustomTraits.add(it.text)
                            sceneCustomPcts.add(it.pct)
                        }
                        Toast.makeText(ctx, "已读取当前性格调试数据", Toast.LENGTH_SHORT).show()
                    }) { Text("读取当前数据", color = ShareGreen, fontSize = 12.sp) }
                }
                Spacer(Modifier.height(4.dp))
                // 5 个维度滑块（照搬 DeepSeek 使用面板的样式）
                val traitLabels = listOf("友好", "凶恶", "理智", "幽默", "极端")
                traitLabels.forEachIndexed { i, label ->
                    val ti = sceneTraits.getOrNull(i) ?: 0f
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, fontSize = 14.sp, color = Color(0xFF374151), modifier = Modifier.width(48.dp))
                        Slider(
                            value = ti,
                            onValueChange = { newVal ->
                                while (sceneTraits.size <= i) sceneTraits.add(0f)
                                val old = sceneTraits[i]
                                val othersSum = sceneTraits.sum() - old
                                val v = newVal.coerceIn(0f, 100f)
                                if (v + othersSum <= 100f) {
                                    sceneTraits[i] = v
                                } else if (othersSum > 0f) {
                                    val scale = (100f - v) / othersSum
                                    for (j in sceneTraits.indices) if (j != i) sceneTraits[j] = sceneTraits[j] * scale
                                    sceneTraits[i] = v
                                } else {
                                    sceneTraits[i] = 100f
                                }
                            },
                            valueRange = 0f..100f,
                            modifier = Modifier.weight(1f),
                            track = { positions ->
                                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFFE5E7EB))) {
                                    Box(Modifier.fillMaxWidth((positions.value / 100f).coerceIn(0f, 1f)).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF1E40AF))) {}
                                }
                            },
                            thumb = { Box(Modifier.size(22.dp).clip(CircleShape).background(Color(0xFF1E40AF))) {} }
                        )
                        Text("${ti.toInt()}%", fontSize = 13.sp, color = Color(0xFF374151), modifier = Modifier.width(44.dp).padding(start = 4.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                }
                // 自定义设定（照搬 DeepSeek 使用面板的样式：点击添加弹窗输入，列表显示文本+权重滑块）
                Spacer(Modifier.height(6.dp))
                Text("＋ 自定义设定（在 5 条调试之外额外添加）", fontSize = 12.sp, color = Color(0xFF1E40AF),
                    modifier = Modifier.fillMaxWidth().clickable { showCustomDialog = true; customDialogText = "" }.padding(vertical = 6.dp))
                if (sceneCustomTraits.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("已添加的自定义设定", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1F2937))
                    Spacer(Modifier.height(8.dp))
                    sceneCustomTraits.forEachIndexed { ci, ct ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(ct, fontSize = 13.sp, color = Color(0xFF374151))
                            }
                            Slider(
                                value = sceneCustomPcts.getOrNull(ci) ?: 50f,
                                onValueChange = { while (sceneCustomPcts.size <= ci) sceneCustomPcts.add(50f); sceneCustomPcts[ci] = it },
                                valueRange = 0f..100f,
                                modifier = Modifier.weight(1f),
                                track = { positions ->
                                    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFFE5E7EB))) {
                                        Box(Modifier.fillMaxWidth((positions.value / 100f).coerceIn(0f, 1f)).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF1E40AF))) {}
                                    }
                                },
                                thumb = { Box(Modifier.size(22.dp).clip(CircleShape).background(Color(0xFF1E40AF))) {} }
                            )
                            Text("${(sceneCustomPcts.getOrNull(ci) ?: 50f).toInt()}%", fontSize = 12.sp, color = Color(0xFF374151), modifier = Modifier.width(40.dp))
                            Text("✕", fontSize = 14.sp, color = Color(0xFFDC2626),
                                modifier = Modifier.clickable {
                                    sceneCustomTraits.removeAt(ci)
                                    if (ci < sceneCustomPcts.size) sceneCustomPcts.removeAt(ci)
                                }.padding(start = 4.dp, end = 2.dp))
                        }
                    }
                }

                // 自定义设定输入弹窗（照搬 DeepSeek 使用面板的样式）
                if (showCustomDialog) {
                    AlertDialog(
                        onDismissRequest = { showCustomDialog = false; customDialogText = "" },
                        containerColor = Color.White,
                        title = { Text("自定义设定", fontWeight = FontWeight.Bold) },
                        text = {
                            OutlinedTextField(
                                value = customDialogText,
                                onValueChange = { customDialogText = it },
                                label = { Text("输入自定义内容（按字面意思注入）") },
                                placeholder = { Text("例如：回答时先给结论再展开") },
                                singleLine = false,
                                modifier = Modifier.fillMaxWidth().height(120.dp)
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                val txt = customDialogText.trim()
                                if (txt.isNotBlank()) {
                                    sceneCustomTraits.add(txt)
                                    sceneCustomPcts.add(50f)
                                }
                                showCustomDialog = false; customDialogText = ""
                            }) { Text("添加", color = Color(0xFF1E40AF)) }
                        },
                        dismissButton = {
                            TextButton(onClick = { showCustomDialog = false; customDialogText = "" }) { Text("取消", color = Color(0xFF6B7280)) }
                        }
                    )
                }
            }


            Spacer(Modifier.height(12.dp))
            // 截图上传（点击占位区域即可添加）
            Text("对话截图", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            if (screenshotUris.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF9FAFB))
                    .clickable { screenshotLauncher.launch("image/*") }, contentAlignment = Alignment.Center) {
                    Text("点击添加截图（可选）", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    screenshotUris.forEachIndexed { idx, uri ->
                        Box(Modifier.size(80.dp)) {
                            AsyncImage(model = uri, contentDescription = "截图$idx", modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                            Box(Modifier.align(Alignment.TopEnd).size(20.dp).clip(CircleShape).background(Color.Red.copy(alpha = 0.8f))
                                .clickable { screenshotUris = screenshotUris.toMutableList().apply { removeAt(idx) } }, contentAlignment = Alignment.Center) {
                                Text("X", fontSize = 10.sp, color = Color.White)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            // 免费 / 收费
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("获取方式", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                if (!isFree) {
                    Spacer(Modifier.width(8.dp))
                    Text("虚假宣传将导致封号", fontSize = 11.sp, color = Color(0xFFDC2626))
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (isFree) ShareGreen else Color(0xFFF3F4F6))
                    .clickable { isFree = true }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    Text("免费", fontSize = 14.sp, fontWeight = if (isFree) FontWeight.Bold else FontWeight.Normal,
                        color = if (isFree) Color.White else Color(0xFF6B7280))
                }
                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (!isFree) ShareGreen else Color(0xFFF3F4F6))
                    .clickable { isFree = false }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    Text("收费（token）", fontSize = 14.sp, fontWeight = if (!isFree) FontWeight.Bold else FontWeight.Normal,
                        color = if (!isFree) Color.White else Color(0xFF6B7280))
                }
            }
            if (!isFree) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = priceTokensStr, onValueChange = { priceTokensStr = it.filter { c -> c.isDigit() } },
                    modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp),
                    placeholder = { Text("用户下载你的对话内容，将把收费的 token 发送至你的账户。", fontSize = 13.sp) },
                    trailingIcon = { Text("token", fontSize = 13.sp, color = Color(0xFF9CA3AF)) })
            }

            Spacer(Modifier.height(12.dp))
            errorMsg?.let { Text(it, fontSize = 13.sp, color = Color(0xFFDC2626)); Spacer(Modifier.height(8.dp)) }

            Spacer(Modifier.height(16.dp))
        }

        // 底部固定提交栏（始终可见，不被键盘/滚动遮挡）
        Button(
            onClick = {
                if (title.isBlank()) { errorMsg = "请填写标题"; return@Button }
                if (content.isBlank()) { errorMsg = "请填写对话内容（可从文件或直接获取）"; return@Button }
                if (!isFree && priceTokensStr.toLongOrNull() ?: 0 <= 0) { errorMsg = "收费内容需设置有效的 token 数量"; return@Button }
                isSubmitting = true; errorMsg = null
                scope.launch {
                    try {
                        var finalContent = content
                        // 隐私替换：将全文中的真实名称替换为占位符（保护隐私）
                        val replaceMapArr = JSONArray()
                        replaceFroms.zip(replaceTos).forEach { (f, t) ->
                            if (f.isNotBlank() && t.isNotBlank()) {
                                replaceMapArr.put(JSONObject().apply { put("from", f.trim()); put("to", t.trim()) })
                            }
                        }
                        for (i in 0 until replaceMapArr.length()) {
                            val o = replaceMapArr.getJSONObject(i)
                            finalContent = finalContent.replace(o.getString("from"), o.getString("to"))
                        }
                        // 场景+角色设定+性格写入 JSON 的 meta.scene_info
                        if (includeScene && (sceneText.isNotBlank() || sceneAiRole.isNotBlank() || sceneMyRole.isNotBlank())) {
                            try {
                                val root = JSONObject(finalContent)
                                val meta = root.optJSONObject("meta") ?: JSONObject().also { root.put("meta", it) }
                                val sceneObj = JSONObject()
                                if (sceneText.isNotBlank()) sceneObj.put("scenario", sceneText.trim())
                                if (sceneAiRole.isNotBlank()) sceneObj.put("ai_role", sceneAiRole.trim())
                                if (sceneMyRole.isNotBlank()) sceneObj.put("my_role", sceneMyRole.trim())
                                // 性格数据
                                val traitsArr = JSONArray()
                                sceneTraits.forEach { traitsArr.put(it.toDouble()) }
                                if (traitsArr.length() > 0) sceneObj.put("traits", traitsArr)
                                val customsArr = JSONArray()
                                sceneCustomTraits.forEachIndexed { ci, ct ->
                                    if (ct.isNotBlank()) {
                                        customsArr.put(JSONObject().apply {
                                            put("text", ct.trim())
                                            put("pct", sceneCustomPcts.getOrNull(ci) ?: 50f)
                                        })
                                    }
                                }
                                if (customsArr.length() > 0) sceneObj.put("custom_traits", customsArr)
                                meta.put("scene_info", sceneObj)
                                finalContent = root.toString()
                            } catch (_: Exception) { /* 非 JSON 内容则跳过场景写入 */ }
                        }
                        val fields = JSONObject().apply {
                            put("avatar", includeAvatar)
                            put("scene", includeScene)
                            put("scene_text", sceneText)
                            put("scene_ai_role", sceneAiRole)
                            put("scene_my_role", sceneMyRole)
                            put("replace_map", replaceMapArr)
                            // 头像图片：base64 编码嵌入 fields，下载时解码还原
                            if (includeAvatar) {
                                if (aiAvatarUri != null) {
                                    try {
                                        val bytes = withContext(Dispatchers.IO) {
                                            context.contentResolver.openInputStream(aiAvatarUri!!)?.use { it.readBytes() }
                                        }
                                        if (bytes != null) put("ai_avatar_data", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))
                                    } catch (_: Exception) {}
                                }
                                if (myAvatarUri != null) {
                                    try {
                                        val bytes = withContext(Dispatchers.IO) {
                                            context.contentResolver.openInputStream(myAvatarUri!!)?.use { it.readBytes() }
                                        }
                                        if (bytes != null) put("my_avatar_data", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))
                                    } catch (_: Exception) {}
                                }
                            }
                        }.toString()
                        val ssBytes = screenshotUris.mapNotNull { uri ->
                            withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } }
                        }
                        val result = AuroraApi.submitAiChat(
                            title = title.trim(),
                            description = description.trim(),
                            content = finalContent,
                            fields = fields,
                            isFree = isFree,
                            priceTokens = priceTokensStr.toLongOrNull() ?: 0,
                            screenshotBytesList = ssBytes
                        )
                        isSubmitting = false
                        if (result.success) {
                            // 更新后端返回的截图数量限制
                            result.data?.optInt("max_screenshots", 3)?.let { AiChatShareBridge.maxScreenshots = it }
                            Toast.makeText(context, "提交成功", Toast.LENGTH_SHORT).show()
                            // 第三步：上传完成后自动删除本地临时导出文件（用户真正的 AI 对话存储不受影响）
                            pendingShareTempFile?.delete()
                            pendingShareTempFile = null
                            onSubmitted()
                        } else {
                            errorMsg = result.message
                        }
                    } catch (e: Exception) {
                        isSubmitting = false
                        val rawMsg = e.localizedMessage ?: "提交失败"
                        // 友好映射：Broken pipe 通常是请求体过大/服务端读超时
                        errorMsg = when {
                            rawMsg.contains("Broken pipe", ignoreCase = true) ||
                            rawMsg.contains("connection", ignoreCase = true) ||
                            rawMsg.contains("timeout", ignoreCase = true) ->
                                "网络错误：上传内容过大或网络中断，请减少截图数量后重试"
                            else -> rawMsg
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 12.dp, bottom = safeBottom).height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ShareGreen), enabled = !isSubmitting
        ) {
            if (isSubmitting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            else Text("提交分享", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ShareFieldChip(label: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(8.dp))
            .background(if (checked) ShareGreen.copy(alpha = 0.12f) else Color(0xFFF3F4F6))
            .border(1.dp, if (checked) ShareGreen else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable { onToggle(!checked) }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (checked) Icon(Icons.Filled.Check, contentDescription = null, tint = ShareGreen, modifier = Modifier.size(14.dp))
            if (checked) Spacer(Modifier.width(4.dp))
            Text(label, fontSize = 13.sp, color = if (checked) ShareGreen else Color(0xFF6B7280), fontWeight = if (checked) FontWeight.Medium else FontWeight.Normal)
        }
    }
}

// ===================== 详情 / 导入 =====================

@Composable
private fun AiChatShareDetail(shareId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val serverUrl = remember { AuroraApi.serverUrl }

    var detail by remember { mutableStateOf<JSONObject?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var buying by remember { mutableStateOf(false) }

    fun incDownload() {
        scope.launch { try { AuroraApi.incAiChatDownload(shareId) } catch (_: Exception) {} }
    }

    fun load() {
        isLoading = true; errorMsg = null
        scope.launch {
            // 冷启动后首次请求偶尔会因瞬时网络/连接问题失败（后端把瞬时 DB 错误也映射成 404），
            // 这里自动重试，避免一进来就显示“404 不”、需手动返回再点。
            var lastErr: String? = null
            repeat(3) { attempt ->
                try {
                    val r = AuroraApi.getAiChatDetail(shareId)
                    if (r.success && r.data != null) {
                        detail = r.data
                        lastErr = null
                        isLoading = false
                        return@launch
                    } else {
                        lastErr = r.message
                    }
                } catch (e: Exception) {
                    lastErr = e.localizedMessage ?: "加载失败"
                }
                if (attempt < 2) delay(800)
            }
            errorMsg = lastErr ?: "加载失败"
            isLoading = false
        }
    }
    LaunchedEffect(shareId) { load() }

    // 评论数（详情返回 comment_count，发表评论后自增）
    var commentCount by remember { mutableStateOf(0L) }
    // 评论抽屉是否展开
    var showComments by remember { mutableStateOf(false) }
    // 缓存待下载内容（CreateDocument 回调中使用）
    var pendingDownloadContent by remember { mutableStateOf("") }

    // 下载到本地：弹出系统文件选择器，让用户自选保存位置与文件名（保存为 JSON）
    val downloadLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val text = pendingDownloadContent
            scope.launch(Dispatchers.IO) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { os -> os.write(text.toByteArray(Charsets.UTF_8)) }
                    withContext(Dispatchers.Main) {
                        incDownload()
                        Toast.makeText(context, "已保存到所选位置", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "保存失败：${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.White).statusBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = Color(0xFF1F2937),
                modifier = Modifier.size(24.dp).clickable { onBack() })
            Spacer(Modifier.width(8.dp))
            Text("对话详情", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            Spacer(Modifier.width(8.dp))
            Text("如被骗请在平台内搜索群聊ID2维权", fontSize = 11.sp, color = Color(0xFFDC2626))
        }

        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(28.dp), color = ShareGreen, strokeWidth = 3.dp)
            }
        } else if (errorMsg != null || detail == null) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(errorMsg ?: "加载失败", color = Color(0xFFDC2626), fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Box(
                        Modifier.clip(RoundedCornerShape(10.dp)).background(ShareGreen)
                            .clickable { load() }.padding(horizontal = 28.dp, vertical = 10.dp)
                    ) {
                        Text("重试", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        } else {
            val d = detail!!
            commentCount = d.optLong("comment_count", 0)
            val userId = d.optLong("user_id", 0)
            val title = d.optString("title", "")
            val username = d.optString("username", "匿名")
            val desc = d.optString("description", "")
            val content = d.optString("content", "")
            val fieldsStr = d.optString("fields", "")
            val fieldsJson = try { if (fieldsStr.isNotBlank()) JSONObject(fieldsStr) else null } catch (_: Exception) { null }
            val hasAiAvatar = fieldsJson?.optString("ai_avatar_data", "")?.isNotEmpty() == true
            val hasMyAvatar = fieldsJson?.optString("my_avatar_data", "")?.isNotEmpty() == true
            val hasSceneInfo = try { JSONObject(content).optJSONObject("meta")?.optJSONObject("scene_info") != null } catch (_: Exception) { false }
            val isFree = d.optInt("is_free", 1) == 1
            val price = d.optLong("price_tokens", 0)
            val purchased = d.optBoolean("purchased", false)
            val viewCount = d.optLong("view_count", 0)
            val downloadCount = d.optLong("download_count", 0)
            val sizeText = formatSize(d.optLong("size", 0))
            val screenshots = try {
                val arr = d.optJSONArray("screenshots")
                (0 until (arr?.length() ?: 0)).mapNotNull { arr?.optString(it) }.filter { it.isNotEmpty() }
            } catch (_: Exception) { emptyList() }

            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                // 作者
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(36.dp).clip(CircleShape).background(ShareGreen), contentAlignment = Alignment.Center) {
                        // 无真实头像时显示首字母兜底
                        Text(username.firstOrNull()?.toString() ?: "?", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        // 真实头像（无头像时服务器返回 204，此处透明，露出首字母）
                        AsyncImage(model = "$serverUrl/api/avatar/$userId", contentDescription = null,
                            modifier = Modifier.fillMaxSize().clip(CircleShape),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(username, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                        Text(if (isFree) "免费分享" else "收费 · ${price} token", fontSize = 12.sp, color = if (isFree) ShareGreen else Color(0xFFD97706))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                if (desc.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(desc, fontSize = 13.sp, color = Color(0xFF6B7280), lineHeight = 18.sp)
                }
                Spacer(Modifier.height(10.dp))
                // 统计信息：对话大小 / 浏览量 / 下载量 / 评论
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFF3F4F6)).padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatItem(Modifier.weight(1f), "对话大小", sizeText)
                    Box(Modifier.width(1.dp).height(28.dp).background(Color(0xFFE5E7EB)))
                    StatItem(Modifier.weight(1f), "浏览量", "$viewCount")
                    Box(Modifier.width(1.dp).height(28.dp).background(Color(0xFFE5E7EB)))
                    StatItem(Modifier.weight(1f), "下载量", "$downloadCount")
                    Box(Modifier.width(1.dp).height(28.dp).background(Color(0xFFE5E7EB)))
                    StatItem(Modifier.weight(1f), "评论", "$commentCount", onClick = { showComments = true })
                }
                if (screenshots.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    LazyRowOf(screenshots, serverUrl, shareId)
                }
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFF0F0F0)))
                Spacer(Modifier.height(12.dp))

                if (!isFree && !purchased) {
                    // 付费未购买：提示购买（购买后可下载 / 导入，详情页不预览对话内容）
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFFF8FAFC))
                        .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp)).padding(16.dp)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(28.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("付费内容", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                            Text("购买后可下载 / 导入到当前对话", fontSize = 12.sp, color = Color(0xFF6B7280))
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    buying = true
                                    scope.launch {
                                        try {
                                            val r = AuroraApi.buyAiChat(shareId)
                                            buying = false
                                            if (r.success) {
                                                Toast.makeText(context, "购买成功", Toast.LENGTH_SHORT).show()
                                                load()
                                            } else {
                                                Toast.makeText(context, r.message, Toast.LENGTH_LONG).show()
                                            }
                                        } catch (e: Exception) {
                                            buying = false
                                            Toast.makeText(context, e.localizedMessage ?: "购买失败", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(42.dp), shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)), enabled = !buying
                            ) {
                                if (buying) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                else Text("购买 · ${price} token", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                // 操作区（仅免费或已购买）
                var showOverlayDialog by remember { mutableStateOf(false) }
                var overlayAvatar by remember { mutableStateOf(true) }
                var overlayScene by remember { mutableStateOf(true) }
                if (isFree || purchased) {
                    Button(
                        onClick = {
                            // 弹出覆盖选项弹窗
                            overlayAvatar = hasAiAvatar || hasMyAvatar
                            overlayScene = hasSceneInfo
                            showOverlayDialog = true
                        },
                        modifier = Modifier.fillMaxWidth().height(46.dp), shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ShareGreen)
                    ) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("覆盖到当前对话", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    // 覆盖选项弹窗
                    if (showOverlayDialog) {
                        AlertDialog(
                            onDismissRequest = { showOverlayDialog = false },
                            containerColor = Color.White,
                            title = { Text("选择覆盖内容", fontWeight = FontWeight.Bold) },
                            text = {
                                Column {
                                    // 头像选项
                                    val hasAnyAvatar = hasAiAvatar || hasMyAvatar
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = overlayAvatar, enabled = hasAnyAvatar,
                                            onCheckedChange = { if (hasAnyAvatar) overlayAvatar = it })
                                        Spacer(Modifier.width(6.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text("头像", fontSize = 14.sp, color = if (hasAnyAvatar) Color(0xFF1F2937) else Color(0xFF9CA3AF))
                                            Text(if (hasAnyAvatar) "包含 AI 头像和我方头像" else "上传者未上传头像", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                                        }
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    // 场景信息选项（含角色设定 + 性格调试）
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = overlayScene, enabled = hasSceneInfo,
                                            onCheckedChange = { if (hasSceneInfo) overlayScene = it })
                                        Spacer(Modifier.width(6.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text("场景信息", fontSize = 14.sp, color = if (hasSceneInfo) Color(0xFF1F2937) else Color(0xFF9CA3AF))
                                            Text(if (hasSceneInfo) "包含场景、角色设定、性格调试" else "上传者未上传场景信息", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                                        }
                                    }
                                }
                            },
                            confirmButton = {
                                TextButton(onClick = {
                                    showOverlayDialog = false
                                    incDownload()
                                    // 构造带覆盖选项的导入数据
                                    var finalContent = content
                                    if (overlayAvatar && fieldsJson != null) {
                                        try {
                                            val root = JSONObject(finalContent)
                                            val meta = root.optJSONObject("meta") ?: JSONObject().also { root.put("meta", it) }
                                            if (hasAiAvatar) meta.put("ai_avatar_data", fieldsJson.optString("ai_avatar_data", ""))
                                            if (hasMyAvatar) meta.put("my_avatar_data", fieldsJson.optString("my_avatar_data", ""))
                                            finalContent = root.toString()
                                        } catch (_: Exception) {}
                                    }
                                    if (!overlayScene && hasSceneInfo) {
                                        try {
                                            val root = JSONObject(finalContent)
                                            val meta = root.optJSONObject("meta")
                                            if (meta != null && meta.has("scene_info")) {
                                                meta.remove("scene_info")
                                                root.put("meta", meta)
                                                finalContent = root.toString()
                                            }
                                        } catch (_: Exception) {}
                                    }
                                    AiChatShareBridge.pendingImport = finalContent
                                    Toast.makeText(context, "已载入，返回对话即可看到覆盖后的内容", Toast.LENGTH_LONG).show()
                                }) { Text("确定覆盖", color = Color(0xFF1E40AF)) }
                            },
                            dismissButton = {
                                TextButton(onClick = { showOverlayDialog = false }) { Text("取消", color = Color(0xFF6B7280)) }
                            }
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = {
                            if (content.isBlank()) {
                                Toast.makeText(context, "对话内容为空，无法下载", Toast.LENGTH_SHORT).show()
                                return@OutlinedButton
                            }
                            // 弹出系统文件选择器，让用户自选保存位置与文件名；内容保持为 JSON 格式
                            pendingDownloadContent = content
                            downloadLauncher.launch("ai_chat_$shareId.json")
                        },
                        modifier = Modifier.fillMaxWidth().height(46.dp), shape = RoundedCornerShape(12.dp),
                        border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(ShareGreen))
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, tint = ShareGreen, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("下载到本地", color = ShareGreen, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
        } // 关闭内层 Column

        // ── 评论遮罩 ──
        AnimatedVisibility(
            visible = showComments,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(200))
        ) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).clickable { showComments = false })
        }
        // ── 评论抽屉（从底部滑入） ──
        AnimatedVisibility(
            visible = showComments,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300))
        ) {
            AiChatCommentDrawer(
                shareId = shareId,
                onCommentAdded = { commentCount++ },
                onDismiss = { showComments = false }
            )
        }
    } // 关闭根 Box
}

@Composable
private fun StatItem(modifier: Modifier, label: String, value: String, onClick: (() -> Unit)? = null) {
    Column(
        modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 11.sp, color = Color(0xFF9CA3AF))
    }
}

/** 字节大小格式化为可读文本（B / KB / MB） */
private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "—"
    return when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format("%.1f KB", bytes / 1024f)
        else -> String.format("%.2f MB", bytes / (1024f * 1024f))
    }
}

@Composable
private fun LazyRowOf(screenshots: List<String>, serverUrl: String, shareId: Long) {
    var previewUrl by remember { mutableStateOf<String?>(null) }
    // 支持左右滚动，避免 3 张图被挤小
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        screenshots.forEach { file ->
            val url = "$serverUrl/api/ai_chat/screenshot/$shareId/$file"
            AsyncImage(model = url, contentDescription = null,
                modifier = Modifier.size(120.dp, 200.dp).clip(RoundedCornerShape(10.dp))
                    .clickable { previewUrl = url },
                contentScale = androidx.compose.ui.layout.ContentScale.Crop)
        }
    }
    // 图片预览弹窗（支持双指缩放）
    if (previewUrl != null) {
        var scale by remember { mutableFloatStateOf(1f) }
        var offsetX by remember { mutableFloatStateOf(0f) }
        var offsetY by remember { mutableFloatStateOf(0f) }
        Dialog(
            onDismissRequest = { previewUrl = null },
            properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true, dismissOnClickOutside = false)
        ) {
            Box(
                Modifier.fillMaxSize().background(Color.Black)
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(0.3f, 5f)
                            offsetX += pan.x
                            offsetY += pan.y
                        }
                    }
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) { previewUrl = null }
            ) {
                AsyncImage(
                    model = previewUrl!!, contentDescription = null,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offsetX, translationY = offsetY)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        ) { previewUrl = null },
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit
                )
            }
        }
    }
}

// ===================== 评论抽屉（从底部滑入，完全复制社区 CommentSheet） =====================

@Composable
private fun AiChatCommentDrawer(
    shareId: Long,
    onCommentAdded: () -> Unit,
    onDismiss: () -> Unit,
    onUserClick: (Long) -> Unit = {}
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var allComments by remember { mutableStateOf<List<CommentInfo>>(emptyList()) }
    var total by remember { mutableStateOf(0) }
    var isLoading by remember { mutableStateOf(true) }
    var replyingTo by remember { mutableStateOf("") }
    var replyingToId by remember { mutableStateOf(0L) }
    var showCommentDialog by remember { mutableStateOf(false) }
    var dialogInputText by remember { mutableStateOf("") }
    // 禁言检测
    var mutedUntil by remember { mutableStateOf(0L) }
    val muteRemainingText = remember(mutedUntil) {
        if (mutedUntil <= 0L) ""
        else {
            val remainSec = (mutedUntil - System.currentTimeMillis() / 1000).coerceAtLeast(0)
            if (remainSec <= 0) ""
            else {
                val days = remainSec / 86400; val hours = (remainSec % 86400) / 3600
                val mins = (remainSec % 3600) / 60
                when { days > 0 -> "${days}天${hours}小时"; hours > 0 -> "${hours}小时${mins}分钟"
                    mins > 0 -> "${mins}分钟"; else -> "${remainSec}秒" }
            }
        }
    }
    val isMuted = mutedUntil > 0L && muteRemainingText.isNotEmpty()
    LaunchedEffect(Unit) {
        try {
            val r = com.aurora.chat.data.api.AuroraApi.adminCheckMuteStatus(com.aurora.chat.data.api.AuroraApi.currentUserId)
            if (r.success && r.data != null && r.data.has("expires_at")) {
                mutedUntil = r.data.optLong("expires_at", 0L)
            }
        } catch (_: Exception) { }
    }

    // 展开回复的状态
    var expandedReplies by rememberSaveable { mutableStateOf(setOf<Long>()) }
    fun onToggleExpand(id: Long) {
        expandedReplies = if (id in expandedReplies) expandedReplies - id else expandedReplies + id
    }

    // 分离顶层评论和子评论：按"根祖先"分组，使任意深度的回复都能归到所属顶层评论下显示
    val commentById = allComments.associateBy { it.id }
    fun rootIdOfId(id: Long): Long {
        var curId = id
        var guard = 0
        while (guard < 50) {
            val c = commentById[curId] ?: break
            if (c.parent_id <= 0L) break
            curId = c.parent_id
            guard++
        }
        return curId
    }
    val topLevelComments = allComments.filter { it.parent_id == 0L }
    val repliesByRoot = allComments.filter { it.parent_id > 0L }.groupBy { rootIdOfId(it.id) }
    // 根据 parent_id 查找被回复的用户名（用于显示"回复"格式）
    val parentUsernameMap = allComments.associate { it.id to it.username }
    val parentUserIdMap = allComments.associate { it.id to it.user_id }

    LaunchedEffect(shareId) {
        val result = ChatRepository.getAiChatComments(shareId)
        if (result.success && result.data != null) {
            allComments = result.data!!.comments
            total = result.data!!.total
        }
        isLoading = false
    }

    val listState = rememberLazyListState()
    val shouldShowScrollDown by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val totalItems = listState.layoutInfo.totalItemsCount
            totalItems > 0 && lastVisible < totalItems - 5
        }
    }

    Box(
        Modifier.fillMaxSize(),
        contentAlignment = Alignment.BottomCenter
    ) {
        var dragFraction by remember { mutableFloatStateOf(0.55f) }
        var isDragging by remember { mutableStateOf(false) }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(dragFraction)
                .background(Color.White, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .clickable(enabled = false) {}
                .systemBarsPadding()
        ) {
        // 顶部：拖拽条单独一行（不跟文字并排）
        Box(
            modifier = Modifier
                .fillMaxWidth().padding(top = 6.dp)
                .height(20.dp)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { isDragging = true },
                        onDragEnd = { isDragging = false },
                        onDragCancel = { isDragging = false }
                    ) { _, dragAmount ->
                        // 灵敏度：/ 3000f 降低灵敏度，拖拽更平滑
                        dragFraction = (dragFraction - dragAmount / 3000f).coerceIn(0.2f, 0.9f)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .width(40.dp).height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFFD1D5DB).copy(alpha = 0.5f))
            )
        }
        // 第二行：标题 + 评论按钮 + 关闭
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("评论 ($total)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("评论", fontSize = 14.sp, color = Color(0xFF1E40AF), fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable {
                        dialogInputText = ""
                        showCommentDialog = true
                    }.padding(end = 16.dp))
                Text("关闭", fontSize = 14.sp, color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable { onDismiss() })
            }
        }


        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))

        // 评论列表
        if (isLoading) {
            Box(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                Text("加载中...", fontSize = 14.sp, color = Color(0xFF9CA3AF), modifier = Modifier.padding(top = 20.dp))
            }
        } else if (topLevelComments.isEmpty()) {
            Box(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                Text("暂无评论，快来抢沙发吧", fontSize = 14.sp, color = Color(0xFF9CA3AF), modifier = Modifier.padding(top = 20.dp))
            }
        } else {
            @OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
            LazyColumn(
                modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
                state = listState
            ) {
                items(topLevelComments, key = { it.id }) { comment ->
                    val replyList = repliesByRoot[comment.id] ?: emptyList()
                    Box(Modifier.animateItemPlacement()) {
                    CommentRow(
                        comment = comment,
                        isExpanded = comment.id in expandedReplies,
                        replyCount = replyList.size,
                        replies = replyList,
                        parentUsernameMap = parentUsernameMap,
                        parentUserIdMap = parentUserIdMap,
                        onUserClick = onUserClick,
                        onToggleExpand = { onToggleExpand(comment.id) },
                        onReplyClick = { id ->
                            replyingTo = parentUsernameMap[id] ?: ""
                            replyingToId = id
                        }
                    )
                    } // end Box animateItemPlacement
                }
            }
        }

        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))

        // 禁言横幅
        if (isMuted) {
            Box(
                modifier = Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFFFEF3C7))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "你已被禁言，$muteRemainingText",
                    fontSize = 13.sp, color = Color(0xFF92400E), fontWeight = FontWeight.Medium
                )
            }
        }

        }       // 关闭Column

        // 滚动到底部按钮
        AnimatedVisibility(
            visible = shouldShowScrollDown,
            enter = fadeIn() + androidx.compose.animation.scaleIn(),
            exit = fadeOut() + androidx.compose.animation.scaleOut(),
            modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 76.dp, end = 16.dp)
        ) {
            Box(
                modifier = Modifier.size(44.dp)
                    .clip(CircleShape)
                    .background(Color.White, CircleShape)
                    .border(1.dp, Color(0xFFD1D5DB), CircleShape)
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) {
                        scope.launch {
                            val target = (topLevelComments.size - 1).coerceAtLeast(0)
                            listState.animateScrollToItem(target)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(24.dp)) {
                    val c = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height / 2f)
                    val path = androidx.compose.ui.graphics.Path().apply {
                        moveTo(c.x - 9f, c.y - 4f)
                        lineTo(c.x, c.y + 5f)
                        lineTo(c.x + 9f, c.y - 4f)
                        close()
                    }
                    drawPath(path, Color(0xFF6B7280))
                }
            }
        }
}           // 关闭Box

    // ── 评论输入对话框 ──
    if (showCommentDialog) {
        AlertDialog(
            onDismissRequest = { showCommentDialog = false },
            title = {
                Text(
                    if (replyingTo.isNotEmpty()) "回复 $replyingTo" else "发表评论",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    if (isMuted) {
                        Text("你已被禁言，$muteRemainingText", fontSize = 13.sp, color = Color(0xFF92400E))
                        Spacer(Modifier.height(8.dp))
                    }
                    OutlinedTextField(
                        value = dialogInputText,
                        onValueChange = { if (!isMuted) dialogInputText = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text(if (isMuted) "禁言中" else "输入评论内容...", fontSize = 14.sp) },
                        singleLine = false,
                        minLines = 3,
                        maxLines = 6,
                        enabled = !isMuted,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val text = dialogInputText.trim()
                        if (text.isBlank() || isMuted) return@TextButton
                        scope.launch {
                            val parentId = replyingToId
                            val result = ChatRepository.addAiChatComment(shareId, text, parentId)
                            if (result.success) {
                                dialogInputText = ""
                                replyingTo = ""
                                val refreshed = ChatRepository.getAiChatComments(shareId)
                                if (refreshed.success && refreshed.data != null) {
                                    allComments = refreshed.data!!.comments
                                    total = refreshed.data!!.total
                                }
                                replyingToId = 0L
                                onCommentAdded()
                                if (parentId > 0L) onToggleExpand(rootIdOfId(parentId))
                                showCommentDialog = false
                            } else {
                                Toast.makeText(ctx, result.message, Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    enabled = dialogInputText.isNotBlank() && !isMuted
                ) {
                    Text("发送", color = Color(0xFF1E40AF), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCommentDialog = false }) {
                    Text("取消", color = Color(0xFF6B7280))
                }
            }
        )
    }
}
