package com.aurora.chat.ui.viewmodel

import com.aurora.chat.data.api.ConversationInfo
import com.aurora.chat.data.api.FriendRequestInfo
import com.aurora.chat.data.api.MessageInfo
import com.aurora.chat.data.local.LocalConversationStore
import com.aurora.chat.data.repository.ChatRepository
import com.aurora.chat.data.repository.LocalMessageStore
import com.aurora.chat.ui.chat.ChatMsg
import com.aurora.chat.ui.chat.isGroupChat
import com.aurora.chat.util.NetworkMonitor
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

import com.aurora.chat.data.api.UserInfo
import android.content.Context

// ==================== 用户信息查询结果（public，避免被 internal 类包裹） ====================
data class UserInfoResult(val userInfo: UserInfo? = null, val friends: List<ConversationInfo> = emptyList())

// ==================== LRU 消息缓存（按会话 key 缓存，超阈值淘汰最久未访问的） ====================
class LruCache<K, V>(private val maxSize: Int) {
    private val map = LinkedHashMap<K, V>(0, 0.75f, true) // accessOrder=true
    @Synchronized fun get(key: K): V? = map[key]
    @Synchronized fun put(key: K, value: V) {
        while (map.size >= maxSize && !map.containsKey(key)) {
            val oldest = map.entries.firstOrNull()?.key ?: break
            map.remove(oldest)
        }
        map[key] = value
    }
    @Synchronized fun remove(key: K) = map.remove(key)
    @Synchronized fun clear() = map.clear()
}

// ==================== 内部状态管理器（绑定 SupervisorJob，配套后台调度器）= ====================
internal class ChatViewModelDelegate {

    /** LRU 消息缓存：最多 20 个会话的消息快照 */
    val msgCache = LruCache<String, List<ChatMsg>>(20)

    /** 主线程协程作用域（页面退出时 cancel 终止全部异步任务） */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /** 后台 IO 协程（上传等持续任务） */
    val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ==================== 网络状态 ====================
    private val _isOffline = MutableStateFlow(false)
    val isOffline: StateFlow<Boolean> = _isOffline.asStateFlow()
    // ==================== 对话列表 ====================
    private val _conversations = MutableStateFlow<List<ConversationInfo>>(emptyList())
    val conversations: StateFlow<List<ConversationInfo>> = _conversations.asStateFlow()
    private val _conversationsLoading = MutableStateFlow(false)
    val conversationsLoading: StateFlow<Boolean> = _conversationsLoading.asStateFlow()
    private var loadConversationsJob: Job? = null
    /** 上次成功拉取对话列表的时间戳，用于新鲜度守卫 */
    private var lastSuccessLoadTime = 0L

    // ==================== 好友请求 ====================
    private val _friendRequests = MutableStateFlow<List<FriendRequestInfo>>(emptyList())
    val friendRequests: StateFlow<List<FriendRequestInfo>> = _friendRequests.asStateFlow()
    private val _friendRequestsLoading = MutableStateFlow(false)
    val friendRequestsLoading: StateFlow<Boolean> = _friendRequestsLoading.asStateFlow()

    // ==================== TCP 推送通知 ====================
    private val _newMessageReceived = MutableStateFlow(0)
    val newMessageReceived: StateFlow<Int> = _newMessageReceived.asStateFlow()
    private val _friendRequestReceived = MutableStateFlow(0)
    val friendRequestReceived: StateFlow<Int> = _friendRequestReceived.asStateFlow()
    private val _selfChatRefreshKey = MutableStateFlow(0)
    val selfChatRefreshKey: StateFlow<Int> = _selfChatRefreshKey.asStateFlow()
    private val _groupAvatarRefreshKey = MutableStateFlow(0)
    val groupAvatarRefreshKey: StateFlow<Int> = _groupAvatarRefreshKey.asStateFlow()

    /** 释放资源：取消所有协程，清空缓存（在 Application.onTerminate 或退出登录时调用） */
    fun release() {
        scope.cancel()
        backgroundScope.cancel()
        msgCache.clear()
    }

    fun notifyNewMessage() { scope.launch { _newMessageReceived.value++ } }
    fun notifyFriendRequest() { scope.launch { _friendRequestReceived.value++ } }

    /** 置顶状态变更通知 */
    private val _pinChanged = MutableStateFlow(0)
    val pinChanged: StateFlow<Int> = _pinChanged.asStateFlow()
    fun notifyPinChanged() { scope.launch { _pinChanged.value++ } }

    /** 根据本地置顶状态排序：置顶的会话排在前面 */
    private fun sortConversationsByPin(context: android.content.Context?, list: List<ConversationInfo>): List<ConversationInfo> {
        if (context == null) return list
        val prefs = context.getSharedPreferences("aurora_friend_settings", Context.MODE_PRIVATE)
        return list.sortedByDescending { conv ->
            // 群聊 id 为负数（-1000 - internalGroupId），本地存储用正数 internalGroupId 做 key
            val key = if (conv.id < 0) "pin_group_${-(conv.id + 1000)}" else "pin_${conv.id}"
            prefs.getBoolean(key, false)
        }
    }

    fun loadConversations(context: android.content.Context? = null, showLoading: Boolean = true, force: Boolean = false) {
        // 新鲜度守卫：缓存非空且距上次成功拉取不足 30s 时（非强制刷新）直接沿用缓存，避免高频切回聊天重复网络请求
        if (!force && _conversations.value.isNotEmpty() && System.currentTimeMillis() - lastSuccessLoadTime < 30_000) return
        loadConversationsJob?.cancel()
        loadConversationsJob = scope.launch {
            val shouldShowLoading = showLoading && _conversations.value.isEmpty()
            if (shouldShowLoading) _conversationsLoading.value = true
            val result = ChatRepository.getConversations()
            if (result.success) {
                val data = result.data ?: emptyList()
                _conversations.value = sortConversationsByPin(context, data); _isOffline.value = false
                lastSuccessLoadTime = System.currentTimeMillis()
                // 每次加载成功都保存到本地（注意去重）
                if (context != null) {
                    try {
                        val existing = LocalConversationStore.load(context)
                        val merged = (existing + data).distinctBy { it.id }
                        LocalConversationStore.save(context, merged)
                    } catch (_: Exception) {}
                }
            } else {
                if (result.message != "暂无消息") android.util.Log.w("ChatVM", "对话列表加载失败: ${result.message}")
                if (context != null) {
                    val local = LocalConversationStore.load(context)
                    if (local.isNotEmpty()) { _conversations.value = sortConversationsByPin(context, local); _isOffline.value = true }
                }
            }
            if (shouldShowLoading) _conversationsLoading.value = false
        }
    }

    fun loadFriendRequests(context: android.content.Context? = null) {
        scope.launch {
            _friendRequestsLoading.value = true
            val result = ChatRepository.getFriendRequests()
            if (result.success) {
                _friendRequests.value = result.data ?: emptyList(); _friendRequestReceived.value = 0
                android.util.Log.i("FriendReq", "拉取好友请求成功: ${_friendRequests.value.size} 条")
            } else {
                _friendRequests.value = emptyList()
                android.util.Log.w("FriendReq", "拉取好友请求失败: ${result.message}")
            }
            _friendRequestsLoading.value = false
        }
    }

    fun sendMessage(currentUserId: Long, friendId: Long, text: String, replyTo: Long = 0,
                    mediaType: String = "", mediaUrl: String = "", flashDuration: Int = 0,
                    onSuccess: (Long) -> Unit, onError: (String) -> Unit,
                    context: android.content.Context? = null) {
        scope.launch {
            val result = if (isGroupChat(friendId)) ChatRepository.sendGroupMessage(friendId, text, replyTo, mediaType, mediaUrl, flashDuration)
            else ChatRepository.sendMessage(friendId, text, replyTo, mediaType, mediaUrl, flashDuration)
            if (result.success) onSuccess(result.data ?: 0L) else onError(result.message)
        }
    }

    suspend fun getUserInfo(userId: Long): UserInfoResult {
        val info = ChatRepository.getUserInfo(userId)
        return UserInfoResult(if (info.success) info.data else null, _conversations.value)
    }

    fun clearFriendRequests() { _friendRequests.value = emptyList() }

    fun respondFriendRequest(requestId: Long, action: String, context: android.content.Context? = null, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        // 立即从本地列表移除（不管后端返回什么，先消失）
        _friendRequests.value = _friendRequests.value.filter { it.id != requestId }
        scope.launch {
            val result = ChatRepository.respondFriendRequest(requestId, action)
            if (!result.success) {
                // 如果失败了，重新加载列表确保数据正确
                loadFriendRequests(context)
            }
            onResult(result.success, result.message)
        }
    }

    fun removeUserData(userId: Long) {
        _conversations.update { current -> current.filter { it.id != userId } }
    }

    fun refreshGroupAvatars() { scope.launch { _groupAvatarRefreshKey.value++ } }
    fun notifySelfChatRefresh() { scope.launch { _selfChatRefreshKey.value++ } }

    fun updateConversationPreview(friendId: Long, preview: String, createdAt: Long) {
        _conversations.update { current ->
            current.map { if (it.id == friendId) it.copy(lastMessage = preview, lastTime = createdAt) else it }
        }
    }

    fun loadMessages(currentUserId: Long, friendId: Long, context: android.content.Context? = null) {
        scope.launch {
            val result = if (isGroupChat(friendId)) ChatRepository.getGroupMessages(friendId, 0, 0)
            else ChatRepository.getMessages(currentUserId, friendId, 0, 0)
            if (result.success && result.data != null) {
                val msgs = result.data!!
                msgCache.put("$currentUserId:$friendId", msgs.map { m ->
                    ChatMsg.create(text = m.content, isMine = m.fromUserId == currentUserId,
                        fromUserId = m.fromUserId, serverId = m.id, isNew = false, senderName = m.fromUserName,
                        wornBadge = m.wornBadge, createdAt = m.createdAt, isRevoked = m.isRevoked,
                        isSystemNotice = m.isRevoked == 1, replyToText = m.replyToText,
                        replyToSender = m.replyToSender, replyToId = m.replyToId, mediaType = m.mediaType,
                        mediaUrl = m.mediaUrl, flashDuration = m.flashDuration, toUserId = m.toUserId, targetName = "")
                })
                // 持久化到本地
                if (context != null) {
                    com.aurora.chat.data.local.LocalMessageStore.saveMessages(context, friendId, msgs)
                }
            } else if (context != null) {
                // 离线/失败时从本地恢复
                val local = com.aurora.chat.data.local.LocalMessageStore.loadMessages(context, friendId)
                if (local.isNotEmpty()) {
                    msgCache.put("$currentUserId:$friendId", local.map { m ->
                        ChatMsg.create(text = m.content, isMine = m.fromUserId == currentUserId,
                            fromUserId = m.fromUserId, serverId = m.id, isNew = false, senderName = m.fromUserName,
                            wornBadge = m.wornBadge, createdAt = m.createdAt, isRevoked = m.isRevoked,
                            isSystemNotice = m.isRevoked == 1, replyToText = m.replyToText,
                            replyToSender = m.replyToSender, replyToId = m.replyToId, mediaType = m.mediaType,
                            mediaUrl = m.mediaUrl, flashDuration = m.flashDuration, toUserId = m.toUserId, targetName = "")
                    })
                }
            }
        }
    }
}

// ==================== 全局单例（兼容原有所有静态访问方式） ====================
object ChatViewModel {
    private val _delegate = ChatViewModelDelegate()

    private inline val d get() = _delegate

    val conversations: StateFlow<List<ConversationInfo>> get() = d.conversations
    val conversationsLoading: StateFlow<Boolean> get() = d.conversationsLoading
    val friendRequests: StateFlow<List<FriendRequestInfo>> get() = d.friendRequests
    val friendRequestsLoading: StateFlow<Boolean> get() = d.friendRequestsLoading
    val newMessageReceived: StateFlow<Int> get() = d.newMessageReceived
    val friendRequestReceived: StateFlow<Int> get() = d.friendRequestReceived
    val isOffline: StateFlow<Boolean> get() = d.isOffline
    val groupAvatarRefreshKey: StateFlow<Int> get() = d.groupAvatarRefreshKey
    val selfChatRefreshKey: StateFlow<Int> get() = d.selfChatRefreshKey
    val pinChanged: StateFlow<Int> get() = d.pinChanged
    val backgroundScope: CoroutineScope get() = d.backgroundScope
    val msgCache: LruCache<String, List<ChatMsg>> get() = d.msgCache

    fun loadConversations(context: android.content.Context? = null, showLoading: Boolean = true, force: Boolean = false) = d.loadConversations(context, showLoading, force)
    fun loadFriendRequests(context: android.content.Context? = null) = d.loadFriendRequests(context)
    fun clearFriendRequests() = d.clearFriendRequests()
    fun respondFriendRequest(requestId: Long, action: String, context: android.content.Context? = null, onResult: (Boolean, String) -> Unit = { _, _ -> }) = d.respondFriendRequest(requestId, action, context, onResult)
    fun removeUserData(userId: Long) = d.removeUserData(userId)
    fun refreshGroupAvatars() = d.refreshGroupAvatars()
    fun sendMessage(currentUserId: Long, friendId: Long, text: String, replyTo: Long = 0,
                    mediaType: String = "", mediaUrl: String = "", flashDuration: Int = 0,
                    onSuccess: (Long) -> Unit, onError: (String) -> Unit,
                    context: android.content.Context? = null) =
        d.sendMessage(currentUserId, friendId, text, replyTo, mediaType, mediaUrl, flashDuration, onSuccess, onError, context)
    fun updateConversationPreview(friendId: Long, preview: String, createdAt: Long) = d.updateConversationPreview(friendId, preview, createdAt)
    suspend fun getUserInfo(userId: Long) = d.getUserInfo(userId)
    fun notifyNewMessage() = d.notifyNewMessage()
    fun notifySelfChatRefresh() = d.notifySelfChatRefresh()
    fun notifyFriendRequest() = d.notifyFriendRequest()
    fun notifyPinChanged() = d.notifyPinChanged()
    fun loadMessages(currentUserId: Long, friendId: Long, context: android.content.Context? = null) = d.loadMessages(currentUserId, friendId, context)
    fun release() = _delegate.release()
}
