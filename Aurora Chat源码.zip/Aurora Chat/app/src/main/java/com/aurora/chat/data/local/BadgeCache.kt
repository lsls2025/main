package com.aurora.chat.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.aurora.chat.data.api.BadgeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * 徽章缓存管理器
 * - 内存缓存（快速访问）
 * - 磁盘缓存（持久化）
 */
object BadgeCache {

    private val badgeImageCache = mutableMapOf<Long, Bitmap>()
    private const val MAX_CACHE = 50

    private fun getCacheDir(context: Context): File {
        val dir = File(context.filesDir, "badge_cache")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getMetaFile(context: Context): File = File(context.filesDir, "badge_meta.json")

    private fun getImageFile(context: Context, badgeId: Long): File =
        File(getCacheDir(context), "badge_$badgeId.png")

    /** 保存徽章列表元数据（不含图片数据） */
    fun saveBadgeMeta(context: Context, badges: List<BadgeInfo>) {
        try {
            val arr = JSONArray()
            badges.forEach { badge ->
                arr.put(JSONObject().apply {
                    put("id", badge.id)
                    put("name", badge.name)
                    put("image_type", badge.image_type)
                    put("display_size", badge.display_size)
                    put("created_at", badge.created_at)
                })
            }
            getMetaFile(context).writeText(arr.toString())
        } catch (_: Exception) {}
    }

    /** 加载徽章列表元数据 */
    fun loadBadgeMeta(context: Context): List<BadgeInfo> {
        try {
            val file = getMetaFile(context)
            if (!file.exists()) return emptyList()
            val arr = JSONArray(file.readText())
            val list = mutableListOf<BadgeInfo>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(BadgeInfo(
                    id = obj.optLong("id"),
                    name = obj.optString("name"),
                    image_type = obj.optString("image_type", "png"),
                    display_size = obj.optString("display_size", "medium"),
                    created_at = obj.optLong("created_at")
                ))
            }
            return list
        } catch (_: Exception) { return emptyList() }
    }

    /** 保存徽章图片到磁盘+内存缓存 */
    fun saveBadgeImage(context: Context, badgeId: Long, imageData: String) {
        try {
            val bytes = Base64.decode(imageData, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bitmap != null) {
                // 内存缓存
                if (badgeImageCache.size >= MAX_CACHE) {
                    val firstKey = badgeImageCache.keys.firstOrNull()
                    if (firstKey != null) badgeImageCache.remove(firstKey)
                }
                badgeImageCache[badgeId] = bitmap
                // 磁盘缓存
                val out = java.io.FileOutputStream(getImageFile(context, badgeId))
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.close()
            }
        } catch (_: Exception) {}
    }

    /** 从缓存加载徽章图片（先内存后磁盘） */
    fun loadBadgeImage(context: Context, badgeId: Long): Bitmap? {
        // 内存缓存
        badgeImageCache[badgeId]?.let { return it }
        // 磁盘缓存
        val file = getImageFile(context, badgeId)
        if (file.exists()) {
            try {
                val bitmap = BitmapFactory.decodeFile(file.absolutePath)
                if (bitmap != null) {
                    badgeImageCache[badgeId] = bitmap
                    return bitmap
                }
            } catch (_: Exception) {}
        }
        return null
    }

    /** 清除所有徽章缓存 */
    fun clearAll(context: Context) {
        badgeImageCache.clear()
        getCacheDir(context).deleteRecursively()
        getMetaFile(context).delete()
    }

    /** 检查某徽章是否已有磁盘缓存 */
    fun hasCachedImage(context: Context, badgeId: Long): Boolean =
        getImageFile(context, badgeId).exists()
}
