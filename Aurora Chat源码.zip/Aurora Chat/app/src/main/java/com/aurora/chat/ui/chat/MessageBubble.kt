package com.aurora.chat.ui.chat

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.ViewConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.chat.R
import com.aurora.chat.ui.components.GroupAvatar
import com.aurora.chat.ui.components.UserAvatar
import com.aurora.chat.ui.text.UrlText
import com.aurora.chat.ui.chat.ChatMsg
import com.aurora.chat.ui.chat.badgeResIds
import com.aurora.chat.ui.chat.FlashIcon
import com.aurora.chat.ui.chat.FlashViewerDialog
import com.aurora.chat.ui.chat.VideoThumbnailView
import com.aurora.chat.ui.chat.media.ChatMediaImage
import com.aurora.chat.ui.chat.media.MediaStore
import com.aurora.chat.ui.chat.isLocationCardMessage
import com.aurora.chat.ui.chat.parseLocationCard
import com.aurora.chat.ui.chat.LocationCardData
import com.aurora.chat.ui.chat.isShareCardMessage
import com.aurora.chat.ui.chat.parseShareCard
import com.aurora.chat.ui.chat.isPrivacyRequestCard
import com.aurora.chat.ui.chat.isPrivacyResponseCard
import com.aurora.chat.ui.chat.PrivacyCard
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

/**
 * AI 自定义头像的全局可观察状态：用户上传后替换默认 AI 头像（ai_avatar 资源）。
 * 使用 mutableStateOf 以便对话中已渲染的 AI 气泡在上传/恢复后自动刷新。
 */
object AiAvatarState {
    var bitmap by mutableStateOf<android.graphics.Bitmap?>(null)
}

/**
 * AI 自定义名称的全局可观察状态：用户设置后替换默认名称（DeepSeek）。
 * 使用 mutableStateOf 以便聊天列表 / 对话标题 / AI 气泡在设置后自动刷新。
 */
object AiNameState {
    var name by mutableStateOf<String?>(null)
}

@Composable
fun GroupMsgBadge(wornBadge: Int, onBadgeClick: (Int) -> Unit = {}) {
    val bi = wornBadge - 1
    if (bi in badgeResIds.indices) {
        Image(
            painter = painterResource(badgeResIds[bi]),
            contentDescription = "徽章",
            modifier = Modifier.height(14.dp).clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onBadgeClick(wornBadge) },
                                contentScale = ContentScale.FillHeight
        )
    }
}

/**
 * 图片渲染（委托给重写后的 ChatMediaImage，统一媒体来源与失败兜底，避免显示空气泡）。
 */
@Composable
private fun MediaImageView(
    url: String,
    isMine: Boolean,
    loadMedia: Boolean,
    highlightAnim: androidx.compose.animation.core.Animatable<Float, androidx.compose.animation.core.AnimationVector1D>,
    onImageClick: (String) -> Unit,
    onBubbleLongPress: () -> Unit
) = ChatMediaImage(
    url = url,
    isMine = isMine,
    loadMedia = loadMedia,
    highlightAnim = highlightAnim,
    onImageClick = onImageClick,
    onBubbleLongPress = onBubbleLongPress
)


@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(text: String, isMine: Boolean, fromUserId: Long, myAvatar: android.graphics.Bitmap?, displayName: String, showSenderName: Boolean = false, groupConvId: Long = 0, currentUserId: Long = 0, onAvatarClick: (Long, String) -> Unit = { _, _ -> }, wornBadge: Int = 0, onBadgeClick: (Int) -> Unit = {}, onBubbleTap: () -> Unit = {}, onBubbleLongPress: () -> Unit = {}, selectable: Boolean = false, replyToText: String = "", replyToSender: String = "", replyToId: Long = 0, isHighlighted: Boolean = false, onCapsuleClick: (Long) -> Unit = {}, onAvatarLongPress: (Long, String) -> Unit = { _, _ -> }, onAvatarDoubleTap: (Long, String) -> Unit = { _, _ -> }, onAtMentionClick: (String) -> Unit = {}, isGroup: Boolean = false, groupMemberNames: Set<String> = emptySet(), loadMedia: Boolean = true, mediaType: String = "", mediaUrl: String = "", isUploading: Boolean = false, uploadProgress: Float = 0f, onImageClick: (String) -> Unit = {}, flashDuration: Int = 0, reasoningText: String = "", msgId: Long = 0, destroyedFlashIds: Set<Long> = emptySet(), onFlashDestroy: (Long) -> Unit = {}, onOpenPostDetail: (Long) -> Unit = {},
    onOpenAiChatDetail: (Long) -> Unit = {}, onOpenGroupDetail: (Long) -> Unit = {}, onOpenSourceCodeDetail: (Long) -> Unit = {}, onReasoningToggled: (Boolean) -> Unit = {}, expandedReasoningMsgId: Long = 0) {
    val avatarSize = 42.dp
    // 媒体 URL 以 MediaStore 为权威单一来源：优先用按 msgId 记录的可达 URL，避免重载时丢失导致空气泡
    val effectiveMediaUrl = if (msgId > 0) (MediaStore.get(msgId)?.url ?: mediaUrl) else mediaUrl
    @Suppress("NAME_SHADOWING")
    val mediaUrl = effectiveMediaUrl
    // 高亮闪烁动画（浅蓝色闪3次）
    val highlightAnim = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(isHighlighted) {
        if (isHighlighted) {
            highlightAnim.snapTo(0f)
            kotlinx.coroutines.delay(50)
            repeat(3) {
                highlightAnim.animateTo(0.4f, androidx.compose.animation.core.tween(200))
                highlightAnim.animateTo(0f, androidx.compose.animation.core.tween(200))
            }
        }
    }

    // 缩短长按判定时长（默认 400ms → 200ms），让气泡/头像长按更容易触发
    val customViewConfig = LocalViewConfiguration.current
    CompositionLocalProvider(
        LocalViewConfiguration provides object : ViewConfiguration by customViewConfig {
            override val longPressTimeoutMillis: Long = 200L
        }
    ) {
    if (isMine) {
        // ── 自己的消息：头像在右，气泡在左 ──
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.Top
        ) {
            // 气泡区（含名字 + 气泡，整体向上偏移，仅限群聊）
            Box(Modifier.widthIn(max = 260.dp)) {
                Column(horizontalAlignment = Alignment.End,
                    modifier = if (groupConvId < 0) Modifier.offset(y = (-10).dp) else Modifier) {
                    // 自己的群聊消息也显示名字（靠右），徽章在名字左边
                    if (showSenderName && displayName.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (groupConvId < 0) { Spacer(Modifier.width(4.dp)); GroupMsgBadge(wornBadge, onBadgeClick) }
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = displayName,
                                fontSize = 11.sp,
                                color = Color(0xFF6B7280),
                                maxLines = 1,
                                modifier = Modifier.padding(bottom = 0.dp)
                            )
                        }
                    }
                    if (mediaType == "image" || mediaType == "jpg" || mediaType == "png" || mediaType == "gif" || mediaType == "jpeg") {
                        if (isUploading) {
                            Box(
                                modifier = Modifier
                                    .width(160.dp).aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF374151)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    androidx.compose.material3.CircularProgressIndicator(
                                        progress = { uploadProgress.coerceIn(0f, 1f) },
                                        modifier = Modifier.size(36.dp),
                                        color = Color.White,
                                        strokeWidth = 3.dp,
                                        trackColor = Color(0x4DFFFFFF)
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        "${(uploadProgress * 100).toInt()}%",
                                        fontSize = 13.sp, color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        } else if (flashDuration > 0 && msgId !in destroyedFlashIds) {
                            var showFlashViewer by remember { mutableStateOf(false) }
                            Box(
                                modifier = Modifier
                                    .width(160.dp).aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF1F2937))
                                    .combinedClickable(
                                        onClick = { showFlashViewer = true },
                                        onLongClick = { onBubbleLongPress() },
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    FlashIcon(iconSize = 32.dp)
                                    Spacer(Modifier.height(4.dp))
                                    Text("闪照", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                                    Text("点击查看", fontSize = 10.sp, color = Color(0xFF6B7280))
                                }
                            }
                            if (showFlashViewer) {
                                FlashViewerDialog(
                                    imageUrl = mediaUrl, durationSec = flashDuration,
                                    onDestroy = { onFlashDestroy(msgId) },
                                    onDismiss = { showFlashViewer = false }
                                )
                            }
                        } else if (flashDuration > 0) {
                            Box(
                                modifier = Modifier
                                    .width(160.dp).aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF374151)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("图片已销毁", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                            }
                        } else {
                        MediaImageView(
                            url = mediaUrl,
                            isMine = isMine,
                            loadMedia = loadMedia,
                            highlightAnim = highlightAnim,
                            onImageClick = onImageClick,
                            onBubbleLongPress = onBubbleLongPress
                        )
                        }
                        } else if (mediaType == "video" || mediaType == "mp4") {
                        if (isUploading) {
                            Box(
                                modifier = Modifier
                                    .width(160.dp).aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF374151)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    androidx.compose.material3.CircularProgressIndicator(
                                        progress = { uploadProgress.coerceIn(0f, 1f) },
                                        modifier = Modifier.size(36.dp),
                                        color = Color.White,
                                        strokeWidth = 3.dp,
                                        trackColor = Color(0x4DFFFFFF)
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        "${(uploadProgress * 100).toInt()}%",
                                        fontSize = 13.sp, color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text("上传中...", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                                }
                            }
                        } else {
                        // 视频消息：不带气泡框，显示缩略图（点击应用内播放）
                        Box(
                            modifier = Modifier
                                .widthIn(max = 200.dp).heightIn(max = 280.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .combinedClickable(
                                    onClick = {
                                        if (mediaUrl.isNotEmpty()) onImageClick(mediaUrl) else onBubbleTap()
                                    },
                                    onLongClick = { onBubbleLongPress() },
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() }
                                )
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth().heightIn(max = 280.dp)
                                    .background(Color(0xFF1F2937))
                                    .clip(RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (loadMedia) VideoThumbnailView(videoUrl = mediaUrl, modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp))
                                else Box(Modifier.fillMaxWidth().height(120.dp).background(Color(0xFF1F2937).copy(alpha = 0.3f)), contentAlignment = Alignment.Center) { Text("视频", fontSize = 13.sp, color = Color(0xFF9CA3AF)) }
                            }
                        }
                        }
                    } else if (com.aurora.chat.ui.chat.isLocationCardMessage(text)) {
                        val locCtx = androidx.compose.ui.platform.LocalContext.current
                        Box(
                            modifier = Modifier.combinedClickable(
                                onClick = {
                                    val loc = com.aurora.chat.ui.chat.parseLocationCard(text)
                                    if (loc != null && loc.lat != 0.0 && loc.lng != 0.0) {
                                        try {
                                            val geoUri = android.net.Uri.parse("geo:${loc.lat},${loc.lng}?q=${loc.lat},${loc.lng}")
                                            val mapIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, geoUri)
                                            locCtx.startActivity(android.content.Intent.createChooser(mapIntent, "选择导航应用"))
                                        } catch (_: Exception) {
                                            android.widget.Toast.makeText(locCtx, "没有可用的导航应用", android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                onLongClick = { onBubbleLongPress() },
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() }
                            )
                        ) {
                            com.aurora.chat.ui.chat.LocationCard(
                                text = text
                            )
                        }
                    } else if (com.aurora.chat.ui.chat.isShareCardMessage(text)) {
                        Box(
                            modifier = Modifier.combinedClickable(
                                onClick = {
                                    val card = com.aurora.chat.ui.chat.parseShareCard(text)
                                    when (card?.targetType) {
                                        "ai_chat" -> { if (card.postId > 0) onOpenAiChatDetail?.invoke(card.postId) }
                                        "group" -> { if (card.postId > 0) onOpenGroupDetail?.invoke(card.postId) }
                                        "source_code" -> { if (card.postId > 0) onOpenSourceCodeDetail?.invoke(card.postId) }
                                        else -> { val pid = card?.postId ?: 0L; if (pid > 0) onOpenPostDetail?.invoke(pid) }
                                    }
                                },
                                onLongClick = { onBubbleLongPress() },
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() }
                            )
                        ) {
                            com.aurora.chat.ui.chat.ShareCard(
                                text = text,
                                isMine = true,
                                onPostClick = onOpenPostDetail,
                                onGroupClick = onOpenGroupDetail,
                                onSourceCodeClick = onOpenSourceCodeDetail
                            )
                        }
                    } else if (isPrivacyRequestCard(text) || isPrivacyResponseCard(text)) {
                        PrivacyCard(text = text, isMine = true)
                    } else {
                        // 自己消息的文本气泡（绿色背景）
                        Box(
                            modifier = Modifier
                                .widthIn(max = 260.dp).heightIn(min = avatarSize).wrapContentHeight()
                                .clip(RoundedCornerShape(12.dp)).background(Color(0xFF95EC69))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .then(if (highlightAnim.value > 0.01f) Modifier.drawWithContent {
                                    drawContent()
                                    drawRect(Color(0xFFBFDBFE).copy(alpha = highlightAnim.value), size = size)
                                } else Modifier),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (selectable) {
                                SelectionContainer {
                                    Text(text, fontSize = 15.sp, lineHeight = 22.sp, color = Color(0xFF000000))
                                }
                            } else {
                                // 长文本折叠：超过 6 行显示"展开"按钮
                                var isExpanded by remember { mutableStateOf(false) }
                                val maxCollapsedLines = 6
                                Column {
                                    UrlText(
                                        text = text,
                                        fontSize = 15.sp,
                                        defaultColor = Color(0xFF000000),
                                        lineHeight = 22.sp,
                                        selectable = false,
                                        clickable = true,
                                        onClick = { if (!selectable) onBubbleTap() },
                                        onLongPress = { if (!selectable) onBubbleLongPress() },
                                        onAtMentionClick = onAtMentionClick,
                                        isGroup = isGroup,
                                        groupMemberNames = groupMemberNames,
                                        maxLines = if (isExpanded) Int.MAX_VALUE else maxCollapsedLines
                                    )
                                    // 如果文本被截断，显示展开按钮
                                    if (text.length > 120 && !isExpanded) {
                                        Text(
                                            "展开",
                                            fontSize = 13.sp,
                                            color = Color(0xFF576B95),
                                            modifier = Modifier.clickable { isExpanded = true }
                                                .padding(top = 2.dp)
                                        )
                                    }
                                    if (isExpanded && text.length > 120) {
                                        Text(
                                            "收起",
                                            fontSize = 13.sp,
                                            color = Color(0xFF576B95),
                                            modifier = Modifier.clickable { isExpanded = false }
                                                .padding(top = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                    // 引用胶囊（可点击跳到原文）
                    if (replyToText.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .widthIn(max = 260.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFE5E7EB))
                                .clickable { if (replyToId > 0) onCapsuleClick(replyToId) }
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                if (replyToText.isNotEmpty()) "${replyToSender}:${replyToText}" else "${replyToSender}:[消息]",
                                fontSize = 10.sp, color = Color(0xFF6B7280),
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.width(6.dp))
            // 头像（无波纹）
            val localView = androidx.compose.ui.platform.LocalView.current
            val shakeOff = remember { androidx.compose.animation.core.Animatable(0f) }
            val shakeScope = rememberCoroutineScope()
            val myMod = Modifier
                .size(avatarSize)
                .clip(RoundedCornerShape(10.dp))
                .graphicsLayer {
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 1f)
                    rotationZ = shakeOff.value
                }
                .pointerInput(fromUserId) {
                    detectTapGestures(
                        onTap = { onAvatarClick(fromUserId, "我") },
                        onDoubleTap = {
                            localView.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM)
                            shakeScope.launch {
                                shakeOff.animateTo(8f, tween(50))
                                shakeOff.animateTo(-8f, tween(50))
                                shakeOff.animateTo(5f, tween(40))
                                shakeOff.animateTo(-5f, tween(40))
                                shakeOff.animateTo(0f, tween(40))
                            }
                            onAvatarDoubleTap(fromUserId, "我")
                        },
                        onLongPress = {
                            localView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                            onAvatarLongPress(fromUserId, "我")
                        }
                    )
                }
            // 右侧头像：根据 fromUserId 决定显示谁的头像（reverseHistory 翻过后可能不是"我"）
            val rightAvatarMod = Modifier
                .size(avatarSize)
                .clip(RoundedCornerShape(10.dp))
                .graphicsLayer {
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 1f)
                    rotationZ = shakeOff.value
                }
                .pointerInput(fromUserId) {
                    detectTapGestures(
                        onTap = { onAvatarClick(fromUserId, if (fromUserId == currentUserId) "我" else displayName) },
                        onDoubleTap = {
                            localView.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM)
                            shakeScope.launch {
                                shakeOff.animateTo(8f, tween(50))
                                shakeOff.animateTo(-8f, tween(50))
                                shakeOff.animateTo(5f, tween(40))
                                shakeOff.animateTo(-5f, tween(40))
                                shakeOff.animateTo(0f, tween(40))
                            }
                            onAvatarDoubleTap(fromUserId, if (fromUserId == currentUserId) "我" else displayName)
                        },
                        onLongPress = {
                            localView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                            onAvatarLongPress(fromUserId, if (fromUserId == currentUserId) "我" else displayName)
                        }
                    )
                }
            when {
                fromUserId == currentUserId -> {
                    if (myAvatar != null) {
                        Image(bitmap = myAvatar.asImageBitmap(), contentDescription = "我的头像",
                            modifier = rightAvatarMod, contentScale = ContentScale.Fit)
                    } else {
                        Image(painter = painterResource(R.drawable.ic_profile), contentDescription = "我的头像",
                            modifier = rightAvatarMod, contentScale = ContentScale.Fit)
                    }
                }
                fromUserId == AI_CHAT_ID -> {
                    val customAiAvatar = AiAvatarState.bitmap
                    if (customAiAvatar != null) {
                        Image(bitmap = customAiAvatar.asImageBitmap(), contentDescription = "DeepSeek",
                            modifier = rightAvatarMod, contentScale = ContentScale.Crop)
                    } else {
                        Image(painter = painterResource(R.drawable.ai_avatar), contentDescription = "DeepSeek",
                            modifier = rightAvatarMod, contentScale = ContentScale.Crop)
                    }
                }
                else -> {
                    UserAvatar(userId = fromUserId, userName = displayName.ifEmpty { "?" },
                        size = avatarSize, modifier = rightAvatarMod)
                }
            }
        }
    } else {
            // 别人的群聊消息：头像在左，名字在头像右上，气泡在名字下方
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                val localView2 = androidx.compose.ui.platform.LocalView.current
                // 头像（可点击/长按查看用户资料/艾特）
                if (groupConvId < 0 && fromUserId == groupConvId) {
                    // 群系统消息头像：使用群默认头像
                    val internalGroupId = -(groupConvId + 1000)
                    GroupAvatar(
                        internalGroupId = internalGroupId,
                        groupName = displayName,
                        size = avatarSize,
                        modifier = Modifier
                            .size(avatarSize)
                            .pointerInput(fromUserId) {
                                detectTapGestures(
                                    onTap = { onAvatarClick(fromUserId, displayName) },
                                    onDoubleTap = { onAvatarDoubleTap(fromUserId, displayName) },
                                    onLongPress = {
                                        localView2.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                                        onAvatarLongPress(fromUserId, displayName)
                                    }
                                )
                            }
                    )
                } else {
                    if (fromUserId == AI_CHAT_ID) {
                        // AI 对话：优先使用用户上传的自定义头像，否则使用内置 AI 默认头像；不可点击
                        val customAiAvatar = AiAvatarState.bitmap
                        if (customAiAvatar != null) {
                            Image(
                                bitmap = customAiAvatar.asImageBitmap(),
                                contentDescription = "DeepSeek",
                                modifier = Modifier.size(avatarSize).clip(RoundedCornerShape(10.dp)),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Image(
                                painter = painterResource(R.drawable.ai_avatar),
                                contentDescription = "DeepSeek",
                                modifier = Modifier.size(avatarSize).clip(RoundedCornerShape(10.dp)),
                                contentScale = ContentScale.Crop
                            )
                        }
                    } else {
                    if (myAvatar != null && fromUserId == currentUserId) {
                        // 身份互换（reverseHistory）时，对方气泡实际翻成了自己的 ID，直接显示本地头像
                        Image(
                            bitmap = myAvatar.asImageBitmap(),
                            contentDescription = "我的头像",
                            modifier = Modifier
                                .size(avatarSize)
                                .clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                    val shakeOff2 = remember { androidx.compose.animation.core.Animatable(0f) }
                    val shakeScope2 = rememberCoroutineScope()
                    UserAvatar(
                        userId = fromUserId,
                        userName = displayName.ifEmpty { "?" },
                        size = avatarSize,
                        modifier = Modifier
                            .size(avatarSize)
                            .graphicsLayer {
                                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 1f)
                                rotationZ = shakeOff2.value
                            }
                            .pointerInput(fromUserId) {
                                detectTapGestures(
                                    onTap = { onAvatarClick(fromUserId, displayName) },
                                    onDoubleTap = {
                                        localView2.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM)
                                        shakeScope2.launch {
                                            shakeOff2.animateTo(8f, tween(50))
                                            shakeOff2.animateTo(-8f, tween(50))
                                            shakeOff2.animateTo(5f, tween(40))
                                            shakeOff2.animateTo(-5f, tween(40))
                                            shakeOff2.animateTo(0f, tween(40))
                                        }
                                        onAvatarDoubleTap(fromUserId, displayName)
                                    },
                                    onLongPress = {
                                        localView2.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                                        onAvatarLongPress(fromUserId, displayName)
                                    }
                                )
                            }
                    )
                    }
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
                // 气泡区（名字在上方独占一行，气泡在下方，整体向上偏移，仅限群聊）
                Box(Modifier.widthIn(max = 260.dp)) {
                    Column(modifier = if (groupConvId < 0) Modifier.offset(y = (-10).dp) else Modifier) {
                        // 名字：在头像右上角，独占一行，群聊徽章在名字右边
                        if (showSenderName && displayName.isNotEmpty()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = displayName,
                                    fontSize = 11.sp,
                                    color = Color(0xFF6B7280),
                                    maxLines = 1,
                                    modifier = Modifier.padding(bottom = 0.dp)
                                )
                                if (groupConvId < 0) { Spacer(Modifier.width(4.dp)); GroupMsgBadge(wornBadge, onBadgeClick) }
                            }
                        }
                        if (mediaType == "image" || mediaType == "jpg" || mediaType == "png" || mediaType == "gif" || mediaType == "jpeg") {
                        if (isUploading) {
                            Box(
                                modifier = Modifier
                                    .width(160.dp).aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF374151)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    androidx.compose.material3.CircularProgressIndicator(
                                        progress = { uploadProgress.coerceIn(0f, 1f) },
                                        modifier = Modifier.size(36.dp),
                                        color = Color.White,
                                        strokeWidth = 3.dp,
                                        trackColor = Color(0x4DFFFFFF)
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        "${(uploadProgress * 100).toInt()}%",
                                        fontSize = 13.sp, color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        } else if (flashDuration > 0 && msgId !in destroyedFlashIds) {
                            var showFlashViewer by remember { mutableStateOf(false) }
                            Box(
                                modifier = Modifier
                                    .width(160.dp).aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF1F2937))
                                    .combinedClickable(
                                        onClick = { showFlashViewer = true },
                                        onLongClick = { onBubbleLongPress() },
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    FlashIcon(iconSize = 32.dp)
                                    Spacer(Modifier.height(4.dp))
                                    Text("闪照", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                                    Text("点击查看", fontSize = 10.sp, color = Color(0xFF6B7280))
                                }
                            }
                            if (showFlashViewer) {
                                FlashViewerDialog(
                                    imageUrl = mediaUrl, durationSec = flashDuration,
                                    onDestroy = { onFlashDestroy(msgId) },
                                    onDismiss = { showFlashViewer = false }
                                )
                            }
                        } else if (flashDuration > 0) {
                            Box(
                                modifier = Modifier
                                    .width(160.dp).aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF374151)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("图片已销毁", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                            }
                        } else {
                        // 图片消息：不带气泡框，直接显示
                        MediaImageView(
                            url = mediaUrl,
                            isMine = isMine,
                            loadMedia = loadMedia,
                            highlightAnim = highlightAnim,
                            onImageClick = onImageClick,
                            onBubbleLongPress = onBubbleLongPress
                        )
                        }
                    } else if (mediaType == "video" || mediaType == "mp4") {
                        if (isUploading) {
                            Box(
                                modifier = Modifier
                                    .width(160.dp).aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF374151)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    androidx.compose.material3.CircularProgressIndicator(
                                        progress = { uploadProgress.coerceIn(0f, 1f) },
                                        modifier = Modifier.size(36.dp),
                                        color = Color.White,
                                        strokeWidth = 3.dp,
                                        trackColor = Color(0x4DFFFFFF)
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        "${(uploadProgress * 100).toInt()}%",
                                        fontSize = 13.sp, color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text("上传中...", fontSize = 11.sp, color = Color(0xCCFFFFFF))
                                }
                            }
                        } else {
                        // 视频消息：不带气泡框，显示缩略图（点击应用内播放）
                        Box(
                            modifier = Modifier
                                .widthIn(max = 200.dp).heightIn(max = 280.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .combinedClickable(
                                    onClick = {
                                        if (mediaUrl.isNotEmpty()) onImageClick(mediaUrl) else onBubbleTap()
                                    },
                                    onLongClick = { onBubbleLongPress() },
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() }
                                )
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth().heightIn(max = 280.dp)
                                    .background(Color(0xFF1F2937))
                                    .clip(RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (loadMedia) VideoThumbnailView(videoUrl = mediaUrl, modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp))
                                else Box(Modifier.fillMaxWidth().height(120.dp).background(Color(0xFF1F2937).copy(alpha = 0.3f)), contentAlignment = Alignment.Center) { Text("视频", fontSize = 13.sp, color = Color(0xFF9CA3AF)) }
                            }
                        }
                        }
                    } else if (com.aurora.chat.ui.chat.isLocationCardMessage(text)) {
                        val locCtx = androidx.compose.ui.platform.LocalContext.current
                        Box(
                            modifier = Modifier.combinedClickable(
                                onClick = {
                                    val loc = com.aurora.chat.ui.chat.parseLocationCard(text)
                                    if (loc != null && loc.lat != 0.0 && loc.lng != 0.0) {
                                        try {
                                            val geoUri = android.net.Uri.parse("geo:${loc.lat},${loc.lng}?q=${loc.lat},${loc.lng}")
                                            val mapIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, geoUri)
                                            locCtx.startActivity(android.content.Intent.createChooser(mapIntent, "选择导航应用"))
                                        } catch (_: Exception) {
                                            android.widget.Toast.makeText(locCtx, "没有可用的导航应用", android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                onLongClick = { onBubbleLongPress() },
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() }
                            )
                        ) {
                            com.aurora.chat.ui.chat.LocationCard(
                                text = text
                            )
                        }
                    } else if (com.aurora.chat.ui.chat.isShareCardMessage(text)) {
                        Box(
                            modifier = Modifier.combinedClickable(
                                onClick = {
                                    val card = com.aurora.chat.ui.chat.parseShareCard(text)
                                    when (card?.targetType) {
                                        "ai_chat" -> { if (card.postId > 0) onOpenAiChatDetail?.invoke(card.postId) }
                                        "group" -> { if (card.postId > 0) onOpenGroupDetail?.invoke(card.postId) }
                                        "source_code" -> { if (card.postId > 0) onOpenSourceCodeDetail?.invoke(card.postId) }
                                        else -> { val pid = card?.postId ?: 0L; if (pid > 0) onOpenPostDetail?.invoke(pid) }
                                    }
                                },
                                onLongClick = { onBubbleLongPress() },
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() }
                            )
                        ) {
                            com.aurora.chat.ui.chat.ShareCard(
                                text = text,
                                isMine = false,
                                onPostClick = onOpenPostDetail,
                                onGroupClick = onOpenGroupDetail,
                                onSourceCodeClick = onOpenSourceCodeDetail
                            )
                        }
                    } else if (isPrivacyRequestCard(text) || isPrivacyResponseCard(text)) {
                        PrivacyCard(text = text, isMine = false)
                    } else {
                        // 对方消息的文本气泡（偏灰白背景）
                        Box(
                            modifier = Modifier
                                .widthIn(max = 260.dp).heightIn(min = avatarSize).wrapContentHeight()
                                .clip(RoundedCornerShape(12.dp)).background(Color(0xFFFFFFFF))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .then(if (highlightAnim.value > 0.01f) Modifier.drawWithContent {
                                    drawContent()
                                    drawRect(Color(0xFFBFDBFE).copy(alpha = highlightAnim.value), size = size)
                                } else Modifier),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Column {
                                // 可折叠的思考过程区域（仅 AI 消息且有 reasoningText 时显示）
                                if (reasoningText.isNotEmpty() && fromUserId == AI_CHAT_ID) {
                                    var reasoningExpanded by remember(msgId, expandedReasoningMsgId) { mutableStateOf(msgId == expandedReasoningMsgId) }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFFF3F4F6))
                                            .clickable {
                                        reasoningExpanded = !reasoningExpanded
                                        onReasoningToggled(!reasoningExpanded)
                                    }
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                if (reasoningExpanded) "思考过程 ▾" else "思考过程 ▸",
                                                fontSize = 11.sp, color = Color(0xFF6B7280)
                                            )
                                        }
                                    }
                                    if (reasoningExpanded) {
                                        Text(
                                            reasoningText,
                                            fontSize = 12.sp, lineHeight = 18.sp,
                                            color = Color(0xFF6B7280),
                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                                        )
                                    }
                                    Spacer(Modifier.height(4.dp))
                                }
                                // 文本内容
                                if (selectable) {
                                    SelectionContainer {
                                        Text(text, fontSize = 15.sp, lineHeight = 22.sp, color = Color(0xFF1F2937))
                                    }
                                } else {
                                    UrlText(
                                        text = text,
                                        fontSize = 15.sp,
                                        defaultColor = Color(0xFF1F2937),
                                        lineHeight = 22.sp,
                                        selectable = false,
                                        clickable = true,
                                        onClick = { if (!selectable) onBubbleTap() },
                                        onLongPress = { if (!selectable) onBubbleLongPress() },
                                        onAtMentionClick = onAtMentionClick,
                                        isGroup = isGroup,
                                        groupMemberNames = groupMemberNames
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    // 引用胶囊（可点击跳到原文）
                    if (replyToText.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .widthIn(max = 260.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFE5E7EB))
                                .clickable { if (replyToId > 0) onCapsuleClick(replyToId) }
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                if (replyToText.isNotEmpty()) "${replyToSender}:${replyToText}" else "${replyToSender}:[消息]",
                                fontSize = 10.sp, color = Color(0xFF6B7280),
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
    }
}

