package com.aurora.chat.ui.community

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.chat.data.api.PostListItem
import com.aurora.chat.data.repository.ChatRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun CommunityPostFeed(
    currentUserId: Long,
    postType: String = "",   // ""=全部, "post"=仅帖子, "resource"=仅资源
    refreshTrigger: Int = 0,
    searchKeyword: String = "",
    onBack: () -> Unit,
    onCreatePost: () -> Unit,
    onPostClick: (Long) -> Unit,
    onDeletePost: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var posts by remember { mutableStateOf<List<PostListItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var isRefreshing by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf(1) }
    var hasMore by remember { mutableStateOf(true) }
    var loadingCooldown by remember { mutableStateOf(false) }

    suspend fun loadPosts(p: Int) {
        val prefs = ctx.getSharedPreferences("community_post_cache", Context.MODE_PRIVATE)
        try {
            val result = ChatRepository.getCommunityPosts(p, 20, postType, searchKeyword)
            if (result.success && result.data != null) {
                val data = result.data!!
                if (p == 1) {
                    posts = data.posts
                    // 预加载前6个头像
                    if (posts.isNotEmpty()) {
                        withContext(Dispatchers.IO) {
                            posts.take(6).forEach { post ->
                                ChatRepository.loadAvatar(ctx, post.user_id)
                            }
                        }
                    }
                } else {
                    // 分页可能因并发/边界重叠返回已存在的帖子，追加前按 id 去重，
                    // 避免 LazyColumn 出现重复 key 导致 IllegalArgumentException 闪退。
                    val existingIds = posts.map { it.id }.toSet()
                    val newPosts = data.posts.filter { it.id !in existingIds }
                    posts = posts + newPosts
                }
                hasMore = data.posts.size >= data.limit
                page = p
                // 缓存帖子列表到本地
                try {
                    val arr = org.json.JSONArray()
                    posts.forEach { post ->
                        arr.put(org.json.JSONObject().apply {
                            put("id", post.id); put("user_id", post.user_id)
                            put("username", post.username); put("title", post.title)
                            put("content", post.content); put("created_at", post.created_at)
                            put("post_type", post.post_type); put("res_types", post.res_types)
                            put("res_exts", post.res_exts); put("res_count", post.res_count)
                            put("first_resource_url", post.first_resource_url)
                        })
                    }
                    prefs.edit().putString("post_list_${postType}", arr.toString()).commit()
                } catch (_: Exception) {}
            } else {
                // API 返回失败，从缓存恢复
                try {
                    val cached = prefs.getString("post_list_${postType}", null)
                    if (cached != null) {
                        val arr = org.json.JSONArray(cached)
                        posts = (0 until arr.length()).map { i ->
                            val obj = arr.getJSONObject(i)
                            com.aurora.chat.data.api.PostListItem(
                                id = obj.getLong("id"),
                                user_id = obj.getLong("user_id"),
                                username = obj.getString("username"),
                                title = obj.getString("title"),
                                content = obj.getString("content"),
                                created_at = obj.getLong("created_at"),
                                post_type = obj.optString("post_type", "post"),
                                res_types = obj.optString("res_types", ""),
                                res_exts = obj.optString("res_exts", ""),
                                res_count = obj.optInt("res_count", 0),
                                first_resource_url = obj.optString("first_resource_url", "")
                            )
                        }
                        hasMore = false
                    }
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            // 断网/异常，从本地缓存恢复
            try {
                val cached = prefs.getString("post_list_${postType}", null)
                if (cached != null) {
                    val arr = org.json.JSONArray(cached)
                    posts = (0 until arr.length()).map { i ->
                        val obj = arr.getJSONObject(i)
                        com.aurora.chat.data.api.PostListItem(
                            id = obj.getLong("id"),
                            user_id = obj.getLong("user_id"),
                            username = obj.getString("username"),
                            title = obj.getString("title"),
                            content = obj.getString("content"),
                            created_at = obj.getLong("created_at"),
                            post_type = obj.optString("post_type", "post"),
                            res_types = obj.optString("res_types", ""),
                            res_exts = obj.optString("res_exts", ""),
                            res_count = obj.optInt("res_count", 0),
                            first_resource_url = obj.optString("first_resource_url", "")
                        )
                    }
                    hasMore = false
                }
            } catch (_: Exception) {}
        }
        isLoading = false
        isRefreshing = false
        delay(300)
        loadingCooldown = false
    }

    LaunchedEffect(Unit) { loadPosts(1) }
    // 搜索关键词变化时重新加载
    LaunchedEffect(searchKeyword) { loadPosts(1) }
    // 外部触发刷新（发布新帖后）：先滚动到顶部再加载
    LaunchedEffect(refreshTrigger) {
        if (refreshTrigger > 0) {
            listState.scrollToItem(0)
            loadPosts(1)
        }
    }

    // 下拉刷新检测
    val firstVisibleIndex by remember { derivedStateOf { listState.firstVisibleItemIndex } }
    LaunchedEffect(firstVisibleIndex) {
        if (firstVisibleIndex <= 0 && !isRefreshing && !isLoading) {
            isRefreshing = true
            loadPosts(1)
        }
    }

    // 触底加载更多（使用 snapshotFlow 持续监控滚动位置，不受快速滑动跳过影响）
    LaunchedEffect(Unit) {
        snapshotFlow {
            val info = listState.layoutInfo
            val lastVisible = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            val totalItems = info.totalItemsCount
            lastVisible to totalItems
        }.collect { (lastVisible, totalItems) ->
            if (lastVisible >= totalItems - 3 && hasMore && !isLoading && !loadingCooldown && posts.isNotEmpty()) {
                isLoading = true
                loadingCooldown = true
                loadPosts(page + 1)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(posts, key = { it.id }) { post ->
                PostCard(
                    post = post,
                    currentUserId = currentUserId,
                    onClick = { onPostClick(post.id) },
                    onDeleted = { postId ->
                        // 软删除已由服务端处理（SET deleted=1），前端仅做本地列表移除
                        posts = posts.filter { it.id != postId }
                    }
                )
            }
            if (isLoading && posts.isNotEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                        Text("加载中...", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                    }
                }
            }
            if (posts.isEmpty() && !isLoading) {
                item {
                    Box(Modifier.fillMaxWidth().padding(top = 60.dp), contentAlignment = Alignment.Center) {
                        Text(
                            if (postType == "resource") "暂无资源，点击右下角 + 发布" else "暂无帖子，点击右下角 + 发布",
                            fontSize = 14.sp, color = Color(0xFF9CA3AF)
                        )
                    }
                }
            }
        }

        // FAB + 按钮
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 20.dp)
                .size(56.dp)
                .clip(CircleShape)
                .background(Color(0xFF1E40AF))
                .clickable { onCreatePost() },
            contentAlignment = Alignment.Center
        ) {
            Text("+", fontSize = 28.sp, fontWeight = FontWeight.Light, color = Color.White)
        }
    }
}

@Composable
private fun PostCard(post: PostListItem, currentUserId: Long, onClick: () -> Unit, onDeleted: (Long) -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val hasImage = post.res_types.contains("image")
    val hasVideo = post.res_types.contains("video")
    val hasAudio = post.res_types.contains("audio") || post.first_resource_url.let {
        it.endsWith(".mp3") || it.endsWith(".aac") || it.endsWith(".wav") || it.endsWith(".ogg") || it.endsWith(".flac") || it.endsWith(".m4a") || it.endsWith(".wma")
    }
    var avatarBmp by remember(post.user_id) { mutableStateOf<android.graphics.Bitmap?>(null) }
    var showMenu by remember { mutableStateOf(false) }
    var showShareDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // 预加载头像
    LaunchedEffect(post.user_id) {
        withContext(kotlinx.coroutines.Dispatchers.IO) {
            avatarBmp = com.aurora.chat.data.repository.ChatRepository.loadAvatar(ctx, post.user_id)
        }
    }

    // 权限：仅开发者（ID=1）或帖子作者可删除
    val canDelete = currentUserId == 1L || currentUserId == post.user_id

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFF8F9FA))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Column {
            // 标题行 + 三点菜单
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = post.title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                // 三点菜单按钮
                Box {
                    Text("⋮", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        color = Color(0xFF6B7280),
                        modifier = Modifier
                            .clickable { showMenu = true }
                            .padding(start = 8.dp, top = 2.dp, bottom = 2.dp))
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        if (canDelete) {
                            DropdownMenuItem(
                                text = { Text("删除", color = Color(0xFFEF4444), fontSize = 14.sp) },
                                onClick = {
                                    showMenu = false
                                    showDeleteConfirm = true
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("分享", fontSize = 14.sp) },
                            onClick = {
                                showMenu = false
                                showShareDialog = true
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.height(6.dp))

            // 内容（截取，仅高亮 URL 颜色，不可点击以免干扰卡片点击）
            val preview = post.content.take(120).replace("\n", " ")
            val displayText = buildAnnotatedString {
                val pText = preview + if (post.content.length > 120) "..." else ""
                // 检测 URL 并用蓝色标记（http:// 作为可选项合并入分支），但不使用 ClickableText
                val urlPattern = Regex(
                    """(?:https?://)?www\.[a-zA-Z0-9-]+(?:\.[a-zA-Z]{2,})+(?:/[^\s]*)?""" +
                    """|""" +
                    """(?:https?://)?[a-zA-Z0-9][a-zA-Z0-9.-]*\.(?:com|cn|net|org|edu|gov|io|me|top|xyz|app|dev|info|cc|tv|co|uk|jp|de|ru|fr|au|ca|in|biz|pro|mobi|name|club|shop|online|site|space|live|wiki|store|blog|vip|fun|cloud|digital|world|work)(?:/[^\s]*)?""",
                    RegexOption.IGNORE_CASE
                )
                var lastIdx = 0
                for (m in urlPattern.findAll(pText)) {
                    append(pText.substring(lastIdx, m.range.first))
                    withStyle(SpanStyle(color = Color(0xFF1E40AF), textDecoration = TextDecoration.Underline)) {
                        append(m.value)
                    }
                    lastIdx = m.range.last + 1
                }
                withStyle(SpanStyle(color = Color(0xFF6B7280))) {
                    append(pText.substring(lastIdx))
                }
            }
            SelectionContainer {
                Text(
                    text = displayText,
                    fontSize = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(8.dp))

            // 底部：用户信息 + 资源标记
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 用户头像（真实头像）
                Box(
                    modifier = Modifier.size(20.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFD1D5DB)),
                    contentAlignment = Alignment.Center
                ) {
                    if (avatarBmp != null) {
                        Image(bitmap = avatarBmp!!.asImageBitmap(), contentDescription = null,
                            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Text(post.username.take(1), fontSize = 10.sp, color = Color.White)
                    }
                }
                Spacer(Modifier.width(6.dp))
                Text(post.username, fontSize = 12.sp, color = Color(0xFF4B5563))
                Spacer(Modifier.width(8.dp))
                Text(formatTime(post.created_at), fontSize = 11.sp, color = Color(0xFF9CA3AF))

                Spacer(Modifier.weight(1f))

                // 资源类型标记
                if (hasImage) {
                    ResourceBadge("图片", Color(0xFF2563EB))
                    Spacer(Modifier.width(6.dp))
                }
                if (hasVideo) {
                    ResourceBadge("视频", Color(0xFF7C3AED))
                    Spacer(Modifier.width(6.dp))
                }
                if (hasAudio) {
                    ResourceBadge("音频", Color(0xFF059669))
                    Spacer(Modifier.width(6.dp))
                }
                if (post.res_count > 0 && !hasImage && !hasVideo && !hasAudio) {
                    val exts = post.res_exts.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
                    val inferredExt = if (exts.isEmpty()) {
                        post.first_resource_url.substringAfterLast('.').lowercase()
                    } else null
                    fun badgeFor(extSet: Set<String>): Pair<String, Color> = when {
                        "apk" in extSet -> "安装包" to Color(0xFF16A34A)
                        "zip" in extSet || "rar" in extSet || "7z" in extSet -> "压缩包" to Color(0xFFD97706)
                        "pdf" in extSet -> "PDF" to Color(0xFFDC2626)
                        "py" in extSet -> "py源码" to Color(0xFF306998)
                        "c" in extSet || "h" in extSet -> "C源码" to Color(0xFF004481)
                        "txt" in extSet || "json" in extSet || "xml" in extSet || "html" in extSet ||
                            "css" in extSet || "js" in extSet || "md" in extSet || "log" in extSet ||
                            "csv" in extSet || "ini" in extSet || "cfg" in extSet || "properties" in extSet -> "文本" to Color(0xFF0891B2)
                        else -> "文件" to Color(0xFF6B7280)
                    }
                    val badgeInfo = if (exts.isNotEmpty()) {
                        badgeFor(exts)
                    } else if (inferredExt != null) {
                        badgeFor(setOf(inferredExt))
                    } else {
                        "文件" to Color(0xFF6B7280)
                    }
                    ResourceBadge(badgeInfo.first, badgeInfo.second)
                }
            }
        }
    }

    // 删除确认对话框
    if (showDeleteConfirm) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("确认删除", fontWeight = FontWeight.SemiBold) },
            text = { Text("确定要删除「${post.title}」吗？此操作不可撤销。", fontSize = 14.sp) },
            confirmButton = {
                androidx.compose.material3.TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        scope.launch {
                            val result = ChatRepository.deleteCommunityPost(post.id)
                            if (result.success) {
                                Toast.makeText(ctx, "删除成功", Toast.LENGTH_SHORT).show()
                                onDeleted(post.id)
                            } else {
                                Toast.makeText(ctx, result.message, Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                ) {
                    Text("删除", color = Color(0xFFEF4444), fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("取消")
                }
            }
        )
    }

    // ── 分享弹窗（用 Dialog 包裹防止在 LazyColumn item 内 fillMaxSize 导致布局循环崩溃） ──
    if (showShareDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showShareDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(Modifier.fillMaxSize()) {
                SharePostDialog(
                    postTitle = post.title,
                    postContent = post.content,
                    postId = post.id,
                    postUserId = post.user_id,
                    postUsername = post.username,
                    postType = post.post_type,
                    onDismiss = { showShareDialog = false }
                )
            }
        }
    }
}

@Composable
private fun ResourceBadge(label: String, color: Color) {
    Text(
        text = label,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        color = color,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.1f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

private suspend fun loadVideoThumbnail(urlStr: String): android.graphics.Bitmap? = withContext(Dispatchers.IO) {
    try {
        val mmr = android.media.MediaMetadataRetriever()
        mmr.setDataSource(urlStr, java.util.HashMap())
        val bmp = mmr.frameAtTime
        mmr.release()
        bmp
    } catch (_: Exception) { null }
}

private fun formatTime(ts: Long): String {
    if (ts <= 0) return ""
    val diff = (System.currentTimeMillis() / 1000) - ts
    return when {
        diff < 60 -> "刚刚"
        diff < 3600 -> "${diff / 60}分钟前"
        diff < 86400 -> "${diff / 3600}小时前"
        else -> "${diff / 86400}天前"
    }
}
