package com.aurora.chat.ui.chat

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.compose.runtime.mutableStateOf
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.data.repository.ChatRepository
import com.aurora.chat.ui.viewmodel.ChatViewModel
import com.aurora.chat.ui.chat.ChatMsg
import com.aurora.chat.ui.chat.MessageBubble
import com.aurora.chat.ui.components.AnimationMode
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import org.json.JSONObject

// 缓存时间格式化器，避免每次调用创建新对象
private val TIME_FMT = SimpleDateFormat("HH:mm:ss", Locale.CHINA)
private val DATE_FMT = SimpleDateFormat("MM月dd日 HH:mm:ss", Locale.CHINA)
private val YEAR_FMT = SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss", Locale.CHINA)
private val DAY_NAMES = arrayOf("周日", "周一", "周二", "周三", "周四", "周五", "周六")

@Composable
internal fun MessageBubbleItem(
    msg: IMessageRef,
    loadMedia: Boolean = true,
    myAvatar: android.graphics.Bitmap?,
    currentUserId: Long,
    currentUserName: String = "",
    friendId: Long,
    friendName: String,
    animMode: AnimationMode,
    advancedAnim: Boolean = false,
    isMenuOpen: Boolean = false,
    onMenuOpen: () -> Unit = {},
    onMenuClose: () -> Unit = {},
    onAvatarClick: (userId: Long, userName: String) -> Unit,
    onBadgeClick: (Int) -> Unit = {},
    onDeleteMessage: (Long) -> Unit = {},
    onCopyMessage: (String) -> Unit = {},
    onReplyTo: (IMessageRef) -> Unit = {},
    onEditMessage: ((IMessageRef) -> Unit)? = null,
    clearSelectionKey: Int = 0,
    isHighlighted: Boolean = false,
    onCapsuleClick: (Long) -> Unit = {},
    onAtMention: (String) -> Unit = {},
    onAvatarLongPress: (Long, String) -> Unit = { _, _ -> },
    onAvatarDoubleTap: (Long, String) -> Unit = { _, _ -> },
    onAtMentionClick: (String) -> Unit = {},
    destroyedFlashIds: Set<Long> = emptySet(),
    onFlashDestroy: (Long) -> Unit = {},
    isGroup: Boolean = false,
    groupMemberNames: Set<String> = emptySet(),
    onImageClick: (String) -> Unit = {},
    uploadProgressMap: Map<Long, Float> = emptyMap(),
    onOpenPostDetail: (Long) -> Unit = {},
    onOpenAiChatDetail: (Long) -> Unit = {},
    onOpenGroupDetail: (Long) -> Unit = {},
    onOpenSourceCodeDetail: (Long) -> Unit = {},
    onReasoningToggled: (Boolean) -> Unit = {},
    expandedReasoningMsgId: Long = 0
) {

    val displayName = when {
        msg.isMine && isGroup -> currentUserName.ifEmpty { friendName }
        msg.isMine -> friendName
        isGroup && msg.fromUserId == friendId -> friendName
        isGroup -> msg.senderName.ifEmpty { friendName }
        else -> friendName
    }

    @Composable
    fun BubbleWithMenu() {
        var isSelecting by remember { mutableStateOf(false) }
        val ctx = LocalContext.current
        val prefs = remember { ctx.getSharedPreferences("aurora_select_info", Context.MODE_PRIVATE) }
        var showInfoDialog by remember { mutableStateOf(false) }
        var dontShowAgain by remember { mutableStateOf(false) }

        // 点击空白区域退出选择模式
        LaunchedEffect(clearSelectionKey) {
            if (clearSelectionKey > 0 && isSelecting) {
                isSelecting = false
            }
        }

        if (showInfoDialog) {
            AlertDialog(
                onDismissRequest = { showInfoDialog = false; if (dontShowAgain) prefs.edit().putBoolean("select_info_dismissed", true).apply() },
                containerColor = Color.White,
                title = { Text("关于选择功能", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                text = {
                    Column {
                        Text("由于 Android Compose 框架的限制，SelectionContainer 不支持代码触发的「全选」操作。\n\n您可以通过系统提供的手柄拖拽选择文字范围，选择后使用菜单中的「复制」按钮复制文字。如需全文复制，可在主菜单中直接点击「复制」按钮。", fontSize = 14.sp, color = Color(0xFF374151), lineHeight = 22.sp)
                        Spacer(Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = dontShowAgain, onCheckedChange = { dontShowAgain = it })
                            Spacer(Modifier.width(6.dp))
                            Text("不再显示", fontSize = 14.sp, color = Color(0xFF6B7280))
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showInfoDialog = false
                        if (dontShowAgain) prefs.edit().putBoolean("select_info_dismissed", true).apply()
                    }) { Text("知道了", fontWeight = FontWeight.SemiBold, color = Color(0xFF1E40AF)) }
                }
            )
        }
        MessageBubble(text = msg.text, isMine = msg.isMine, fromUserId = msg.fromUserId, myAvatar = myAvatar, displayName = displayName, showSenderName = isGroup && displayName.isNotEmpty(), onAvatarClick = onAvatarClick, wornBadge = msg.wornBadge, onBadgeClick = onBadgeClick,
        groupConvId = if (isGroup) friendId else 0, currentUserId = currentUserId,
            onBubbleTap = { onMenuClose(); isSelecting = false },
            onBubbleLongPress = { isSelecting = false; onMenuOpen() },
            selectable = isSelecting, replyToText = msg.replyToText, replyToSender = msg.replyToSender,
            replyToId = msg.replyToId, isHighlighted = isHighlighted, onCapsuleClick = onCapsuleClick,
            onAvatarLongPress = onAvatarLongPress,
            onAvatarDoubleTap = onAvatarDoubleTap,
            onAtMentionClick = onAtMentionClick,
            isGroup = isGroup,
            groupMemberNames = groupMemberNames,
            loadMedia = loadMedia,
            mediaType = msg.mediaType,
            mediaUrl = msg.mediaUrl,
            isUploading = msg.isUploading,
            uploadProgress = uploadProgressMap[msg.id] ?: 0f,
            onImageClick = onImageClick,
            flashDuration = msg.flashDuration,
            reasoningText = msg.reasoningText,
            msgId = msg.id,
            onOpenPostDetail = onOpenPostDetail,
            onOpenAiChatDetail = onOpenAiChatDetail,
            onOpenGroupDetail = onOpenGroupDetail,
            onOpenSourceCodeDetail = onOpenSourceCodeDetail,
            destroyedFlashIds = destroyedFlashIds,
            onFlashDestroy = onFlashDestroy,
            onReasoningToggled = onReasoningToggled,
            expandedReasoningMsgId = expandedReasoningMsgId
        )

        // 消息信息弹窗（全界面样式）
        var showMsgInfoDialog by remember { mutableStateOf(false) }
        var msgInfoData by remember { mutableStateOf<JSONObject?>(null) }
        if (showMsgInfoDialog) {
            androidx.compose.ui.window.Dialog(
                onDismissRequest = { showMsgInfoDialog = false },
                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .background(Color.White, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    val info = msgInfoData
                    if (info != null) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // 标题
                            Text("消息信息", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF111827))
                            Spacer(Modifier.height(20.dp))
                            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE5E7EB)))
                            Spacer(Modifier.height(16.dp))

                            fun formatTime(ts: Long): String {
                                if (ts <= 0) return "未知"
                                val calNow = Calendar.getInstance()
                                val calMsg = Calendar.getInstance().apply { timeInMillis = ts }

                                val sameDay = calNow.get(Calendar.YEAR) == calMsg.get(Calendar.YEAR) &&
                                    calNow.get(Calendar.DAY_OF_YEAR) == calMsg.get(Calendar.DAY_OF_YEAR)
                                val isYesterday = {
                                    val y = Calendar.getInstance()
                                    y.add(Calendar.DAY_OF_YEAR, -1)
                                    calMsg.get(Calendar.YEAR) == y.get(Calendar.YEAR) &&
                                        calMsg.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
                                }()
                                val isDayBefore = {
                                    val db = Calendar.getInstance()
                                    db.add(Calendar.DAY_OF_YEAR, -2)
                                    calMsg.get(Calendar.YEAR) == db.get(Calendar.YEAR) &&
                                        calMsg.get(Calendar.DAY_OF_YEAR) == db.get(Calendar.DAY_OF_YEAR)
                                }()

                                val weekDay = calMsg.get(Calendar.DAY_OF_WEEK) - 1
                                val d = java.util.Date(ts)
                                return when {
                                    sameDay -> TIME_FMT.format(d)
                                    isYesterday -> "昨天 ${TIME_FMT.format(d)}"
                                    isDayBefore -> "前天 ${TIME_FMT.format(d)}"
                                    calNow.get(Calendar.WEEK_OF_YEAR) == calMsg.get(Calendar.WEEK_OF_YEAR) &&
                                        calNow.get(Calendar.YEAR) == calMsg.get(Calendar.YEAR) ->
                                        "${DAY_NAMES[weekDay]} ${TIME_FMT.format(d)}"
                                    calNow.get(Calendar.YEAR) == calMsg.get(Calendar.YEAR) ->
                                        DATE_FMT.format(d)
                                    else -> YEAR_FMT.format(d)
                                }
                            }
                            val sentTime = info.optLong("created_at", 0) * 1000L

                            // 发送时间
                            InfoRow(label = "消息发送时间", value = formatTime(sentTime))
                            Spacer(Modifier.height(14.dp))
                            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFF3F4F6)))
                            Spacer(Modifier.height(14.dp))

                            // 到达时间
                            InfoRow(label = "消息到达时间", value = formatTime(sentTime))
                            Spacer(Modifier.height(14.dp))
                            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFF3F4F6)))
                            Spacer(Modifier.height(14.dp))

                            // 已读信息
                            if (info.optInt("read_count", -1) >= 0) {
                                InfoRow(label = "消息已读人数", value = "${info.optInt("read_count", 0)} 人")
                            } else {
                                val readAt = info.optLong("other_read_at", 0) * 1000L
                                val readStatus = if (info.optString("other_read_status", "unread") == "read" && readAt > 0) {
                                    formatTime(readAt)
                                } else {
                                    "对方未读"
                                }
                                InfoRow(label = "对方已读时间", value = readStatus)
                            }

                            Spacer(Modifier.height(20.dp))
                            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE5E7EB)))
                            Spacer(Modifier.height(16.dp))

                            // 关闭按钮
                            TextButton(
                                onClick = { showMsgInfoDialog = false },
                                modifier = Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFF3F4F6))
                            ) {
                                Text("关闭", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                            }
                        }
                    } else {
                        Box(Modifier.padding(32.dp)) {
                            Text("加载中...", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                        }
                    }
                }
            }
        }

        // 长按菜单弹窗（使用 Dialog + 全屏居中覆盖，避免 AlertDialog 在 LazyColumn 中定位异常）
        if (isMenuOpen && !isSelecting) {
            val menuScope = rememberCoroutineScope()
            Dialog(
                onDismissRequest = { onMenuClose() },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color(0x80000000)).clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { onMenuClose() },
                contentAlignment = Alignment.Center
            ) {
            Card(
                modifier = Modifier.widthIn(min = 220.dp, max = 290.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("操作", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                    Column(Modifier.fillMaxWidth()) {
                        // 第一行：修改  复制  选择  引用
                        Row(Modifier.fillMaxWidth().height(48.dp)) {
                            if (onEditMessage != null) {
                                TextButton(onClick = { onEditMessage?.invoke(msg); onMenuClose() }, modifier = Modifier.weight(1f).fillMaxHeight(), contentPadding = PaddingValues(horizontal = 2.dp)) {
                                    Text("修改", fontSize = 13.sp, color = Color(0xFF374151))
                                }
                            }
                            TextButton(onClick = { onCopyMessage(msg.text); onMenuClose() }, modifier = Modifier.weight(1f).fillMaxHeight(), contentPadding = PaddingValues(horizontal = 2.dp)) {
                                Text("复制", fontSize = 13.sp, color = Color(0xFF374151))
                            }
                            TextButton(onClick = { onMenuClose(); if (prefs.getBoolean("select_info_dismissed", false)) { isSelecting = true } else { showInfoDialog = true } }, modifier = Modifier.weight(1f).fillMaxHeight(), contentPadding = PaddingValues(horizontal = 2.dp)) {
                                Text("选择", fontSize = 13.sp, color = Color(0xFF374151))
                            }
                            TextButton(onClick = { onReplyTo(msg); onMenuClose() }, modifier = Modifier.weight(1f).fillMaxHeight(), contentPadding = PaddingValues(horizontal = 2.dp)) {
                                Text("引用", fontSize = 13.sp, color = Color(0xFF374151))
                            }
                        }
                        // 第二行：撤回  信息  删除
                        Row(Modifier.fillMaxWidth().height(48.dp)) {
                            TextButton(
                                onClick = {
                                    menuScope.launch {
                                    if (isLocalChat(friendId)) {
                                        // 个人对话：本地撤回，直接更新 JSON 文件
                                        com.aurora.chat.PendingMessageRecalled.messageId = msg.id
                                        com.aurora.chat.PendingMessageRecalled.senderName = currentUserName
                                        com.aurora.chat.PendingMessageRecalled.hasUpdate = true
                                        ChatViewModel.updateConversationPreview(friendId, "$currentUserName 撤回了一条消息", System.currentTimeMillis() / 1000)
                                        try {
                                            val file = localChatMessagesFile(ctx, currentUserId, localChatKey(friendId))
                                                if (file.exists()) {
                                                    val arr = org.json.JSONArray(file.readText())
                                                    for (i in 0 until arr.length()) {
                                                        if (arr.getJSONObject(i).optLong("id", 0) == msg.id) {
                                                            arr.getJSONObject(i).put("revoked", true); break
                                                        }
                                                    }
                                                    file.writeText(arr.toString())
                                                }
                                            } catch (_: Exception) {}
                                            Toast.makeText(ctx, "已撤回", Toast.LENGTH_SHORT).show()
                                            onMenuClose()
                                            return@launch
                                        }
                                        val result = com.aurora.chat.data.api.AuroraApi.recallMessage(msg.id)
                                        if (result.success) {
                                            Toast.makeText(ctx, "撤回成功", Toast.LENGTH_SHORT).show()
                                            com.aurora.chat.PendingMessageRecalled.messageId = msg.id
                                            com.aurora.chat.PendingMessageRecalled.senderName =
                                                if (msg.isMine) currentUserName else msg.senderName
                                            com.aurora.chat.PendingMessageRecalled.hasUpdate = true
                                            ChatViewModel.updateConversationPreview(friendId, "${if (msg.isMine) currentUserName else msg.senderName} 撤回了一条消息", System.currentTimeMillis() / 1000)
                                            onMenuClose()
                                        } else {
                                            Toast.makeText(ctx, result.message, Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f).fillMaxHeight()
                            ) {
                                Text("撤回", fontSize = 14.sp, color = Color(0xFF374151))
                            }
                            TextButton(
                                onClick = {
                                    menuScope.launch {
                                        val result = com.aurora.chat.data.api.AuroraApi.getMessageInfo(msg.id)
                                        if (result.success) {
                                            msgInfoData = result.data
                                            showMsgInfoDialog = true
                                        } else {
                                            Toast.makeText(ctx, result.message, Toast.LENGTH_SHORT).show()
                                        }
                                        onMenuClose()
                                    }
                                },
                                modifier = Modifier.weight(1f).fillMaxHeight()
                            ) {
                                Text("信息", fontSize = 14.sp, color = Color(0xFF374151))
                            }
                            TextButton(onClick = { onDeleteMessage(msg.id); onMenuClose() }, modifier = Modifier.weight(1f).fillMaxHeight()) {
                                Text("删除", fontSize = 14.sp, color = Color(0xFF374151))
                            }
                        }
                        // 第三行：朗读（朗读中显示「停止」）  @
                        Row(Modifier.fillMaxWidth().height(48.dp)) {
                            val speaking = TtsHelper.isSpeaking.value
                            TextButton(onClick = {
                                if (speaking) {
                                    TtsHelper.stop()
                                } else if (msg.text.isBlank()) {
                                    Toast.makeText(ctx, "没有可朗读的内容", Toast.LENGTH_SHORT).show()
                                } else {
                                    TtsHelper.speak(ctx, msg.text)
                                }
                                onMenuClose()
                            }, modifier = Modifier.weight(1f).fillMaxHeight()) {
                                Text(if (speaking) "停止" else "朗读", fontSize = 14.sp, color = if (speaking) Color(0xFFDC2626) else Color(0xFF374151))
                            }
                        }
                    }
                } // Card
            } // Box (overlay)
        } // Dialog
        }
    }

    Box {
        BubbleWithMenu()
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 13.sp, color = Color(0xFF6B7280))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF111827))
    }
}

// ============ 系统原生 TTS 朗读（长按消息「朗读」按钮调用） ============
// 单例持有 TextToSpeech 实例，懒初始化；朗读前剥离常见 markdown 标记，避免把 **、# 等符号念出来。
object TtsHelper {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var initStarted = false
    private val pending = ArrayDeque<String>()
    // 当前是否正在朗读，供 UI 切换「朗读 / 停止」按钮
    val isSpeaking = mutableStateOf(false)
    private const val UTTERANCE_ID = "aurora_tts"

    fun speak(context: Context, text: String) {
        val content = cleanForTts(text)
        if (content.isBlank()) return
        if (tts == null && !initStarted) {
            initStarted = true
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.CHINA
                    tts?.setSpeechRate(1.0f)
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) { isSpeaking.value = true }
                        override fun onDone(utteranceId: String?) { isSpeaking.value = false }
                        override fun onError(utteranceId: String?) { isSpeaking.value = false }
                    })
                    ready = true
                    // 初始化期间排队的文本现在补播
                    while (pending.isNotEmpty()) {
                        tts?.speak(pending.removeFirst(), TextToSpeech.QUEUE_ADD, null, UTTERANCE_ID)
                    }
                } else {
                    initStarted = false
                    tts = null
                    Toast.makeText(context.applicationContext, "语音引擎不可用，请检查系统 TTS", Toast.LENGTH_SHORT).show()
                }
            }
        }
        if (ready) {
            // QUEUE_FLUSH：朗读新内容前停止上一段
            tts?.speak(content, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
        } else if (initStarted) {
            pending.addLast(content)
        }
    }

    fun stop() {
        tts?.stop()
        isSpeaking.value = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
        initStarted = false
        isSpeaking.value = false
        pending.clear()
    }

    // 去掉 markdown / 链接等会影响朗读体验的符号
    private fun cleanForTts(text: String): String {
        return text
            .replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("`[^`]*`"), " ")
            .replace(Regex("(?m)^\\s{0,3}#{1,6}\\s+"), "")
            .replace(Regex("\\*\\*(.+?)\\*\\*"), "$1")
            .replace(Regex("__(.+?)__"), "$1")
            .replace(Regex("[*_~]"), "")
            .replace(Regex(">\\s?"), "")
            .replace(Regex("!\\[[^\\]]*\\]\\([^)]+\\)"), "")
            .replace(Regex("\\[([^\\]]+)\\]\\([^)]+\\)"), "$1")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}

