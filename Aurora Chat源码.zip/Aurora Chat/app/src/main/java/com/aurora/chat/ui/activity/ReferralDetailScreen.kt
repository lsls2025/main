package com.aurora.chat.ui.activity

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.util.DeviceFingerprintUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

/**
 * 拉新用户 - 激活码详情界面
 * 生成激活码（最多5个）、展示已有码、输入兑换
 */
@Composable
fun ReferralDetailScreen(
    userId: Long,
    onBack: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var myCodes by remember { mutableStateOf<List<MyCodeItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var redeemCodeText by remember { mutableStateOf("") }
    var isRedeeming by remember { mutableStateOf(false) }
    var isGenerating by remember { mutableStateOf(false) }
    var stats by remember { mutableStateOf<Map<String, Any>?>(null) }

    // 加载数据
    fun loadData() {
        scope.launch {
            isLoading = true
            val codesResult = AuroraApi.getMyActivationCodes()
            val statsResult = AuroraApi.getActivityStats()
            if (codesResult.success && codesResult.data != null) {
                val arr = codesResult.data!!
                myCodes = (0 until arr.length()).mapNotNull { i ->
                    try {
                        val json = arr.optJSONObject(i) ?: return@mapNotNull null
                        MyCodeItem(
                            code = json.optString("code", ""),
                            status = json.optString("status", ""),
                            usedByUsername = json.optString("used_by_username", ""),
                            createdAt = json.optLong("created_at", 0)
                        )
                    } catch (_: Exception) { null }
                }
            }
            if (statsResult.success) {
                stats = statsResult.data
            }
            isLoading = false
        }
    }

    fun getIntStat(key: String, default: Int = 0): Int =
        (stats?.get(key) as? Number)?.toInt() ?: default

    LaunchedEffect(Unit) { loadData() }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // 顶栏
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "←",
                    fontSize = 24.sp,
                    color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) { onBack() }
                )
                Spacer(Modifier.weight(1f))
                Text(
                    text = "拉新用户",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937)
                )
                Spacer(Modifier.weight(1f))
                Box(Modifier.width(48.dp))
            }

            // 统计信息条（消费制：最多5个未使用，用掉一个腾一个）
            val invited = (stats?.get("invited_count") as? Number)?.toInt() ?: 0
            val activeCount = (stats?.get("active_count") as? Number)?.toInt() ?: 0
            val totalGenerated = (stats?.get("total_generated") as? Number)?.toInt() ?: 0
            val maxActive = (stats?.get("max_active") as? Number)?.toInt() ?: 5
            val canGenerate = activeCount < maxActive

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF0F4FF))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$invited",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E40AF)
                        )
                        Text("已邀请", fontSize = 12.sp, color = Color(0xFF6B7280))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$activeCount/$maxActive",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E40AF)
                        )
                        Text("未使用", fontSize = 12.sp, color = Color(0xFF6B7280))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$totalGenerated",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E40AF)
                        )
                        Text("累计生成", fontSize = 12.sp, color = Color(0xFF6B7280))
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF1E40AF))
                }
            } else {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp)
                ) {
                    // ===== 我的激活码 =====
                    Text(
                        text = "我的激活码",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )
                    Spacer(Modifier.height(10.dp))

                    // 生成按钮（消费制：用掉一个，位置空出来才能再生成）
                    Button(
                        onClick = {
                            if (!canGenerate) {
                                Toast.makeText(context, "当前已有 $maxActive 个未使用的激活码，等好友使用后再生成", Toast.LENGTH_LONG).show()
                                return@Button
                            }
                            isGenerating = true
                            scope.launch {
                                val result = AuroraApi.generateActivationCode()
                                isGenerating = false
                                if (result.success) {
                                    Toast.makeText(context, "生成成功", Toast.LENGTH_SHORT).show()
                                    loadData()
                                } else {
                                    Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (canGenerate) Color(0xFF1E40AF) else Color(0xFF9CA3AF)
                        ),
                        enabled = !isGenerating
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = if (canGenerate) "生成激活码" else "已满 $activeCount/$maxActive",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // 已有激活码列表
                    if (myCodes.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFF9FAFB)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "点击上方按钮生成激活码",
                                fontSize = 14.sp,
                                color = Color(0xFF9CA3AF)
                            )
                        }
                    } else {
                        myCodes.forEach { item ->
                            CodeCard(
                                code = item.code,
                                status = item.status,
                                usedBy = item.usedByUsername,
                                onCopy = {
                                    clipboard.setText(AnnotatedString(item.code))
                                    Toast.makeText(context, "已复制到剪贴板", Toast.LENGTH_SHORT).show()
                                }
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                    }

                    Spacer(Modifier.height(24.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE5E7EB)))
                    Spacer(Modifier.height(24.dp))

                    // ===== 兑换激活码 =====
                    Text(
                        text = "兑换激活码",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "输入好友分享的激活码，完成兑换",
                        fontSize = 13.sp,
                        color = Color(0xFF6B7280)
                    )
                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = redeemCodeText,
                        onValueChange = {
                            if (it.length <= 20) redeemCodeText = it.uppercase()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("输入激活码，如 AURORA-XXXX-XXXX") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Characters,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                // 触发兑换
                            }
                        )
                    )

                    Spacer(Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (redeemCodeText.isBlank()) {
                                Toast.makeText(context, "请输入激活码", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isRedeeming = true
                            scope.launch {
                                val fp = withContext(Dispatchers.IO) {
                                    DeviceFingerprintUtil.collect(context)
                                }
                                val appInstallSec = withContext(Dispatchers.IO) {
                                    DeviceFingerprintUtil.getAppInstallSeconds(context)
                                }
                                val result = AuroraApi.redeemActivationCode(
                                    code = redeemCodeText.trim(),
                                    deviceFingerprint = fp.fingerprintHash,
                                    deviceInfo = fp.deviceInfoJson,
                                    isEmulator = DeviceFingerprintUtil.isEmulator(),
                                    appInstallSeconds = appInstallSec
                                )
                                isRedeeming = false
                                if (result.success) {
                                    Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                                    redeemCodeText = ""
                                    loadData()
                                } else {
                                    Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1E40AF)
                        ),
                        enabled = !isRedeeming
                    ) {
                        if (isRedeeming) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "立即兑换",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(Modifier.height(24.dp))

                    // 使用说明
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFFFF7ED))
                            .border(
                                width = 1.dp,
                                color = Color(0xFFFDE68A),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Column {
                            Text(
                                text = "使用说明",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E)
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "使用说明\n" +
                                        "  消费制：最多5个未使用的激活码同时在手\n" +
                                        "  用掉一个空出一个位置，可继续生成\n" +
                                        "  真实拉新用户，永远不会被卡住\n" +
                                        "\n" +
                                        "  拉一个新用户给10元现金\n" +
                                        "\n" +
                                        "  每个激活码仅限使用一次\n" +
                                        "  不能使用自己的激活码\n" +
                                        "  同一台设备只能绑定一个账号\n" +
                                        "  禁止模拟器环境使用\n" +
                                        "\n" +
                                        "  如有疑问请联系管理员",
                                fontSize = 12.sp,
                                color = Color(0xFF92400E),
                                lineHeight = 20.sp
                            )
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
}

/**
 * 激活码卡片
 */
@Composable
private fun CodeCard(
    code: String,
    status: String,
    usedBy: String,
    onCopy: () -> Unit
) {
    val bgColor = if (status == "active") Color(0xFFF0FDF4) else Color(0xFFF3F4F6)
    val borderColor = if (status == "active") Color(0xFF86EFAC) else Color(0xFFD1D5DB)
    val codeColor = if (status == "active") Color(0xFF166534) else Color(0xFF6B7280)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(width = 1.dp, color = borderColor, shape = RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = code,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = codeColor,
                    letterSpacing = 1.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = when (status) {
                        "active" -> "● 有效"
                        "used" -> "● 已使用 by $usedBy"
                        else -> "● $status"
                    },
                    fontSize = 11.sp,
                    color = if (status == "active") Color(0xFF16A34A) else Color(0xFF6B7280)
                )
            }
            // 复制按钮
            if (status == "active") {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1E40AF).copy(alpha = 0.1f))
                        .clickable { onCopy() }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "复制",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1E40AF)
                    )
                }
            }
        }
    }
}

/**
 * 我的激活码列表项（本地模型）
 */
data class MyCodeItem(
    val code: String,
    val status: String,
    val usedByUsername: String,
    val createdAt: Long
)
