package com.aurora.chat.ui.profile

import android.Manifest
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.aurora.chat.R
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.ui.components.BadgeResources
import com.aurora.chat.data.repository.ChatRepository
import com.aurora.chat.ui.components.BadgeInfoDialog
import com.aurora.chat.ui.components.EventBlocker
import com.aurora.chat.ui.activity.ActivityScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicLong

// ==================== 佩戴徽章辅助 ====================

// ==================== 在线时间追踪器（永不重置版） ====================
// 原理：serverBase（服务端/本地最大值） + 本次会话已过秒数
// 启动时从本地 + 服务端取最大值作为基线，防止任何一方数据丢失

object OnlineTimeTracker {
    private const val PREFS = "aurora_online_time"
    private const val KEY_TOTAL_SECONDS = "total_seconds"

    private var serverBase = 0L          // 基线（取本地与服务端的最大值）
    private var sessionStartMs = AtomicLong(0L)
    private var isRunning = false

    fun isRunning(): Boolean = isRunning

    /** 从本地 SharedPreferences 恢复上次保存的总值 */
    fun restoreFromPrefs(context: Context): Long {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_TOTAL_SECONDS, 0L)
        if (saved > serverBase) serverBase = saved
        return serverBase
    }

    /** 设置服务端基线，只接受更大的值（防止旧数据覆写新数据） */
    fun setServerBase(seconds: Long) {
        if (seconds > serverBase) serverBase = seconds
    }

    /** 启动计时（恢复本地 + 返回当前基线） */
    fun start(context: Context): Long {
        restoreFromPrefs(context)
        sessionStartMs.set(System.currentTimeMillis())
        isRunning = true
        return serverBase
    }

    /** 停止计时并持久化 */
    fun stop(context: Context) {
        if (!isRunning) return
        flushToPrefsNow(context)
        isRunning = false
    }

    /** 获取当前总秒数 */
    fun getCurrentTotalSeconds(context: Context): Long {
        if (!isRunning) return serverBase
        flushIfNeeded(context)
        val elapsed = (System.currentTimeMillis() - sessionStartMs.get()) / 1000
        return serverBase + elapsed
    }

    /** 持久化当前总值到本地 */
    private var lastFlush = 0L
    private fun flushToPrefsNow(context: Context) {
        lastFlush = System.currentTimeMillis()
        val total = if (isRunning) {
            serverBase + (System.currentTimeMillis() - sessionStartMs.get()) / 1000
        } else {
            serverBase
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putLong(KEY_TOTAL_SECONDS, total).apply()
    }

    /** 每 60 秒自动持久化（由 getCurrentTotalSeconds 调用） */
    private fun flushIfNeeded(context: Context) {
        val now = System.currentTimeMillis()
        if (now - lastFlush < 60000L) return
        flushToPrefsNow(context)
    }
}

// ==================== 发言字数追踪器（本地累计 + 服务端基线） ====================

object WordCountTracker {
    private const val PREFS = "aurora_word_count"
    private const val KEY_LOCAL_DELTA = "local_delta"

    private var serverBase = 0L    // 服务端累计值
    private var localDelta = 0L    // 上次同步后本地新增

    fun setServerBase(count: Long) {
        serverBase = count
    }

    fun addChars(context: Context, count: Int) {
        if (count <= 0) return
        localDelta += count
    }

    fun getTotal(): Long = serverBase + localDelta

    /** 供 ProfileScreen 定时同步时获取应上传的值 */
    fun computeSyncValue(): Long = serverBase + localDelta

    fun markSynced(context: Context) {
        serverBase += localDelta
        localDelta = 0
    }
}

// ==================== 格式化工具 ====================

private fun formatOnlineTime(totalSeconds: Long): String {
    val days = totalSeconds / 86400
    val hours = (totalSeconds % 86400) / 3600
    val minutes = (totalSeconds % 3600) / 60
    return when {
        days > 0 -> "${days}天${hours}小时"
        hours > 0 -> "${hours}小时${minutes}分"
        else -> "${minutes}分钟"
    }
}

private fun formatDaysOnPlatform(createdAtSeconds: Long): String {
    if (createdAtSeconds <= 0) return "新用户"
    val days = (System.currentTimeMillis() / 1000 - createdAtSeconds) / 86400
    return when {
        days < 1 -> "今天加入"
        days < 30 -> "${days}天"
        days < 365 -> "${days / 30}个月"
        else -> "${days / 365}年${(days % 365) / 30}个月"
    }
}


// ==================== 主界面 ====================

@Composable
fun ProfileScreen(
    userId: Long = 0,
    onSwitchAccount: () -> Unit = {},
    onLogout: () -> Unit = {},
    isDeveloper: Boolean = false,
    onDeveloperManagementClick: () -> Unit = {},
    activityScreenOpen: Boolean = false,
    onActivityScreenOpenChange: (Boolean) -> Unit = {},
    // 二维码入口：点击后在 MainActivity 根级打开"我的二维码"，避免内部覆盖层被压缩/事件穿透
    onShowMyQr: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var avatarBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showSourceDialog by remember { mutableStateOf(false) }
    var cropImageUri by remember { mutableStateOf<Uri?>(null) }
    var showCrop by remember { mutableStateOf(false) }
    var cameraPhotoUri by remember { mutableStateOf<Uri?>(null) }

    var userName by remember { mutableStateOf("") }
    var userSignature by remember { mutableStateOf("") }
    var userCreatedAt by remember { mutableStateOf(0L) }
    var userWornBadge by remember { mutableIntStateOf(0) }
    var showNameDialog by remember { mutableStateOf(false) }
    var showSignatureDialog by remember { mutableStateOf(false) }
    var editNameText by remember { mutableStateOf("") }
    var editSignatureText by remember { mutableStateOf("") }
    var badgeDialogId by remember { mutableStateOf(0) }

    // 在线时间
    var onlineTimeSec by remember { mutableStateOf(OnlineTimeTracker.restoreFromPrefs(context)) }
    var serverDataReady by remember { mutableStateOf(false) }
    var showTimeDetail by remember { mutableStateOf(false) }
    var showPlatformDetail by remember { mutableStateOf(false) }
    var userEmailVerified by remember { mutableStateOf(com.aurora.chat.data.api.AuroraApi.currentUserEmailVerified) }

    // userId 变化时重新拉取服务器资料 + 头像 + 在线时间基线
    LaunchedEffect(userId) {
        withContext(Dispatchers.IO) {
            try {
                val info = ChatRepository.getUserInfo(userId)
                if (info.success && info.data != null) {
                    userName = info.data!!.username
                    userSignature = info.data!!.signature
                    userWornBadge = info.data!!.wornBadge
                    userCreatedAt = info.data!!.createdAt
                    userEmailVerified = info.data!!.emailVerified
                    // 设置服务端累计值为基线
                    OnlineTimeTracker.setServerBase(info.data!!.onlineTimeSeconds)
                    com.aurora.chat.data.local.LocalStorage.saveUserProfile(
                        context, userId, userName, userSignature
                    )
                } else {
                    userName = com.aurora.chat.data.local.LocalStorage.getUserName(context, userId)
                    userSignature = com.aurora.chat.data.local.LocalStorage.getUserSignature(context, userId)
                }
            } catch (_: Exception) {
                userName = com.aurora.chat.data.local.LocalStorage.getUserName(context, userId)
                userSignature = com.aurora.chat.data.local.LocalStorage.getUserSignature(context, userId)
            }
            val avatarFile = com.aurora.chat.data.local.LocalStorage.getMyAvatarFile(context, userId)
            if (avatarFile.exists()) {
                avatarBitmap = BitmapFactory.decodeFile(avatarFile.absolutePath)
            } else {
                try {
                    val bmp = ChatRepository.loadAvatar(context, userId)
                    if (bmp != null) avatarBitmap = bmp
                } catch (_: Exception) {}
            }
        }
        // 服务端数据加载完成后启动追踪
        OnlineTimeTracker.start(context)
        serverDataReady = true
    }

    // 计时器（每秒刷新，每60秒同步到服务端）
    LaunchedEffect(Unit) {
        var syncCounter = 0
        while (true) {
            delay(1000)
            if (serverDataReady) {
                onlineTimeSec = OnlineTimeTracker.getCurrentTotalSeconds(context)
                syncCounter++
                if (syncCounter >= 15) { // 每15秒同步一次在线时间
                    syncCounter = 0
                    withContext(Dispatchers.IO) {
                        try {
                            val ot = OnlineTimeTracker.getCurrentTotalSeconds(context)
                            AuroraApi.syncUserStats(ot, 0)
                        } catch (_: Exception) {}
                    }
                }
            }
        }
    }

    fun saveName(name: String) {
        scope.launch {
            try {
                val result = AuroraApi.updateProfile(name, userSignature)
                if (result.success) {
                    com.aurora.chat.data.local.LocalStorage.saveUserProfile(context, userId, name, userSignature)
                    userName = name
                } else {
                    Toast.makeText(context, "昵称保存失败: ${result.message}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "昵称保存失败: ${e.localizedMessage ?: "网络错误"}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    fun saveSignature(sig: String) {
        scope.launch {
            try {
                val result = AuroraApi.updateSignature(sig)
                if (result.success) {
                    com.aurora.chat.data.local.LocalStorage.saveUserProfile(context, userId, userName, sig)
                    userSignature = sig
                } else {
                    Toast.makeText(context, "签名保存失败: ${result.message}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "签名保存失败: ${e.localizedMessage ?: "网络错误"}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { cropImageUri = it; showCrop = true }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success: Boolean ->
        if (success && cameraPhotoUri != null) { cropImageUri = cameraPhotoUri; showCrop = true }
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { val uri = createTempImageUri(context); cameraPhotoUri = uri; cameraLauncher.launch(uri) }
        else { Toast.makeText(context, "需要相机权限才能拍照", Toast.LENGTH_SHORT).show() }
    }
    val storagePermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { galleryLauncher.launch("image/*") }
        else { Toast.makeText(context, "需要存储权限才能选择图片", Toast.LENGTH_SHORT).show() }
    }

    // ── 绑定邮箱弹窗 ──
    var showBindEmailDialog by remember { mutableStateOf(false) }
    if (showBindEmailDialog) {
        BindEmailDialog(
            onDismiss = { showBindEmailDialog = false },
            onBound = {
                showBindEmailDialog = false
                Toast.makeText(context, "邮箱绑定成功，功能已解锁", Toast.LENGTH_SHORT).show()
            }
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
        // ==================== 头像 + 昵称/ID/签名 ====================
        Row(
            modifier = Modifier.fillMaxWidth().height(80.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFD1D5DB))
                    .clickable { showSourceDialog = true },
                contentAlignment = Alignment.Center
            ) {
                if (avatarBitmap != null) {
                    Image(
                        bitmap = avatarBitmap!!.asImageBitmap(),
                        contentDescription = "头像",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Image(
                        painter = painterResource(R.drawable.ic_profile),
                        contentDescription = "默认头像",
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        contentScale = ContentScale.Fit
                    )
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.CenterStart) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = userName.ifEmpty { "未设置昵称" },
                            fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937),
                            modifier = Modifier.clickable { editNameText = userName; showNameDialog = true }
                        )
                        // 佩戴的徽章（名字右边，来自服务端）
                        if (userWornBadge in 1..BadgeResources.allBadgeResIds.size) {
                            Spacer(Modifier.width(6.dp))
                            val badgeIndex = userWornBadge - 1
                            val badgeHeight = if (badgeIndex == 3 || badgeIndex == 4 || badgeIndex == 9) 24.dp else 20.dp
                            Image(
                                painter = painterResource(id = BadgeResources.allBadgeResIds[badgeIndex]),
                                contentDescription = "佩戴的徽章",
                                modifier = Modifier.height(badgeHeight).clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() }
                                ) { badgeDialogId = userWornBadge },
                                contentScale = ContentScale.FillHeight
                            )
                        }
                    }
                }
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.CenterStart) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "ID: $userId", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                        Spacer(Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFEFF4FF))
                                .clickable { onShowMyQr() }
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "二维码",
                                fontSize = 12.sp,
                                color = Color(0xFF2563EB),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.CenterStart) {
                    Text(
                        text = userSignature.ifEmpty { "这个人很懒，什么都没写…" },
                        fontSize = 14.sp, color = Color(0xFF6B7280),
                        modifier = Modifier.clickable { editSignatureText = userSignature; showSignatureDialog = true }
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // ==================== 中间大胶囊体统计 ====================
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFFF0F4FF))
                .border(
                    width = 1.dp,
                    color = Color(0xFFD6E4FF),
                    shape = RoundedCornerShape(20.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 在线时间（点击弹出详情）
                StatItem(
                    value = formatOnlineTime(onlineTimeSec),
                    label = "在线时间",
                    onClick = { showTimeDetail = true }
                )
                // 分隔线
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(50.dp)
                        .background(Color(0xFFD6E4FF))
                )
                // 在平台（点击弹出注册详情）
                StatItem(
                    value = formatDaysOnPlatform(userCreatedAt),
                    label = "在平台",
                    onClick = { showPlatformDetail = true }
                )
                // 分隔线
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(50.dp)
                        .background(Color(0xFFD6E4FF))
                )
                // 活动（点击进入活动中心）
                StatItem(
                    value = "活动",
                    label = "拉新有奖",
                    onClick = { onActivityScreenOpenChange(true) }
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ==================== 切换账号 + 退出登录 ====================
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 切换账号
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF3F4F6))
                    .clickable { onSwitchAccount() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "切换账号",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1F2937)
                )
            }
            // 退出登录
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF3F4F6))
                    .clickable { onLogout() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "退出登录",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1F2937)
                )
            }
        }

        // ── 开发者/管理员入口 ──
        if (isDeveloper) {
            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF0F4FF))
                    .clickable { onDeveloperManagementClick() }
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1E40AF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(20.dp)) {
                            val cx = size.width / 2
                            val cy = size.height / 2
                            val outerR = size.width / 2
                            val innerR = outerR * 0.52f
                            val teethCount = 8
                            val teethLen = outerR * 0.18f

                            // 齿轮外圈齿
                            val gearPath = Path()
                            for (i in 0 until teethCount) {
                                val angle = (i * 360f / teethCount - 90f) * (Math.PI / 180).toFloat()
                                val halfTooth = (360f / teethCount / 2f) * (Math.PI / 180).toFloat()
                                val r1 = outerR
                                val r2 = outerR + teethLen
                                // 绘制每个齿
                                val x1 = cx + r1 * kotlin.math.cos(angle - halfTooth * 0.6f)
                                val y1 = cy + r1 * kotlin.math.sin(angle - halfTooth * 0.6f)
                                val x2 = cx + r2 * kotlin.math.cos(angle - halfTooth * 0.3f)
                                val y2 = cy + r2 * kotlin.math.sin(angle - halfTooth * 0.3f)
                                val x3 = cx + r2 * kotlin.math.cos(angle + halfTooth * 0.3f)
                                val y3 = cy + r2 * kotlin.math.sin(angle + halfTooth * 0.3f)
                                val x4 = cx + r1 * kotlin.math.cos(angle + halfTooth * 0.6f)
                                val y4 = cy + r1 * kotlin.math.sin(angle + halfTooth * 0.6f)
                                if (i == 0) gearPath.moveTo(x1, y1)
                                gearPath.lineTo(x2, y2)
                                gearPath.lineTo(x3, y3)
                                gearPath.lineTo(x4, y4)
                            }
                            gearPath.close()
                            drawPath(gearPath, Color.White)
                            // 中心圆
                            drawCircle(Color(0xFF1E40AF), innerR, center = Offset(cx, cy))
                            // 中心小圆
                            drawCircle(Color.White, innerR * 0.42f, center = Offset(cx, cy))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "开发者管理",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1F2937)
                        )
                        Text(
                            "Aurora Chat 后台",
                            fontSize = 11.sp,
                            color = Color(0xFF6B7280)
                        )
                    }
                    Text("›", fontSize = 20.sp, color = Color(0xFF9CA3AF))
                }
            }
        }
    }

    // ==================== 在线时间详情（Dialog 全屏） ====================
    if (showTimeDetail) {
        Dialog(
            onDismissRequest = { showTimeDetail = false },
            properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
        ) {
            OnlineTimeDetailPanel(
                totalSeconds = onlineTimeSec,
                onBack = { showTimeDetail = false }
            )
        }
    }

    // ==================== 在平台详情（Dialog 全屏） ====================
    if (showPlatformDetail) {
        Dialog(
            onDismissRequest = { showPlatformDetail = false },
            properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
        ) {
            PlatformDetailPanel(
                createdAtSeconds = userCreatedAt,
                onBack = { showPlatformDetail = false }
            )
        }
    }

    }

    // ==================== 弹窗 ====================

    if (showSourceDialog) {
        Dialog(onDismissRequest = { showSourceDialog = false }) {
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(24.dp)) {
                Text("选择头像", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.height(20.dp))
                Text("相册上传", fontSize = 16.sp, color = Color(0xFF1F2937),
                    modifier = Modifier.fillMaxWidth().clickable {
                        showSourceDialog = false
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            if (context.checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == android.content.pm.PackageManager.PERMISSION_GRANTED)
                                galleryLauncher.launch("image/*")
                            else storagePermissionLauncher.launch(Manifest.permission.READ_MEDIA_IMAGES)
                        } else { galleryLauncher.launch("image/*") }
                    }.padding(vertical = 12.dp))
                Spacer(Modifier.height(8.dp))
                Text("拍照上传", fontSize = 16.sp, color = Color(0xFF1F2937),
                    modifier = Modifier.fillMaxWidth().clickable {
                        showSourceDialog = false
                        if (context.checkSelfPermission(Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            val uri = createTempImageUri(context); cameraPhotoUri = uri; cameraLauncher.launch(uri)
                        } else { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) }
                    }.padding(vertical = 12.dp))
            }
        }
    }

    if (showCrop && cropImageUri != null) {
        CropPreviewDialog(
            imageUri = cropImageUri!!, context = context,
            onCropConfirm = { cropped ->
                avatarBitmap = cropped; showCrop = false; cropImageUri = null
                scope.launch {
                    withContext(Dispatchers.IO) {
                        try {
                            val file = com.aurora.chat.data.local.LocalStorage.getMyAvatarFile(context, userId)
                            file.parentFile?.mkdirs()
                            FileOutputStream(file).use { out -> cropped.compress(Bitmap.CompressFormat.PNG, 100, out) }
                            val serverOk = ChatRepository.uploadAvatarBitmap(context, cropped)
                            if (!serverOk) { withContext(Dispatchers.Main) { Toast.makeText(context, "头像上传失败，本地已保存", Toast.LENGTH_SHORT).show() } }
                        } catch (e: Exception) { withContext(Dispatchers.Main) { Toast.makeText(context, "保存失败: ${e.message}", Toast.LENGTH_SHORT).show() } }
                    }
                }
            },
            onDismiss = { showCrop = false; cropImageUri = null }
        )
    }

    if (showNameDialog) {
        Dialog(onDismissRequest = { showNameDialog = false }) {
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(24.dp)) {
                Text("修改昵称", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937)); Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = editNameText, onValueChange = { editNameText = it }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { showNameDialog = false }) { Text("取消") }; Spacer(Modifier.width(8.dp))
                    Button(onClick = { userName = editNameText; saveName(editNameText); showNameDialog = false }) { Text("保存") }
                }
            }
        }
    }
    if (showSignatureDialog) {
        Dialog(onDismissRequest = { showSignatureDialog = false }) {
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(24.dp)) {
                Text("修改签名", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937)); Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = editSignatureText, onValueChange = { if (it.length <= 30) editSignatureText = it }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Text("${editSignatureText.length}/30", fontSize = 12.sp, color = if (editSignatureText.length > 25) Color(0xFFD97706) else Color(0xFF9CA3AF), modifier = Modifier.fillMaxWidth().padding(end = 4.dp), textAlign = TextAlign.End)
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { showSignatureDialog = false }) { Text("取消") }; Spacer(Modifier.width(8.dp))
                    Button(onClick = { userSignature = editSignatureText; saveSignature(editSignatureText); showSignatureDialog = false }) { Text("保存") }
                }
            }
        }
    }

    // 徽章点击弹窗
    if (badgeDialogId > 0) {
        BadgeInfoDialog(badgeId = badgeDialogId, onDismiss = { badgeDialogId = 0 })
    }

    // ==================== 活动中心入口 ====================
    // 活动中心改由 MainActivity 统一渲染（showActivity），此处不再重复渲染

    // ==================== 我的二维码 / 扫一扫 / 用户资料 ====================
    // 已提升到 MainActivity 根级渲染（onShowMyQr），彻底解决内部覆盖层被压缩与事件穿透问题
}

// ==================== 胶囊体内单项统计 ====================

@Composable
private fun StatItem(value: String, label: String, onClick: (() -> Unit)? = null) {
    val intSrc = remember { MutableInteractionSource() }
    val mod = if (onClick != null) Modifier.clickable(interactionSource = intSrc, indication = null) { onClick() } else Modifier
    Column(
        modifier = mod,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1E40AF)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color(0xFF6B7280)
        )
    }
}

// ===================== 裁剪预览弹窗 =====================

@Composable
fun CropPreviewDialog(
    imageUri: android.net.Uri, context: Context,
    onCropConfirm: (Bitmap) -> Unit, onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    CropPreviewDialogContent(imageUri = imageUri, context = context, scope = scope, onCropConfirm = onCropConfirm, onDismiss = onDismiss)
}

@Composable
private fun CropPreviewDialogContent(
    imageUri: android.net.Uri, context: Context, scope: kotlinx.coroutines.CoroutineScope,
    onCropConfirm: (Bitmap) -> Unit, onDismiss: () -> Unit
) {
    var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(imageUri) {
        withContext(Dispatchers.IO) {
            try {
                val inputStream = context.contentResolver.openInputStream(imageUri)
                sourceBitmap = BitmapFactory.decodeStream(inputStream); inputStream?.close()
            } catch (_: Exception) {}
        }
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var screenW by remember { mutableFloatStateOf(1080f) }
    var screenH by remember { mutableFloatStateOf(2100f) }
    var initialized by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            sourceBitmap?.let { bmp ->
                val fitScale = minOf(screenW / bmp.width.toFloat(), screenH / bmp.height.toFloat())
                val imgScrW = bmp.width.toFloat() * fitScale
                val imgScrH = bmp.height.toFloat() * fitScale
                val cropSize = minOf(screenW, screenH) * 0.7f
                val cropL = (screenW - cropSize) / 2f
                val cropT = (screenH - cropSize) / 2f
                if (!initialized) {
                    scale = minOf(screenW / imgScrW, screenH / imgScrH) * 0.85f
                    offsetX = 0f; offsetY = 0f; initialized = true
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .onSizeChanged { screenW = it.width.toFloat(); screenH = it.height.toFloat() }
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(0.3f, 5f)
                                offsetX += pan.x
                                offsetY += pan.y
                            }
                        }
                ) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "裁剪",
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = scale; scaleY = scale
                                translationX = offsetX; translationY = offsetY
                            },
                        contentScale = ContentScale.Fit,
                        alpha = 0.6f
                    )
                }

                // 裁剪框遮罩
                Canvas(Modifier.fillMaxSize()) {
                    val cr = 24.dp.toPx()
                    val outer = Path().apply { addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height)) }
                    val inner = Path().apply { addRoundRect(androidx.compose.ui.geometry.RoundRect(
                        androidx.compose.ui.geometry.Rect(cropL, cropT, cropL + cropSize, cropT + cropSize),
                        androidx.compose.ui.geometry.CornerRadius(cr)
                    )) }
                    val mask = Path().apply { op(outer, inner, PathOperation.Difference) }
                    drawPath(mask, Color.Black.copy(alpha = 0.55f))
                    drawRoundRect(
                        Color.White,
                        androidx.compose.ui.geometry.Offset(cropL, cropT),
                        androidx.compose.ui.geometry.Size(cropSize, cropSize),
                        androidx.compose.ui.geometry.CornerRadius(cr),
                        style = Stroke(2.dp.toPx())
                    )
                }

                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Button(
                        onClick = {
                            val cx = screenW / 2f + offsetX; val cy = screenH / 2f + offsetY
                            val iL = cx - imgScrW * scale / 2f; val iT = cy - imgScrH * scale / 2f
                            val cropRelX = (cropL - iL) / (imgScrW * scale)
                            val cropRelY = (cropT - iT) / (imgScrH * scale)
                            val bx = (cropRelX * bmp.width).toInt().coerceIn(0, bmp.width - 1)
                            val by = (cropRelY * bmp.height).toInt().coerceIn(0, bmp.height - 1)
                            val bSz = ((cropSize / (imgScrW * scale)) * bmp.width).toInt().coerceIn(1, minOf(bmp.width - bx, bmp.height - by))
                            val cropped = try { Bitmap.createBitmap(bmp, bx, by, bSz, bSz) } catch (_: Exception) { null }
                            if (cropped != null) onCropConfirm(cropped) else onCropConfirm(bmp)
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF))
                    ) {
                        Text("确认裁剪", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = onDismiss) {
                        Text("取消", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                    }
                }
            } ?: run {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("加载图片中...", color = Color.White, fontSize = 16.sp)
                }
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp)
                ) {
                    Text("取消", color = Color(0xFF9CA3AF))
                }
            }
        }
    }
}

fun createTempImageUri(context: Context): android.net.Uri {
    val dir = File(context.cacheDir, "camera_photos"); if (!dir.exists()) dir.mkdirs()
    val file = File(dir, "avatar_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

// ==================== 在线时间详情面板 ====================

@Composable
private fun OnlineTimeDetailPanel(totalSeconds: Long, onBack: () -> Unit) {
    val entries = buildTimeEntries(totalSeconds)

    Box(Modifier.fillMaxSize().background(Color.White)) {
        // 事件拦截：防止点击穿透
        EventBlocker()

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 顶栏
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "←",
                    fontSize = 24.sp,
                    color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onBack() }
                )
                Spacer(Modifier.weight(1f))
                Text(
                    text = "在线时间",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937)
                )
                Spacer(Modifier.weight(1f))
                Box(Modifier.width(48.dp))
            }

            Spacer(Modifier.height(16.dp))

            // 各时间单位行
            entries.forEach { (displayText, fontSize) ->
                Text(
                    text = displayText,
                    fontSize = fontSize,
                    fontWeight = if (fontSize >= 24.sp) FontWeight.Bold else FontWeight.Medium,
                    color = Color(0xFF1F2937),
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
        }
    }
}

// ==================== 时间条目生成 ====================

private data class TimeEntry(val value: String, val unit: String)

private fun buildTimeEntries(totalSeconds: Long): List<Pair<String, androidx.compose.ui.unit.TextUnit>> {
    val s = totalSeconds.toDouble()
    val m = s / 60.0
    val h = s / 3600.0
    val d = s / 86400.0
    val mo = s / (86400.0 * 30.4375)
    val y = s / (86400.0 * 365.25)

    return listOf(
        "${fmt(s)} 秒" to 26.sp,
        "${fmt(m)} 分钟" to 22.sp,
        "${fmt(h)} 小时" to 18.sp,
        "${fmt(d)} 天" to 16.sp,
        "${fmt(mo)} 月" to 14.sp,
        "${fmt(y)} 年" to 13.sp,
    )
}

private fun fmt(value: Double): String {
    if (value == 0.0) return "0"
    if (value == value.toLong().toDouble()) return value.toLong().toString()
    return String.format("%.10f", value).trimEnd('0').trimEnd('.')
}

// ==================== 在平台详情面板 ====================

@Composable
private fun PlatformDetailPanel(createdAtSeconds: Long, onBack: () -> Unit) {
    val regDate = remember(createdAtSeconds) {
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = createdAtSeconds * 1000 }
        "${cal.get(java.util.Calendar.YEAR)}年${cal.get(java.util.Calendar.MONTH) + 1}月${cal.get(java.util.Calendar.DAY_OF_MONTH)}日" +
            "${cal.get(java.util.Calendar.HOUR_OF_DAY)}时${cal.get(java.util.Calendar.MINUTE)}分${cal.get(java.util.Calendar.SECOND)}秒"
    }

    // 每秒刷新的当前时间
    var currentTimeStr by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            val cal = java.util.Calendar.getInstance()
            currentTimeStr = "${cal.get(java.util.Calendar.YEAR)}年${cal.get(java.util.Calendar.MONTH) + 1}月${cal.get(java.util.Calendar.DAY_OF_MONTH)}日" +
                "${cal.get(java.util.Calendar.HOUR_OF_DAY)}时${cal.get(java.util.Calendar.MINUTE)}分${cal.get(java.util.Calendar.SECOND)}秒"
        }
    }

    // 每秒刷新的"已在平台"累积时长（精确到秒）
    var sinceRegStr by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            val diff = System.currentTimeMillis() / 1000 - createdAtSeconds
            val y = diff / 31536000
            val mo = (diff % 31536000) / 2592000
            val d = (diff % 2592000) / 86400
            val h = (diff % 86400) / 3600
            val mi = (diff % 3600) / 60
            val s = diff % 60
            sinceRegStr = "${y}年${mo}个月${d}日${h}时${mi}分${s}秒"
        }
    }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        EventBlocker()
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("←", fontSize = 24.sp, color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onBack() })
                Spacer(Modifier.weight(1f))
                Text("在平台", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.weight(1f))
                Box(Modifier.width(48.dp))
            }

            Spacer(Modifier.height(24.dp))

            Text("注册时间", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF6B7280))
            Spacer(Modifier.height(6.dp))
            Text(regDate, fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(Modifier.height(14.dp))
            Text("注册了此账号", fontSize = 16.sp, color = Color(0xFF1F2937))

            Spacer(Modifier.height(28.dp))
            Box(Modifier.fillMaxWidth(0.8f).height(1.dp).background(Color(0xFFE5E7EB)))
            Spacer(Modifier.height(28.dp))

            Text("距现在", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF6B7280))
            Spacer(Modifier.height(6.dp))
            Text(currentTimeStr, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))

            Spacer(Modifier.height(28.dp))
            Box(Modifier.fillMaxWidth(0.8f).height(1.dp).background(Color(0xFFE5E7EB)))
            Spacer(Modifier.height(28.dp))

            Text("已在平台", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF6B7280))
            Spacer(Modifier.height(6.dp))
            Text(sinceRegStr, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        }
    }
}

// ==================== 绑定邮箱弹窗 ====================

@Composable
private fun BindEmailDialog(onDismiss: () -> Unit, onBound: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var isSendingCode by remember { mutableStateOf(false) }
    var codeCountdown by remember { mutableStateOf(0) }
    var binding by remember { mutableStateOf(false) }

    LaunchedEffect(codeCountdown) {
        if (codeCountdown > 0) {
            kotlinx.coroutines.delay(1000)
            codeCountdown--
        }
    }

    fun sendCode() {
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(ctx, "邮箱格式不正确", Toast.LENGTH_SHORT).show(); return
        }
        isSendingCode = true
        scope.launch {
            val result = com.aurora.chat.data.api.AuroraApi.sendBindCode(email)
            isSendingCode = false
            if (result.success) {
                Toast.makeText(ctx, "验证码已发送", Toast.LENGTH_SHORT).show()
                codeCountdown = 60
            } else {
                Toast.makeText(ctx, result.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun bind() {
        if (email.isBlank() || code.isBlank()) {
            Toast.makeText(ctx, "请填写邮箱和验证码", Toast.LENGTH_SHORT).show(); return
        }
        binding = true
        scope.launch {
            val result = com.aurora.chat.data.api.AuroraApi.bindEmail(email, code)
            binding = false
            if (result.success) {
                com.aurora.chat.data.api.AuroraApi.currentUserEmailVerified = true
                onBound()
            } else {
                Toast.makeText(ctx, result.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(24.dp)
        ) {
            Text("绑定邮箱", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            Spacer(Modifier.height(4.dp))
            Text("绑定后即可解锁全部功能（私信、群聊、社区等）",
                fontSize = 12.sp, color = Color(0xFF6B7280))
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(value = email, onValueChange = { email = it },
                placeholder = { Text("输入邮箱", fontSize = 14.sp) },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(10.dp),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Email))

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = code, onValueChange = { code = it },
                    placeholder = { Text("输入验证码", fontSize = 14.sp) },
                    modifier = Modifier.weight(1f), singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number))
                Spacer(Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .height(48.dp).widthIn(min = 90.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (codeCountdown > 0 || isSendingCode) Color(0xFFD1D5DB) else Color(0xFF1E40AF))
                        .clickable(enabled = codeCountdown == 0 && !isSendingCode && email.isNotBlank()) { sendCode() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when { isSendingCode -> "发送中..."; codeCountdown > 0 -> "${codeCountdown}s"; else -> "发送验证码" },
                        fontSize = 13.sp, fontWeight = FontWeight.Medium,
                        color = if (codeCountdown > 0 || isSendingCode) Color(0xFF6B7280) else Color.White)
                }
            }

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { bind() },
                modifier = Modifier.fillMaxWidth().height(44.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)),
                enabled = !binding
            ) {
                Text(if (binding) "绑定中…" else "绑定邮箱", color = Color.White, fontSize = 15.sp)
            }

            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                Text("暂不绑定", color = Color(0xFF9CA3AF))
            }
        }
    }
}
