package com.aurora.chat.ui.components

import androidx.compose.runtime.staticCompositionLocalOf

/** 全局控制是否显示分割线 */
val LocalShowDividers = staticCompositionLocalOf { true }
