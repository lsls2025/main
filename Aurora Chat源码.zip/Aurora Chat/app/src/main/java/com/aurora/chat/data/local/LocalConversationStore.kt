package com.aurora.chat.data.local

import android.content.Context
import com.aurora.chat.CryptoUtil
import com.aurora.chat.data.api.ConversationInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * 对话列表本地缓存（JSON 文件）
 * 断网时读取缓存，不显示"暂无会话"
 */
object LocalConversationStore {

    private const val FILE_NAME = "conversations_cache.json"

    private fun getFile(context: Context): File =
        File(context.filesDir, FILE_NAME)

    /** 保存对话列表到本地 */
    fun save(context: Context, conversations: List<ConversationInfo>) {
        try {
            val json = JSONArray()
            conversations.forEach { c ->
                json.put(JSONObject().apply {
                    put("id", c.id)
                    put("email", c.email)
                    put("username", c.username)
                    put("createdAt", c.createdAt)
                    // 会话预览加密存储，防止明文落盘
                    put("lastMessage", CryptoUtil.encryptLocal(c.lastMessage))
                    put("lastTime", c.lastTime)
                })
            }
            getFile(context).writeText(json.toString(2))
        } catch (_: Exception) {}
    }

    /** 从本地加载对话列表 */
    fun load(context: Context): List<ConversationInfo> {
        try {
            val file = getFile(context)
            if (!file.exists()) return emptyList()
            val text = file.readText()
            val json = JSONArray(text)
            val list = mutableListOf<ConversationInfo>()
            for (i in 0 until json.length()) {
                val obj = json.getJSONObject(i)
                list.add(ConversationInfo(
                    id = obj.optLong("id"),
                    email = obj.optString("email"),
                    username = obj.optString("username"),
                    createdAt = obj.optLong("createdAt"),
                    lastMessage = CryptoUtil.decryptLocal(obj.optString("lastMessage")),
                    lastTime = obj.optLong("lastTime")
                ))
            }
            return list
        } catch (_: Exception) {
            return emptyList()
        }
    }
}
