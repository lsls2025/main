package com.aurora.chat

import android.app.AlarmManager
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Process
import android.util.Log

/**
 * 全局崩溃拦截器 —— 捕获所有线程的未捕获异常，持久化闪退计数，
 * 写入日志后重启应用。支持跨进程重启计数。
 */
object CrashHandler {

    private const val TAG = "CrashHandler"

    fun init(application: Application) {
        // 接管全局未捕获异常处理器（所有线程的未捕获异常都会经过这里）
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                handleCrash(application, thread, throwable)
            } catch (_: Exception) {
            } finally {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
        Log.i(TAG, "CrashHandler 已初始化，已接管所有线程的未捕获异常")
    }

    private fun handleCrash(app: Application, thread: Thread, throwable: Throwable) {
        // 1. 持久化闪退计数到 SharedPreferences（重启后依然可读）
        persistCrashCount(app)

        // 2. 写入日志文件（含线程信息）
        ErrorReporter.fatal(
            tag = "Crash",
            message = "线程:${thread.name}(${thread.id}) ${throwable.javaClass.simpleName}: ${throwable.message?.take(200) ?: ""}",
            throwable = throwable
        )

        // 3. 通过 AlarmManager 重启应用
        try {
            val intent = Intent(app, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("from_crash", true)
            }
            val pendingIntent = PendingIntent.getActivity(
                app, 10086, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmMgr = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmMgr.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 500L, pendingIntent)
        } catch (_: Exception) {}

        // 4. 结束进程
        Process.killProcess(Process.myPid())
    }

    /** 读取持久化闪退总数 */
    fun getCrashCount(context: Context): Int {
        return context.getSharedPreferences("crash_stats", Context.MODE_PRIVATE)
            .getInt("total_crashes", 0)
    }

    /** 重置闪退计数 */
    fun resetCrashCount(context: Context) {
        context.getSharedPreferences("crash_stats", Context.MODE_PRIVATE)
            .edit().putInt("total_crashes", 0).apply()
    }

    private fun persistCrashCount(context: Context) {
        val prefs = context.getSharedPreferences("crash_stats", Context.MODE_PRIVATE)
        val current = prefs.getInt("total_crashes", 0)
        prefs.edit().putInt("total_crashes", current + 1).apply()
    }
}
