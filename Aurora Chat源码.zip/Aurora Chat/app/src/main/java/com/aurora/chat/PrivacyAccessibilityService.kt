package com.aurora.chat

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * 隐私锁定辅助功能服务 —— 拦截返回键实现"禁止退出"功能。
 * 
 * 当 PrivacyFloatingService.noExit == true 时，拦截系统返回键，
 * 阻止用户退出当前聊天界面。
 * 双方都开启后，必须双方都同意才能解锁退出。
 */
class PrivacyAccessibilityService : AccessibilityService() {

    companion object {
        private var isServiceRunning = false
        private var serviceInstance: PrivacyAccessibilityService? = null

        fun isRunning(): Boolean = isServiceRunning

        /** 模拟返回键（用于解锁后恢复退出功能） */
        fun simulateBackPress() {
            try {
                serviceInstance?.performGlobalAction(GLOBAL_ACTION_BACK)
            } catch (_: Exception) {}
        }

        /** 检查无障碍服务是否在运行 */
        fun checkEnabled(): Boolean = isServiceRunning
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        serviceInstance = this
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            // 关键：声明要拦截返回键
            flags = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 用于检测窗口变化
    }

    override fun onInterrupt() {
        isServiceRunning = false
        serviceInstance = null
    }

    override fun onDestroy() {
        isServiceRunning = false
        serviceInstance = null
        super.onDestroy()
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false
        // 拦截返回键：当禁止退出开启时，阻止返回操作
        if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_DOWN) {
            if (PrivacyFloatingService.masterOn && PrivacyFloatingService.noExit) {
                // 显示 Toast 提示
                showToast("隐私锁定中，无法退出")
                return true // 拦截事件
            }
        }
        return false
    }

    private fun showToast(msg: String) {
        try {
            Handler(Looper.getMainLooper()).post {
                android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
            }
        } catch (_: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }
}
