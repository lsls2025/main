package com.aurora.chat.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit

/**
 * 头像缓存管理器
 * - 内存缓存（快速访问）
 * - 磁盘缓存（持久化，60 分钟过期自动刷新）
 * - 统一加载入口
 * - 并发控制：同一用户去重 + 全局限流，避免首屏几十个头像同时读盘/联网占满 IO 线程池
 */
object AvatarCache {

    private val memoryCache = mutableMapOf<Long, Bitmap>()
    private val groupMemoryCache = mutableMapOf<Long, Bitmap>()
    private const val MAX_MEMORY_CACHE = 100
    /** 磁盘缓存过期时间（毫秒），默认 7 天 */
    private const val CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000L
    /** 无头像标记（userId → 标记时间戳），1小时后自动过期，避免网络错误永久标记 */
    private val noAvatarMap = mutableMapOf<Long, Long>()
    private const val NO_AVATAR_TTL_MS = 60 * 60 * 1000L // 1小时

    fun markNoAvatar(userId: Long) { noAvatarMap[userId] = System.currentTimeMillis() }
    fun hasNoAvatar(userId: Long): Boolean {
        val ts = noAvatarMap[userId] ?: return false
        if (System.currentTimeMillis() - ts > NO_AVATAR_TTL_MS) {
            noAvatarMap.remove(userId)
            return false
        }
        return true
    }
    fun clearNoAvatar(userId: Long) { noAvatarMap.remove(userId) }

    // 同一用户并发请求排队复用（避免重复网络请求），首次渲染几十个头像时分流加载
    private val userLocks = ConcurrentHashMap<Long, Mutex>()
    private val groupLocks = ConcurrentHashMap<Long, Mutex>()
    // 全局头像加载限流：限制同时进行的读盘/联网数量，避免占满 IO 线程池拖累其他任务
    private val loadThrottle = Semaphore(4)

    /** 同步读取用户头像内存缓存（仅内存，不碰磁盘/网络），供组合期立即显示已缓存头像 */
    fun getCachedUserAvatarSync(userId: Long): Bitmap? = memoryCache[userId]

    /** 同步读取群头像内存缓存（仅内存，不碰磁盘/网络） */
    fun getCachedGroupAvatarSync(groupId: Long): Bitmap? = groupMemoryCache[groupId]

    // ==================== 用户头像 ====================

    /**
     * 获取头像 Bitmap（优先读内存 -> 磁盘（未过期） -> 网络）
     */
    suspend fun getAvatar(context: Context, userId: Long): Bitmap? {
        // 0. 已知无头像（1小时内有效）→ 直接跳过
        if (hasNoAvatar(userId)) return null
        // 1. 内存缓存
        memoryCache[userId]?.let { return it }

        // 2. 磁盘缓存（检查是否过期，同时排除无效的小头像）
        val diskFile = getDiskFile(context, userId)
        if (diskFile.exists() && !isCacheExpired(diskFile)) {
            try {
                val bitmap = decodeSampledFile(diskFile)
                if (bitmap != null && bitmap.width >= 16 && bitmap.height >= 16) {
                    putMemoryCache(userId, bitmap)
                    return bitmap
                }
            } catch (_: Exception) {}
            try { diskFile.delete() } catch (_: Exception) {}
        }

        return null
    }

    /**
     * 从网络加载并缓存头像（loader 返回 null 或后端返回 204 时标记无头像）
     * 同一用户去重 + 全局限流，避免首屏多个头像并发读盘/联网占满 IO 线程池
     */
    suspend fun loadAvatar(context: Context, userId: Long, loader: suspend (Long) -> ByteArray?): Bitmap? {
        // 先检查缓存（无锁快速路径）
        getAvatar(context, userId)?.let { return it }
        val mutex = userLocks.computeIfAbsent(userId) { Mutex() }
        return mutex.withLock {
            // 双重检查：等锁期间可能已被其他协程加载进缓存
            getAvatar(context, userId)?.let { return@withLock it }
            loadThrottle.withPermit {
                doLoadAvatar(context, userId, loader)
            }
        }
    }

    private suspend fun doLoadAvatar(context: Context, userId: Long, loader: suspend (Long) -> ByteArray?): Bitmap? {
        // 从网络加载
        val bytes = loader(userId)
        if (bytes == null) {
            // 后端返回 204 → 无头像，标记缓存避免重复请求
            markNoAvatar(userId)
            com.aurora.chat.BugTracker.warn("数据", "用户 $userId 无头像")
            return null
        }
        val bitmap = decodeSampledBytes(bytes)
        if (bitmap == null) {
            com.aurora.chat.BugTracker.warn("数据", "用户 $userId 头像解码失败")
            return null
        }

        // 验证头像尺寸
        if (bitmap.width < 16 || bitmap.height < 16) {
            com.aurora.chat.BugTracker.warn("数据", "用户 $userId 头像太小 ${bitmap.width}x${bitmap.height}")
            return null
        }

        // 有真实头像 → 清除无头像标记并缓存
        clearNoAvatar(userId)
        putMemoryCache(userId, bitmap)
        saveToDisk(context, userId, bytes)
        saveCacheTime(context, userId)

        return bitmap
    }

    /**
     * 清除指定用户的头像缓存（内存 + 磁盘）
     */
    fun clear(userId: Long, context: Context? = null) {
        memoryCache.remove(userId)
        noAvatarMap.remove(userId)
        if (context != null) {
            try {
                val dir = java.io.File(context.filesDir, "avatar_cache")
                java.io.File(dir, "avatar_$userId.png").delete()
                java.io.File(dir, "avatar_$userId.time").delete()
            } catch (_: Exception) {}
        }
    }

    /**
     * 清除所有缓存（内存 + 磁盘全部清除）
     * 用于登录/切换账号时强制从头加载
     */
    fun clearAll(context: Context? = null) {
        memoryCache.clear()
        groupMemoryCache.clear()
        noAvatarMap.clear()
        // 清除磁盘缓存（保留自己的 avatar.png，它是"已上传"的标志）
        if (context != null) {
            try {
                val userDir = File(context.filesDir, "avatar_cache")
                if (userDir.exists()) userDir.deleteRecursively()
                val groupDir = File(context.filesDir, "group_avatar_cache")
                if (groupDir.exists()) groupDir.deleteRecursively()
            } catch (_: Exception) {}
        }
    }

    // ==================== 群头像 ====================

    /**
     * 获取群头像 Bitmap（优先内存 -> 磁盘（未过期） -> 网络）
     */
    suspend fun getGroupAvatar(context: Context, groupId: Long): Bitmap? {
        groupMemoryCache[groupId]?.let { return it }
        val diskFile = getGroupDiskFile(context, groupId)
        if (diskFile.exists() && !isCacheExpired(diskFile)) {
            try {
                val bitmap = decodeSampledFile(diskFile)
                if (bitmap != null) {
                    putGroupMemoryCache(groupId, bitmap)
                    return bitmap
                }
            } catch (_: Exception) {}
        }
        return null
    }

    /**
     * 从网络加载并缓存群头像（保存到本地磁盘，永不过期，直到主动清除）
     * 同一群去重 + 全局限流，避免首屏多个头像并发读盘/联网占满 IO 线程池
     */
    suspend fun loadGroupAvatar(context: Context, groupId: Long, loader: suspend (Long) -> ByteArray?): Bitmap? {
        // 先检查本地缓存（磁盘或内存）
        getGroupAvatar(context, groupId)?.let { return it }
        val mutex = groupLocks.computeIfAbsent(groupId) { Mutex() }
        return mutex.withLock {
            // 双重检查：等锁期间可能已被其他协程加载进缓存
            getGroupAvatar(context, groupId)?.let { return@withLock it }
            loadThrottle.withPermit {
                doLoadGroupAvatar(context, groupId, loader)
            }
        }
    }

    private suspend fun doLoadGroupAvatar(context: Context, groupId: Long, loader: suspend (Long) -> ByteArray?): Bitmap? {
        val bytes = loader(groupId) ?: return null
        val bitmap = decodeSampledBytes(bytes) ?: return null

        // 保存到内存 + 磁盘
        putGroupMemoryCache(groupId, bitmap)
        saveGroupToDisk(context, groupId, bytes)
        saveGroupCacheTime(context, groupId)

        return bitmap
    }

    /**
     * 强制刷新群头像（清除缓存后从网络拉取）
     */
    suspend fun refreshGroupAvatar(context: Context, groupId: Long, loader: suspend (Long) -> ByteArray?): Bitmap? {
        clearGroupCache(groupId)
        return loadGroupAvatar(context, groupId, loader)
    }

    /**
     * 清除群头像缓存（内存 + 磁盘）
     */
    fun clearGroupCache(groupId: Long, context: Context? = null) {
        groupMemoryCache.remove(groupId)
        if (context != null) {
            try {
                val dir = getGroupCacheDir(context)
                File(dir, "group_avatar_$groupId.png").delete()
                File(dir, "group_avatar_$groupId.time").delete()
            } catch (_: Exception) {}
        }
    }

    /** 保存刚上传的群头像到内存缓存，供立即使用 */
    fun cacheUploadedGroupAvatar(groupId: Long, bitmap: Bitmap) {
        putGroupMemoryCache(groupId, bitmap)
    }

    /** 获取刚上传的内存缓存群头像 */
    fun getCachedUploadedGroupAvatar(groupId: Long): Bitmap? = groupMemoryCache[groupId]

    /**
     * 将用户头像直接存入缓存（上传后调用，避免重新从网络加载）
     */
    fun cacheUserAvatar(userId: Long, bitmap: Bitmap, context: Context? = null) {
        putMemoryCache(userId, bitmap)
        if (context != null) {
            try {
                val dir = File(context.filesDir, "avatar_cache")
                if (!dir.exists()) dir.mkdirs()
                val stream = java.io.ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.PNG, 80, stream)
                saveToDisk(context, userId, stream.toByteArray())
                saveCacheTime(context, userId)
            } catch (_: Exception) {}
        }
    }

    // ==================== 群头像 私有方法 ====================

    private fun getGroupCacheDir(context: Context): File {
        val dir = File(context.filesDir, "group_avatar_cache")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getGroupDiskFile(context: Context, groupId: Long): File {
        return File(getGroupCacheDir(context), "group_avatar_$groupId.png")
    }

    private fun saveGroupToDisk(context: Context, groupId: Long, bytes: ByteArray) {
        try {
            getGroupDiskFile(context, groupId).writeBytes(bytes)
        } catch (_: Exception) {}
    }

    private fun saveGroupCacheTime(context: Context, groupId: Long) {
        try {
            val dir = getGroupCacheDir(context)
            val timeFile = File(dir, "group_avatar_${groupId}.time")
            timeFile.writeText(System.currentTimeMillis().toString())
        } catch (_: Exception) {}
    }

    private fun putGroupMemoryCache(groupId: Long, bitmap: Bitmap) {
        if (groupMemoryCache.size >= MAX_MEMORY_CACHE) {
            val oldest = groupMemoryCache.keys.firstOrNull()
            if (oldest != null) groupMemoryCache.remove(oldest)
        }
        groupMemoryCache[groupId] = bitmap
    }

    // ==================== 用户头像 私有方法 ====================

    /** 判断磁盘缓存是否已过期 */
    private fun isCacheExpired(file: File): Boolean {
        val timeFile = File(file.parent, file.name.replace(".png", ".time"))
        if (!timeFile.exists()) return true
        val cachedTime = try { timeFile.readText().toLong() } catch (_: Exception) { 0L }
        return System.currentTimeMillis() - cachedTime > CACHE_TTL_MS
    }

    /** 保存缓存时间戳 */
    private fun saveCacheTime(context: Context, userId: Long) {
        try {
            val dir = File(context.filesDir, "avatar_cache")
            val timeFile = File(dir, "avatar_${userId}.time")
            timeFile.writeText(System.currentTimeMillis().toString())
        } catch (_: Exception) {}
    }

    private fun putMemoryCache(userId: Long, bitmap: Bitmap) {
        if (memoryCache.size >= MAX_MEMORY_CACHE) {
            val oldest = memoryCache.keys.firstOrNull()
            if (oldest != null) memoryCache.remove(oldest)
        }
        memoryCache[userId] = bitmap
    }

    // ==================== 采样解码 ====================

    /** 头像解码目标尺寸上限（px）：覆盖最大显示尺寸（好友面板 80dp@3x=240px）并贴合 2 的幂。
     *  不宜过大，否则首屏加载时堆内存峰值高、频繁 GC 停顿导致主线程卡顿 */
    private const val AVATAR_TARGET_PX = 144

    /** 根据源尺寸计算 inSampleSize（2 的幂），将解码结果限制在 target 内 */
    private fun calcInSampleSize(outWidth: Int, outHeight: Int, target: Int): Int {
        var inSampleSize = 1
        while (outWidth / inSampleSize >= target || outHeight / inSampleSize >= target) {
            inSampleSize *= 2
        }
        return inSampleSize
    }

    /** 带采样解码文件，避免全尺寸解码导致的内存峰值（原图 1080p+ 时单图内存可降为 1/9~1/16） */
    private fun decodeSampledFile(file: java.io.File, target: Int = AVATAR_TARGET_PX): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val opts = BitmapFactory.Options().apply {
            inSampleSize = calcInSampleSize(bounds.outWidth, bounds.outHeight, target)
        }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }

    /** 带采样解码字节数组 */
    private fun decodeSampledBytes(bytes: ByteArray, target: Int = AVATAR_TARGET_PX): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val opts = BitmapFactory.Options().apply {
            inSampleSize = calcInSampleSize(bounds.outWidth, bounds.outHeight, target)
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    private fun getDiskFile(context: Context, userId: Long): File {
        val dir = File(context.filesDir, "avatar_cache")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "avatar_$userId.png")
    }

    private fun saveToDisk(context: Context, userId: Long, bytes: ByteArray) {
        try {
            getDiskFile(context, userId).writeBytes(bytes)
        } catch (_: Exception) {}
    }
}
