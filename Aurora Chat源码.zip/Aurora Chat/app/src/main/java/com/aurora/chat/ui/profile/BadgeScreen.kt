package com.aurora.chat.ui.profile

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.aurora.chat.R
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.ui.components.BadgeInfo
import com.aurora.chat.ui.components.BadgeResources
import kotlinx.coroutines.launch
import org.json.JSONObject

/** 已知徽章定义（含描述） */
private val badgeDefs = BadgeResources.badgeInfos

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BadgeScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // 开关
    var badgeEnabled by remember {
        val prefs = context.getSharedPreferences("aurora_badge", Context.MODE_PRIVATE)
        mutableStateOf(prefs.getBoolean("badge_display_enabled", true))
    }

    // 徽章数据
    var ownedBadgeIds by remember { mutableStateOf(setOf<Int>()) }
    var wornBadgeId by remember { mutableIntStateOf(0) }
    var badgeExpiresAt by remember { mutableStateOf(mapOf<Int, Long>()) }
    var isLoading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }

    // 每秒更新剩余天数
    var nowTick by remember { mutableLongStateOf(System.currentTimeMillis() / 1000) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            nowTick = System.currentTimeMillis() / 1000
        }
    }

    fun remainingDays(expiresAt: Long): String {
        if (expiresAt == 0L) return "永久"
        val days = ((expiresAt - nowTick) / 86400).toInt()
        return if (days <= 0) "已过期" else "${days}天"
    }

    // 加载数据（从 AuroraApi 获取完整 JSON，含 worn_badge 和 expires_at）
    suspend fun loadBadges() {
        isLoading = true
        loadError = null
        try {
            val result = AuroraApi.getUserBadges()
            val data = result.data
            if (data != null) {
                val arr = data.optJSONArray("badges")
                val ids = mutableSetOf<Int>()
                val expMap = mutableMapOf<Int, Long>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val bid = obj.optInt("badge_id")
                        ids.add(bid)
                        expMap[bid] = obj.optLong("expires_at", 0)
                    }
                }
                ownedBadgeIds = ids
                badgeExpiresAt = expMap
                wornBadgeId = data.optInt("worn_badge", 0)
            } else {
                loadError = result.message
            }
        } catch (e: Exception) {
            loadError = e.localizedMessage ?: "未知错误"
        }
        isLoading = false
    }

    // 静默同步（不显示转圈）
    suspend fun syncBadges() {
        try {
            val result = AuroraApi.getUserBadges()
            val data = result.data
            if (data != null) {
                val arr = data.optJSONArray("badges")
                val ids = mutableSetOf<Int>()
                val expMap = mutableMapOf<Int, Long>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val bid = obj.optInt("badge_id")
                        ids.add(bid)
                        expMap[bid] = obj.optLong("expires_at", 0)
                    }
                }
                ownedBadgeIds = ids
                badgeExpiresAt = expMap
                wornBadgeId = data.optInt("worn_badge", 0)
            }
        } catch (_: Exception) { }
    }

    LaunchedEffect(Unit) { loadBadges() }

    Box(
        modifier = Modifier.fillMaxSize().background(Color.White).statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // ── 顶部栏 ──
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable { onBack() })
                Spacer(Modifier.width(12.dp))
                Text("徽章", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937),
                    modifier = Modifier.weight(1f))

                Switch(
                    checked = badgeEnabled,
                    onCheckedChange = { enabled ->
                        badgeEnabled = enabled
                        context.getSharedPreferences("aurora_badge", Context.MODE_PRIVATE)
                            .edit().putBoolean("badge_display_enabled", enabled).apply()
                        if (!enabled && wornBadgeId > 0) {
                            wornBadgeId = 0
                            scope.launch {
                                try { AuroraApi.setWornBadge(0); syncBadges() }
                                catch (_: Exception) { syncBadges() }
                            }
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF1E40AF),
                        uncheckedThumbColor = Color.White,
                        uncheckedTrackColor = Color(0xFFD1D5DB)
                    )
                )
            }

            Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))

            when {
                isLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color(0xFF1E40AF))
                            Spacer(Modifier.height(8.dp))
                            Text("加载中...", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                        }
                    }
                }
                loadError != null -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("加载失败", fontSize = 16.sp, color = Color(0xFFEF4444))
                            Spacer(Modifier.height(4.dp))
                            Text(loadError ?: "", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                            Spacer(Modifier.height(12.dp))
                            Text("点击重试", fontSize = 14.sp, color = Color(0xFF1E40AF),
                                modifier = Modifier.clickable { scope.launch { loadBadges() } })
                        }
                    }
                }
                !badgeEnabled -> {
                    Spacer(Modifier.height(60.dp))
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🏅", fontSize = 36.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("徽章展示已关闭", fontSize = 15.sp, color = Color(0xFF9CA3AF))
                        Spacer(Modifier.height(4.dp))
                        Text("打开开关后可佩戴徽章", fontSize = 13.sp, color = Color(0xFFD1D5DB))
                    }
                }
                else -> {
                    // ── 统计信息 + 提示 ──
                    val extraBadgeIds = ownedBadgeIds.filter { it > badgeDefs.size }
                    val totalBadgeCount = badgeDefs.size + extraBadgeIds.size

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("共 $totalBadgeCount 个", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                        Text(" · 长按卡片查看详情", fontSize = 11.sp, color = Color(0xFF6B7280))
                        Spacer(Modifier.weight(1f))
                        Text(
                            if (ownedBadgeIds.isNotEmpty()) "已拥有 ${ownedBadgeIds.size} 个" else "未拥有",
                            fontSize = 12.sp,
                            color = if (ownedBadgeIds.isNotEmpty()) Color(0xFF1E40AF) else Color(0xFF9CA3AF)
                        )
                    }

                    Spacer(Modifier.height(4.dp))

                    // ── 徽章网格 ──
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 20.dp)
                    ) {
                        // 1-10 已知徽章
                        itemsIndexed(badgeDefs) { index, badge ->
                            val badgeId = index + 1
                            val owned = badgeId in ownedBadgeIds
                            val isWorn = wornBadgeId == badgeId
                            val remaining = if (owned) remainingDays(badgeExpiresAt[badgeId] ?: 0L) else ""
                            BadgeGridItem(
                                badge = badge,
                                owned = owned,
                                isWorn = isWorn,
                                remainingText = remaining,
                                onWear = {
                                    if (owned) {
                                        scope.launch {
                                            try {
                                                val newId = if (isWorn) 0 else badgeId
                                                AuroraApi.setWornBadge(newId)
                                                wornBadgeId = newId
                                                syncBadges()
                                            } catch (_: Exception) { syncBadges() }
                                        }
                                    }
                                }
                            )
                        }
                        // 超出范围的额外徽章
                        val sortedExtra = ownedBadgeIds.filter { it > badgeDefs.size }.sorted()
                        itemsIndexed(sortedExtra) { _, badgeId ->
                            val isWorn = wornBadgeId == badgeId
                            val remaining = remainingDays(badgeExpiresAt[badgeId] ?: 0L)
                            BadgeGridItem(
                                badge = BadgeInfo("徽章 #${badgeId}", R.drawable.badge_bazaar_1, ""),
                                owned = true,
                                isWorn = isWorn,
                                remainingText = remaining,
                                onWear = {
                                    scope.launch {
                                        try {
                                            val newId = if (isWorn) 0 else badgeId
                                            AuroraApi.setWornBadge(newId)
                                            wornBadgeId = newId
                                            syncBadges()
                                        } catch (_: Exception) { syncBadges() }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

// ── 单个徽章卡片 ──

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BadgeGridItem(
    badge: BadgeInfo,
    owned: Boolean,
    isWorn: Boolean,
    remainingText: String,
    onWear: () -> Unit
) {
    var showDetail by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .then(
                if (isWorn) Modifier.border(2.5.dp, Color(0xFF1E40AF), RoundedCornerShape(12.dp))
                else Modifier
            )
            .combinedClickable(
                onClick = { if (owned) onWear() },
                onLongClick = { showDetail = true },
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isWorn) Color(0xFFE8F0FE) else if (owned) Color(0xFFF0F4FF) else Color(0xFFF8F9FA)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(8.dp)) {
                Image(
                    painter = painterResource(id = badge.resId),
                    contentDescription = badge.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(4.dp)
                        .alpha(if (owned) 1f else 0.45f)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (isWorn) "佩戴中" else if (owned) "已拥有" else "未拥有",
                    fontSize = 11.sp,
                    color = if (isWorn || owned) Color(0xFF1E40AF) else Color(0xFF9CA3AF),
                    textAlign = TextAlign.Center,
                    fontWeight = if (isWorn) FontWeight.Bold else FontWeight.Medium
                )
                if (owned && remainingText.isNotEmpty()) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        remainingText,
                        fontSize = 10.sp,
                        color = if (remainingText == "永久") Color(0xFF10B981) else Color(0xFFF59E0B),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }

    // 长按详情弹窗
    if (showDetail) {
        BadgeDetailDialog(badge = badge, owned = owned, onDismiss = { showDetail = false })
    }
}

// ── 详情弹窗 ──

@Composable
private fun BadgeDetailDialog(
    badge: BadgeInfo,
    owned: Boolean,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = badge.resId),
                contentDescription = badge.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .alpha(if (owned) 1f else 0.6f)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(16.dp))
            Text(badge.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937), textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Surface(shape = RoundedCornerShape(4.dp), color = if (owned) Color(0xFFE8F0FE) else Color(0xFFF3F4F6)) {
                Text(
                    if (owned) "已拥有" else "未拥有",
                    fontSize = 12.sp,
                    color = if (owned) Color(0xFF1E40AF) else Color(0xFF9CA3AF),
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp)
                )
            }
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFE5E7EB)))
            Spacer(Modifier.height(12.dp))
            Text("获得条件", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Text(
                badge.description,
                fontSize = 14.sp,
                color = Color(0xFF6B7280),
                lineHeight = 22.sp,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)),
                shape = RoundedCornerShape(10.dp)
            ) { Text("知道了", fontSize = 15.sp, fontWeight = FontWeight.Medium) }
        }
    }
}
