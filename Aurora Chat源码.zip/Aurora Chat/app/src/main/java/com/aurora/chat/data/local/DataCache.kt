package com.aurora.chat.data.local

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * 通用本地数据缓存（聊天列表/社区帖子/应用列表）
 * 所有写操作使用 commit() 同步落盘，避免异步 apply() 丢失数据
 */
object DataCache {

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("data_cache", Context.MODE_PRIVATE)

    // ── 聊天列表 ──
    fun saveChatList(ctx: Context, json: String) {
        prefs(ctx).edit().putString("chat_list", json).commit()
    }

    fun loadChatList(ctx: Context): String? = prefs(ctx).getString("chat_list", null)

    // ── 社区帖子 ──
    fun savePost(ctx: Context, postId: Long, json: String) {
        // 同步写入 SP + 文件双重保障
        prefs(ctx).edit().putString("post_$postId", json).commit()
        try {
            val dir = File(ctx.filesDir, "community_posts")
            if (!dir.exists()) dir.mkdirs()
            File(dir, "${postId}.json").writeText(json)
        } catch (_: Exception) {}
    }

    fun loadPost(ctx: Context, postId: Long): String? {
        prefs(ctx).getString("post_$postId", null)?.let { return it }
        try {
            val f = File(File(ctx.filesDir, "community_posts"), "${postId}.json")
            if (f.exists()) return f.readText()
        } catch (_: Exception) {}
        return null
    }

    // ── 应用列表 ──
    fun saveAppList(ctx: Context, json: String) {
        prefs(ctx).edit().putString("app_list", json).commit()
    }

    fun loadAppList(ctx: Context): String? = prefs(ctx).getString("app_list", null)
}
