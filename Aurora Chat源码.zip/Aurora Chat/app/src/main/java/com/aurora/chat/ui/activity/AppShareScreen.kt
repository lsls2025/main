﻿package com.aurora.chat.ui.activity

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.aurora.chat.data.api.AuroraApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

private val qqGroupLink = "https://qun.qq.com/universal-share/share?ac=1&authKey=avHzTc8oP0mzVwKHDz%2BqUjnsSm6IEe6z5ExspMhY868zjKy2Rld08CtsHEzfGLYy&busi_data=eyJncm91cENvZGUiOiIxMDg0NjEyODk5IiwidG9rZW4iOiI4MDJJd0FHekwvUDdWS013RjhUVVp6Tzcyd1NmTzVGZVVRbWtFUmh6ZHpFN1Y5cGd0aGs2STFXRHpXNGhuWlpDIiwidWluIjoiMzg4ODU0NDUzOSJ9&data=ez7gr4G39W9LovVWUkSFvxM5emsSfd-BwTJmFoZKlAbl2Z6rDawFskHD3ZYkvhN2lWeS_N11N14HfPPfNY2zIA&svctype=4&tempid=h5_group_info"

@Composable
fun AppShareScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // 上传表单状态
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var downloadUrl by remember { mutableStateOf("") }
    var packageName by remember { mutableStateOf("") }
    var fileSizeStr by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var iconUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var screenshotUris by remember { mutableStateOf<List<android.net.Uri>>(emptyList()) }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    // 下载方式: "url" = 填写直链, "upload" = 上传APK
    var downloadType by remember { mutableStateOf("url") }
    var apkUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var apkFileName by remember { mutableStateOf("") }

    val iconLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> iconUri = uri }
    val screenshotLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        val remaining = 10 - screenshotUris.size
        if (remaining <= 0) return@rememberLauncherForActivityResult
        val newUris = uris.take(remaining)
        val videos = mutableListOf<android.net.Uri>()
        val images = mutableListOf<android.net.Uri>()
        newUris.forEach { uri ->
            val mime = try { context.contentResolver.getType(uri) } catch (_: Exception) { "" }
            if (mime?.startsWith("video/") == true) videos.add(uri) else images.add(uri)
        }
        screenshotUris = screenshotUris + videos + images
    }
    val apkLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            apkUri = uri
            // 从 URI 读取文件名
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0) {
                        apkFileName = it.getString(nameIndex) ?: "app.apk"
                    } else {
                        apkFileName = "app.apk"
                    }
                }
            }
            if (apkFileName.isEmpty()) apkFileName = "app.apk"

            // 自动填写大小和包名
            scope.launch(Dispatchers.IO) {
                try {
                    // 读取文件大小
                    val apkBytes = context.contentResolver.openInputStream(uri)?.use { s -> s.readBytes() }
                    if (apkBytes != null) {
                        val sizeMb = apkBytes.size / (1024.0 * 1024.0)
                        fileSizeStr = String.format("%.1f", sizeMb)
                    }

                    // 尝试识别包名：将 APK 复制到临时文件后用 PackageManager 解析
                    val tempFile = File(context.cacheDir, "temp_apk_${System.currentTimeMillis()}.apk")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    val pkgInfo = context.packageManager.getPackageArchiveInfo(tempFile.absolutePath, 0)
                    if (pkgInfo != null && pkgInfo.packageName != null) {
                        packageName = pkgInfo.packageName
                    }
                    tempFile.delete()
                } catch (_: Exception) {
                    // 解析失败就空着
                }
            }
        }
    }

    // 当前tab: "upload" 或 "manage"
    var currentTab by remember { mutableStateOf("upload") }

    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(rememberScrollState()).navigationBarsPadding().imePadding()) {
        // 顶栏
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 24.sp, color = Color(0xFF1E40AF),
                modifier = Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onBack() })
            Spacer(Modifier.weight(1f))
            Text("应用分享", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            Spacer(Modifier.weight(1f))
            Box(Modifier.width(48.dp))
        }

        // QQ群卡片
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF1E40AF), Color(0xFF3B82F6))))
                .padding(20.dp)
        ) {
            Column {
                Text("Aurora Chat 官方QQ群", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(4.dp))
                Text("群号: 123456789", fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f))
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(Color.White.copy(alpha = 0.2f))
                            .clickable { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(qqGroupLink))) }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) { Text("打开", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Medium) }
                    Box(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(Color.White.copy(alpha = 0.2f))
                            .clickable {
                                val clip = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                clip.setPrimaryClip(android.content.ClipData.newPlainText("qq_group", "123456789"))
                                Toast.makeText(context, "已复制群号", Toast.LENGTH_SHORT).show()
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) { Text("复制", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Medium) }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ── Tab 切换 ──
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (currentTab == "upload") Color(0xFF1E40AF) else Color(0xFFF3F4F6))
                    .clickable { currentTab = "upload" }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("上传应用",
                    fontSize = 14.sp,
                    fontWeight = if (currentTab == "upload") FontWeight.Bold else FontWeight.Normal,
                    color = if (currentTab == "upload") Color.White else Color(0xFF6B7280))
            }
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (currentTab == "manage") Color(0xFF1E40AF) else Color(0xFFF3F4F6))
                    .clickable { currentTab = "manage" }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("应用管理",
                    fontSize = 14.sp,
                    fontWeight = if (currentTab == "manage") FontWeight.Bold else FontWeight.Normal,
                    color = if (currentTab == "manage") Color.White else Color(0xFF6B7280))
            }
        }

        Spacer(Modifier.height(12.dp))

        if (currentTab == "upload") {
            // ── 上传表单 ──
            Column(Modifier.padding(horizontal = 20.dp)) {

            Text("应用名称 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp))

            Spacer(Modifier.height(10.dp))
            Text("应用描述", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = description, onValueChange = { description = it }, modifier = Modifier.fillMaxWidth().height(80.dp), shape = RoundedCornerShape(10.dp))

            Spacer(Modifier.height(10.dp))

            // ── 下载方式选择 ──
            Text("安装包方式 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // 填写直链
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (downloadType == "url") Color(0xFF1E40AF) else Color(0xFFF3F4F6))
                        .border(
                            width = if (downloadType == "url") 0.dp else 1.dp,
                            color = if (downloadType == "url") Color.Transparent else Color(0xFFD1D5DB),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { downloadType = "url" }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("填写直链",
                            fontSize = 14.sp,
                            fontWeight = if (downloadType == "url") FontWeight.Bold else FontWeight.Normal,
                            color = if (downloadType == "url") Color.White else Color(0xFF6B7280))
                    }
                }
                // 上传APK
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (downloadType == "upload") Color(0xFF1E40AF) else Color(0xFFF3F4F6))
                        .border(
                            width = if (downloadType == "upload") 0.dp else 1.dp,
                            color = if (downloadType == "upload") Color.Transparent else Color(0xFFD1D5DB),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { downloadType = "upload" }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("上传APK",
                            fontSize = 14.sp,
                            fontWeight = if (downloadType == "upload") FontWeight.Bold else FontWeight.Normal,
                            color = if (downloadType == "upload") Color.White else Color(0xFF6B7280))
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // 根据下载方式显示不同的输入
            if (downloadType == "url") {
                Text("安装包直链 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
                OutlinedTextField(value = downloadUrl, onValueChange = { downloadUrl = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp), placeholder = { Text("粘贴 APK 直链下载地址", fontSize = 13.sp) })
            } else {
                Text("选择APK安装包 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
                Box(
                    Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF9FAFB))
                        .border(1.dp, Color(0xFFD1D5DB), RoundedCornerShape(10.dp))
                        .clickable { apkLauncher.launch("application/vnd.android.package-archive") },
                    contentAlignment = Alignment.Center
                ) {
                    if (apkUri != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            Text(apkFileName, fontSize = 13.sp, color = Color(0xFF1E40AF),
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 200.dp))
                        }
                    } else {
                        Text("点击选择 APK 文件", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("包名", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
                    OutlinedTextField(value = packageName, onValueChange = { packageName = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("大小(MB)", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
                    OutlinedTextField(value = fileSizeStr, onValueChange = { fileSizeStr = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp))
                }
            }

            Spacer(Modifier.height(10.dp))
            Text("分类 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            var showCatDialog by remember { mutableStateOf(false) }
            var catLabel by remember { mutableStateOf("请选择") }
            Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFFF3F4F6)).clickable { showCatDialog = true }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text(catLabel, fontSize = 14.sp, color = Color(0xFF1F2937))
            }
            if (showCatDialog) {
                androidx.compose.ui.window.Dialog(onDismissRequest = { showCatDialog = false }) {
                    Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(20.dp)) {
                        Text("选择分类", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                        Spacer(Modifier.height(12.dp))
                        allCategories.chunked(4).forEach { rowCats ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowCats.forEach { cat ->
                                    Box(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (category == cat) Color(0xFF1E40AF) else Color(0xFFF3F4F6)).clickable { category = cat; catLabel = cat; showCatDialog = false }.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                        Text(cat, fontSize = 13.sp, color = if (category == cat) Color.White else Color(0xFF6B7280), fontWeight = if (category == cat) FontWeight.Medium else FontWeight.Normal)
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("应用图标", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                Text(" *", fontSize = 13.sp, color = Color(0xFF374151))
            }
            Spacer(Modifier.height(4.dp))
            Box(Modifier.size(80.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF3F4F6)).clickable { iconLauncher.launch("image/*") }, contentAlignment = Alignment.Center) {
                if (iconUri != null) AsyncImage(model = iconUri!!, contentDescription = "图标", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text("选择图标", fontSize = 11.sp, color = Color(0xFF6B7280))
            }

            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("应用截图 (最多10张)", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                Spacer(Modifier.weight(1f))
                if (screenshotUris.size < 10) TextButton(onClick = { screenshotLauncher.launch("*/*") }) { Text("添加", fontSize = 12.sp, color = Color(0xFF1E40AF)) }
            }
            if (screenshotUris.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF9FAFB)).clickable { screenshotLauncher.launch("*/*") }, contentAlignment = Alignment.Center) { Text("点击选择截图", fontSize = 13.sp, color = Color(0xFF9CA3AF)) }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(screenshotUris.size) { idx ->
                        Box(Modifier.size(80.dp)) {
                            AsyncImage(model = screenshotUris[idx], contentDescription = "截图$idx", modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                            Box(Modifier.align(Alignment.TopEnd).size(20.dp).clip(RoundedCornerShape(50)).background(Color.Red.copy(alpha = 0.8f)).clickable { screenshotUris = screenshotUris.toMutableList().apply { removeAt(idx) } }, contentAlignment = Alignment.Center) { Text("X", fontSize = 10.sp, color = Color.White) }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            errorMsg?.let { Text(it, fontSize = 13.sp, color = Color.Red); Spacer(Modifier.height(8.dp)) }

            Button(
                onClick = {
                    // 验证
                    if (name.isBlank()) { errorMsg = "应用名称为必填"; return@Button }
                    if (category.isBlank()) { errorMsg = "请选择分类"; return@Button }
                    if (iconUri == null) { errorMsg = "请选择应用图标"; return@Button }
                    if (downloadType == "url" && downloadUrl.isBlank()) { errorMsg = "请填写下载地址"; return@Button }
                    if (downloadType == "upload" && apkUri == null) { errorMsg = "请选择APK安装包"; return@Button }
                    isSubmitting = true; errorMsg = null
                    scope.launch {
                        try {
                            val iconBytes = iconUri?.let { withContext(Dispatchers.IO) { context.contentResolver.openInputStream(it)?.use { s -> s.readBytes() } } }
                            val screenshotBytesList = screenshotUris.mapNotNull { uri -> withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { s -> s.readBytes() } } }

                            var apkBytes: ByteArray? = null
                            if (downloadType == "upload" && apkUri != null) {
                                apkBytes = withContext(Dispatchers.IO) {
                                    context.contentResolver.openInputStream(apkUri!!)?.use { s -> s.readBytes() }
                                }
                            }
                            // upload模式直接用实际字节数，url模式从用户填的MB转换
                            val fileSizeBytes = if (downloadType == "upload" && apkBytes != null) {
                                apkBytes.size.toLong()
                            } else {
                                fileSizeStr.toFloatOrNull()?.let { (it * 1_048_576).toLong() } ?: 0L
                            }

                            val result = AuroraApi.submitApp(
                                name = name.trim(),
                                description = description.trim(),
                                downloadUrl = if (downloadType == "url") downloadUrl.trim() else "",
                                category = category,
                                packageName = packageName.trim(),
                                fileSize = fileSizeBytes,
                                iconBytes = iconBytes,
                                screenshotBytesList = screenshotBytesList,
                                apkType = downloadType,
                                apkBytes = apkBytes
                            )
                            isSubmitting = false
                            if (result.success) {
                                Toast.makeText(context, "提交成功，等待管理员审核", Toast.LENGTH_LONG).show()
                                // 清空表单
                                name = ""; description = ""; downloadUrl = ""; packageName = ""; fileSizeStr = ""
                                iconUri = null; screenshotUris = emptyList(); errorMsg = null
                                apkUri = null; apkFileName = ""; downloadType = "url"
                            } else errorMsg = result.message
                        } catch (e: Exception) { isSubmitting = false; errorMsg = e.localizedMessage ?: "提交失败" }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)), enabled = !isSubmitting
            ) {
                if (isSubmitting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                else Text("提交审核", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        } else {
            AppManageContent()
        }

        Spacer(Modifier.height(60.dp))
    }
}

private val allCategories = listOf(
    "推荐", "实用", "开发", "游戏", "社交", "影音",
    "购物", "工具", "通讯", "娱乐", "成人"
)

// ==================== 应用管理 ====================

@Composable
private fun AppManageContent() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val serverUrl = remember { AuroraApi.serverUrl }

    var apps by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var manageSubPage by remember { mutableStateOf("list") } // "list" | "update" | "info"
    var selectedApp by remember { mutableStateOf<JSONObject?>(null) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    fun refreshList() {
        isLoading = true
        scope.launch {
            val r = AuroraApi.getMyApps()
            isLoading = false
            if (r.success && r.data != null) {
                apps = (0 until r.data.length()).map { r.data.getJSONObject(it) }
            } else {
                errorMsg = r.message
            }
        }
    }
    LaunchedEffect(Unit) { refreshList() }

    if (manageSubPage == "update" && selectedApp != null) {
        AppUpdateContent(
            app = selectedApp!!,
            onBack = { manageSubPage = "list"; selectedApp = null },
            onUpdated = { manageSubPage = "list"; selectedApp = null; refreshList() }
        )
        return
    }

    // ── 应用列表 ──
    Column(Modifier.padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(8.dp))
        // 刷新按钮行
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("我提交的应用", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            Spacer(Modifier.weight(1f))
            Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFFF3F4F6)).clickable { refreshList() }.padding(horizontal = 12.dp, vertical = 6.dp)) {
                Text("刷新", fontSize = 12.sp, color = Color(0xFF1E40AF))
            }
        }
        Spacer(Modifier.height(12.dp))

        if (isLoading) {
            Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(24.dp), color = Color(0xFF1E40AF), strokeWidth = 2.dp)
            }
        } else if (apps.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                Text("暂无提交记录", fontSize = 14.sp, color = Color(0xFF9CA3AF))
            }
        } else {
            apps.forEach { app ->
                val appId = app.optLong("id", 0)
                val name = app.optString("name", "")
                val version = app.optString("version", "1.0")
                val status = app.optString("status", "")
                val statusText = when (status) {
                    "approved" -> "已通过"
                    "pending" -> "审核中"
                    "rejected" -> "已拒绝"
                    else -> status
                }
                val statusColor = when (status) {
                    "approved" -> Color(0xFF16A34A)
                    "pending" -> Color(0xFFD97706)
                    "rejected" -> Color(0xFFEF4444)
                    else -> Color(0xFF6B7280)
                }
                val iconUrl = "$serverUrl/api/apps/icon/$appId"

                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFF3F4F6))) {
                        AsyncImage(model = iconUrl, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("v$version", fontSize = 12.sp, color = Color(0xFF6B7280))
                            Spacer(Modifier.width(8.dp))
                            Text(statusText, fontSize = 12.sp, color = statusColor, fontWeight = FontWeight.Medium)
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFFEEF2FF)).clickable { selectedApp = app; manageSubPage = "update" }.padding(horizontal = 10.dp, vertical = 6.dp)) {
                        Text("更新", fontSize = 12.sp, color = Color(0xFF1E40AF), fontWeight = FontWeight.Medium)
                    }
                }
                Spacer(Modifier.height(2.dp))
                Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))
            }
        }
        errorMsg?.let { Text(it, fontSize = 13.sp, color = Color.Red); Spacer(Modifier.height(8.dp)) }
    }
}

// ==================== 版本更新界面 ====================

@Composable
private fun AppUpdateContent(app: JSONObject, onBack: () -> Unit, onUpdated: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val serverUrl = remember { AuroraApi.serverUrl }

    val appId = app.optLong("id", 0)
    val appName = app.optString("name", "")
    val currentVersion = app.optString("version", "1.0")
    val prevDownloadUrl = app.optString("download_url", "")
    val prevApkPath = app.optString("apk_path", "")
    // 判断上一次的方式：apk_path 非空或 download_url 以 /api/apps/apk/ 开头 => 上传APK模式
    val prevWasUpload = prevApkPath.isNotEmpty() || prevDownloadUrl.startsWith("/api/apps/apk/")
    val prevUrl = if (prevWasUpload) "" else prevDownloadUrl

    var version by remember { mutableStateOf(currentVersion) }
    var apkType by remember { mutableStateOf(if (prevWasUpload) "upload" else "url") }
    var downloadUrl by remember { mutableStateOf(prevUrl) }
    var apkUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var changelog by remember { mutableStateOf("") }
    var showChangelog by remember { mutableStateOf(false) }
    var allowOld by remember { mutableStateOf(false) }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val apkLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        apkUri = uri
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes != null) {
                        val mb = bytes.size / (1024.0 * 1024.0)
                        downloadUrl = String.format("%.1f", mb)
                    }
                } catch (_: Exception) { }
            }
        }
        apkType = "upload"
    }

    Column(Modifier.padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF),
                modifier = Modifier.clickable { onBack() }.padding(end = 8.dp))
            Text("版本更新", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        }
        Spacer(Modifier.height(4.dp))
        Text("$appName  v$currentVersion", fontSize = 13.sp, color = Color(0xFF6B7280))
        Spacer(Modifier.height(16.dp))

        Text("新版本号 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
        OutlinedTextField(value = version, onValueChange = { version = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp), placeholder = { Text("大于 $currentVersion", fontSize = 13.sp) })

        Spacer(Modifier.height(12.dp))
        Text("安装包方式 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (apkType == "url") Color(0xFF1E40AF) else Color(0xFFF3F4F6)).clickable { apkType = "url" }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Text("安装包直链", fontSize = 14.sp, fontWeight = if (apkType == "url") FontWeight.Bold else FontWeight.Normal, color = if (apkType == "url") Color.White else Color(0xFF6B7280))
            }
            Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (apkType == "upload") Color(0xFF1E40AF) else Color(0xFFF3F4F6)).clickable { apkType = "upload" }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Text("上传APK", fontSize = 14.sp, fontWeight = if (apkType == "upload") FontWeight.Bold else FontWeight.Normal, color = if (apkType == "upload") Color.White else Color(0xFF6B7280))
            }
        }

        Spacer(Modifier.height(12.dp))
        if (apkType == "url") {
            Text("下载地址 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = downloadUrl, onValueChange = { downloadUrl = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp), placeholder = { Text("粘贴 APK 直链下载地址", fontSize = 13.sp) })
        } else {
            Text("选择APK文件 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            Box(Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFF9FAFB)).border(1.dp, Color(0xFFD1D5DB), RoundedCornerShape(10.dp)).clickable { apkLauncher.launch("application/vnd.android.package-archive") }, contentAlignment = Alignment.Center) {
                Text(if (apkUri != null) "已选择 APK" else "点击选择 APK 文件", fontSize = 13.sp, color = if (apkUri != null) Color(0xFF1E40AF) else Color(0xFF9CA3AF))
            }
        }

        // ── 元数据编辑区（名称、描述、分类、图标、截图） ──
        Spacer(Modifier.height(12.dp))
        Text("应用名称 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
        var editName by remember { mutableStateOf(appName) }
        OutlinedTextField(value = editName, onValueChange = { editName = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp))

        Spacer(Modifier.height(10.dp))
        Text("应用描述", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
        var editDesc by remember { mutableStateOf(app.optString("description", "")) }
        OutlinedTextField(value = editDesc, onValueChange = { editDesc = it }, modifier = Modifier.fillMaxWidth().height(80.dp), shape = RoundedCornerShape(10.dp))

        Spacer(Modifier.height(10.dp))
        Text("分类 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
        var editCategory by remember { mutableStateOf(app.optString("category", "")) }
        var showCatDialog by remember { mutableStateOf(false) }
        var catLabel by remember { mutableStateOf(editCategory.ifEmpty { "请选择" }) }
        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFFF3F4F6)).clickable { showCatDialog = true }.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Text(catLabel, fontSize = 14.sp, color = Color(0xFF1F2937))
        }
        if (showCatDialog) {
            androidx.compose.ui.window.Dialog(onDismissRequest = { showCatDialog = false }) {
                Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(20.dp)) {
                    Text("选择分类", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                    Spacer(Modifier.height(12.dp))
                    allCategories.chunked(4).forEach { rowCats ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowCats.forEach { cat ->
                                Box(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (editCategory == cat) Color(0xFF1E40AF) else Color(0xFFF3F4F6)).clickable { editCategory = cat; catLabel = cat; showCatDialog = false }.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                    Text(cat, fontSize = 13.sp, color = if (editCategory == cat) Color.White else Color(0xFF6B7280), fontWeight = if (editCategory == cat) FontWeight.Medium else FontWeight.Normal)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("应用图标", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Text("（点击更换）", fontSize = 11.sp, color = Color(0xFF9CA3AF))
        }
        Spacer(Modifier.height(4.dp))
        val curIconUrl = "$serverUrl/api/apps/icon/$appId"
        var iconUri by remember { mutableStateOf<android.net.Uri?>(null) }
        val iconLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> iconUri = uri }
        Box(Modifier.size(80.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF3F4F6)).clickable { iconLauncher.launch("image/*") }, contentAlignment = Alignment.Center) {
            if (iconUri != null) AsyncImage(model = iconUri!!, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else AsyncImage(model = "$curIconUrl?t=${System.currentTimeMillis()}", contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }

        Spacer(Modifier.height(10.dp))
        // 截图相关状态定义在 launcher 之前
        val curScreenshots = app.optString("screenshots", "[]")
        val initialSs = remember(curScreenshots) {
            try {
                val arr = org.json.JSONArray(curScreenshots)
                (0 until arr.length()).map { arr.optString(it, "") }.filter { it.isNotEmpty() }
            } catch (_: Exception) { emptyList() }
        }
        var ssFiles by remember { mutableStateOf(initialSs) }
        var ssNewUris by remember { mutableStateOf<List<android.net.Uri>>(emptyList()) }
        var ssDeletedFiles by remember { mutableStateOf<List<String>>(emptyList()) }
        val ssTotalCount = ssFiles.size + ssNewUris.size
        val screenshotLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            val remaining = 10 - ssTotalCount
            if (remaining <= 0) return@rememberLauncherForActivityResult
            val newUris = uris.take(remaining)
            val videos = mutableListOf<android.net.Uri>()
            val images = mutableListOf<android.net.Uri>()
            newUris.forEach { uri ->
                val mime = try { context.contentResolver.getType(uri) } catch (_: Exception) { "" }
                if (mime?.startsWith("video/") == true) videos.add(uri) else images.add(uri)
            }
            ssNewUris = ssNewUris + videos + images
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("截图", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
            Spacer(Modifier.weight(1f))
            if (ssTotalCount < 10) TextButton(onClick = { screenshotLauncher.launch("*/*") }) { Text("添加", fontSize = 12.sp, color = Color(0xFF1E40AF)) }
        }
        if (ssTotalCount == 0) {
            Box(Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF9FAFB)).clickable { screenshotLauncher.launch("*/*") }, contentAlignment = Alignment.Center) { Text("点击添加截图", fontSize = 13.sp, color = Color(0xFF9CA3AF)) }
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ssTotalCount) { idx ->
                    Box(Modifier.size(80.dp)) {
                        val isNew = idx >= ssFiles.size
                        val realIdx = if (isNew) idx - ssFiles.size else idx
                        val model = if (isNew) ssNewUris[realIdx] else "$serverUrl/api/apps/screenshot/$appId/${ssFiles[realIdx]}"
                        AsyncImage(model = model, contentDescription = "截图$idx", modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                        Box(Modifier.align(Alignment.TopEnd).size(22.dp).clip(RoundedCornerShape(50)).background(Color(0xFF9CA3AF).copy(alpha = 0.85f)).clickable {
                            if (isNew) {
                                val list = ssNewUris.toMutableList(); list.removeAt(realIdx)
                                ssNewUris = list
                            } else {
                                val file = ssFiles[realIdx]
                                val list = ssFiles.toMutableList(); list.removeAt(realIdx)
                                ssFiles = list; ssDeletedFiles = ssDeletedFiles + file
                            }
                        }, contentAlignment = Alignment.Center) {
                            Text("✕", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        // 支持旧版本（仅 APK 上传模式可用）
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = allowOld, onCheckedChange = { allowOld = it }, colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1E40AF)),
                enabled = (apkType == "upload"))
            Spacer(Modifier.width(4.dp))
            Text("支持旧版本下载", fontSize = 13.sp, color = if (apkType == "upload") Color(0xFF374151) else Color(0xFF9CA3AF))
        }
        Spacer(Modifier.height(4.dp))
        // 更新内容
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = showChangelog, onCheckedChange = { showChangelog = it }, colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1E40AF)))
            Spacer(Modifier.width(4.dp))
            Text("更新内容", fontSize = 13.sp, color = Color(0xFF374151))
        }
        if (showChangelog) {
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = changelog, onValueChange = { if (it.length <= 500) changelog = it },
                modifier = Modifier.fillMaxWidth().height(120.dp),
                shape = RoundedCornerShape(10.dp),
                placeholder = { Text("请输入更新内容（最多500字）", fontSize = 13.sp) }
            )
            Text("${changelog.length}/500", fontSize = 11.sp, color = Color(0xFF9CA3AF), modifier = Modifier.align(Alignment.End))
        }

        Spacer(Modifier.height(12.dp))
        errorMsg?.let { Text(it, fontSize = 13.sp, color = Color.Red); Spacer(Modifier.height(8.dp)) }

        Button(
            onClick = {
                if (version.isBlank()) { errorMsg = "请填写新版本号"; return@Button }
                if (editName.isBlank()) { errorMsg = "应用名称不能为空"; return@Button }
                if (editCategory.isBlank()) { errorMsg = "请选择分类"; return@Button }
                if (apkType == "url" && downloadUrl.isBlank()) { errorMsg = "请填写下载地址"; return@Button }
                if (apkType == "upload" && apkUri == null) { errorMsg = "请选择APK文件"; return@Button }
                isSubmitting = true; errorMsg = null
                scope.launch {
                    try {
                        var apkBytes: ByteArray? = null
                        var fileSize = 0L
                        if (apkType == "upload" && apkUri != null) {
                            apkBytes = withContext(Dispatchers.IO) { context.contentResolver.openInputStream(apkUri!!)?.use { it.readBytes() } }
                            fileSize = apkBytes?.size?.toLong() ?: 0L
                        }
                        val iconBytes = if (iconUri != null) withContext(Dispatchers.IO) { context.contentResolver.openInputStream(iconUri!!)?.use { it.readBytes() } } else null
                        val ssBytesList = ssNewUris.mapNotNull { uri -> withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } } }
                        val result = AuroraApi.updateAppVersion(appId, version.trim(),
                            if (apkType == "url") downloadUrl.trim() else "",
                            apkBytes, fileSize, changelog.trim(), if (allowOld) "1" else "0",
                            editName.trim(), editDesc.trim(), editCategory,
                            iconBytes, ssBytesList, ssDeletedFiles.joinToString(","))
                        isSubmitting = false
                        if (result.success) {
                            Toast.makeText(context, "版本更新成功", Toast.LENGTH_SHORT).show()
                            onUpdated()
                        } else errorMsg = result.message
                    } catch (e: Exception) { isSubmitting = false; errorMsg = e.localizedMessage ?: "提交失败" }
                }
            },
            modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)), enabled = !isSubmitting
        ) {
            if (isSubmitting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            else Text("提交更新", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}
