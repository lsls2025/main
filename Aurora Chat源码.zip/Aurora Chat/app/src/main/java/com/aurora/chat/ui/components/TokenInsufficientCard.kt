package com.aurora.chat.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.chat.data.api.AuroraApi
import kotlinx.coroutines.launch

/**
 * token 余额耗尽卡片（沿用「通知中心」大卡片视觉样式）。
 *
 * 两种触发场景，共用同一张卡片、同一套逻辑：
 *  - 场景一：AI 正在输出时，余额刚好耗尽（streamChat 回调 onTokenInsufficient，
 *    剩余=0 或服务端 402），卡片直接浮在最上层弹出。
 *  - 场景二：用户本就没有余额，发起调用 API 前预校验即发现余额不足
 *    （预发送校验回调 onTokenExhausted），同样弹出此卡片。
 */
@Composable
fun TokenInsufficientCard(
    onRecharge: () -> Unit,
    onSubscribe: () -> Unit,
    onCheckIn: () -> Unit,
    onDismiss: () -> Unit
) {
    var checkedToday by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        scope.launch {
            try {
                val res = AuroraApi.checkinStatus()
                if (res.success && res.data != null) {
                    val d = if (res.data!!.has("data")) res.data!!.optJSONObject("data") ?: res.data!! else res.data!!
                    checkedToday = d.optBoolean("checked_today", false)
                }
            } catch (_: Exception) {}
        }
    }

    AnimatedVisibility(
        visible = true,
        enter = fadeIn(tween(200)),
        exit = fadeOut(tween(150))
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.4f))
                .clickable(onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .widthIn(min = 260.dp, max = 340.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(onClick = onDismiss),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F4FC)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "token余额已耗尽",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2329),
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(10.dp))
                    if (!checkedToday) {
                        Text(
                            text = "你今天似乎还未签到，签到可领 5000 token",
                            fontSize = 14.sp,
                            color = Color(0xFF5B6472),
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp
                        )
                    } else {
                        Text(
                            text = "可充值 token 或开通会员订阅获取 token",
                            fontSize = 14.sp,
                            color = Color(0xFF5B6472),
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp
                        )
                    }
                    Spacer(Modifier.height(18.dp))
                    if (!checkedToday) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TokenCardPill("充值token") { onRecharge() }
                            TokenCardPill("会员订阅") { onSubscribe() }
                            TokenCardPill("立即签到") { onCheckIn() }
                        }
                    } else {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TokenCardPill("充值token") { onRecharge() }
                            TokenCardPill("会员订阅") { onSubscribe() }
                        }
                    }
                }
            }
        }
    }
}

/** 底部胶囊按钮（沿用通知中心卡片的蓝色圆角胶囊风格） */
@Composable
private fun RowScope.TokenCardPill(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(999.dp))
            .background(Color(0xFF1E40AF))
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White
        )
    }
}
