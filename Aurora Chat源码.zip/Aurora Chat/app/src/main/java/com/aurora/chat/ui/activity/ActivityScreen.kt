package com.aurora.chat.ui.activity

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurora.chat.ui.chat.AiChatManager
import androidx.compose.foundation.horizontalScroll
import android.widget.Toast
import com.aurora.chat.R
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.data.api.ApiResult
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

@Composable
fun ActivityScreen(userId: Long, onDismiss: () -> Unit, initialPage: Int = 0) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var currentPage by remember { mutableIntStateOf(initialPage.coerceIn(0, 6)) } // 0=list, 1=referral, 2=appshare, 3=bottle, 4=checkin, 5=member, 6=balance

    var activityStats by remember { mutableStateOf<Map<String, Any>?>(null) }

    LaunchedEffect(Unit) {
        val result = AuroraApi.getActivityStats()
        if (result.success) activityStats = result.data
    }

    // 子页面中按返回键退回到列表页
    BackHandler(enabled = currentPage != 0) {
        currentPage = 0
    }

    Dialog(
        onDismissRequest = { if (currentPage == 0) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        AnimatedContent(
            targetState = currentPage,
            transitionSpec = {
                if (targetState > initialState) {
                    slideInHorizontally(tween(350), initialOffsetX = { it }) +
                        fadeIn(tween(350)) togetherWith
                        slideOutHorizontally(tween(350), targetOffsetX = { -it }) +
                        fadeOut(tween(350))
                } else {
                    slideInHorizontally(tween(350), initialOffsetX = { -it }) +
                        fadeIn(tween(350)) togetherWith
                        slideOutHorizontally(tween(350), targetOffsetX = { it }) +
                        fadeOut(tween(350))
                }
            },
            label = "activity_anim"
        ) { target ->
            val density = LocalDensity.current
            val edgeSwipeMod = Modifier.pointerInput(target) {
                val edgePx = with(density) { 30.dp.toPx() }
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    if (down.position.x > edgePx) {
                        do { awaitPointerEvent() } while (currentEvent.changes.any { it.pressed })
                        return@awaitEachGesture
                    }
                    var dragDistance = 0f
                    do {
                        val event = awaitPointerEvent()
                        event.changes.forEach { change ->
                            dragDistance += change.position.x - change.previousPosition.x
                            change.consume()
                        }
                    } while (currentEvent.changes.any { it.pressed })
                    if (dragDistance > size.width * 0.3f && currentPage != 0) {
                        currentPage = 0
                    }
                }
            }
            Box(edgeSwipeMod) {
                when (target) {
                    0 -> ActivityListScreen(
                        stats = activityStats,
                        onReferralClick = { currentPage = 1 },
                        onAppShareClick = { currentPage = 2 },
                        onBottleClick = { currentPage = 3 },
                        onCheckInClick = { currentPage = 4 },
                        onMemberClick = { currentPage = 5 },
                        onBalanceClick = { currentPage = 6 },
                        onBack = onDismiss
                    )
                    1 -> ReferralDetailScreen(
                        userId = userId, onBack = { currentPage = 0 }, onDismiss = onDismiss
                    )
                    2 -> AppShareScreen(onBack = { currentPage = 0 })
                    3 -> BottleScreen(onBack = { currentPage = 0 })
                    4 -> CheckInScreen(onBack = { currentPage = 0 })
                    5 -> MemberScreen(onBack = { currentPage = 0 })
                    6 -> BalanceScreen(onBack = { currentPage = 0 })
                }
            }
        }
    }
}

@Composable
private fun ActivityListScreen(
    stats: Map<String, Any>?,
    onReferralClick: () -> Unit,
    onAppShareClick: () -> Unit,
    onBottleClick: () -> Unit,
    onCheckInClick: () -> Unit,
    onMemberClick: () -> Unit,
    onBalanceClick: () -> Unit,
    onBack: () -> Unit
) {
    val balanceScope = rememberCoroutineScope()
    var tokenBalance by remember { mutableLongStateOf(-1L) }
    LaunchedEffect(Unit) {
        if (AuroraApi.authToken != null) {
            balanceScope.launch {
                val res = AuroraApi.memberStatus()
                if (res.success && res.data != null) {
                    val d = if (res.data!!.has("data")) res.data!!.optJSONObject("data") ?: res.data!! else res.data!!
                    if (d.has("token_balance")) tokenBalance = d.getLong("token_balance")
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("←", fontSize = 24.sp, color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onBack() })
                Spacer(Modifier.weight(1f))
                Text("活动中心", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.weight(1f))
                Box(Modifier.width(48.dp))
            }

            Spacer(Modifier.height(16.dp))

            ActivityCard(
                icon = ActivityCardIcon.GIFT,
                title = "拉新用户",
                description = "邀请好友注册，生成专属激活码",
                onClick = onReferralClick
            )

            Spacer(Modifier.height(16.dp))

            ActivityCard(
                icon = ActivityCardIcon.APPS,
                title = "应用分享",
                description = "上传和浏览用户分享的应用",
                onClick = onAppShareClick
            )

            Spacer(Modifier.height(16.dp))

            ActivityCard(
                icon = ActivityCardIcon.BOTTLE,
                title = "漂流瓶",
                description = "扔瓶子或从大海中捞起未知的漂流瓶",
                onClick = onBottleClick
            )

            Spacer(Modifier.height(16.dp))

            ActivityCard(
                icon = ActivityCardIcon.CALENDAR,
                title = "每日签到",
                description = "每日签到领取奖励，连续签到惊喜更多",
                onClick = onCheckInClick
            )

            Spacer(Modifier.height(16.dp))

            ActivityCard(
                icon = ActivityCardIcon.CROWN,
                title = "会员中心",
                description = "尊享会员特权，畅享更多专属功能",
                onClick = onMemberClick
            )

            Spacer(Modifier.height(16.dp))

            ActivityCard(
                icon = ActivityCardIcon.WALLET,
                title = "余额",
                description = "查看AI对话的token余额",
                statsLine = if (tokenBalance >= 0L) "Token：$tokenBalance" else null,
                onClick = onBalanceClick
            )

            Spacer(Modifier.height(20.dp))

            Text("更多活动即将上线，敬请期待", fontSize = 13.sp, color = Color(0xFF9CA3AF))
        }
    }
}

private enum class ActivityCardIcon { GIFT, APPS, BOTTLE, SERVER, CALENDAR, CROWN, WALLET }

@Composable
private fun ActivityCard(
    icon: ActivityCardIcon,
    title: String,
    description: String,
    statsLine: String? = null,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFF0F4FF))
            .clickable { onClick() }
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1E40AF)),
                contentAlignment = Alignment.Center
            ) {
                if (icon == ActivityCardIcon.GIFT) {
                    Canvas(modifier = Modifier.size(30.dp)) {
                        val cx = size.width / 2; val cy = size.height / 2
                        val boxW = size.width * 0.8f; val boxH = size.height * 0.55f
                        val boxL = cx - boxW / 2; val boxT = cy - boxH / 2 + 4
                        drawRoundRect(Color.White, Offset(boxL, boxT), Size(boxW, boxH), CornerRadius(3.dp.toPx(), 3.dp.toPx()))
                        val bowR = 5.dp.toPx()
                        val path = Path().apply {
                            moveTo(cx - bowR, boxT - 2)
                            quadraticTo(cx - bowR * 2, boxT - 2 - bowR, cx, boxT - 2 - bowR * 0.5f)
                            quadraticTo(cx + bowR * 2, boxT - 2 - bowR, cx + bowR, boxT - 2)
                            close()
                        }
                        drawPath(path, Color.White)
                    }
                } else if (icon == ActivityCardIcon.APPS) {
                    Canvas(modifier = Modifier.size(30.dp)) {
                        val s = size.width / 3
                        drawRect(Color.White, Offset(0f, 0f), Size(s - 2, s - 2))
                        drawRect(Color.White, Offset(s + 1, 0f), Size(s - 2, s - 2))
                        drawRect(Color.White.copy(alpha = 0.6f), Offset(0f, s + 1), Size(s - 2, s - 2))
                        drawRect(Color.White.copy(alpha = 0.6f), Offset(s + 1, s + 1), Size(s - 2, s - 2))
                    }
                } else if (icon == ActivityCardIcon.BOTTLE) {
                    Image(
                        painter = painterResource(R.drawable.ic_bottle),
                        contentDescription = "漂流瓶",
                        modifier = Modifier.size(36.dp),
                        colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(Color.White)
                    )
                } else if (icon == ActivityCardIcon.SERVER) {
                    Canvas(modifier = Modifier.size(30.dp)) {
                        val w = size.width; val h = size.height
                        val boxH = h * 0.7f; val boxW = w * 0.85f
                        val l = (w - boxW) / 2; val t = (h - boxH) / 2
                        val r = l + boxW; val b = t + boxH
                        val lineW = 1.8f
                        val body = Path().apply {
                            moveTo(l, t); lineTo(r, t); lineTo(r, b); lineTo(l, b); close()
                        }
                        drawPath(body, Color.White, style = Stroke(width = lineW))
                        drawLine(Color.White, Offset(l, t + boxH * 0.33f), Offset(r, t + boxH * 0.33f), strokeWidth = lineW)
                        drawLine(Color.White, Offset(l, t + boxH * 0.66f), Offset(r, t + boxH * 0.66f), strokeWidth = lineW)
                        drawCircle(Color.White, radius = 2.5f, center = Offset(l + 5f, t + boxH * 0.165f))
                        drawCircle(Color.White, radius = 2.5f, center = Offset(l + 5f, t + boxH * 0.5f))
                        drawCircle(Color.White, radius = 2.5f, center = Offset(l + 5f, t + boxH * 0.835f))
                    }
                } else if (icon == ActivityCardIcon.CALENDAR) {
                    Canvas(modifier = Modifier.size(30.dp)) {
                        val w = size.width; val h = size.height
                        val calW = w * 0.82f; val calH = h * 0.85f
                        val l = (w - calW) / 2; val t = (h - calH) / 2
                        val lineW = 1.8f
                        drawRoundRect(Color.White, Offset(l, t), Size(calW, calH),
                            CornerRadius(3.dp.toPx(), 3.dp.toPx()), style = Stroke(width = lineW))
                        drawLine(Color.White, Offset(l, t + calH * 0.34f), Offset(l + calW, t + calH * 0.34f), strokeWidth = lineW)
                        drawLine(Color.White, Offset(l + calW * 0.3f, t), Offset(l + calW * 0.3f, t - calH * 0.14f), strokeWidth = 2f)
                        drawLine(Color.White, Offset(l + calW * 0.7f, t), Offset(l + calW * 0.7f, t - calH * 0.14f), strokeWidth = 2f)
                        drawCircle(Color.White, radius = calW * 0.09f, center = Offset(l + calW * 0.5f, t + calH * 0.68f))
                    }
                } else if (icon == ActivityCardIcon.CROWN) {
                    Canvas(modifier = Modifier.size(30.dp)) {
                        val w = size.width; val h = size.height
                        val baseY = h * 0.82f; val topY = h * 0.28f
                        val path = Path().apply {
                            moveTo(w * 0.15f, baseY)
                            lineTo(w * 0.15f, topY + h * 0.16f)
                            lineTo(w * 0.35f, topY + h * 0.04f)
                            lineTo(w * 0.5f, topY)
                            lineTo(w * 0.65f, topY + h * 0.04f)
                            lineTo(w * 0.85f, topY + h * 0.16f)
                            lineTo(w * 0.85f, baseY)
                            close()
                        }
                        drawPath(path, Color.White)
                        drawCircle(Color.White, radius = w * 0.05f, center = Offset(w * 0.5f, topY + h * 0.02f))
                    }
                } else if (icon == ActivityCardIcon.WALLET) {
                    Text(
                        text = "￥",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.height(4.dp))
                Text(description, fontSize = 13.sp, color = Color(0xFF6B7280))
                if (statsLine != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(statsLine, fontSize = 12.sp, color = Color(0xFF1E40AF), fontWeight = FontWeight.Medium)
                }
            }
            Text("›", fontSize = 24.sp, color = Color(0xFF9CA3AF))
        }
    }
}

// ==================== 每日签到页面 ====================
// 后端已接入：签到接口 POST /api/activity/checkin 每天固定发放 5000 Token，计入永久余额；
// GET /api/activity/checkin/status 返回 first_checkin_date（首签锚点）/ checked_dates（窗口内已签日期）/
// streak / checked_today / token_balance / daily_rewards（7 天均为 5000）/ reward（本次发放）。
// 展示规则：以「首次签到日」为最左第一天（固定不动），连续签到从左到右依次排开；
// 断签的格标注「漏签」。每格仅显示数值（不带单位）；签到弹窗提示带单位「token」。
@Composable
private fun CheckInScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val loggedIn = AuroraApi.authToken != null
    val dateFmt = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()) }
    val prefs = remember { context.getSharedPreferences("aurora_checkin", android.content.Context.MODE_PRIVATE) }

    // 今天（归一化到 0 点）
    val todayCal = remember {
        java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
    }
    val todayKey = remember { "checkin_" + dateFmt.format(todayCal.time) }

    // 首签锚点（最左第一天），默认为今天；登录态下由后端 first_checkin_date 覆盖
    var anchorKey by remember { mutableStateOf(todayKey) }
    // 窗口内已签到的日期集合（key 形如 checkin_YYYY-MM-DD），用于判断每格是否「已签」
    var checkedSet by remember { mutableStateOf<Set<String>>(emptySet()) }
    var checkedToday by remember { mutableStateOf(prefs.getBoolean(todayKey, false)) }
    var streak by remember { mutableIntStateOf(0) }
    var tokenBalance by remember { mutableLongStateOf(0L) }
    // 每日档位（默认本地常量，登录态下由后端 daily_rewards 覆盖）
    var dailyRewards by remember { mutableStateOf(CHECKIN_REWARDS) }

    // 未登录时从本地 SharedPreferences 推算锚点与已签集合
    fun computeLocal() {
        val dates = prefs.all.keys
            .filter { it.startsWith("checkin_") && prefs.getBoolean(it, false) }
            .map { it.removePrefix("checkin_") }
            .sorted()
        if (dates.isNotEmpty()) anchorKey = "checkin_" + dates.first()
        checkedSet = dates.map { "checkin_" + it }.toSet()
    }

    // 连续签到天数（未登录时按本地记录推算）
    fun recomputeLocalStreak() {
        var s = 0
        val cur = todayCal.clone() as java.util.Calendar
        if (!prefs.getBoolean(todayKey, false)) cur.add(java.util.Calendar.DAY_OF_YEAR, -1)
        while (prefs.getBoolean("checkin_" + dateFmt.format(cur.time), false)) {
            s++; cur.add(java.util.Calendar.DAY_OF_YEAR, -1)
        }
        streak = s
    }

    // 将后端返回状态映射到本地展示状态
    fun applyStatus(json: org.json.JSONObject) {
        val d = if (json.has("data")) json.optJSONObject("data") ?: json else json
        if (d.has("checked_today")) checkedToday = d.getBoolean("checked_today")
        if (d.has("streak")) streak = d.getInt("streak")
        if (d.has("token_balance")) tokenBalance = d.getLong("token_balance")
        if (d.has("first_checkin_date")) {
            val f = d.optString("first_checkin_date", "")
            if (f.isNotEmpty() && f != "null") anchorKey = "checkin_" + f
        }
        if (d.has("checked_dates")) {
            val arr = d.optJSONArray("checked_dates")
            val set = mutableSetOf<String>()
            if (arr != null) for (i in 0 until arr.length()) set.add("checkin_" + arr.getString(i))
            checkedSet = set
        }
        if (d.has("daily_rewards")) {
            val arr = d.optJSONArray("daily_rewards")
            if (arr != null && arr.length() == 7) {
                val list = mutableListOf<Long>()
                for (i in 0 until arr.length()) list.add(arr.optLong(i, 0L))
                dailyRewards = list
            }
        }
    }

    fun loadStatus() {
        if (!loggedIn) return
        scope.launch {
            val res = AuroraApi.checkinStatus()
            if (res.success && res.data != null) applyStatus(res.data)
        }
    }

    LaunchedEffect(Unit) {
        if (!loggedIn) { computeLocal(); recomputeLocalStreak() }
        loadStatus()
    }

    fun doCheckIn() {
        if (checkedToday) return
        // 本地乐观更新（未登录 / 离线时作为回退记录）
        prefs.edit().putBoolean(todayKey, true).apply()
        checkedToday = true
        checkedSet = checkedSet + todayKey
        // 若为首次签到（或此前无锚点），锚点落到今天（最左第一天）
        if (anchorKey == todayKey || checkedSet.size == 1) anchorKey = todayKey
        if (!loggedIn) { recomputeLocalStreak(); return }
        scope.launch {
            val res = AuroraApi.checkin()
            if (res.success && res.data != null) {
                applyStatus(res.data)
                // 优先用后端返回的本次奖励；兜底按当前连续天数档位计算
                val granted = res.data?.optJSONObject("data")?.optLong("reward", 0L) ?: 0L
                val rw = if (granted > 0) granted else checkinRewardForDay(streak)
                Toast.makeText(context, "已获得 ${rw} token", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, res.message.ifBlank { "签到失败" }, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 展示窗口：以首签日为最左第一天，向右 7 格（anchor .. anchor+6）
    val anchorCal = remember(anchorKey) {
        val c = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
        try {
            val dateStr = anchorKey.removePrefix("checkin_")
            if (dateStr.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                dateFmt.parse(dateStr)?.let { c.time = it }
            }
        } catch (_: Exception) { /* 无效日期格式则保留 todayCal */ }
        c
    }
    val slots = (0..6).map { i ->
        val c = (anchorCal.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_YEAR, i) }
        val key = "checkin_" + dateFmt.format(c.time)
        val isToday = key == todayKey
        val isFuture = c.after(todayCal)
        val done = if (isToday) checkedToday else checkedSet.contains(key)
        val missed = !isFuture && !isToday && !done
        CheckInSlot(index = i, key = key, isToday = isToday, isFuture = isFuture, done = done, missed = missed)
    }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            // 顶部栏
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("←", fontSize = 24.sp, color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onBack() })
                Spacer(Modifier.weight(1f))
                Text("每日签到", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.weight(1f))
                Box(Modifier.width(48.dp))
            }

            Spacer(Modifier.height(16.dp))

            // 主卡片
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E40AF)),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("已连续签到", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("$streak 天", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    if (loggedIn) {
                        Spacer(Modifier.height(6.dp))
                        Text("我的 Token：$tokenBalance", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(20.dp))

                    if (checkedToday) {
                        // 已签到：展示打勾
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Canvas(modifier = Modifier.size(30.dp)) {
                                drawCircle(Color(0xFF22C55E), radius = size.minDimension / 2, center = center)
                                val p = size.minDimension * 0.26f
                                val path = Path().apply {
                                    moveTo(center.x - p, center.y)
                                    lineTo(center.x - p * 0.2f, center.y + p * 0.95f)
                                    lineTo(center.x + p, center.y - p * 0.85f)
                                }
                                drawPath(path, Color.White, style = Stroke(
                                    width = size.minDimension * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                            Spacer(Modifier.width(10.dp))
                            Text("今日已签到", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = { doCheckIn() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(26.dp),
                            modifier = Modifier.fillMaxWidth(0.7f)
                        ) {
                            Text("立即签到", color = Color(0xFF1E40AF), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(Modifier.height(28.dp))

            Text("连续签到打卡", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937),
                modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                slots.forEach { slot ->
                    CheckInCell(slot, dailyRewards.getOrElse(slot.index) { 0L }) {
                        if (slot.isToday && !slot.done) doCheckIn()
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

// 连续签到每日奖励：每天固定 5000，计入永久余额（原本余额 +5000，不随天数变化、不清零）。
// 与后端 checkinDailyRewards 保持一致。
private val CHECKIN_REWARDS = listOf(5000L, 5000L, 5000L, 5000L, 5000L, 5000L, 5000L)

// checkinRewardForDay 返回第 day 天（从 1 起）的奖励，每天固定 5000
private fun checkinRewardForDay(day: Int): Long {
    val d = if (day < 1) 1 else day
    return CHECKIN_REWARDS[(d - 1) % 7]
}

private data class CheckInSlot(
    val index: Int,
    val key: String,
    val isToday: Boolean,
    val isFuture: Boolean,
    val done: Boolean,
    val missed: Boolean
)

/** 单个签到格：已签=绿勾 / 漏签=红叉 / 未来=待打卡 / 今天未签=高亮「今天」；每格下方仅显示奖励数值（不带单位） */
@Composable
private fun CheckInCell(
    slot: CheckInSlot,
    reward: Long,
    onClick: () -> Unit
) {
    val bg = when {
        slot.done -> Color(0xFF22C55E)
        slot.isFuture -> Color(0xFFF3F4F6)
        slot.missed -> Color(0xFFFEE2E2)
        else -> Color(0xFFEFF6FF) // 今天未签：蓝色高亮
    }
    val subText = when {
        slot.done -> "已签"
        slot.missed -> "漏签"
        slot.isFuture -> "待打卡"
        else -> "今天"
    }
    val subColor = when {
        slot.done -> Color(0xFF22C55E)
        slot.missed -> Color(0xFFDC2626)
        slot.isFuture -> Color(0xFF9CA3AF)
        else -> Color(0xFF1E40AF)
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(enabled = slot.isToday && !slot.done, onClick = onClick)
    ) {
        Box(
            modifier = Modifier.size(40.dp).clip(CircleShape).background(bg),
            contentAlignment = Alignment.Center
        ) {
            when {
                slot.done -> Canvas(modifier = Modifier.size(22.dp)) {
                    val p = size.minDimension * 0.26f
                    val path = Path().apply {
                        moveTo(center.x - p, center.y)
                        lineTo(center.x - p * 0.2f, center.y + p * 0.95f)
                        lineTo(center.x + p, center.y - p * 0.85f)
                    }
                    drawPath(path, Color.White, style = Stroke(
                        width = size.minDimension * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                slot.missed -> Canvas(modifier = Modifier.size(22.dp)) {
                    val p = size.minDimension * 0.3f
                    val path = Path().apply {
                        moveTo(center.x - p, center.y - p)
                        lineTo(center.x + p, center.y + p)
                        moveTo(center.x + p, center.y - p)
                        lineTo(center.x - p, center.y + p)
                    }
                    drawPath(path, Color(0xFFDC2626), style = Stroke(
                        width = size.minDimension * 0.14f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                slot.isFuture -> Text("·", color = Color(0xFF9CA3AF), fontSize = 18.sp)
                else -> Text("今", color = Color(0xFF1E40AF), fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(reward.toString(), fontSize = 11.sp, color = if (slot.isToday) Color(0xFF1E40AF) else Color(0xFF9CA3AF))
        Text(subText, fontSize = 10.sp, color = subColor)
    }
}

// ==================== 会员中心页面 ====================
// 后端已接入：POST /api/member/open 开通会员（按 level 发放对应等级、有效期与欢迎 Token、授予徽章 13/14/15）；
// GET /api/member/status 查询当前会员状态；卡密(reward_type=member)核销逻辑在 handleValidateCardKey 中实现。
private data class MemberTier(
    val level: Int,        // 1=普通 2=高级 3=尊享
    val name: String,
    val price: String,     // 价格数字，如 "9.9"
    val unit: String,      // 计费单位，如 "元 / 月"
    val tokens: String,    // 赠送 AI 聊天 Token 数量（必选福利）
    val badgeRes: Int,     // 对应会员徽章图片
    val accent: Color,     // 主题强调色
    val highlight: Boolean,// 是否标记"推荐"
    val durationDays: Int, // 开通/续费有效期（天）
    val perks: List<String>// 更多特权（非必选）
)

@Composable
private fun MemberScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val loggedIn = AuroraApi.authToken != null

    // 当前会员状态（来自后端）
    var memberLevel by remember { mutableIntStateOf(0) }
    var memberExpiresAt by remember { mutableLongStateOf(0L) }
    var tokenBalance by remember { mutableLongStateOf(0L) }
    var showMemberOpen by remember { mutableStateOf<MemberTier?>(null) }

    // 三档会员：价格与福利（Token 为会员福利之一，其余为核心权益，可据实调整）
    val tiers = listOf(
        MemberTier(
            level = 1, name = "普通会员", price = "9.9", unit = "元 / 月",
            tokens = "200万", badgeRes = R.drawable.badge_member_1,
            accent = Color(0xFF1E40AF), highlight = false, durationDays = 30,
            perks = listOf("AI沙盒自定义功能增多", "AI数量可上调至10位", "可使用AI高级功能")
        ),
        MemberTier(
            level = 2, name = "高级会员", price = "49.9", unit = "元 / 3 个月",
            tokens = "1000万", badgeRes = R.drawable.badge_member_3,
            accent = Color(0xFF7C3AED), highlight = true, durationDays = 90,
            perks = listOf("AI沙盒自定义功能增多", "AI数量可上调至15位", "可使用AI高级功能", "官方客服服务")
        ),
        MemberTier(
            level = 3, name = "尊享会员", price = "168", unit = "元 / 年",
            tokens = "3500万", badgeRes = R.drawable.badge_member_2,
            accent = Color(0xFFB45309), highlight = false, durationDays = 365,
            perks = listOf("AI沙盒自定义功能增多", "AI数量可上调至20位", "可使用AI高级功能", "提供开发者服务")
        ),
    )

    fun applyStatus(json: org.json.JSONObject) {
        val d = if (json.has("data")) json.optJSONObject("data") ?: json else json
        if (d.has("member_level")) memberLevel = d.getInt("member_level")
        if (d.has("member_expires_at")) memberExpiresAt = d.getLong("member_expires_at")
        if (d.has("token_balance")) tokenBalance = d.getLong("token_balance")
        // 缓存服务器真实 token 余额，供聊天页“每天限额”显示真实值
        AiChatManager.cacheServerTokenBalance(context, AuroraApi.currentUserId, tokenBalance)
    }

    fun loadStatus() {
        if (!loggedIn) return
        scope.launch {
            val res = AuroraApi.memberStatus()
            if (res.success && res.data != null) applyStatus(res.data)
        }
    }

    LaunchedEffect(Unit) { loadStatus() }

    Box(Modifier.fillMaxSize().background(Color(0xFFF7F8FA))) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        ) {
            // 顶部栏
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("←", fontSize = 24.sp, color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onBack() })
                Spacer(Modifier.weight(1f))
                Text("会员中心", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.weight(1f))
                Box(Modifier.width(48.dp))
            }

            // 标题区
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("开通会员，畅享专属特权", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.height(6.dp))
                Text("每一档会员均包含：AI 聊天 Token（必选）+ 会员专属徽章（必选）", fontSize = 13.sp, color = Color(0xFF6B7280))
            }

            Spacer(Modifier.height(12.dp))

            // 当前会员状态（来自后端）
            if (loggedIn) {
                val levelName = listOf("未开通会员", "普通会员", "高级会员", "尊享会员")
                val expired = memberExpiresAt != 0L && System.currentTimeMillis() / 1000 > memberExpiresAt
                val expText = if (expired) "已过期" else if (memberExpiresAt == 0L) "永久有效" else {
                    val f = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                    "有效期至 ${f.format(java.util.Date(memberExpiresAt * 1000))}"
                }
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = if (memberLevel > 0 && !expired) Color(0xFFEFF6FF) else Color(0xFFF3F4F6))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (expired) "会员已过期" else levelName.getOrElse(memberLevel) { "未开通会员" }, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = if (memberLevel > 0 && !expired) Color(0xFF1E40AF) else Color(0xFF6B7280))
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(expText, fontSize = 12.sp, color = Color(0xFF6B7280))
                            Text("Token：$tokenBalance", fontSize = 12.sp, color = Color(0xFF6B7280))
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            // 会员档位卡片
            tiers.forEach { tier ->
                MemberTierCard(tier = tier) {
                    if (!loggedIn) {
                        Toast.makeText(context, "请先登录后再开通会员", Toast.LENGTH_SHORT).show()
                        return@MemberTierCard
                    }
                    showMemberOpen = tier
                }
                Spacer(Modifier.height(16.dp))
            }

            // 开通会员弹窗（扫码支付 + 填订单号提交审核）
            showMemberOpen?.let { t ->
                MemberOpenDialog(tier = t, onDismiss = { showMemberOpen = null })
            }

            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun MemberTierCard(tier: MemberTier, onBuy: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = if (tier.highlight) 6.dp else 2.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            // 头部：徽章 + 名称 + 等级 + 推荐标签
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = tier.badgeRes),
                    contentDescription = tier.name,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(tier.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                    Text("等级 Lv.${tier.level}", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                }
                if (tier.highlight) {
                    Surface(shape = RoundedCornerShape(6.dp), color = tier.accent) {
                        Text("推荐", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text("¥", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = tier.accent)
                Text(tier.price, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = tier.accent)
                Spacer(Modifier.width(4.dp))
                Text(tier.unit, fontSize = 13.sp, color = Color(0xFF6B7280), modifier = Modifier.padding(bottom = 4.dp))
            }

            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFFF0F1F3)))
            Spacer(Modifier.height(12.dp))

            Text("会员福利", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF374151))
            Spacer(Modifier.height(8.dp))

            // Token
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                Text("🪙", fontSize = 16.sp)
                Spacer(Modifier.width(8.dp))
                Text("赠送 AI 聊天 Token ${tier.tokens}", fontSize = 14.sp, color = Color(0xFF1F2937), modifier = Modifier.weight(1f))
            }
            // 会员徽章
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                Image(painter = painterResource(id = tier.badgeRes), contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("${tier.name}专属徽章", fontSize = 14.sp, color = Color(0xFF1F2937), modifier = Modifier.weight(1f))
            }

            Spacer(Modifier.height(8.dp))
            tier.perks.forEach { perk ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                    Text("✓", fontSize = 13.sp, color = tier.accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text(perk, fontSize = 13.sp, color = Color(0xFF4B5563))
                }
            }

            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onBuy,
                modifier = Modifier.fillMaxWidth().height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tier.accent),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("开通${tier.name}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

// 开通会员弹窗：应付金额 + 赞赏码二维码 + 订单号输入
@Composable
private fun MemberOpenDialog(tier: MemberTier, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var orderNo by remember { mutableStateOf("") }
    var submitting by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = { if (!submitting) onDismiss() }) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("开通${tier.name}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.height(12.dp))

                // (a) 顶部：应付金额
                Text("应付金额", fontSize = 13.sp, color = Color(0xFF6B7280))
                Text("¥ ${tier.price} ${tier.unit}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE74C3C))

                Spacer(Modifier.height(16.dp))

                // (b) 中部：赞赏码二维码
                Text("请扫码支付（赞赏码）", fontSize = 13.sp, color = Color(0xFF6B7280))
                Spacer(Modifier.height(8.dp))
                Image(
                    painter = painterResource(R.drawable.qr_reward),
                    contentDescription = "赞赏码",
                    modifier = Modifier.size(180.dp),
                    contentScale = ContentScale.Fit
                )

                Spacer(Modifier.height(16.dp))

                // (c) 底部：订单号输入
                OutlinedTextField(
                    value = orderNo,
                    onValueChange = { orderNo = it },
                    label = { Text("请输入微信转账单号（31或32位）") },
                    placeholder = { Text("微信转账单号，31或32位", fontSize = 13.sp, color = Color(0xFF9CA3AF)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(16.dp))

                Button(
                    onClick = {
                        val no = orderNo.trim()
                        if (no.isEmpty()) {
                            Toast.makeText(context, "请填写订单号", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        submitting = true
                        scope.launch {
                            try {
                                val res = AuroraApi.submitMemberOrder(
                                    tier.level, tier.durationDays,
                                    tier.price.toDoubleOrNull() ?: 0.0, no
                                )
                                if (res.success) {
                                    Toast.makeText(context, "订单已提交，等待审核", Toast.LENGTH_LONG).show()
                                    onDismiss()
                                } else {
                                    Toast.makeText(context, res.message.ifBlank { "提交失败" }, Toast.LENGTH_LONG).show()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "提交失败：${e.message}", Toast.LENGTH_LONG).show()
                            } finally {
                                submitting = false
                            }
                        }
                    },
                    enabled = !submitting,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)),
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (submitting) "提交中..." else "提交订单", color = Color.White, fontSize = 15.sp)
                }
            }
        }
    }
}

// ==================== 余额页面 ====================
// Token 充值汇率：1 元 = 30 万 Token（用于充值弹窗按 token 计算应付金额，最低 1 元起充）
private const val TOKENS_PER_YUAN = 450000L

@Composable
private fun BalanceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val loggedIn = AuroraApi.authToken != null

    var tokenBalance by remember { mutableLongStateOf(-1L) }
    var memberLevel by remember { mutableIntStateOf(0) }
    var memberExpiresAt by remember { mutableLongStateOf(0L) }
    var loading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf("") }
    // 充值弹窗状态
    var showRechargeDialog by remember { mutableStateOf(false) }
    var rechargeTokens by remember { mutableStateOf("") }
    var rechargeOrderNo by remember { mutableStateOf("") }
    var rechargeSubmitting by remember { mutableStateOf(false) }

    fun load() {
        if (!loggedIn) { errorMsg = "请先登录后查看余额"; return }
        loading = true; errorMsg = ""
        scope.launch {
            val res = AuroraApi.memberStatus()
            if (res.success && res.data != null) {
                val d = if (res.data!!.has("data")) res.data!!.optJSONObject("data") ?: res.data!! else res.data!!
                if (d.has("token_balance")) tokenBalance = d.getLong("token_balance")
                if (d.has("member_level")) memberLevel = d.getInt("member_level")
                if (d.has("member_expires_at")) memberExpiresAt = d.getLong("member_expires_at")
                AiChatManager.cacheServerTokenBalance(context, AuroraApi.currentUserId, tokenBalance)
                Toast.makeText(context, "余额已刷新", Toast.LENGTH_SHORT).show()
            } else {
                errorMsg = res.message
                Toast.makeText(context, "刷新失败：${res.message}", Toast.LENGTH_SHORT).show()
            }
            loading = false
        }
    }

    LaunchedEffect(Unit) { load() }

    Box(Modifier.fillMaxSize().background(Color(0xFFF7F8FA))) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            // 顶部栏
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("←", fontSize = 24.sp, color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onBack() })
                Spacer(Modifier.weight(1f))
                Text("我的余额", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.weight(1f))
                Text(if (loading) "刷新中..." else "刷新", fontSize = 14.sp, color = if (loading) Color(0xFF9CA3AF) else Color(0xFF1E40AF),
                    modifier = Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { if (!loading) load() })
            }

            Spacer(Modifier.height(12.dp))

            if (!loggedIn) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
                        Text("请先登录后查看 Token 余额", fontSize = 14.sp, color = Color(0xFF6B7280))
                    }
                }
            } else {
                // 余额卡片（渐变高亮）
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)
                        .clickable { showRechargeDialog = true },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.cardElevation(0.dp)
                ) {
                    Box(
                        Modifier.fillMaxWidth()
                            .background(
                                androidx.compose.ui.graphics.Brush.horizontalGradient(
                                    listOf(Color(0xFF1E40AF), Color(0xFF7C3AED))
                                )
                            )
                            .padding(24.dp)
                    ) {
                        Column {
                            Text("Token 余额", fontSize = 14.sp, color = Color.White.copy(alpha = 0.85f))
                            Spacer(Modifier.height(8.dp))
                            if (loading && tokenBalance < 0) {
                                Text("加载中…", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            } else {
                                Text(
                                    text = tokenBalance.toString(),
                                    fontSize = 38.sp, fontWeight = FontWeight.Bold, color = Color.White
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("个 Token", fontSize = 13.sp, color = Color.White.copy(alpha = 0.8f))
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("点击卡片充值", fontSize = 13.sp, color = Color.White.copy(alpha = 0.92f))
                                Spacer(Modifier.width(4.dp))
                                Text("›", fontSize = 18.sp, color = Color.White.copy(alpha = 0.92f))
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // 会员状态
                val levelName = listOf("未开通会员", "普通会员", "高级会员", "尊享会员")
                val expired = memberExpiresAt != 0L && System.currentTimeMillis() / 1000 > memberExpiresAt
                val expText = if (expired) "已过期" else if (memberExpiresAt == 0L) "未开通" else {
                    val f = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                    "有效期至 ${f.format(java.util.Date(memberExpiresAt * 1000))}"
                }
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (expired) "会员已过期" else levelName.getOrElse(memberLevel) { "未开通会员" }, fontSize = 15.sp,
                            fontWeight = FontWeight.Bold, color = if (memberLevel > 0 && !expired) Color(0xFF1E40AF) else Color(0xFF6B7280))
                        Spacer(Modifier.weight(1f))
                        Text(expText, fontSize = 12.sp, color = Color(0xFF6B7280))
                    }
                }

                if (errorMsg.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text(errorMsg, fontSize = 13.sp, color = Color(0xFFDC2626),
                        modifier = Modifier.padding(horizontal = 24.dp))
                }

                Spacer(Modifier.height(16.dp))
                Text(
                    "※ 余额为你账户的 Token 总数，对话消耗以官方接口统计为准。\n· 每日签到奖励（每天 5000）直接计入永久余额，可长期累积使用，不会被清零。\n· 会员、充值与卡密兑换获得的 Token 同样不会被清零。",
                    fontSize = 11.sp, color = Color(0xFF9CA3AF),
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                )
                Spacer(Modifier.height(20.dp))
            }
        }
    }
    // 充值弹窗：输入 token 数量与支付订单号，自动计算金额（最低 1 元起充），提交后由开发者审核
    if (showRechargeDialog) {
        AlertDialog(
            onDismissRequest = { if (!rechargeSubmitting) showRechargeDialog = false },
            containerColor = Color.White,
            title = { Text("充值 Token", fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    OutlinedTextField(
                        value = rechargeTokens,
                        onValueChange = { rechargeTokens = it.filter { c -> c.isDigit() }.take(12) },
                        label = { Text("充值 Token 数量") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    // 收款二维码（与会员开通一致的赞赏码）
                    Text("请扫码支付", fontSize = 13.sp, color = Color(0xFF6B7280))
                    Spacer(Modifier.height(8.dp))
                    Image(
                        painter = painterResource(R.drawable.qr_reward),
                        contentDescription = "收款码",
                        modifier = Modifier.size(180.dp),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = rechargeOrderNo,
                        onValueChange = { rechargeOrderNo = it.trim() },
                        label = { Text("支付订单号") },
                        placeholder = { Text("微信支付订单号", fontSize = 13.sp, color = Color(0xFF9CA3AF)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("请填写微信支付完成后的订单号", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                    Spacer(Modifier.height(10.dp))
                    val tk = rechargeTokens.toLongOrNull() ?: 0L
                    val amt = if (tk > 0) (tk.toDouble() / TOKENS_PER_YUAN) else 0.0
                    Text("应付金额：¥%.2f".format(amt), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                    if (tk > 0 && amt < 1.0) {
                        Spacer(Modifier.height(4.dp))
                        Text("最低 1 元起充（至少 ${TOKENS_PER_YUAN} Token）", fontSize = 12.sp, color = Color(0xFFDC2626))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("提交后由开发者审核，通过后 Token 自动到账。", fontSize = 11.sp, color = Color(0xFF9CA3AF))
                }
            },
            confirmButton = {
                Button(
                    enabled = !rechargeSubmitting && (rechargeTokens.toLongOrNull() ?: 0) >= TOKENS_PER_YUAN && rechargeOrderNo.isNotBlank(),
                    onClick = {
                        val tk = rechargeTokens.toLongOrNull() ?: 0
                        val amt = tk.toDouble() / TOKENS_PER_YUAN
                        rechargeSubmitting = true
                        scope.launch {
                            val r = com.aurora.chat.data.api.AuroraApi.submitRechargeOrder(tk, amt, rechargeOrderNo.trim())
                            rechargeSubmitting = false
                            if (r.success) {
                                showRechargeDialog = false
                                rechargeTokens = ""
                                rechargeOrderNo = ""
                                android.widget.Toast.makeText(context, "订单已提交，等待审核", android.widget.Toast.LENGTH_SHORT).show()
                            } else {
                                android.widget.Toast.makeText(context, r.message, android.widget.Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                ) { Text(if (rechargeSubmitting) "提交中..." else "提交订单") }
            },
            dismissButton = {
                TextButton(onClick = { if (!rechargeSubmitting) showRechargeDialog = false }) { Text("取消", color = Color(0xFF6B7280)) }
            }
        )
    }
}
