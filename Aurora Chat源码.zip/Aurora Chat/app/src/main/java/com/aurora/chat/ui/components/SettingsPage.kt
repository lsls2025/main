package com.aurora.chat.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.launch
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.aurora.chat.R
import java.io.File
import java.io.FileOutputStream

enum class AnimationMode(val value: Int, val label: String) {
    NONE(0, "无动画"),
    LEFT_RIGHT(1, "左右滑出"),
    BOTTOM_RIGHT(2, "下方滑出")
}

// ===================== 壁纸数据模型 & 存储 =====================

/** 壁纸类型 */
enum class WallpaperType(val value: String) {
    DEFAULT("default"),   // 默认白色
    PRESET("preset"),     // 内置图片
    CUSTOM("custom")      // 用户自定义上传
}

/** 内置壁纸信息 */
data class PresetWallpaper(val resId: Int, val label: String)

object WallpaperStorage {
    private const val PREFS = "aurora_wallpaper"
    private const val CUSTOM_DIR = "wallpapers"

    fun getPrefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** 当前壁纸类型 */
    fun getType(context: Context): String =
        getPrefs(context).getString("type", WallpaperType.DEFAULT.value) ?: WallpaperType.DEFAULT.value

    fun setType(context: Context, type: String) {
        getPrefs(context).edit().putString("type", type).apply()
    }

    /** 内置壁纸索引 (1-4) */
    fun getPresetIndex(context: Context): Int =
        getPrefs(context).getInt("preset_index", 0)

    fun setPresetIndex(context: Context, index: Int) {
        getPrefs(context).edit().putInt("preset_index", index).apply()
    }

    /** 自定义文件路径（内部存储） */
    fun getCustomFilePath(context: Context): String {
        val dir = File(context.filesDir, CUSTOM_DIR)
        val file = File(dir, "custom_data")
        return file.absolutePath
    }

    /** 自定义媒体类型 "image" 或 "video" */
    fun getCustomType(context: Context): String =
        getPrefs(context).getString("custom_type", "image") ?: "image"

    fun setCustomType(context: Context, type: String) {
        getPrefs(context).edit().putString("custom_type", type).apply()
    }

    fun saveCustomFile(context: Context, uri: Uri): Boolean {
        return try {
            val dir = File(context.filesDir, CUSTOM_DIR)
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "custom_data")
            val inputStream = context.contentResolver.openInputStream(uri) ?: return false
            FileOutputStream(file).use { output ->
                inputStream.copyTo(output)
            }
            inputStream.close()
            true
        } catch (e: Exception) {
            false
        }
    }

    /** 加载自定义图片 Bitmap */
    fun loadCustomBitmap(context: Context): Bitmap? {
        val file = File(getCustomFilePath(context))
        return if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
    }

    /** 是否全屏模式（覆盖顶部/底部导航栏） */
    fun isFullscreen(context: Context): Boolean =
        getPrefs(context).getBoolean("fullscreen", false)

    fun setFullscreen(context: Context, full: Boolean) {
        getPrefs(context).edit().putBoolean("fullscreen", full).apply()
    }

    /** 是否去除分割线 */
    fun isDividerHidden(context: Context): Boolean =
        getPrefs(context).getBoolean("no_divider", false)

    fun setDividerHidden(context: Context, hide: Boolean) {
        getPrefs(context).edit().putBoolean("no_divider", hide).apply()
    }

    /** 视频背景是否开启声音 */
    fun isVideoSoundOn(context: Context): Boolean =
        getPrefs(context).getBoolean("video_sound", false)

    fun setVideoSound(context: Context, on: Boolean) {
        getPrefs(context).edit().putBoolean("video_sound", on).apply()
    }

    /** 重置为默认 */
    fun resetToDefault(context: Context) {
        setType(context, WallpaperType.DEFAULT.value)
        setPresetIndex(context, 0)
        // 不删除自定义图片，用户重选时可能会再用
    }
}

/** 内置 4 张壁纸 */
val presetWallpapers = listOf(
    R.drawable.wallpaper_1,
    R.drawable.wallpaper_2,
    R.drawable.wallpaper_3,
    R.drawable.wallpaper_4,
)

// ===================== 设置页面 =====================

@Composable
fun SettingsPage(
    currentAnimMode: AnimationMode,
    onAnimModeSelect: (AnimationMode) -> Unit,
    advancedAnim: Boolean,
    onAdvancedToggle: (Boolean) -> Unit,
    onClose: () -> Unit,
    onWallpaperChanged: () -> Unit = {},
    isDeveloper: Boolean = false,
    onDeveloperManagementClick: () -> Unit = {},
    onSwitchAccount: () -> Unit = {},
    onLogout: () -> Unit = {},
    onOpenKeepAlive: () -> Unit = {},
    onClearCache: () -> Unit = {},
    onClearData: () -> Unit = {},
    onOpenErrorLog: () -> Unit = {},
    onOpenCrashIntercept: () -> Unit = {},
    currentAccount: String = "",
    onAccountDeleted: () -> Unit = {}
) {
    var showAnimDialog by remember { mutableStateOf(false) }
    var showWallpaperDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(280.dp)
            .background(MaterialTheme.colorScheme.surface)
            .padding(top = 24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "设置",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "✕",
                fontSize = 20.sp,
                color = Color(0xFF9CA3AF),
                modifier = Modifier.clickable { onClose() }
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // ── 消息动画 ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showAnimDialog = true }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "消息动画", fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(modifier = Modifier.weight(1f))
            val modeLabel = if (currentAnimMode == AnimationMode.NONE) "无动画"
                else "${currentAnimMode.label}${if (advancedAnim) " + 高级" else ""} ›"
            Text(text = modeLabel, fontSize = 14.sp, color = Color(0xFF9CA3AF))
        }

        // ── 应用背景 ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showWallpaperDialog = true }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "应用背景", fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(modifier = Modifier.weight(1f))
            val type = WallpaperStorage.getType(context)
            val label = when (type) {
                WallpaperType.PRESET.value -> "壁纸 ${WallpaperStorage.getPresetIndex(context) + 1}"
                WallpaperType.CUSTOM.value -> "自定义"
                else -> "默认"
            }
            Text(text = "$label ›", fontSize = 14.sp, color = Color(0xFF9CA3AF))
        }

        // ── 分割线 ──
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))

        // ── 后台保活（占位行，点击跳转到独立面板） ──
        Row(
            modifier = Modifier.fillMaxWidth().clickable { onOpenKeepAlive() }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "后台保活", fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(Modifier.weight(1f))
            val activeCount = listOf(
                com.aurora.chat.KeepAliveManager.isLayer1Enabled(context),
                com.aurora.chat.KeepAliveManager.isLayer2Enabled(context),
                com.aurora.chat.KeepAliveManager.isLayer3Enabled(context)
            ).count { it }
            Text(text = "${activeCount}/3 层已开启 ›", fontSize = 14.sp, color = Color(0xFF9CA3AF))
        }

    // ── 分割线 ──
    Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))
        // 错误日志
        Row(Modifier.fillMaxWidth().clickable { onOpenErrorLog() }
            .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(text = "错误日志", fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(Modifier.weight(1f))
            Text(text = "›", fontSize = 18.sp, color = Color(0xFF9CA3AF))
        }
        // 闪退拦截
        Row(Modifier.fillMaxWidth().clickable { onOpenCrashIntercept() }
            .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(text = "闪退拦截", fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(Modifier.weight(1f))
            Text(text = "›", fontSize = 18.sp, color = Color(0xFF9CA3AF))
        }
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))
        // 清理缓存
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onClearCache() }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "清理缓存", fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(modifier = Modifier.weight(1f))
            Text(text = "›", fontSize = 18.sp, color = Color(0xFF9CA3AF))
        }
        // 清空数据（无分割线）
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onClearData() }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "清空数据", fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(modifier = Modifier.weight(1f))
            Text(text = "›", fontSize = 18.sp, color = Color(0xFF9CA3AF))
        }
        // 开发者管理（仅开发者可见）
        if (isDeveloper) {
            Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onDeveloperManagementClick() }
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "开发者管理", fontSize = 16.sp, color = Color(0xFF1F2937))
                Spacer(modifier = Modifier.weight(1f))
                Text(text = "›", fontSize = 18.sp, color = Color(0xFF9CA3AF))
            }
        }
        // ── 分割线 ──
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSwitchAccount() }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "切换账号", fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(modifier = Modifier.weight(1f))
            Text(text = "›", fontSize = 18.sp, color = Color(0xFF9CA3AF))
        }

        // ── 退出登录 ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onLogout() }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "退出登录", fontSize = 16.sp, color = Color(0xFF1F2937))
            Spacer(modifier = Modifier.weight(1f))
            Text(text = "›", fontSize = 18.sp, color = Color(0xFF9CA3AF))
        }

        // ── 分割线 ──
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))
        // ── 注销账号（危险操作，红色） ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showDeleteDialog = true }
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "注销账号", fontSize = 16.sp, color = Color(0xFFDC2626))
            Spacer(modifier = Modifier.weight(1f))
            Text(text = "›", fontSize = 18.sp, color = Color(0xFFDC2626))
        }
    }

    if (showDeleteDialog) {
        DeleteAccountDialog(
            account = currentAccount,
            onDismiss = { showDeleteDialog = false },
            onSuccess = onAccountDeleted
        )
    }

    if (showAnimDialog) {
        AnimationSettingDialog(
            currentMode = currentAnimMode,
            onSelect = { onAnimModeSelect(it) },
            advancedAnim = advancedAnim,
            onAdvancedToggle = onAdvancedToggle,
            onDismiss = { showAnimDialog = false }
        )
    }

    if (showWallpaperDialog) {
        WallpaperPickerDialog(
            onSelect = {
                showWallpaperDialog = false
                onWallpaperChanged()
                Toast.makeText(context, "应用背景已更新", Toast.LENGTH_SHORT).show()
            },
            onCancel = { showWallpaperDialog = false }
        )
    }
}

// ===================== 注销账号弹窗 =====================

@Composable
private fun DeleteAccountDialog(
    account: String,
    onDismiss: () -> Unit,
    onSuccess: () -> Unit
) {
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = { if (!isLoading) onDismiss() }) {
        Surface(
            modifier = Modifier.fillMaxWidth().wrapContentHeight(),
            shape = RoundedCornerShape(16.dp),
            color = Color.White
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("注销账号", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.height(8.dp))
                Text("此操作将永久删除该账号的所有数据（含 QQ 号与邮箱），且不可恢复。", fontSize = 13.sp, color = Color(0xFF6B7280))
                Spacer(Modifier.height(18.dp))

                // 账号（只读确认）
                OutlinedTextField(
                    value = account,
                    onValueChange = {},
                    label = { Text("账号") },
                    readOnly = true,
                    enabled = false,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFDC2626),
                        cursorColor = Color(0xFFDC2626)
                    )
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; errorMsg = null },
                    label = { Text("密码（必填）") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFDC2626),
                        cursorColor = Color(0xFFDC2626)
                    )
                )

                if (errorMsg != null) {
                    Spacer(Modifier.height(10.dp))
                    Text(errorMsg!!, fontSize = 13.sp, color = Color(0xFFDC2626))
                }

                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text("取消", fontSize = 15.sp, color = Color(0xFF9CA3AF),
                        modifier = Modifier.clickable { if (!isLoading) onDismiss() }
                            .padding(horizontal = 16.dp, vertical = 8.dp))
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (password.isBlank()) { errorMsg = "请输入密码"; return@Button }
                            isLoading = true
                            errorMsg = null
                            scope.launch {
                                try {
                                    val r = com.aurora.chat.data.api.AuroraApi.selfDeleteAccount(password)
                                    if (r.success) {
                                        onSuccess()
                                    } else {
                                        errorMsg = r.message ?: "注销失败"
                                        isLoading = false
                                    }
                                } catch (e: Exception) {
                                    errorMsg = e.message ?: "注销失败"
                                    isLoading = false
                                }
                            }
                        },
                        modifier = Modifier.height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        enabled = !isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Text("确认注销", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

// ===================== 壁纸选择弹窗 =====================

@Composable
private fun WallpaperPickerDialog(
    onSelect: () -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current

    // 当前选择状态
    var selectedType by remember { mutableStateOf(WallpaperStorage.getType(context)) }
    var selectedPreset by remember { mutableStateOf(WallpaperStorage.getPresetIndex(context)) }
    var customBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var customExists by remember { mutableStateOf(File(WallpaperStorage.getCustomFilePath(context)).exists()) }

    // 自定义文件上传（图片/视频）
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val mimeType = context.contentResolver.getType(uri) ?: ""
            val saved = WallpaperStorage.saveCustomFile(context, uri)
            if (saved) {
                val isVideo = mimeType.startsWith("video/")
                WallpaperStorage.setCustomType(context, if (isVideo) "video" else "image")
                customBitmap = WallpaperStorage.loadCustomBitmap(context)
                customExists = true
                selectedType = WallpaperType.CUSTOM.value
                Toast.makeText(context, if (isVideo) "视频已设为背景" else "图片已设为背景", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "文件保存失败", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 初次加载自定义内容
    LaunchedEffect(customExists) {
        if (customExists) {
            customBitmap = WallpaperStorage.loadCustomBitmap(context)
        }
    }

    Dialog(onDismissRequest = onCancel) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(16.dp))
                .padding(24.dp)
        ) {
            // ── 标题栏：应用背景 + 恢复默认 ──
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("应用背景", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.weight(1f))
                Text(
                    "恢复默认",
                    fontSize = 14.sp,
                    color = Color(0xFF1E40AF),
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable {
                        WallpaperStorage.resetToDefault(context)
                        selectedType = WallpaperType.DEFAULT.value
                        selectedPreset = 0
                    }.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            Spacer(Modifier.height(12.dp))

            // ── 横向滑动壁纸列表 ──
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // 默认（白色）
                item {
                    WallpaperThumb(
                        isSelected = selectedType == WallpaperType.DEFAULT.value,
                        modifier = Modifier.width(130.dp),
                        onTap = { selectedType = WallpaperType.DEFAULT.value }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.White)
                        )
                    }
                }

                // 四张内置壁纸
                itemsIndexed(presetWallpapers) { index, resId ->
                    WallpaperThumb(
                        isSelected = selectedType == WallpaperType.PRESET.value && selectedPreset == index,
                        modifier = Modifier.width(130.dp),
                        onTap = {
                            selectedType = WallpaperType.PRESET.value
                            selectedPreset = index
                        }
                    ) {
                        Image(
                            painter = androidx.compose.ui.res.painterResource(resId),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // 自定义
                item {
                    WallpaperThumb(
                        isSelected = selectedType == WallpaperType.CUSTOM.value,
                        modifier = Modifier.width(130.dp),
                        onTap = {
                            selectedType = WallpaperType.CUSTOM.value
                            filePickerLauncher.launch("*/*")
                        }
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize().background(Color(0xFFF3F4F6)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (customExists && customBitmap != null) {
                                Image(
                                    bitmap = customBitmap!!.asImageBitmap(),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Text("自定义", fontSize = 12.sp, color = Color(0xFF6B7280))
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ── 全屏切换 ──
            var isFull by remember { mutableStateOf(WallpaperStorage.isFullscreen(context)) }
            var showFullHelp by remember { mutableStateOf(false) }
            Row(
                modifier = Modifier.fillMaxWidth().clickable { isFull = !isFull },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("全屏", fontSize = 14.sp, color = Color(0xFF1F2937))
                Spacer(Modifier.width(6.dp))
                Text("?", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable { showFullHelp = true })
                Spacer(Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                        .background(if (isFull) Color(0xFF1E40AF) else Color(0xFFD1D5DB)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isFull) Text("✓", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
            // ── 视频声音 ──
            var videoSound by remember { mutableStateOf(WallpaperStorage.isVideoSoundOn(context)) }
            Row(
                modifier = Modifier.fillMaxWidth().clickable { videoSound = !videoSound },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("视频声音", fontSize = 14.sp, color = Color(0xFF1F2937))
                Spacer(Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                        .background(if (videoSound) Color(0xFF1E40AF) else Color(0xFFD1D5DB)),
                    contentAlignment = Alignment.Center
                ) {
                    if (videoSound) Text("✓", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            // ── 去除分割线 ──
            var noDivider by remember { mutableStateOf(WallpaperStorage.isDividerHidden(context)) }
            Row(
                modifier = Modifier.fillMaxWidth().clickable { noDivider = !noDivider },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("去除分割线", fontSize = 14.sp, color = Color(0xFF1F2937))
                Spacer(Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                        .background(if (noDivider) Color(0xFF1E40AF) else Color(0xFFD1D5DB)),
                    contentAlignment = Alignment.Center
                ) {
                    if (noDivider) Text("✓", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            // 确认按钮记得保存 noDivider
            if (showFullHelp) {
                Dialog(onDismissRequest = { showFullHelp = false }) {
                    Column(
                        modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(24.dp)
                    ) {
                        Text("全屏模式", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                        Spacer(Modifier.height(12.dp))
                        Text("开启后壁纸将铺满整个屏幕，覆盖顶部标题栏和底部导航栏。关闭则壁纸只显示在中间内容区域。",
                            fontSize = 14.sp, lineHeight = 22.sp, color = Color(0xFF6B7280))
                        Spacer(Modifier.height(20.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Text("知道了", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1E40AF),
                                modifier = Modifier.clickable { showFullHelp = false }
                                    .padding(horizontal = 16.dp, vertical = 8.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ── 操作按钮 ──
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Text("取消", fontSize = 15.sp, color = Color(0xFF9CA3AF),
                    modifier = Modifier
                        .clickable { onCancel() }
                        .padding(horizontal = 16.dp, vertical = 8.dp))
                Spacer(Modifier.width(8.dp))
                Text("确认", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1E40AF),
                    modifier = Modifier
                        .clickable {
                            WallpaperStorage.setFullscreen(context, isFull)
                            WallpaperStorage.setVideoSound(context, videoSound)
                            WallpaperStorage.setDividerHidden(context, noDivider)
                            WallpaperStorage.setType(context, selectedType)
                            if (selectedType == WallpaperType.PRESET.value) {
                                WallpaperStorage.setPresetIndex(context, selectedPreset)
                            }
                            onSelect()
                        }
                        .padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }
    }
}

// ===================== 壁纸缩略图组件 =====================

@Composable
private fun WallpaperThumb(
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onTap: () -> Unit = {},
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .aspectRatio(9f / 16f)
            .clip(RoundedCornerShape(10.dp))
            .then(if (isSelected) Modifier.border(3.dp, Color(0xFF1E40AF), RoundedCornerShape(10.dp)) else Modifier)
            .clickable { onTap() }
    ) {
        content()
    }
}

// ===================== 动画设置弹窗（不变） =====================

@Composable
private fun AnimationSettingDialog(
    currentMode: AnimationMode,
    onSelect: (AnimationMode) -> Unit,
    advancedAnim: Boolean,
    onAdvancedToggle: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var showAdvancedInfo by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(16.dp))
                .padding(top = 24.dp, bottom = 16.dp)
        ) {
            Text(
                text = "消息动画",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937),
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            listOf(AnimationMode.NONE, AnimationMode.LEFT_RIGHT, AnimationMode.BOTTOM_RIGHT).forEach { mode ->
                val isSelected = currentMode == mode
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(mode) }
                        .padding(horizontal = 24.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = mode.label, fontSize = 15.sp, color = Color(0xFF1F2937), modifier = Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color(0xFF1E40AF) else Color(0xFFD1D5DB)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSelected) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color.White))
                        }
                    }
                }
            }

            Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp).height(1.dp).background(Color(0xFFE5E7EB)))
            Spacer(Modifier.height(4.dp))

            val advancedEnabled = currentMode != AnimationMode.NONE
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (advancedEnabled) Modifier.clickable { onAdvancedToggle(!advancedAnim) } else Modifier)
                    .padding(horizontal = 24.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("高级动画", fontSize = 15.sp, color = if (advancedEnabled) Color(0xFF1F2937) else Color(0xFFD1D5DB))
                Spacer(Modifier.width(6.dp))
                Text("?", fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    color = if (advancedEnabled) Color(0xFF1E40AF) else Color(0xFFD1D5DB),
                    modifier = if (advancedEnabled) Modifier.clickable { showAdvancedInfo = true } else Modifier)
                Spacer(Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                        .background(if (advancedEnabled && advancedAnim) Color(0xFF1E40AF) else Color(0xFFD1D5DB)),
                    contentAlignment = Alignment.Center
                ) {
                    if (advancedEnabled && advancedAnim) Text("✓", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }

    if (showAdvancedInfo) {
        Dialog(onDismissRequest = { showAdvancedInfo = false }) {
            Column(
                modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(24.dp)
            ) {
                Text("高级动画", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.height(12.dp))
                Text("该选项可多选，可配合左右滑出、右下滑出、开启后每次进入对话或查看以往消息都将触发动画。",
                    fontSize = 14.sp, lineHeight = 22.sp, color = Color(0xFF6B7280))
                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text("取消", fontSize = 15.sp, color = Color(0xFF9CA3AF),
                        modifier = Modifier.clickable { showAdvancedInfo = false }.padding(horizontal = 16.dp, vertical = 8.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("好的", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1E40AF),
                        modifier = Modifier.clickable { showAdvancedInfo = false }.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }
        }
    }
}
