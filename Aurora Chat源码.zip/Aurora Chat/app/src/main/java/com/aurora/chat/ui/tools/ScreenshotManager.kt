package com.aurora.chat.ui.tools

import android.content.Context
import android.graphics.BitmapFactory

/**
 * 截图管理 - 从 assets/screenshots/[appName]/ 目录读取截图（打包在 APK 内部）
 *
 * 目录结构：app/src/main/assets/screenshots/[appName]/screenshot_1.jpg ...
 * 通过 [Context.getAssets] 动态列举，新增截图放入对应目录即可，无需改代码；
 * 同时消除原 `when` 硬编码编号导致的「编号空洞」与「指向不存在目录」的死分支。
 */
object ScreenshotManager {

    /** 获取某个应用的所有截图文件路径（assets 路径），按文件名自然排序 */
    fun getScreenshotAssetsPaths(context: Context, appName: String): List<String> {
        val sub = findScreenshotDir(context, appName) ?: return emptyList()
        val files = context.assets.list(sub) ?: return emptyList()
        return files
            .filter { it.endsWith(".jpg", true) || it.endsWith(".png", true) }
            .sortedWith(naturalComparator)
            .map { "$sub/$it" }
    }

    /** 在 assets/screenshots/ 下按名称（大小写不敏感）查找应用目录 */
    private fun findScreenshotDir(context: Context, appName: String): String? {
        val base = "screenshots"
        val entries = context.assets.list(base) ?: return null
        val target = appName.lowercase().trim()
        val exact = entries.firstOrNull { it.lowercase() == target }
        if (exact != null) return "$base/$exact"
        val partial = entries.firstOrNull { it.lowercase().contains(target) }
        return partial?.let { "$base/$it" }
    }

    /** 自然排序：Q1 < Q2 < Q10，screenshot_1 < screenshot_2 < screenshot_10 */
    private val naturalComparator = Comparator<String> { a, b ->
        val pa = splitChunks(a)
        val pb = splitChunks(b)
        val len = if (pa.size < pb.size) pa.size else pb.size
        for (i in 0 until len) {
            val na = pa[i].toIntOrNull()
            val nb = pb[i].toIntOrNull()
            val cmp = if (na != null && nb != null) na.compareTo(nb) else pa[i].compareTo(pb[i])
            if (cmp != 0) return@Comparator cmp
        }
        pa.size.compareTo(pb.size)
    }

    private fun splitChunks(s: String): List<String> {
        return Regex("(\\d+|\\D+)").findAll(s).map { it.value }.toList()
    }

    /** 从 assets 路径加载 Bitmap */
    fun loadBitmapFromAssets(context: Context, assetPath: String): android.graphics.Bitmap? {
        return try {
            context.assets.open(assetPath).use { inputStream ->
                BitmapFactory.decodeStream(inputStream)
            }
        } catch (_: Exception) {
            null
        }
    }

    /** 带采样解码（避免全尺寸解码内存峰值），maxDim 为解码后最大边长上限 */
    fun loadBitmapFromAssetsSampled(context: Context, assetPath: String, maxDim: Int = 1024): android.graphics.Bitmap? {
        return try {
            context.assets.open(assetPath).use { inputStream ->
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeStream(inputStream, null, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
                var inSampleSize = 1
                while (bounds.outWidth / inSampleSize >= maxDim || bounds.outHeight / inSampleSize >= maxDim) {
                    inSampleSize *= 2
                }
                val opts = BitmapFactory.Options().apply { this.inSampleSize = inSampleSize }
                context.assets.open(assetPath).use { s2 ->
                    BitmapFactory.decodeStream(s2, null, opts)
                }
            }
        } catch (_: Exception) {
            null
        }
    }
}
