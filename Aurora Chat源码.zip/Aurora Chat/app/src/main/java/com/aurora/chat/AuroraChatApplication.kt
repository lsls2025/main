package com.aurora.chat

import android.app.Application
import coil.Coil
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.aurora.chat.util.SignatureValidator
import java.io.File

class AuroraChatApplication : Application() {
    companion object {
        lateinit var instance: AuroraChatApplication
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        CrashHandler.init(this)
        ErrorReporter.init(this)

        // 初始化签名校验（打印当前签名供开发者配置）
        SignatureValidator.printActualSignature(this)

        // 配置 Coil 全局图片加载器：内存缓存 + 200MB 磁盘缓存
        val imageLoader = ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(cacheDir, "image_cache"))
                    .maxSizeBytes(200L * 1024 * 1024)
                    .build()
            }
            .build()
        Coil.setImageLoader(imageLoader)
    }
}
