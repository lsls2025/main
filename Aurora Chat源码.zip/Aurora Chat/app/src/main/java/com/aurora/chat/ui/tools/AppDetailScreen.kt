﻿package com.aurora.chat.ui.tools

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import coil.compose.AsyncImage
import com.aurora.chat.R
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.ui.components.UserAvatar

/** 应用评论数据类 */
private data class AppComment(
    val id: Long,
    val user_id: Long,
    val username: String,
    val content: String,
    val created_at: Long
)

/** 全屏图片查看器（支持本地 assets 与网络 URL） */
@Composable
fun FullScreenImageViewer(
    imageSources: List<String>,
    assetBitmaps: List<Bitmap?>,
    initialIndex: Int,
    onDismiss: () -> Unit
) {
    if (imageSources.isEmpty()) return
    val pagerState = rememberPagerState(pageCount = { imageSources.size }, initialPage = initialIndex)
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            val source = imageSources.getOrNull(page) ?: return@HorizontalPager
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (source.startsWith("http")) {
                    AsyncImage(
                        model = source,
                        contentDescription = "截图 ${page + 1}",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    val bmp = assetBitmaps.getOrNull(page)
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "截图 ${page + 1}",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Text("加载失败", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 16.dp, vertical = 12.dp).statusBarsPadding(),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)).clickable { onDismiss() },
                contentAlignment = Alignment.Center) {
                Text("✕", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Text("${pagerState.currentPage + 1} / ${imageSources.size}", color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.size(36.dp))
        }
    }
}


/**
 * 应用详情页 - 从右侧滑入覆盖全屏
 */
@Composable
fun AppDetailScreen(
    tool: ToolItem,
    screenshotPaths: List<String>,
    onBack: () -> Unit,
    onCheckVersion: () -> Unit = {},
    onUserClick: (Long, String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showFullImage by remember { mutableStateOf(false) }
    var fullImageIndex by remember { mutableStateOf(0) }
    var realFileSize by remember { mutableStateOf(0L) }
    var isAppInstalled by remember { mutableStateOf<Boolean?>(null) }
    val isAuroraChat = tool.name == "Aurora Chat"
    // 版本历史
    var oldVersions by remember { mutableStateOf<List<org.json.JSONObject>>(emptyList()) }
    var showVersionPicker by remember { mutableStateOf(false) }
    var selectedVersion by remember { mutableStateOf(tool.version) }
    var selectedDownloadUrl by remember { mutableStateOf(tool.downloadUrl) }
    var selectedChangelog by remember { mutableStateOf(tool.changelog) }
    var showChangelogDialog by remember { mutableStateOf(false) }
    var selectedVersionId by remember { mutableStateOf(0L) }  // 0 = 当前版本
    // 版本切换时同步更新的展示数据
    var displayVersion by remember { mutableStateOf(tool.version) }
    var displayDownloadUrl by remember { mutableStateOf(tool.downloadUrl) }
    var displayIconUrl by remember { mutableStateOf("") }
    var displayScreenshots by remember { mutableStateOf(tool.screenshotUrls) }
    var displayDescription by remember { mutableStateOf(tool.description) }
    var displayFileSize by remember { mutableStateOf(tool.fileSizeBytes) }
    // 评论
    val appId = tool.userAppId
    var comments by remember { mutableStateOf(listOf<AppComment>()) }
    var commentInput by remember { mutableStateOf("") }
    var commentLoading by remember { mutableStateOf(false) }
    var commentTotal by remember { mutableStateOf(0) }
    var showCommentInput by remember { mutableStateOf(false) }
    // 加载评论
    LaunchedEffect(appId) {
        if (appId > 0) {
            val r = AuroraApi.getAppComments(appId)
            if (r.success && r.data != null) {
                comments = r.data.comments.map { AppComment(it.id, it.user_id, it.username, it.content, it.created_at) }
                commentTotal = r.data.total
            }
        }
    }
    // 时间格式化辅助
    fun formatTime(ts: Long): String {
        val now = System.currentTimeMillis() / 1000
        val diff = now - ts
        return when {
            diff < 60 -> "刚刚"
            diff < 3600 -> "${diff / 60}分钟前"
            diff < 86400 -> "${diff / 3600}小时前"
            else -> {
                val cal = java.util.Calendar.getInstance().apply { timeInMillis = ts * 1000 }
                String.format("%d月%d日", cal.get(java.util.Calendar.MONTH) + 1, cal.get(java.util.Calendar.DAY_OF_MONTH))
            }
        }
    }
    // 更新版本选择的回调：同步切换所有展示信息
    val selectVersion: (String, String, String, String, String, List<String>, String, Long, Long) -> Unit = { ver, dl, ch, iconUrl, _, ssList, desc, fsize, vid ->
        selectedVersion = ver; selectedDownloadUrl = dl; selectedChangelog = ch; selectedVersionId = vid
        displayVersion = ver; displayDownloadUrl = dl; displayIconUrl = iconUrl; displayScreenshots = ssList
        displayDescription = desc; displayFileSize = fsize
        showVersionPicker = false
    }

    // 加载历史版本（页面加载时就获取，保证更新内容能正常显示所有版本）
    LaunchedEffect(tool.userAppId) {
        if (tool.isUserApp) {
            val r = com.aurora.chat.data.api.AuroraApi.getAppVersions(tool.userAppId)
            if (r.success && r.data != null) {
                oldVersions = (0 until r.data!!.length()).map { r.data!!.getJSONObject(it) }
            }
        }
    }

    // 如果是 Aurora Chat，从后端获取最新版本信息
    var latestVersionName by remember { mutableStateOf("") }
    var latestVersionCode by remember { mutableStateOf(0) }
    var serverDownloadUrl by remember { mutableStateOf("") }
    var serverForceUpdate by remember { mutableStateOf(false) }

    LaunchedEffect(tool.name) {
        if (isAuroraChat) {
            kotlinx.coroutines.delay(800)
            try {
                val r = com.aurora.chat.data.api.AuroraApi.checkAppVersion()
                if (r.success && r.data != null) {
                    latestVersionName = r.data.optString("latest_version_name", "")
                    latestVersionCode = r.data.optInt("latest_version_code", 0)
                    serverDownloadUrl = r.data.optString("download_url", "")
                    serverForceUpdate = r.data.optBoolean("force_update", false)
                } else {
                    latestVersionName = "获取失败"
                }
            } catch (_: Exception) {
                latestVersionName = "获取失败"
            }
        }
    }

    // 从服务器获取精确文件大小（仅对内置工具有效；用户应用直接用上传时填的值）
    if (!tool.isUserApp) {
        LaunchedEffect(tool.fileName) {
            realFileSize = com.aurora.chat.data.api.AuroraApi.fetchFileSize(tool.fileName)
        }
    }

    // 检查应用是否已安装（按优先级：packageName → 已保存包名 → 从缓存的 APK 读）
    LaunchedEffect(tool.fileName) {
        val pkg = when {
            tool.packageName.isNotEmpty() -> tool.packageName
            else -> {
                val saved = DownloadManager.getSavedPackageName(context, tool.name)
                if (saved.isNotEmpty()) saved
                else {
                    try {
                        val f = java.io.File(context.filesDir, "downloads/${tool.fileName}")
                        if (f.exists()) {
                            val pi = context.packageManager.getPackageArchiveInfo(f.absolutePath, 0)
                            pi?.packageName ?: ""
                        } else ""
                    } catch (_: Exception) { "" }
                }
            }
        }
        isAppInstalled = if (pkg.isNotEmpty()) {
            try { context.packageManager.getLaunchIntentForPackage(pkg) != null } catch (_: Exception) { false }
        } else false
    }

    //  拦截系统返回手势，确保只退回到应用列表，不会越级到聊天
    BackHandler(enabled = !showFullImage) { onBack() }
    BackHandler(enabled = showFullImage) { showFullImage = false }

    // 预加载本地 assets 截图：异步在 IO 线程带采样解码，避免主线程解码 1080p+ 大图导致卡顿
    val bitmaps = remember(displayScreenshots) {
        mutableStateListOf<Bitmap?>(*Array(displayScreenshots.size) { null })
    }
    LaunchedEffect(displayScreenshots) {
        withContext(Dispatchers.IO) {
            displayScreenshots.forEachIndexed { idx, path ->
                val bmp = if (path.startsWith("http")) null else ScreenshotManager.loadBitmapFromAssetsSampled(context, path, 1080)
                withContext(Dispatchers.Main) {
                    if (idx < bitmaps.size) bitmaps[idx] = bmp
                }
            }
        }
    }
    val hasScreenshots = displayScreenshots.isNotEmpty() && displayScreenshots.indices.any { idx ->
        val path = displayScreenshots[idx]
        path.startsWith("http") || bitmaps.getOrNull(idx) != null
    }



    Box(modifier = Modifier.fillMaxSize().background(Color.White)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // ── 顶部栏 ──
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .statusBarsPadding() //  状态栏内边距，把内容推到下面
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF3F4F6))
                        .clickable { onBack() },
                    contentAlignment = Alignment.Center
                ) {
                    Text("←", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    text = tool.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1F2937)
                )
            }

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(0.5.dp)
                    .background(Color(0xFFE5E7EB))
            )

            val pagerState = rememberPagerState(pageCount = { displayScreenshots.size })

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
            ) {
                Spacer(Modifier.height(24.dp))

                // ── 应用图标 + 名称 ──
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        if (tool.isUserApp && tool.userAppId > 0) {
                            val iconModel = displayIconUrl.ifEmpty { "${AuroraApi.serverUrl}/api/apps/icon/${tool.userAppId}" }
                            AsyncImage(
                                model = iconModel,
                                contentDescription = tool.name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else if (tool.iconRes != null) {
                            Image(
                                painter = painterResource(tool.iconRes),
                                contentDescription = tool.name,
                                modifier = Modifier.fillMaxSize().scale(tool.iconContentScale),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = tool.name,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF111827)
                        )
                        Spacer(Modifier.height(6.dp))
                        if (!isAuroraChat) {
                            val displaySize = if (realFileSize > 0) {
                                val mib = realFileSize / 1_048_576.0
                                String.format("%.2f MiB", mib)
                            } else if (displayFileSize > 0) {
                                when {
                                    displayFileSize >= 1_000_000_000 -> String.format("%.2f GB", displayFileSize / 1_000_000_000.0)
                                    displayFileSize >= 1_000_000 -> String.format("%.2f MB", displayFileSize / 1_000_000.0)
                                    displayFileSize >= 1_000 -> String.format("%.2f KB", displayFileSize / 1_000.0)
                                    else -> "$displayFileSize B"
                                }
                            } else {
                                "未知大小"
                            }
                            Text(text = displaySize, fontSize = 13.sp, color = Color(0xFF6B7280))
                            if (tool.version.isNotEmpty()) {
                                Spacer(Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("v$displayVersion", fontSize = 13.sp, color = Color(0xFF6B7280))
                                    if (tool.isUserApp) {
                                        Spacer(Modifier.width(4.dp))
                                        // 下载旧版本
                                        Box(Modifier.clip(RoundedCornerShape(4.dp)).background(Color(0xFFF3F4F6)).clickable {
                                            showVersionPicker = true
                                        }.padding(horizontal = 6.dp, vertical = 2.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("▾", fontSize = 10.sp, color = Color(0xFF1E40AF))
                                            }
                                        }
                                        Spacer(Modifier.width(4.dp))
                                        // 更新内容
                                        Box(Modifier.clip(RoundedCornerShape(4.dp)).background(Color(0xFFF3F4F6)).clickable {
                                            selectedChangelog = if (selectedVersion == tool.version) tool.changelog else selectedChangelog
                                            showChangelogDialog = true
                                        }.padding(horizontal = 6.dp, vertical = 2.dp)) {
                                            Text("更新内容", fontSize = 10.sp, color = Color(0xFF1E40AF))
                                        }
                                    }
                                }
                            }
                        }
                    }
                    // 使用服务端统一的全局下载计数（不再用本地 SharedPreferences 的分散计数）
                    val downloadCount = tool.downloadCount
                    Text(
                        text = "下载${downloadCount}次",
                        fontSize = 11.sp,
                        color = Color(0xFF9CA3AF),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(Modifier.height(20.dp))

                // ── 开发者信息 ──
                if (tool.developerUserId > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("开发者: ", fontSize = 14.sp, color = Color(0xFF6B7280))
                        Text(
                            text = tool.developerUsername,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1E40AF),
                            modifier = Modifier.clickable { onUserClick(tool.developerUserId, tool.developerUsername) }
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }

                // ── 应用介绍 ──
                Text(
                    text = "介绍",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF374151)
                )
                Spacer(Modifier.height(8.dp))
                if (isAuroraChat) {
                    Text(
                        text = "该应用为Aurora Chat最新安装包\n最新版本: ${latestVersionName.ifEmpty { "获取中..." }}\n可点击下方检查版本来获取最新安装包",
                        fontSize = 14.sp,
                        color = Color(0xFF6B7280),
                        lineHeight = 22.sp
                    )
                } else {
                    Text(
                        text = displayDescription,
                        fontSize = 14.sp,
                        color = Color(0xFF6B7280),
                        lineHeight = 22.sp
                    )
                }

                Spacer(Modifier.height(28.dp))

                // ── 截图区 ──
                Text(
                    text = "详情",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF374151)
                )
                Spacer(Modifier.height(12.dp))

                if (!hasScreenshots) {
                    // 无截图，显示占位
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF9FAFB))
                            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("暂无截图", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                            Spacer(Modifier.height(4.dp))
                            Text("等待上传", fontSize = 12.sp, color = Color(0xFFD1D5DB))
                        }
                    }
                } else {
                    // 按截图实际宽高比预览，限制最大高度避免过长
                    val imgAspect = bitmaps.filterNotNull().firstOrNull()?.let { bmp ->
                        if (bmp.width > 0) bmp.height.toFloat() / bmp.width.toFloat() else 0f
                    } ?: 0f
                    val previewHeight = if (imgAspect > 0f) {
                        // 手机屏按宽度比例，但限制最大 340dp
                        (340.dp * imgAspect.coerceAtMost(1.6f) / 1.6f).coerceIn(180.dp, 340.dp)
                    } else 260.dp

                    // 截图 HorizontalPager（pagerState 已在外层声明）
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(previewHeight)
                    ) { page ->
                        val source = displayScreenshots.getOrNull(page) ?: return@HorizontalPager
                        val isUrl = source.startsWith("http")
                        val bmp = if (isUrl) null else bitmaps.getOrNull(page)
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFF3F4F6))
                                .clickable {
                                    fullImageIndex = page
                                    showFullImage = true
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            when {
                                isUrl -> {
                                    AsyncImage(
                                        model = source,
                                        contentDescription = "截图 ${page + 1}",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                                bmp != null -> {
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = "截图 ${page + 1}",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                                else -> {
                                    Text("加载失败", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // 分页指示点
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        repeat(displayScreenshots.size) { index ->
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 3.dp)
                                    .size(if (pagerState.currentPage == index) 8.dp else 6.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (pagerState.currentPage == index) Color(0xFF1E40AF)
                                        else Color(0xFFD1D5DB)
                                    )
                            )
                        }
                    }
                }


                Spacer(Modifier.height(28.dp))

                // ── 评论区 ──
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "评论 ($commentTotal)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF374151),
                        modifier = Modifier.weight(1f)
                    )
                    if (!showCommentInput) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF1E40AF))
                                .clickable {
                                    if (appId > 0) showCommentInput = true
                                    else android.widget.Toast.makeText(context, "仅用户提交的应用支持评论", android.widget.Toast.LENGTH_SHORT).show()
                                }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text("写评论", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))

                // 评论输入框（点击"写评论"后显示）
                AnimatedVisibility(visible = showCommentInput) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = commentInput,
                                onValueChange = { commentInput = it },
                                modifier = Modifier.weight(1f),
                                placeholder = { Text("输入评论内容...", fontSize = 13.sp) },
                                singleLine = true,
                                textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, lineHeight = 20.sp),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    unfocusedBorderColor = Color(0xFFD1D5DB),
                                    focusedBorderColor = Color(0xFF1E40AF)
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val text = commentInput.trim()
                                    if (text.isNotEmpty() && appId > 0) {
                                        commentLoading = true
                                        scope.launch {
                                            try {
                                                val r = AuroraApi.addAppComment(appId, text)
                                                if (r.success) {
                                                    commentInput = ""
                                                    showCommentInput = false
                                                    // 重新加载评论
                                                    val r2 = AuroraApi.getAppComments(appId)
                                                    if (r2.success && r2.data != null) {
                                                        comments = r2.data.comments.map { AppComment(it.id, it.user_id, it.username, it.content, it.created_at) }
                                                        commentTotal = r2.data.total
                                                    }
                                                } else {
                                                    android.widget.Toast.makeText(context, r.message, android.widget.Toast.LENGTH_SHORT).show()
                                                }
                                            } catch (_: Exception) {
                                                android.widget.Toast.makeText(context, "评论失败", android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                            commentLoading = false
                                        }
                                    }
                                },
                                modifier = Modifier.height(42.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)),
                                enabled = commentInput.trim().isNotEmpty() && !commentLoading
                            ) {
                                if (commentLoading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                else Text("发送", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                }

                if (comments.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF9FAFB)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("暂无评论，来写第一条吧", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                    }
                } else {
                    comments.forEachIndexed { index, comment ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFF9FAFB))
                                .padding(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .clickable { onUserClick(comment.user_id, comment.username) }
                                ) {
                                    UserAvatar(
                                        userId = comment.user_id,
                                        userName = comment.username,
                                        size = 34.dp
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        text = comment.username,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF1E40AF),
                                        modifier = Modifier.clickable { onUserClick(comment.user_id, comment.username) }
                                    )
                                    Text(
                                        text = formatTime(comment.created_at),
                                        fontSize = 10.sp,
                                        color = Color(0xFF9CA3AF)
                                    )
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = comment.content,
                                fontSize = 14.sp,
                                color = Color(0xFF374151),
                                lineHeight = 20.sp
                            )
                        }
                        if (index < comments.lastIndex) Spacer(Modifier.height(8.dp))
                    }
                }

                Spacer(Modifier.height(32.dp))
            }

            // ── 底部操作按钮 ──
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                if (isAuroraChat) {
                    Button(
                        onClick = { onCheckVersion() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF))
                    ) {
                        Text("检查版本", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                } else if (isAppInstalled == true && tool.packageName.isNotEmpty()) {
                    Button(
                        onClick = {
                            try {
                                val intent = context.packageManager.getLaunchIntentForPackage(tool.packageName)
                                if (intent != null) {
                                    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                }
                            } catch (_: Exception) {
                                android.widget.Toast.makeText(context, "启动失败", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                    ) {
                        Text("启动应用", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    Button(
                        onClick = {
                                if (tool.isUserApp && displayDownloadUrl.isNotEmpty()) {
                                val apkUrl = if (displayDownloadUrl.startsWith("/")) {
                                    "${AuroraApi.serverUrl}${displayDownloadUrl}"
                                } else {
                                    displayDownloadUrl
                                }
                                val isOldVersion = selectedVersionId != 0L && selectedVersion != tool.version
                                val displayName = if (isOldVersion) "${tool.name}(v$displayVersion)" else tool.name
                                val dlFileName = if (isOldVersion) "${tool.name}_v$displayVersion.apk" else tool.fileName
                                DownloadManager.addAppShareDownload(
                                    name = displayName,
                                    fileName = dlFileName,
                                    downloadUrl = apkUrl,
                                    iconUrl = "${AuroraApi.serverUrl}/api/apps/icon/${tool.userAppId}"
                                )
                            } else {
                                DownloadManager.addToQueue(
                                    name = tool.name,
                                    fileName = tool.fileName,
                                    iconRes = tool.iconRes ?: R.drawable.ic_apps,
                                    packageName = tool.packageName,
                                    downloadUrl = if (isAuroraChat && serverDownloadUrl.isNotEmpty()) serverDownloadUrl else ""
                                )
                            }
                            DownloadManager.startDownloads(context)
                            onBack()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF))
                    ) {
                        Text("下载应用", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // ── 全屏图片查看器 ──
        AnimatedVisibility(
            visible = showFullImage,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(200))
        ) {
            FullScreenImageViewer(
                imageSources = displayScreenshots,
                assetBitmaps = bitmaps,
                initialIndex = fullImageIndex.coerceAtMost(displayScreenshots.size - 1).coerceAtLeast(0),
                onDismiss = { showFullImage = false }
            )

        }
    }

    // ── 版本选择弹窗 ──
    if (showVersionPicker) {
        val serverUrl = com.aurora.chat.data.api.AuroraApi.serverUrl
        androidx.compose.ui.window.Dialog(onDismissRequest = { showVersionPicker = false }) {
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(20.dp)) {
                Text("选择版本", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                Spacer(Modifier.height(12.dp))
                // 当前版本
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(if (selectedVersion == tool.version) Color(0xFFEEF2FF) else Color.Transparent).clickable {
                    selectVersion(tool.version, tool.downloadUrl, tool.changelog, "$serverUrl/api/apps/icon/${tool.userAppId}", "", tool.screenshotUrls, tool.description, tool.fileSizeBytes, 0L)
                }.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("v${tool.version}", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                        Spacer(Modifier.weight(1f))
                        Text(if (selectedVersion == tool.version) "当前" else "最新版本", fontSize = 11.sp, color = Color(0xFF16A34A))
                    }
                }
                // 旧版本
                oldVersions.forEach { v ->
                    val ver = v.optString("version", "")
                    val vid = v.optLong("id", 0L)
                    val apkPath = v.optString("apk_path", "")
                    val dl = if (apkPath.isNotEmpty()) "/api/apps/apk/${tool.userAppId}?v=$vid" else v.optString("download_url", "")
                    val ch = v.optString("changelog", "")
                    val desc = v.optString("description", tool.description)
                    val fsize = v.optLong("file_size", tool.fileSizeBytes)
                    val iconPath = v.optString("icon_path", "")
                    val iconUrl = if (iconPath.isNotEmpty()) "$serverUrl/api/apps/icon/${tool.userAppId}/$iconPath" else "$serverUrl/api/apps/icon/${tool.userAppId}"
                    val ssStr = v.optString("screenshots", "[]")
                    val ssList = try {
                        val arr = org.json.JSONArray(ssStr)
                        (0 until arr.length()).map { "$serverUrl/api/apps/screenshot/${tool.userAppId}/${arr.optString(it)}" }
                    } catch (_: Exception) { tool.screenshotUrls }
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(if (selectedVersion == ver) Color(0xFFEEF2FF) else Color.Transparent).clickable {
                        selectVersion(ver, dl, ch, iconUrl, "", ssList, desc, fsize, vid)
                    }.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("v$ver", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (selectedVersion == ver) Color(0xFF1E40AF) else Color(0xFF6B7280))
                            Spacer(Modifier.weight(1f))
                            if (selectedVersion == ver) Text("当前", fontSize = 11.sp, color = Color(0xFF1E40AF))
                        }
                    }
                }
                if (oldVersions.isEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("暂无历史版本", fontSize = 13.sp, color = Color(0xFF9CA3AF), modifier = Modifier.align(Alignment.CenterHorizontally))
                }
            }
        }
    }

    // ── 更新内容侧滑界面 ──
    AnimatedVisibility(
        visible = showChangelogDialog,
        enter = slideInHorizontally(initialOffsetX = { it }, animationSpec = tween(300)),
        exit = slideOutHorizontally(targetOffsetX = { it }, animationSpec = tween(300))
    ) {
        Box(Modifier.fillMaxSize().background(Color.White)) {
            Column(Modifier.fillMaxSize()) {
                // 顶栏
                Row(Modifier.fillMaxWidth().background(Color.White).statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF3F4F6)).clickable { showChangelogDialog = false }, contentAlignment = Alignment.Center) {
                        Text("←", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("更新内容", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
                }
                Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))

                // 当前版本
                Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                    // 当前版本卡片
                    Text("当前版本", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF6B7280))
                    Spacer(Modifier.height(6.dp))
                    ChangelogCard(version = tool.version, changelog = tool.changelog)

                    // 旧版本
                    if (oldVersions.isNotEmpty()) {
                        Spacer(Modifier.height(16.dp))
                        Text("历史版本", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF6B7280))
                        Spacer(Modifier.height(6.dp))
                        oldVersions.forEach { v ->
                            ChangelogCard(version = v.optString("version", ""), changelog = v.optString("changelog", ""))
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChangelogCard(version: String, changelog: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("v$version", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            Spacer(Modifier.height(8.dp))
            Text(changelog.ifEmpty { "该用户未填写更新内容" }, fontSize = 14.sp, color = Color(0xFF6B7280), lineHeight = 22.sp)
        }
    }
}
