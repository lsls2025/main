package com.aurora.chat

import com.aurora.chat.data.api.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

// 后端服务器地址（HTTPS，自签名证书）
const val SERVER_URL = "https://192.168.0.104:8080"

data class ApiResult<T>(
    val success: Boolean,
    val message: String,
    val data: T? = null
)

data class LoginResult(
    val id: Long,
    val email: String,
    val username: String
)

data class UserInfo(
    val id: Long,
    val email: String,
    val username: String,
    val createdAt: Long
)

data class FriendRequestInfo(
    val id: Long,
    val fromUserId: Long,
    val fromEmail: String,
    val fromUsername: String,
    val greeting: String,
    val status: String,
    val createdAt: Long
)

data class MessageInfo(
    val id: Long,
    val fromUserId: Long,
    val toUserId: Long,
    val content: String,
    val createdAt: Long
)

data class ConversationInfo(
    val id: Long,
    val email: String,
    val username: String,
    val createdAt: Long,
    val lastMessage: String = "",
    val lastTime: Long = 0
)

object ApiClient {

    private suspend fun request(
        method: String,
        path: String,
        body: JSONObject? = null
    ): JSONObject = withContext(Dispatchers.IO) {
        val raw = try {
            // 不抛非 2xx：原实现即返回响应体由调用方解析业务 code
            HttpClient.jsonRequestAllowError(method, "$SERVER_URL$path", body?.toString())
        } catch (e: IOException) {
            throw Exception("网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
        }
        try {
            JSONObject(raw)
        } catch (e: Exception) {
            throw Exception("服务器返回异常：${e.localizedMessage ?: ""}")
        }
    }

    // ==================== 认证 ====================

    suspend fun sendCode(email: String): ApiResult<Unit> = try {
        val body = JSONObject().apply { put("email", email) }
        val json = request("POST", "/api/send-code", body)
        val code = json.optInt("code", 500)
        ApiResult(success = code == 200, message = json.optString("message", ""))
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    suspend fun register(email: String, username: String, password: String, code: String): ApiResult<LoginResult> = try {
        val body = JSONObject().apply {
            put("email", email); put("username", username); put("password", password); put("code", code)
        }
        val json = request("POST", "/api/register", body)
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val d = json.optJSONObject("data")
            ApiResult(true, json.optString("message", ""), LoginResult(
                id = d?.optLong("id", 0) ?: 0,
                email = d?.optString("email", "") ?: "",
                username = d?.optString("username", "") ?: ""
            ))
        } else {
            ApiResult(false, json.optString("message", "注册失败"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    suspend fun login(email: String, password: String): ApiResult<LoginResult> = try {
        val body = JSONObject().apply { put("email", email); put("password", password) }
        val json = request("POST", "/api/login", body)
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val d = json.optJSONObject("data")
            ApiResult(true, json.optString("message", ""), LoginResult(
                id = d?.optLong("id", 0) ?: 0,
                email = d?.optString("email", "") ?: "",
                username = d?.optString("username", "") ?: ""
            ))
        } else {
            ApiResult(false, json.optString("message", "邮箱或密码错误"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    // ==================== 搜索用户 ====================

    suspend fun searchUsers(keyword: String, excludeUserId: Long = 0): ApiResult<List<UserInfo>> = try {
        val json = request("GET", "/api/search-users?q=$keyword&exclude=$excludeUserId")
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val data = json.optJSONArray("data") ?: JSONArray()
            val users = mutableListOf<UserInfo>()
            for (i in 0 until data.length()) {
                val obj = data.getJSONObject(i)
                users.add(UserInfo(obj.optLong("id"), obj.optString("email"), obj.optString("username"), obj.optLong("created_at")))
            }
            ApiResult(true, json.optString("message", ""), users)
        } else {
            ApiResult(false, json.optString("message", "搜索失败"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    // ==================== 好友请求 ====================

    suspend fun sendFriendRequest(fromUserId: Long, toEmail: String, greeting: String = ""): ApiResult<Unit> = try {
        val body = JSONObject().apply { put("from_user_id", fromUserId); put("to_email", toEmail); put("greeting", greeting) }
        val json = request("POST", "/api/friend-request/send", body)
        ApiResult(json.optInt("code") == 200, json.optString("message", ""))
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    suspend fun getFriendRequests(userId: Long): ApiResult<List<FriendRequestInfo>> = try {
        val json = request("GET", "/api/friend-requests/$userId")
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val data = json.optJSONArray("data") ?: JSONArray()
            val list = mutableListOf<FriendRequestInfo>()
            for (i in 0 until data.length()) {
                val obj = data.getJSONObject(i)
                list.add(FriendRequestInfo(
                    id = obj.optLong("id"),
                    fromUserId = obj.optLong("from_user_id"),
                    fromEmail = obj.optString("from_email"),
                    fromUsername = obj.optString("from_username"),
                    greeting = obj.optString("greeting"),
                    status = obj.optString("status"),
                    createdAt = obj.optLong("created_at")
                ))
            }
            ApiResult(true, "获取成功", list)
        } else {
            ApiResult(false, json.optString("message", "获取失败"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    suspend fun respondFriendRequest(requestId: Long, action: String, userId: Long): ApiResult<Unit> = try {
        val body = JSONObject().apply { put("request_id", requestId); put("action", action); put("user_id", userId) }
        val json = request("POST", "/api/friend-request/respond", body)
        ApiResult(json.optInt("code") == 200, json.optString("message", ""))
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    // ==================== 好友列表 ====================

    suspend fun getFriends(userId: Long): ApiResult<List<UserInfo>> = try {
        val json = request("GET", "/api/friends/$userId")
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val data = json.optJSONArray("data") ?: JSONArray()
            val users = mutableListOf<UserInfo>()
            for (i in 0 until data.length()) {
                val obj = data.getJSONObject(i)
                users.add(UserInfo(obj.optLong("id"), obj.optString("email"), obj.optString("username"), obj.optLong("created_at")))
            }
            ApiResult(true, "获取成功", users)
        } else {
            ApiResult(false, json.optString("message", "获取失败"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    // ==================== E2EE 密钥管理 ====================

    // 公钥缓存（内存缓存，避免频繁请求）
    private val publicKeyCache = mutableMapOf<Long, String>()

    /** 上传自己的公钥 */
    suspend fun uploadPublicKey(userId: Long, publicKeyBase64: String): ApiResult<Unit> = try {
        val body = JSONObject().apply { put("user_id", userId); put("public_key", publicKeyBase64) }
        val json = request("POST", "/api/keys/upload", body)
        ApiResult(json.optInt("code") == 200, json.optString("message", ""))
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    /** 获取对方公钥 */
    suspend fun getPublicKey(userId: Long): ApiResult<String> = try {
        // 先查缓存
        publicKeyCache[userId]?.let { return ApiResult(true, "", it) }
        val json = request("GET", "/api/keys/$userId")
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val key = json.optJSONObject("data")?.optString("public_key", "") ?: ""
            if (key.isNotEmpty()) publicKeyCache[userId] = key
            ApiResult(true, "获取成功", key)
        } else {
            ApiResult(false, json.optString("message", "对方未设置密钥"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    // ==================== 群消息（明文，不走加密） ====================

    /** 发送群消息（明文存储，不走 E2EE） */
    suspend fun sendGroupMessage(fromUserId: Long, toUserId: Long, content: String): ApiResult<Unit> = try {
        val body = JSONObject().apply { put("from_user_id", fromUserId); put("to_user_id", toUserId); put("content", content) }
        val json = request("POST", "/api/messages/send", body)
        ApiResult(json.optInt("code") == 200, json.optString("message", ""))
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    // ==================== 消息（E2EE） ====================

    /**
     * 发送消息 - ECDH + 临时密钥 + AES-GCM 加密后发送
     * 服务器只能看到密文，无法解密
     */
    suspend fun sendMessage(fromUserId: Long, toUserId: Long, content: String): ApiResult<Unit> {
        return try {
            val keyResult = getPublicKey(toUserId)
            if (!keyResult.success || keyResult.data.isNullOrEmpty()) {
                ApiResult(false, "对方尚未配置端到端加密密钥")
            } else {
                val encrypted = CryptoUtil.encrypt(content, keyResult.data!!)
                val body = JSONObject().apply { put("from_user_id", fromUserId); put("to_user_id", toUserId); put("content", encrypted) }
                val json = request("POST", "/api/messages/send", body)
                ApiResult(json.optInt("code") == 200, json.optString("message", ""))
            }
        } catch (e: Exception) {
            ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
        }
    }

    /**
     * 获取群消息（明文，不解密）
     */
    suspend fun getGroupMessages(userId2: Long, limit: Int = 100, offset: Int = 0): ApiResult<List<MessageInfo>> = try {
        val json = request("GET", "/api/messages/0/$userId2?limit=$limit&offset=$offset")
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val data = json.optJSONArray("data") ?: JSONArray()
            val list = mutableListOf<MessageInfo>()
            for (i in 0 until data.length()) {
                val obj = data.getJSONObject(i)
                list.add(MessageInfo(
                    id = obj.optLong("id"),
                    fromUserId = obj.optLong("from_user_id"),
                    toUserId = obj.optLong("to_user_id"),
                    content = obj.optString("content", ""),
                    createdAt = obj.optLong("created_at")
                ))
            }
            ApiResult(true, "获取成功", list)
        } else {
            ApiResult(false, json.optString("message", "获取失败"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    /**
     * 获取好友消息 - ECDH 解密
     */
    suspend fun getMessages(userId1: Long, userId2: Long, limit: Int = 50, offset: Int = 0): ApiResult<List<MessageInfo>> = try {
        val json = request("GET", "/api/messages/$userId1/$userId2?limit=$limit&offset=$offset")
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val data = json.optJSONArray("data") ?: JSONArray()
            val list = mutableListOf<MessageInfo>()
            for (i in 0 until data.length()) {
                val obj = data.getJSONObject(i)
                val encrypted = obj.optString("content", "")
                val decrypted = if (userId2 > 0 && CryptoUtil.isEncrypted(encrypted)) {
                    try {
                        CryptoUtil.decrypt(encrypted)
                    } catch (e: Exception) {
                        "[端到端加密消息]"
                    }
                } else {
                    encrypted
                }
                list.add(MessageInfo(
                    id = obj.optLong("id"),
                    fromUserId = obj.optLong("from_user_id"),
                    toUserId = obj.optLong("to_user_id"),
                    content = decrypted,
                    createdAt = obj.optLong("created_at")
                ))
            }
            ApiResult(true, "获取成功", list)
        } else {
            ApiResult(false, json.optString("message", "获取失败"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    // ==================== 最近聊天（含消息预览） ====================

    suspend fun getConversations(userId: Long): ApiResult<List<ConversationInfo>> = try {
        val json = request("GET", "/api/conversations/$userId")
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val data = json.optJSONArray("data") ?: JSONArray()
            val list = mutableListOf<ConversationInfo>()
            for (i in 0 until data.length()) {
                val obj = data.getJSONObject(i)
                list.add(ConversationInfo(
                    id = obj.optLong("id"),
                    email = obj.optString("email", ""),
                    username = obj.optString("username", ""),
                    createdAt = obj.optLong("created_at"),
                    lastMessage = obj.optString("last_message", ""),
                    lastTime = obj.optLong("last_time", 0)
                ))
            }
            ApiResult(true, "获取成功", list)
        } else {
            ApiResult(false, json.optString("message", "获取失败"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    /** 获取所有注册用户（开发者管理） */
    suspend fun getAllUsers(): ApiResult<List<UserInfo>> = try {
        val json = request("GET", "/api/users")
        val respCode = json.optInt("code", 500)
        if (respCode == 200) {
            val data = json.optJSONArray("data") ?: JSONArray()
            val users = mutableListOf<UserInfo>()
            for (i in 0 until data.length()) {
                val obj = data.getJSONObject(i)
                users.add(UserInfo(obj.optLong("id"), obj.optString("email"), obj.optString("username"), obj.optLong("created_at")))
            }
            ApiResult(true, "获取成功", users)
        } else {
            ApiResult(false, json.optString("message", "获取失败"))
        }
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    // ==================== 头像管理 ====================

    /** 获取头像 URL（拼接得到） */
    fun getAvatarUrl(userId: Long): String = "$SERVER_URL/api/avatar/$userId"

    /**
     * 上传头像（base64）
     */
    suspend fun uploadAvatar(userId: Long, avatarBase64: String): ApiResult<Unit> = try {
        val body = JSONObject().apply { put("user_id", userId); put("avatar", avatarBase64) }
        val json = request("POST", "/api/avatar/upload", body)
        ApiResult(json.optInt("code") == 200, json.optString("message", ""))
    } catch (e: Exception) {
        ApiResult(false, "网络连接失败：${e.localizedMessage ?: "请检查服务器是否启动"}")
    }

    /** 下载头像字节数组 */
    suspend fun loadAvatarBytes(userId: Long): ByteArray? = withContext(Dispatchers.IO) {
        try {
            HttpClient.downloadBytes(getAvatarUrl(userId))
        } catch (_: Exception) { null }
    }
}
