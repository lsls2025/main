package com.aurora.chat.ui.qr

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.chat.data.api.AuroraApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun MyQrScreen(
    userId: Long,
    userName: String,
    onBack: () -> Unit,
    onScanClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var refreshKey by remember { mutableStateOf(0) }
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var saving by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }

    // 从服务器获取二维码内容并生成 Bitmap（中心叠加用户真实头像，无头像时用应用图标兜底）
    LaunchedEffect(refreshKey) {
        loading = true
        val result = AuroraApi.getMyQrCode()
        if (result.success && result.data != null) {
            val centerIcon = withContext(Dispatchers.IO) {
                // 强制从服务器获取头像（绕过本地缓存与 noAvatar 误判）
                var icon: android.graphics.Bitmap? = null
                try {
                    val bytes = com.aurora.chat.data.api.AuroraApi.loadAvatarBytes(userId)
                    android.util.Log.d("MyQr", "服务器头像字节=${bytes?.size} 字节")
                    if (bytes != null) {
                        icon = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        android.util.Log.d("MyQr", "服务器头像解码=${icon != null} 尺寸=${icon?.width}x${icon?.height}")
                    }
                } catch (e: Exception) {
                    android.util.Log.e("MyQr", "获取服务器头像异常", e)
                }
                // 服务器没有，用应用图标兜底，避免中心空白
                if (icon == null) {
                    icon = runCatching {
                        android.graphics.BitmapFactory.decodeResource(context.resources, com.aurora.chat.R.mipmap.ic_launcher)
                    }.getOrNull()
                    android.util.Log.d("MyQr", "兜底图标结果=${icon != null}")
                }
                icon
            }
            // 头像由 overlayCenterIcon 裁剪为正方形圆角并填满分割线内区域
            val bmp = withContext(Dispatchers.IO) { generateQrBitmap(result.data!!, 720, centerIcon) }
            qrBitmap = bmp
        } else {
            toast(context, result.message)
        }
        loading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F6F8))
            .statusBarsPadding()
    ) {
        // 顶部栏
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Text("‹", fontSize = 28.sp, color = Color(0xFF1F2937))
            }
            Spacer(Modifier.width(8.dp))
            Text("我的二维码", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        }

        Spacer(Modifier.height(24.dp))

        // 昵称
        Text(
            text = userName.ifEmpty { "Aurora 用户" },
            fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111827),
            modifier = Modifier.fillMaxWidth(),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Text(
            text = "ID: $userId",
            fontSize = 13.sp, color = Color(0xFF9CA3AF),
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(Modifier.height(28.dp))

        // 大二维码（点击刷新）
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            if (qrBitmap != null) {
                Image(
                    bitmap = qrBitmap!!.asImageBitmap(),
                    contentDescription = "我的二维码",
                    modifier = Modifier
                        .size(260.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White)
                        .clickable {
                            refreshKey++
                            toast(context, "刷新中…")
                        }
                        .padding(16.dp)
                )
            } else if (loading) {
                Text("加载中…", fontSize = 14.sp, color = Color(0xFF9CA3AF))
            } else {
                Text("加载失败，点击重试", fontSize = 14.sp, color = Color(0xFF9CA3AF),
                    modifier = Modifier.clickable { refreshKey++ })
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            text = "点击二维码可刷新",
            fontSize = 12.sp, color = Color(0xFF9CA3AF),
            modifier = Modifier.fillMaxWidth(),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(Modifier.weight(1f))

        // 底部按钮：保存 / 扫一扫
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 24.dp)
                .navigationBarsPadding(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White)
                    .clickable(enabled = !saving && qrBitmap != null) {
                        saving = true
                        scope.launch {
                            val ok = saveBitmapToGallery(context, qrBitmap!!, "aurora_qr_$userId.png")
                            withContext(Dispatchers.Main) {
                                toast(context, if (ok) "已保存到相册" else "保存失败")
                                saving = false
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(if (saving) "保存中…" else "保存", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Color(0xFF2563EB))
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF2563EB))
                    .clickable { onScanClick() },
                contentAlignment = Alignment.Center
            ) {
                Text("扫一扫", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Color.White)
            }
        }
    }
}
