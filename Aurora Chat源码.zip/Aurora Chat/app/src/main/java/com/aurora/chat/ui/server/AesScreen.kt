package com.aurora.chat.ui.server

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

// ───────────── 配色 ─────────────
private val AesBlue = Color(0xFF2563EB)
private val AesBlueDark = Color(0xFF1D4ED8)
private val AesOrange = Color(0xFFD97706)
private val AesBg = Color(0xFFF8FAFC)
private val AesCard = Color(0xFFFFFFFF)
private val AesBorder = Color(0xFFE2E8F0)
private val AesText = Color(0xFF1F2937)
private val AesSub = Color(0xFF64748B)

// ═════════════════════════════════════════
// AES 加解密核心
// ═════════════════════════════════════════
private object AesCrypto {
    private const val GCM_IV_LENGTH = 12
    private const val GCM_TAG_LENGTH = 128
    private const val SALT_LENGTH = 16

    // 输出格式: [salt(16)][iv(12)][ciphertext + tag]
    fun encrypt(data: ByteArray, password: String, keyBits: Int, iterations: Int): ByteArray {
        val salt = ByteArray(SALT_LENGTH).also { SecureRandom().nextBytes(it) }
        val secret = deriveKey(password, salt, keyBits, iterations)
        val iv = ByteArray(GCM_IV_LENGTH).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(secret, "AES"), GCMParameterSpec(GCM_TAG_LENGTH, iv))
        val ct = cipher.doFinal(data)
        return salt + iv + ct
    }

    fun decrypt(data: ByteArray, password: String, keyBits: Int, iterations: Int): ByteArray {
        require(data.size > SALT_LENGTH + GCM_IV_LENGTH) { "数据长度异常，可能不是有效的加密文件" }
        val salt = data.copyOfRange(0, SALT_LENGTH)
        val iv = data.copyOfRange(SALT_LENGTH, SALT_LENGTH + GCM_IV_LENGTH)
        val ct = data.copyOfRange(SALT_LENGTH + GCM_IV_LENGTH, data.size)
        val secret = deriveKey(password, salt, keyBits, iterations)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(secret, "AES"), GCMParameterSpec(GCM_TAG_LENGTH, iv))
        return cipher.doFinal(ct)
    }

    private fun deriveKey(password: String, salt: ByteArray, keyBits: Int, iterations: Int): ByteArray {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(password.toCharArray(), salt, iterations, keyBits)
        return factory.generateSecret(spec).encoded
    }
}

// ═════════════════════════════════════════
// 文本编解码
// ═════════════════════════════════════════
private fun encodeText(bytes: ByteArray, encoding: String): String = when (encoding) {
    "Hex" -> bytes.joinToString("") { "%02x".format(it) }
    else -> Base64.encodeToString(bytes, Base64.NO_WRAP)
}

private fun decodeText(text: String, encoding: String): ByteArray {
    val t = text.trim()
    return when {
        encoding == "Hex" || t.matches(Regex("^[0-9a-fA-F]+$")) -> t.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        else -> Base64.decode(t, Base64.DEFAULT)
    }
}

// ═════════════════════════════════════════
// 文件 / 文件夹读写辅助
// ═════════════════════════════════════════
private suspend fun readUriBytes(context: Context, uri: Uri): ByteArray = withContext(Dispatchers.IO) {
    context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        ?: throw Exception("无法读取所选内容")
}

private fun saveToPublicDownloads(context: Context, fileName: String, bytes: ByteArray): File? {
    // fileName 可能是 "subdir/file.txt"，剥离路径只取末尾文件名用于 MediaStore
    val displayName = fileName.substringAfterLast('/')
    val subDir = fileName.substringBeforeLast('/', "")

    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+：通过 MediaStore 写入公共 Downloads/AuroraCrypto/
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.IS_PENDING, 1)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/AuroraCrypto/${subDir}")
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
            }
            // 写入缓存文件供 FileProvider 分享使用
            val cacheFile = File(context.cacheDir, "AuroraCrypto/$fileName")
            cacheFile.parentFile?.mkdirs()
            cacheFile.writeBytes(bytes)
            cacheFile
        } else {
            // Android 8-9：直接写入公共 Download/AuroraCrypto/ 目录
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AuroraCrypto/$subDir")
            dir.mkdirs()
            val f = File(dir, displayName)
            f.writeBytes(bytes)
            f
        }
    } catch (e: Exception) {
        // 降级：写入应用缓存
        try {
            val cacheFile = File(context.cacheDir, "AuroraCrypto/$fileName")
            cacheFile.parentFile?.mkdirs()
            cacheFile.writeBytes(bytes)
            cacheFile
        } catch (_: Exception) { null }
    }
}


private fun saveOutputFile(context: Context, baseName: String, bytes: ByteArray, mode: String): File? {
    val outName = if (mode == "encrypt") "$baseName.aes" else baseName.removeSuffix(".aes")
    return saveToPublicDownloads(context, outName, bytes)
}

// 遍历 SAF 文档树，返回 (文件Uri, 相对路径)
private fun walkTree(context: Context, treeUri: Uri): List<Pair<Uri, String>> {
    val result = mutableListOf<Pair<Uri, String>>()
    val treeId = DocumentsContract.getTreeDocumentId(treeUri)
    val rootUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeId)
    val stack = ArrayDeque<Pair<Uri, String>>()
    stack.addLast(rootUri to "")
    while (stack.isNotEmpty()) {
        val (dirUri, rel) = stack.removeLast()
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, DocumentsContract.getDocumentId(dirUri))
        val cursor = context.contentResolver.query(
            childrenUri,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
            ),
            null, null, null
        )
        cursor?.use { c ->
            val idIdx = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val mimeIdx = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            val nameIdx = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            while (c.moveToNext()) {
                val id = c.getString(idIdx)
                val mime = c.getString(mimeIdx)
                val name = c.getString(nameIdx) ?: "file"
                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                val childRel = if (rel.isEmpty()) name else "$rel/$name"
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    stack.addLast(childUri to childRel)
                } else {
                    result.add(childUri to childRel)
                }
            }
        }
    }
    return result
}

private fun getTreeName(context: Context, treeUri: Uri): String {
    val rootUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri))
    val cursor = context.contentResolver.query(
        rootUri,
        arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
        null, null, null
    )
    cursor?.use { c ->
        if (c.moveToFirst()) return c.getString(0) ?: "folder"
    }
    return "folder"
}

// 将文件夹压缩为 zip
private fun zipFolder(srcDir: File, zipFile: File) {
    val base = srcDir.absolutePath.length + if (srcDir.absolutePath.endsWith("/")) 0 else 1
    ZipOutputStream(zipFile.outputStream()).use { zos ->
        srcDir.walkTopDown().forEach { f ->
            if (f.isFile) {
                val entryName = f.absolutePath.substring(base).replace('\\', '/').trim('/')
                if (entryName.isNotEmpty()) {
                    zos.putNextEntry(ZipEntry(entryName))
                    FileInputStream(f).use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        }
    }
}

private fun shareFile(context: Context, file: File) {
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "分享文件")
        if (chooser.resolveActivity(context.packageManager) != null) {
            context.startActivity(chooser)
        } else {
            android.widget.Toast.makeText(context, "没有可用的分享应用", android.widget.Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "分享失败: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

// ═════════════════════════════════════════
// 密码强度
// ═════════════════════════════════════════
private fun passwordStrength(pw: String): Int {
    if (pw.isEmpty()) return 0
    var score = 1
    if (pw.length >= 8) score++
    if (pw.length >= 12) score++
    if (pw.any { it.isUpperCase() } && pw.any { it.isLowerCase() }) score++
    if (pw.any { it.isDigit() }) score++
    if (pw.any { !it.isLetterOrDigit() }) score++
    return score.coerceAtMost(4)
}

private fun generatePassword(len: Int = 16): String {
    val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#\$%^&*()-_=+"
    val r = SecureRandom()
    return (1..len).map { chars[r.nextInt(chars.length)] }.joinToString("")
}

// ═════════════════════════════════════════
// 通用分段选择
// ═════════════════════════════════════════
@Composable
private fun <T> SegmentedRow(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFFF1F5F9))
            .padding(4.dp)
    ) {
        options.forEach { (value, label) ->
            val sel = value == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (sel) AesCard else Color.Transparent)
                    .clickable { onSelect(value) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    fontSize = 14.sp,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                    color = if (sel) AesBlue else AesSub
                )
            }
        }
    }
}

// ═════════════════════════════════════════
// 区块标题
// ═════════════════════════════════════════
@Composable
private fun SectionTitle(text: String, icon: ImageVector? = null) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = AesBlue, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AesSub)
    }
}

// ═════════════════════════════════════════
// AES 全屏界面
// ═════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AesScreen(
    visible: Boolean,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    // 模式: encrypt / decrypt
    var mode by remember { mutableStateOf("encrypt") }
    // 加密对象: text / file / folder
    var target by remember { mutableStateOf("text") }

    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var algo by remember { mutableStateOf("AES-256-GCM") }
    var encoding by remember { mutableStateOf("Base64") }
    var iterations by remember { mutableIntStateOf(50000) }

    var inputText by remember { mutableStateOf("") }
    var inputFileUri by remember { mutableStateOf<Uri?>(null) }
    var inputFileName by remember { mutableStateOf("") }
    var inputFolderUri by remember { mutableStateOf<Uri?>(null) }
    var inputFolderName by remember { mutableStateOf("") }

    var outputText by remember { mutableStateOf("") }
    var outputMsg by remember { mutableStateOf("") }
    var lastOutputFile by remember { mutableStateOf<File?>(null) }
    var lastOutputFolder by remember { mutableStateOf<String?>(null) }
    var lastOutputFolderName by remember { mutableStateOf<String?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }

    val keyBits = if (algo == "AES-256-GCM") 256 else 128
    val isEncrypt = mode == "encrypt"

    // 选择文件
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            inputFileUri = it
            inputFileName = try {
                val c = context.contentResolver.query(it, null, null, null, null)
                c?.use { cur ->
                    val idx = cur.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (cur.moveToFirst() && idx >= 0) cur.getString(idx) else it.lastPathSegment
                } ?: it.lastPathSegment
            } catch (_: Exception) { it.lastPathSegment } ?: "未命名文件"
            errorMsg = ""
        }
    }
    // 选择文件夹
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let {
            inputFolderUri = it
            inputFolderName = getTreeName(context, it)
            errorMsg = ""
        }
    }

    fun doProcess() {
        if (password.isEmpty()) { errorMsg = "请输入密码"; return }
        scope.launch {
            isProcessing = true
            errorMsg = ""
                outputText = ""
                outputMsg = ""
                lastOutputFile = null
                lastOutputFolder = null
                lastOutputFolderName = null
            try {
                when (target) {
                    "text" -> {
                        val raw = if (isEncrypt) inputText.toByteArray(Charsets.UTF_8)
                        else decodeText(inputText, encoding)
                        val out = if (isEncrypt) AesCrypto.encrypt(raw, password, keyBits, iterations)
                        else AesCrypto.decrypt(raw, password, keyBits, iterations)
                        outputText = if (isEncrypt) encodeText(out, encoding)
                        else String(out, Charsets.UTF_8)
                        statusMsg = if (isEncrypt) "加密完成" else "解密完成"
                    }
                    "file" -> {
                        val uri = inputFileUri ?: throw Exception("请先选择文件")
                        val raw = readUriBytes(context, uri)
                        val out = if (isEncrypt) AesCrypto.encrypt(raw, password, keyBits, iterations)
                        else AesCrypto.decrypt(raw, password, keyBits, iterations)
                        val baseName = inputFileName.ifEmpty { "file" }
                        val f = saveOutputFile(context, baseName, out, mode)
                        if (f != null) {
                            lastOutputFile = f
                            outputMsg = "已保存到：下载/AuroraCrypto/${f.name}"
                        } else {
                            outputMsg = "保存失败，请检查存储权限"
                        }
                        statusMsg = if (isEncrypt) "文件加密完成" else "文件解密完成"
                    }
                    "folder" -> {
                        val uri = inputFolderUri ?: throw Exception("请先选择文件夹")
                        val treeName = inputFolderName.ifEmpty { "folder" }
                        val suffix = if (isEncrypt) "_aes" else "_dec"
                        val outRootName = "${treeName}${suffix}"
                        val files = walkTree(context, uri)
                        var successCount = 0
                        withContext(Dispatchers.IO) {
                            for ((fileUri, rel) in files) {
                                val raw = context.contentResolver.openInputStream(fileUri)?.use { it.readBytes() }
                                    ?: continue
                                val processed = try {
                                    if (isEncrypt) AesCrypto.encrypt(raw, password, keyBits, iterations)
                                    else AesCrypto.decrypt(raw, password, keyBits, iterations)
                                } catch (e: Exception) { continue }
                                val outName = if (isEncrypt) "$rel.aes" else rel.removeSuffix(".aes")
                                val saved = saveToPublicDownloads(context, "$outRootName/$outName", processed)
                                if (saved != null) successCount++
                            }
                        }
                        lastOutputFolder = "下载/AuroraCrypto/$outRootName/"
                        lastOutputFolderName = outRootName
                        outputMsg = "已处理 $successCount 个文件，保存在 $lastOutputFolder 目录"
                        statusMsg = if (isEncrypt) "文件夹加密完成" else "文件夹解密完成"
                    }
                }
            } catch (e: Exception) {
                errorMsg = when (e) {
                    is AEADBadTagException -> "解密失败：密码错误，或数据已被篡改"
                    else -> "操作失败：${e.message ?: e.javaClass.simpleName}"
                }
                statusMsg = ""
            } finally {
                isProcessing = false
            }
        }
    }

    fun copyOutput() {
        if (outputText.isNotEmpty()) {
            clipboard.setText(AnnotatedString(outputText))
            Toast.makeText(context, "已复制到剪贴板", Toast.LENGTH_SHORT).show()
        }
    }

    fun downloadOutputText() {
        if (outputText.isEmpty()) return
        val fileName = (if (isEncrypt) "aes_output" else "dec_output") + ".txt"
        val f = saveToPublicDownloads(context, fileName, outputText.toByteArray(Charsets.UTF_8))
        if (f != null) {
            Toast.makeText(context, "已保存到 下载/AuroraCrypto/$fileName", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "保存失败", Toast.LENGTH_SHORT).show()
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically(initialOffsetY = { it }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { it })
    ) {
        Dialog(
            onDismissRequest = onClose,
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false,
                decorFitsSystemWindows = false
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AesBg)
                    .systemBarsPadding()
            ) {
                Column(Modifier.fillMaxSize()) {
                    // ── 顶栏 ──
                    Surface(
                        tonalElevation = 2.dp,
                        shadowElevation = 4.dp,
                        color = Color.White
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onClose) {
                                Icon(Icons.Filled.ArrowBack, contentDescription = "返回", tint = AesText)
                            }
                            Icon(
                                Icons.Filled.Lock,
                                contentDescription = null,
                                tint = AesOrange,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text("AES 加密工具", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = AesText)
                                Text(
                                    if (isEncrypt) "使用密码加密你的文件与文本" else "使用密码解密文件与文本",
                                    fontSize = 11.sp, color = AesSub
                                )
                            }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = {
                                password = ""
                                inputText = ""
                                inputFileUri = null; inputFileName = ""
                                inputFolderUri = null; inputFolderName = ""
                                outputText = ""; outputMsg = ""
                                statusMsg = ""; errorMsg = ""
                                Toast.makeText(context, "已清空所有输入", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(Icons.Filled.RestartAlt, contentDescription = "清空", tint = AesSub)
                            }
                        }
                    }

                    // ── 模式 Tab ──
                    TabRow(
                        selectedTabIndex = if (isEncrypt) 0 else 1,
                        containerColor = Color.White,
                        contentColor = AesBlue,
                        divider = { HorizontalDivider(color = AesBorder) }
                    ) {
                        Tab(
                            selected = isEncrypt,
                            onClick = { mode = "encrypt" },
                            selectedContentColor = AesBlue,
                            unselectedContentColor = AesSub,
                            text = { Text("加密", fontWeight = if (isEncrypt) FontWeight.Bold else FontWeight.Medium) }
                        )
                        Tab(
                            selected = !isEncrypt,
                            onClick = { mode = "decrypt" },
                            selectedContentColor = AesBlue,
                            unselectedContentColor = AesSub,
                            text = { Text("解密", fontWeight = if (!isEncrypt) FontWeight.Bold else FontWeight.Medium) }
                        )
                    }

                    // ── 内容 ──
                    Column(
                        Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // 加密对象
                        Card(
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = AesCard),
                            border = BorderStroke(1.dp, AesBorder)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                SectionTitle(if (isEncrypt) "加密对象" else "解密对象", Icons.Filled.Category)
                                SegmentedRow(
                                    options = listOf(
                                        "text" to "文本",
                                        "file" to "文件",
                                        "folder" to "文件夹"
                                    ),
                                    selected = target,
                                    onSelect = { target = it }
                                )
                            }
                        }

                        // 输入区
                        Card(
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = AesCard),
                            border = BorderStroke(1.dp, AesBorder)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                SectionTitle(if (isEncrypt) "输入（待加密）" else "输入（待解密）", Icons.Filled.Input)
                                when (target) {
                                    "text" -> {
                                        OutlinedTextField(
                                            value = inputText,
                                            onValueChange = { inputText = it; errorMsg = "" },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .heightIn(min = 120.dp, max = 220.dp),
                                            placeholder = { Text(if (isEncrypt) "输入要加密的文本…" else "粘贴密文（Base64 / Hex）…") },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                unfocusedBorderColor = AesBorder,
                                                focusedBorderColor = AesBlue,
                                                cursorColor = AesBlue
                                            ),
                                            textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
                                        )
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            Text("${inputText.length} 字符", fontSize = 11.sp, color = AesSub)
                                        }
                                    }
                                    "file" -> {
                                        val has = inputFileUri != null
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(if (has) Color(0xFFEFF6FF) else Color(0xFFF1F5F9))
                                                .clickable { filePicker.launch("*/*") }
                                                .padding(20.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(
                                                    if (has) Icons.Filled.Description else Icons.Filled.UploadFile,
                                                    contentDescription = null,
                                                    tint = AesBlue,
                                                    modifier = Modifier.size(30.dp)
                                                )
                                                Spacer(Modifier.height(8.dp))
                                                Text(
                                                    if (has) inputFileName else "点击选择文件",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = if (has) AesText else AesSub
                                                )
                                                if (has) {
                                                    Spacer(Modifier.height(6.dp))
                                                    TextButton(onClick = {
                                                        inputFileUri = null; inputFileName = ""
                                                    }) { Text("清除", color = Color(0xFFDC2626), fontSize = 12.sp) }
                                                }
                                            }
                                        }
                                    }
                                    "folder" -> {
                                        val has = inputFolderUri != null
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(if (has) Color(0xFFEFF6FF) else Color(0xFFF1F5F9))
                                                .clickable { folderPicker.launch(null) }
                                                .padding(20.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(
                                                    if (has) Icons.Filled.FolderOpen else Icons.Filled.CreateNewFolder,
                                                    contentDescription = null,
                                                    tint = AesBlue,
                                                    modifier = Modifier.size(30.dp)
                                                )
                                                Spacer(Modifier.height(8.dp))
                                                Text(
                                                    if (has) inputFolderName else "点击选择文件夹",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = if (has) AesText else AesSub
                                                )
                                                if (has) {
                                                    Spacer(Modifier.height(6.dp))
                                                    TextButton(onClick = {
                                                        inputFolderUri = null; inputFolderName = ""
                                                    }) { Text("清除", color = Color(0xFFDC2626), fontSize = 12.sp) }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // 密码
                        Card(
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = AesCard),
                            border = BorderStroke(1.dp, AesBorder)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                SectionTitle("密码", Icons.Filled.Key)
                                OutlinedTextField(
                                    value = password,
                                    onValueChange = { password = it; errorMsg = "" },
                                    modifier = Modifier.fillMaxWidth(),
                                    placeholder = { Text("输入密码") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                    trailingIcon = {
                                        Row {
                                            if (isEncrypt) {
                                                IconButton(onClick = {
                                                    password = generatePassword()
                                                    clipboard.setText(AnnotatedString(password))
                                                    Toast.makeText(context, "随机密码已生成并复制到剪贴板", Toast.LENGTH_SHORT).show()
                                                }) {
                                                    Icon(Icons.Filled.Casino, contentDescription = "随机密码", tint = AesBlue)
                                                }
                                            }
                                            IconButton(onClick = { showPassword = !showPassword }) {
                                                Icon(
                                                    if (showPassword) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                                    contentDescription = if (showPassword) "隐藏密码" else "显示密码", tint = AesSub
                                                )
                                            }
                                            if (password.isNotEmpty()) {
                                                IconButton(onClick = {
                                                    clipboard.setText(AnnotatedString(password))
                                                    Toast.makeText(context, "密码已复制", Toast.LENGTH_SHORT).show()
                                                }) {
                                                    Icon(Icons.Filled.ContentCopy, contentDescription = "复制密码", tint = AesBlue)
                                                }
                                            }
                                        }
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        unfocusedBorderColor = AesBorder,
                                        focusedBorderColor = AesBlue,
                                        cursorColor = AesBlue
                                    )
                                )
                                if (isEncrypt) {
                                    Spacer(Modifier.height(8.dp))
                                    val strength = passwordStrength(password)
                                    val strengthColors = listOf(
                                        Color(0xFFE2E8F0), Color(0xFFEF4444), Color(0xFFF59E0B),
                                        Color(0xFF3B82F6), Color(0xFF059669)
                                    )
                                    val strengthLabels = listOf("", "弱", "一般", "较强", "强")
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        repeat(4) { i ->
                                            Box(
                                                Modifier
                                                    .weight(1f)
                                                    .height(6.dp)
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(if (i < strength) strengthColors[strength] else Color(0xFFE2E8F0))
                                            )
                                        }
                                    }
                                    if (password.isNotEmpty()) {
                                        Spacer(Modifier.height(4.dp))
                                        Text("密码强度：${strengthLabels[strength]}", fontSize = 11.sp, color = strengthColors[strength])
                                    }
                                }
                            }
                        }

                        // 算法与参数（仅加密时显示完整参数，解密时只显示提示）
                        if (isEncrypt) {
                            Card(
                                Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = AesCard),
                                border = BorderStroke(1.dp, AesBorder)
                            ) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    SectionTitle("算法与参数", Icons.Filled.Settings)
                                    Column {
                                        Text("加密算法", fontSize = 12.sp, color = AesSub)
                                        Spacer(Modifier.height(6.dp))
                                        SegmentedRow(
                                            options = listOf("AES-256-GCM" to "AES-256-GCM", "AES-128-GCM" to "AES-128-GCM"),
                                            selected = algo,
                                            onSelect = { algo = it }
                                        )
                                    }
                                    if (target == "text") {
                                        Column {
                                            Text("输出编码", fontSize = 12.sp, color = AesSub)
                                            Spacer(Modifier.height(6.dp))
                                            SegmentedRow(
                                                options = listOf("Base64" to "Base64", "Hex" to "Hex"),
                                                selected = encoding,
                                                onSelect = { encoding = it }
                                            )
                                        }
                                    }
                                    Column {
                                        Text("密钥派生迭代次数 (PBKDF2)", fontSize = 12.sp, color = AesSub)
                                        Spacer(Modifier.height(6.dp))
                                        SegmentedRow(
                                            options = listOf(10000 to "1万", 50000 to "5万", 100000 to "10万"),
                                            selected = iterations,
                                            onSelect = { iterations = it }
                                        )
                                    }
                                }
                            }
                        }

                        // 执行按钮
                        Button(
                            onClick = { doProcess() },
                            enabled = !isProcessing,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if (isEncrypt) AesBlue else AesOrange)
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("处理中…", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            } else {
                                Icon(if (isEncrypt) Icons.Filled.Lock else Icons.Filled.LockOpen, contentDescription = null, tint = Color.White)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    if (isEncrypt) "加密" else "解密",
                                    fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White
                                )
                            }
                        }

                        // 状态 / 错误
                        if (statusMsg.isNotEmpty()) {
                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFFECFDF5)).padding(12.dp)
                            ) {
                                Text(statusMsg, fontSize = 13.sp, color = Color(0xFF059669), fontWeight = FontWeight.Medium)
                            }
                        }
                        if (errorMsg.isNotEmpty()) {
                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFFFEF2F2)).padding(12.dp)
                            ) {
                                Text(errorMsg, fontSize = 13.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Medium)
                            }
                        }

                        // 输出区
                        Card(
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = AesCard),
                            border = BorderStroke(1.dp, AesBorder)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    SectionTitle("输出（${if (isEncrypt) "密文" else "明文"}）", Icons.Filled.Output)
                                    Spacer(Modifier.weight(1f))
                                    if (target == "text" && outputText.isNotEmpty()) {
                                        TextButton(onClick = { copyOutput() }) {
                                            Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = AesBlue, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(2.dp))
                                            Text("复制", color = AesBlue, fontSize = 12.sp)
                                        }
                                        TextButton(onClick = { downloadOutputText() }) {
                                            Icon(Icons.Filled.Download, contentDescription = null, tint = AesBlue, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(2.dp))
                                            Text("保存", color = AesBlue, fontSize = 12.sp)
                                        }
                                    }
                                    if (target == "file" && lastOutputFile != null) {
                                        TextButton(onClick = { shareFile(context, lastOutputFile!!) }) {
                                            Icon(Icons.Filled.Share, contentDescription = null, tint = AesBlue, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(2.dp))
                                            Text("分享文件", color = AesBlue, fontSize = 12.sp)
                                        }
                                        TextButton(onClick = {
                                            clipboard.setText(AnnotatedString(lastOutputFile!!.absolutePath))
                                            Toast.makeText(context, "路径已复制", Toast.LENGTH_SHORT).show()
                                        }) {
                                            Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = AesBlue, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(2.dp))
                                            Text("复制路径", color = AesBlue, fontSize = 12.sp)
                                        }
                                    }
                                    if (target == "folder" && lastOutputFolder != null) {
                                        TextButton(onClick = {
                                            val rootName = lastOutputFolderName
                                            if (rootName != null) {
                                                val src = File(context.cacheDir, "AuroraCrypto/$rootName")
                                                if (src.exists() && src.isDirectory) {
                                                    val zip = File(context.cacheDir, "AuroraCrypto/${rootName}.zip")
                                                    try {
                                                        zipFolder(src, zip)
                                                        shareFile(context, zip)
                                                    } catch (e: Exception) {
                                                        Toast.makeText(context, "打包失败: ${e.message}", Toast.LENGTH_SHORT).show()
                                                    }
                                                } else {
                                                    Toast.makeText(context, "未找到输出文件，无法分享", Toast.LENGTH_SHORT).show()
                                                }
                                            } else {
                                                Toast.makeText(context, "未找到输出文件，无法分享", Toast.LENGTH_SHORT).show()
                                            }
                                        }) {
                                            Icon(Icons.Filled.Share, contentDescription = null, tint = AesBlue, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(2.dp))
                                            Text("分享文件夹", color = AesBlue, fontSize = 12.sp)
                                        }
                                        TextButton(onClick = {
                                            clipboard.setText(AnnotatedString(lastOutputFolder!!))
                                            Toast.makeText(context, "目录路径已复制", Toast.LENGTH_SHORT).show()
                                        }) {
                                            Icon(Icons.Filled.ContentCopy, contentDescription = null, tint = AesBlue, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(2.dp))
                                            Text("复制目录路径", color = AesBlue, fontSize = 12.sp)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                when (target) {
                                    "text" -> {
                                        if (outputText.isEmpty()) {
                                            Text("结果将显示在这里", fontSize = 13.sp, color = AesSub)
                                        } else {
                                            OutlinedTextField(
                                                value = outputText,
                                                onValueChange = {},
                                                readOnly = true,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .heightIn(min = 120.dp, max = 260.dp)
                                                    .verticalScroll(rememberScrollState()),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = OutlinedTextFieldDefaults.colors(
                                                    unfocusedBorderColor = AesBorder,
                                                    focusedBorderColor = AesBlue
                                                ),
                                                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                                            )
                                        }
                                    }
                                    else -> {
                                        if (outputMsg.isEmpty()) {
                                            Text("结果将显示在这里", fontSize = 13.sp, color = AesSub)
                                        } else {
                                            Text(outputMsg, fontSize = 13.sp, color = AesText, lineHeight = 20.sp)
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}
