package com.aurora.chat.ui.chat

// ==================== 热缓存（内存消息缓存，2分钟过期） ====================
// key = "currentUserId:friendId"，切换账号后不命中旧缓存
internal data class HotCacheEntry(val cachedAtMs: Long, val messages: List<ChatMsg>)
internal val messageHotCache = mutableMapOf<String, HotCacheEntry>()
internal const val HOT_CACHE_TTL_MS = 1_800_000L // 30分钟（缓存永不过期，网络刷新增量）

data class ChatMsg(
    override val id: Long,
    override val text: String,
    override val isMine: Boolean,
    override val fromUserId: Long,
    override val senderName: String = "",
    override val wornBadge: Int = 0,
    override val time: Long = System.currentTimeMillis(),
    override var isNew: Boolean = false,
    override val createdAt: Long = 0,  // 服务端时间戳（秒），0表示本地消息
    override val isRevoked: Int = 0,
    override val isSystemNotice: Boolean = false,  // true = 系统通知（居中显示，非气泡）
    override val replyToText: String = "",
    override val replyToSender: String = "",
    override val replyToId: Long = 0,
    override val mediaType: String = "",
    override val mediaUrl: String = "",
    override val isUploading: Boolean = false,  // 正在上传中
    override val toUserId: Long = 0,
    override val targetName: String = "",
    override val flashDuration: Int = 0,  // 0=普通照片，>0=闪照秒数
    override val reasoningText: String = ""
) : IMessageRef {
    companion object {
        private var nextId = System.currentTimeMillis()
        fun create(text: String, isMine: Boolean, fromUserId: Long = 0, serverId: Long = 0, isNew: Boolean = false, senderName: String = "", wornBadge: Int = 0, createdAt: Long = 0, isRevoked: Int = 0, isSystemNotice: Boolean = false, replyToText: String = "", replyToSender: String = "", replyToId: Long = 0, mediaType: String = "", mediaUrl: String = "", isUploading: Boolean = false, flashDuration: Int = 0, toUserId: Long = 0, targetName: String = "", reasoningText: String = ""): ChatMsg {
            val normalizedType = when {
                mediaType.startsWith("video/") -> "video"
                mediaType.startsWith("image/") -> "image"
                mediaType == "mp4" -> "video"
                mediaType == "jpg" || mediaType == "png" || mediaType == "gif" || mediaType == "jpeg" -> "image"
                else -> mediaType
            }
            return ChatMsg(
                id = if (serverId > 0) serverId else nextId++,
                text = text, isMine = isMine, fromUserId = fromUserId, isNew = isNew, senderName = senderName, wornBadge = wornBadge, createdAt = createdAt, isRevoked = isRevoked, isSystemNotice = isSystemNotice, replyToText = replyToText, replyToSender = replyToSender, replyToId = replyToId, mediaType = normalizedType, mediaUrl = mediaUrl, isUploading = isUploading, flashDuration = flashDuration, toUserId = toUserId, targetName = targetName, reasoningText = reasoningText
            )
        }
    }
}
