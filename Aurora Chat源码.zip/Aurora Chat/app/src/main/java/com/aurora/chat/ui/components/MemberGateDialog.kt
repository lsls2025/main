package com.aurora.chat.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * 会员专享功能限用弹窗：非会员点击受保护功能时弹出，
 * 提示跳转会员中心购买会员。点击「跳转会员」先关闭弹窗再触发 onSubscribe（与会员订阅按钮一致）。
 */
@Composable
fun MemberGateDialog(onDismiss: () -> Unit, onSubscribe: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = {
            Text("会员专享", fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        },
        text = {
            Text(
                "仅会员可使用该功能，是否跳转至会员中心购买会员？",
                fontSize = 14.sp,
                color = Color(0xFF374151)
            )
        },
        confirmButton = {
            TextButton(onClick = {
                onDismiss()
                onSubscribe()
            }) {
                Text("跳转会员", color = Color(0xFF1E40AF), fontWeight = FontWeight.Medium)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消", color = Color(0xFF6B7280))
            }
        }
    )
}
