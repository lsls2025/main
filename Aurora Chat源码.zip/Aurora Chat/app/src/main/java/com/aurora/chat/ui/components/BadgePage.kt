package com.aurora.chat.ui.components

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.aurora.chat.R
import com.aurora.chat.data.api.AuroraApi
import kotlinx.coroutines.launch

/**
 * 徽章数据
 */
data class BadgeInfo(
    val name: String,
    val resId: Int,
    val description: String
)

/**
 * 已知徽章列表（1-10 号），动态添加的徽章 >10 号会自动追加显示
 */
val badgeList = BadgeResources.badgeInfos

@Composable
fun BadgePage(
    onClose: () -> Unit,
    isDeveloper: Boolean = false
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val badgePrefs = remember { context.getSharedPreferences("aurora_badges", Context.MODE_PRIVATE) }
    var badgeEnabled by remember { mutableStateOf(badgePrefs.getBoolean("enabled", true)) }
    var ownedBadgeIds by remember { mutableStateOf(setOf<Int>()) }
    // 徽章到期时间：badge_id -> expires_at (0=永久)
    var badgeExpiresAt by remember { mutableStateOf(mapOf<Int, Long>()) }
    var wornBadgeId by remember { mutableIntStateOf(0) }
    var loaded by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf(false) }
    // 倒计时：每秒触发一次重组以更新剩余天数显示
    var nowTick by remember { mutableLongStateOf(System.currentTimeMillis() / 1000) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            nowTick = System.currentTimeMillis() / 1000
        }
    }

    fun remainingDays(expiresAt: Long): String {
        if (expiresAt == 0L) return "永久"
        val days = ((expiresAt - nowTick) / 86400).toInt()
        return if (days <= 0) "已过期" else "${days}天"
    }

    // 从服务器加载徽章数据（首次进入页面时调用，显示加载转圈）
    suspend fun loadBadges() {
        loaded = false
        loadError = false
        try {
            val result = AuroraApi.getUserBadges()
            val data = result.data
            if (data != null) {
                val arr = data.optJSONArray("badges")
                val ids = mutableSetOf<Int>()
                val expMap = mutableMapOf<Int, Long>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val bid = obj.optInt("badge_id")
                        ids.add(bid)
                        expMap[bid] = obj.optLong("expires_at", 0)
                    }
                }
                ownedBadgeIds = ids
                badgeExpiresAt = expMap
                wornBadgeId = data.optInt("worn_badge", 0)
            } else {
                loadError = true
            }
        } catch (e: Exception) {
            android.util.Log.e("BadgePage", "加载徽章失败: ${e.localizedMessage}", e)
            loadError = true
        }
        loaded = true
    }

    // 静默同步：佩戴/取消后用（不显示加载转圈，仅刷新数据）
    suspend fun syncBadges() {
        try {
            val result = AuroraApi.getUserBadges()
            val data = result.data
            if (data != null) {
                val arr = data.optJSONArray("badges")
                val ids = mutableSetOf<Int>()
                val expMap = mutableMapOf<Int, Long>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val bid = obj.optInt("badge_id")
                        ids.add(bid)
                        expMap[bid] = obj.optLong("expires_at", 0)
                    }
                }
                ownedBadgeIds = ids
                badgeExpiresAt = expMap
                wornBadgeId = data.optInt("worn_badge", 0)
            }
        } catch (_: Exception) { }
    }

    // 每次进入页面时从服务器重新加载
    LaunchedEffect(Unit) { loadBadges() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { /* 阻止事件穿透 */ }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            // 顶部栏
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clickable { onClose() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "←",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E40AF)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    "徽章",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1F2937),
                    modifier = Modifier.weight(1f)
                )
                // 开关：关闭时自动取消佩戴并重新同步
                Switch(
                    checked = badgeEnabled,
                    onCheckedChange = { enabled ->
                        badgeEnabled = enabled
                        badgePrefs.edit().putBoolean("enabled", enabled).apply()
                        if (!enabled && wornBadgeId > 0) {
                            wornBadgeId = 0
                            scope.launch {
                                try {
                                    AuroraApi.setWornBadge(0)
                                    syncBadges()
                                } catch (_: Exception) {
                                    syncBadges()
                                }
                            }
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF1E40AF),
                        uncheckedThumbColor = Color.White,
                        uncheckedTrackColor = Color(0xFFD1D5DB)
                    )
                )
            }

            HorizontalDivider(
                color = Color(0xFFE5E7EB),
                thickness = 0.5.dp
            )

            Spacer(Modifier.height(8.dp))

            if (!badgeEnabled) {
                // 关闭状态提示
                Spacer(Modifier.height(60.dp))
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🏅", fontSize = 36.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("徽章展示已关闭", fontSize = 15.sp, color = Color(0xFF9CA3AF))
                    Spacer(Modifier.height(4.dp))
                    Text("打开开关后可佩戴徽章", fontSize = 13.sp, color = Color(0xFFD1D5DB))
                }
            } else if (!loaded) {
                // 加载中：显示蓝色转圈，不显示任何徽章
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF1E40AF), modifier = Modifier.size(36.dp))
                }
            } else if (loadError) {
                // 加载失败
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("加载失败", fontSize = 15.sp, color = Color(0xFFEF4444))
                        Spacer(Modifier.height(8.dp))
                        Text("点击重新加载", fontSize = 13.sp, color = Color(0xFF1E40AF),
                            modifier = Modifier.clickable { scope.launch { loadBadges() } })
                    }
                }
            } else {

            // 统计信息 + 提示
            Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val extraBadgeIds = ownedBadgeIds.filter { it > badgeList.size }
                    val totalBadgeCount = badgeList.size + extraBadgeIds.size
                    Text(
                        "共 $totalBadgeCount 个",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1F2937)
                    )
                    Text(
                        " · 长按卡片查看详情",
                        fontSize = 11.sp,
                        color = Color(0xFF6B7280)
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (ownedBadgeIds.isNotEmpty()) "已拥有 ${ownedBadgeIds.size} 个" else "未拥有",
                        fontSize = 12.sp,
                        color = if (ownedBadgeIds.isNotEmpty()) Color(0xFF1E40AF) else Color(0xFF9CA3AF)
                    )
                }

                Spacer(Modifier.height(8.dp))

                // 徽章网格 - 3列
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 20.dp)
                ) {
                    // 显示所有已知徽章（1-10），无论是否拥有
                    itemsIndexed(badgeList) { index, badge ->
                        val badgeId = index + 1
                        val owned = badgeId in ownedBadgeIds
                        val isWorn = wornBadgeId == badgeId
                        val remaining = if (owned) remainingDays(badgeExpiresAt[badgeId] ?: 0L) else ""
                        BadgeItem(
                            badge = badge,
                            index = index,
                            owned = owned,
                            isWorn = isWorn,
                            remainingText = remaining,
                            onWear = {
                                if (owned) {
                                    scope.launch {
                                        try {
                                            val newBadgeId = if (isWorn) 0 else badgeId
                                            AuroraApi.setWornBadge(newBadgeId)
                                            // 佩戴成功立即更新本地状态，静默同步后台
                                            wornBadgeId = newBadgeId
                                            syncBadges()
                                        } catch (_: Exception) {
                                            syncBadges()
                                        }
                                    }
                                }
                            }
                        )
                    }
                    // 额外显示拥有但超出 1-10 范围的徽章
                    val extraBadgeIds = ownedBadgeIds.filter { it > badgeList.size }.sorted()
                    itemsIndexed(extraBadgeIds) { _, badgeId ->
                        val isWorn = wornBadgeId == badgeId
                        val remaining = remainingDays(badgeExpiresAt[badgeId] ?: 0L)
                        BadgeItem(
                            badge = BadgeInfo(
                                name = "徽章 #${badgeId}",
                                resId = R.drawable.badge_bazaar_1,
                                description = ""
                            ),
                            index = badgeId - 1,
                            owned = true,
                            isWorn = isWorn,
                            remainingText = remaining,
                            onWear = {
                                scope.launch {
                                    try {
                                        val newBadgeId = if (isWorn) 0 else badgeId
                                        AuroraApi.setWornBadge(newBadgeId)
                                        wornBadgeId = newBadgeId
                                        syncBadges()
                                    } catch (_: Exception) {
                                        syncBadges()
                                    }
                                }
                            }
                        )
                    }
                }
            } // else block end
        }
    }
}

/**
 * 单个徽章卡片 — 长按查看详情；点击佩戴/取消；蓝框表示当前佩戴
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BadgeItem(
    badge: BadgeInfo,
    index: Int,
    owned: Boolean = false,
    isWorn: Boolean = false,
    remainingText: String = "",
    onWear: () -> Unit = {}
) {
    var showDetail by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .then(
                if (isWorn) Modifier.border(2.5.dp, Color(0xFF1E40AF), RoundedCornerShape(12.dp))
                else Modifier
            )
            .combinedClickable(
                onClick = { if (owned) onWear() },
                onLongClick = { showDetail = true },
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isWorn) Color(0xFFE8F0FE) else if (owned) Color(0xFFF0F4FF) else Color(0xFFF8F9FA)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(8.dp)
            ) {
                // 徽章图片
                Image(
                    painter = painterResource(id = badge.resId),
                    contentDescription = badge.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(4.dp)
                        .alpha(if (owned) 1f else 0.45f)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Fit
                )

                Spacer(Modifier.height(6.dp))

                // 状态文字
                Text(
                    if (isWorn) "佩戴中" else if (owned) "已拥有" else "未拥有",
                    fontSize = 11.sp,
                    color = if (isWorn) Color(0xFF1E40AF) else if (owned) Color(0xFF1E40AF) else Color(0xFF9CA3AF),
                    textAlign = TextAlign.Center,
                    fontWeight = if (isWorn) FontWeight.Bold else FontWeight.Medium
                )

                // 拥有时显示剩余天数
                if (owned && remainingText.isNotEmpty()) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        remainingText,
                        fontSize = 10.sp,
                        color = if (remainingText == "永久") Color(0xFF10B981) else Color(0xFFF59E0B),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }

    // 长按弹出详情弹窗
    if (showDetail) {
        BadgeDetailDialog(
            badge = badge,
            owned = owned,
            remainingText = remainingText,
            onDismiss = { showDetail = false }
        )
    }
}

/**
 * 公共徽章信息弹窗 — 供外部场景点击徽章时使用
 * 只显示徽章名称、图片和描述内容，不显示"获得条件"标签
 */
@Composable
fun BadgeInfoDialog(
    badgeId: Int,
    onDismiss: () -> Unit
) {
    // 规范映射：bazaar 1-12 + 会员 13/14/15（与后端授予及聊天/开发管理一致）。
    // 旧 badgeList 仅 13 项且把会员徽章误放在 11/12/13，导致 id 14/15 越界不弹窗。
    val info = run {
        val canonical = mutableListOf<BadgeInfo>().apply {
            addAll(badgeList.subList(0, 10)) // bazaar 1-10
            add(BadgeInfo("官方限定徽章", R.drawable.badge_bazaar_11, "官方限定徽章"))
            add(BadgeInfo("官方限定徽章", R.drawable.badge_bazaar_12, "官方限定徽章"))
            add(BadgeInfo("普通会员徽章", R.drawable.badge_member_1, "开通普通会员即可获得，佩戴展示您的会员身份"))
            add(BadgeInfo("高级会员徽章", R.drawable.badge_member_3, "开通高级会员即可获得，彰显更高会员等级"))
            add(BadgeInfo("尊享会员徽章", R.drawable.badge_member_2, "开通尊享会员尊享专属身份标识"))
        }
        canonical.getOrNull(badgeId - 1)
    } ?: return
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = info.resId),
                contentDescription = info.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(16.dp))
            Text(
                info.name,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0xFFE5E7EB))
            )
            Spacer(Modifier.height(12.dp))
            Text(
                info.description,
                fontSize = 14.sp,
                color = Color(0xFF6B7280),
                lineHeight = 22.sp,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("知道了", fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

/**
 * 徽章详情弹窗 (BadgePage 内部使用，含拥有状态和佩戴功能)
 */
@Composable
private fun BadgeDetailDialog(
    badge: BadgeInfo,
    owned: Boolean = false,
    remainingText: String = "",
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 徽章图片
            Image(
                painter = painterResource(id = badge.resId),
                contentDescription = badge.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .alpha(if (owned) 1f else 0.6f)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Fit
            )

            Spacer(Modifier.height(16.dp))

            // 徽章名称
            Text(
                badge.name,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937),
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(4.dp))

            // 状态
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = if (owned) Color(0xFFE8F0FE) else Color(0xFFF3F4F6)
            ) {
                Text(
                    if (owned) "已拥有" else "未拥有",
                    fontSize = 12.sp,
                    color = if (owned) Color(0xFF1E40AF) else Color(0xFF9CA3AF),
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp)
                )
            }

            Spacer(Modifier.height(16.dp))

            // 分割线
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0xFFE5E7EB))
            )

            Spacer(Modifier.height(12.dp))

            // 获得条件
            Text(
                "获得条件",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1F2937),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(6.dp))

            Text(
                badge.description,
                fontSize = 14.sp,
                color = Color(0xFF6B7280),
                lineHeight = 22.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(20.dp))

            // 关闭按钮
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1E40AF)
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("知道了", fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}
