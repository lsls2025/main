package com.aurora.chat.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.chat.KeepAliveManager

@Composable
fun KeepAliveSettingsPage(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    // 每次进入直接从 SharedPreferences 读，不依赖 remember 缓存
    var l1 by remember { mutableStateOf(KeepAliveManager.isLayer1Enabled(context)) }
    var l2 by remember { mutableStateOf(KeepAliveManager.isLayer2Enabled(context)) }
    var l3 by remember { mutableStateOf(KeepAliveManager.isLayer3Enabled(context)) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
    ) {
        // ── 顶部栏 ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("←", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF),
                modifier = Modifier.clickable { onBack() }.padding(end = 12.dp))
            Text("后台保活", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
        }

        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ── L1 核心保活 ──
            KeepAliveCard(
                title = "核心保活",
                subtitle = "最低功耗，推荐始终开启",
                description = "使用前台服务维持 TCP 长连接，TCP KeepAlive 内核探活防止 NAT 超时；自适应心跳根据当前网络自动调整（WiFi 45秒/移动网络 20秒）",
                isChecked = l1,
                accentColor = Color(0xFF1E40AF),
                onToggle = {
                    val newState = !l1
                    l1 = newState
                    KeepAliveManager.setLayer1(context, newState)
                }
            )

            // ── L2 辅助防休眠 ──
            KeepAliveCard(
                title = "辅助防休眠",
                subtitle = "减少系统杀进程概率",
                description = "创建 1px 透明悬浮窗提升进程优先级，引导你加入电池优化白名单和厂商后台白名单。开启后系统对后台限制减少，续航会有轻微影响",
                isChecked = l2,
                accentColor = Color(0xFFD97706),
                onToggle = {
                    val newState = !l2
                    l2 = newState
                    KeepAliveManager.setLayer2(context, newState)
                    if (newState) KeepAliveManager.requestBackgroundPermission(context)
                }
            )

            // ── L3 定时唤醒 ──
            KeepAliveCard(
                title = "定时唤醒",
                subtitle = "断连后自动恢复，适合高实时性需求",
                description = "AlarmManager 每 10 分钟唤醒 CPU 检测连接状态，断连后自动重连。会额外增加一定耗电，适合对消息实时性要求高的场景",
                isChecked = l3,
                accentColor = Color(0xFF059669),
                onToggle = {
                    val newState = !l3
                    l3 = newState
                    KeepAliveManager.setLayer3(context, newState)
                }
            )

            Spacer(Modifier.height(8.dp))

            // ── 测试通知 ──
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF0FDF4))
                    .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(14.dp))
                    .clickable {
                        com.aurora.chat.NotificationHelper.showMessageNotification(
                            context, "Aurora Chat 测试通知",
                            "如果你的设备能看到这条通知，说明通知通道是正常的"
                        )
                        android.widget.Toast.makeText(context, "已发送测试通知，请下拉通知栏查看", android.widget.Toast.LENGTH_LONG).show()
                    }
                    .padding(vertical = 16.dp, horizontal = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("发送测试通知", fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF16A34A))
            }

            Spacer(Modifier.height(16.dp))

            // ── 请求后台运行权限 ──
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFEFF6FF))
                    .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(14.dp))
                    .clickable { KeepAliveManager.requestBackgroundPermission(context) }
                    .padding(vertical = 16.dp, horizontal = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("请求后台运行权限", fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1E40AF))
            }
        }
    }
}

@Composable
private fun KeepAliveCard(
    title: String,
    subtitle: String,
    description: String,
    isChecked: Boolean,
    accentColor: Color,
    onToggle: () -> Unit
) {
    val bgColor = if (isChecked) accentColor.copy(alpha = 0.08f) else Color(0xFFF9FAFB)
    val borderColor = if (isChecked) accentColor.copy(alpha = 0.3f) else Color(0xFFE5E7EB)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable { onToggle() }
            .padding(16.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
                    Spacer(Modifier.height(2.dp))
                    Text(subtitle, fontSize = 12.sp, color = Color(0xFF6B7280))
                }
                // 自定义开关
                Box(
                    modifier = Modifier
                        .size(48.dp, 28.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isChecked) accentColor else Color(0xFFD1D5DB))
                        .padding(horizontal = 3.dp, vertical = 3.dp),
                    contentAlignment = if (isChecked) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(Color.White)
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(description, fontSize = 12.sp, color = Color(0xFF6B7280), lineHeight = 18.sp)
        }
    }
}
