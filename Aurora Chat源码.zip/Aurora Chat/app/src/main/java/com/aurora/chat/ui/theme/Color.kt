package com.aurora.chat.ui.theme

import androidx.compose.ui.graphics.Color

val AuroraPrimary = Color(0xFF1E40AF)
val AuroraPrimaryDark = Color(0xFF1E3A5F)
val AuroraPrimaryLight = Color(0xFF60A5FA)
val StatusOnline = Color(0xFF00B894)
val StatusOffline = Color(0xFFE17055)
val StatusConnecting = Color(0xFFD29922)

val BgLight = Color(0xFFF0F6FF)
val CardLight = Color(0xFFFFFFFF)
val TextLight = Color(0xFF1A1A2E)
val TextLightSec = Color(0xFF6C757D)
val BorderLight = Color(0xFFD0D5DD)
val SurfaceLight = Color(0xFFFFFFFF)       // 亮色页面背景
val CardBgLight = Color(0xFFF8FAFC)         // 亮色卡片背景
val DividerLight = Color(0xFFE5E7EB)        // 亮色分割线

val BgDark = Color(0xFF0D1117)
val CardDark = Color(0xFF161B22)
val CardDarkElevated = Color(0xFF1C2128)
val TextDark = Color(0xFFE6EDF3)
val TextDarkSec = Color(0xFF8B949E)
val BorderDark = Color(0xFF30363D)
val SurfaceDark = Color(0xFF0D1117)         // 暗色页面背景
val CardBgDark = Color(0xFF161B22)          // 暗色卡片背景
val DividerDark = Color(0xFF30363D)         // 暗色分割线
