package com.aurora.chat.ui.tools

import androidx.compose.foundation.Image
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.aurora.chat.R
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.data.local.DataCache
import org.json.JSONObject

/**
 * 应用（工具）数据模型
 */
data class ToolItem(
    val name: String,
    val iconRes: Int?,
    val description: String,
    val fileName: String,
    val fileSizeBytes: Long = 0L,
    val packageName: String = "",
    val iconContentScale: Float = 1f,
    val isUserApp: Boolean = false,
    val userAppId: Long = 0L,
    val downloadUrl: String = "",
    val category: String = "",
    val screenshotUrls: List<String> = emptyList(),
    val version: String = "",
    val changelog: String = "",
    val downloadCount: Long = 0L,
    val developerUserId: Long = 0L,
    val developerUsername: String = ""
) {
    val sizeDisplay: String get() = when {
        fileSizeBytes >= 1_000_000_000 -> String.format("%.2f GB", fileSizeBytes / 1_000_000_000.0)
        fileSizeBytes >= 1_000_000 -> String.format("%.2f MB", fileSizeBytes / 1_000_000.0)
        fileSizeBytes >= 1_000 -> String.format("%.2f KB", fileSizeBytes / 1_000.0)
        fileSizeBytes > 0 -> "$fileSizeBytes B"
        else -> "未知大小"
    }
}

/** 全部分类列表（第一个"所有"表示不筛选） */
private val allCategories = listOf("所有", "推荐", "实用", "开发", "游戏", "社交", "影音", "购物", "工具", "通讯", "娱乐", "成人")

/** 硬编码工具列表（仅保留用于平台原生更新的内置应用） */
private val builtinTools = listOf(
    ToolItem(name = "Aurora Chat", iconRes = R.drawable.ic_app_icon, category = "实用",
        description = "Aurora Chat 是一款功能强大的即时通讯应用，支持文字聊天、群组管理、社区互动、应用市场等功能。",
        fileName = "aurora.apk", fileSizeBytes = 0L, packageName = "asia.aurorachat.app"),
)

/** JSONObject -> ToolItem */
private fun JSONObject.toToolItem(): ToolItem {
    val aid = optLong("id")
    val serverUrl = AuroraApi.serverUrl
    val screenshotArr = try {
        org.json.JSONArray(optString("screenshots", "[]"))
    } catch (_: Exception) {
        org.json.JSONArray()
    }
    val screenshotUrls = (0 until screenshotArr.length()).mapNotNull { idx ->
        val fileName = screenshotArr.optString(idx, "").trim()
        if (fileName.isNotEmpty()) "$serverUrl/api/apps/screenshot/$aid/$fileName" else null
    }
    return ToolItem(
        name = optString("name", "?"),
        iconRes = null,
        description = optString("description", ""),
        fileName = optString("name", "app") + ".apk",
        fileSizeBytes = optLong("file_size", 0),
        packageName = optString("package_name", ""),
        isUserApp = true,
        userAppId = aid,
        downloadUrl = optString("download_url", ""),
        category = optString("category", ""),
        screenshotUrls = screenshotUrls,
        version = optString("version", ""),
        changelog = optString("changelog", ""),
        downloadCount = optLong("download_count", 0),
        developerUserId = optLong("user_id", 0),
        developerUsername = optString("username", "")
    )
}

@Composable
fun ToolsScreen(onAppClick: (ToolItem) -> Unit = {}) {
    val ctx = LocalContext.current
    var searchText by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("所有") }
    var showTypeDialog by remember { mutableStateOf(false) }
    var searchTriggered by remember { mutableStateOf(false) }
    var userApps by remember { mutableStateOf<List<ToolItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // 加载用户提交的已审核应用
    LaunchedEffect(Unit) {
        isLoading = true
        val result = AuroraApi.getAppList()
        if (result.success && result.data != null) {
            userApps = (0 until result.data!!.length()).map { result.data!!.getJSONObject(it).toToolItem() }
            // 缓存应用列表到本地
            try {
                DataCache.saveAppList(ctx, result.data!!.toString())
            } catch (_: Exception) {}
        } else {
            // 离线时从本地缓存恢复
            try {
                val cached = DataCache.loadAppList(ctx)
                if (cached != null) {
                    val arr = org.json.JSONArray(cached)
                    userApps = (0 until arr.length()).map { arr.getJSONObject(it).toToolItem() }
                }
            } catch (_: Exception) {}
        }
        isLoading = false
    }

    // 合并所有应用
    val allTools = remember(builtinTools, userApps) { builtinTools + userApps }

    // 按类型过滤
    val filteredTools = if (selectedCategory == "所有") {
        allTools
    } else {
        allTools.filter { it.category == selectedCategory }
    }.let { list ->
        val keyword = searchText.trim().lowercase()
        if (searchTriggered && keyword.isNotEmpty()) list.filter { it.name.lowercase().contains(keyword) }
        else list
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF3F4F6))
                    .clickable { showTypeDialog = true }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(selectedCategory, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))
                    Spacer(Modifier.width(3.dp))
                    Text("▾", fontSize = 10.sp, color = Color(0xFF6B7280))
                }
            }

            Spacer(Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .weight(1f).heightIn(min = 36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFF3F4F6))
                    .padding(horizontal = 10.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                androidx.compose.foundation.text.BasicTextField(
                    value = searchText,
                    onValueChange = { searchText = it; if (it.isEmpty()) searchTriggered = false },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(fontSize = 13.sp, color = Color(0xFF1F2937)),
                    singleLine = true,
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(Color(0xFF1E40AF)),
                    decorationBox = { innerTextField ->
                        if (searchText.isEmpty()) {
                            Text("搜索应用", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                        }
                        innerTextField()
                    }
                )
            }

            Spacer(Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .height(36.dp).widthIn(min = 48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E40AF))
                    .clickable { searchTriggered = true },
                contentAlignment = Alignment.Center
            ) {
                Text("搜索", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White)
            }
        }

        Spacer(Modifier.height(20.dp))

        if (isLoading) {
            Box(
                modifier = Modifier.fillMaxWidth().height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    androidx.compose.material3.CircularProgressIndicator(
                        modifier = Modifier.size(36.dp),
                        color = Color(0xFF1E40AF),
                        strokeWidth = 3.dp
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("加载应用中...", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(filteredTools, key = { if (it.isUserApp) "user_${it.userAppId}" else "builtin_${it.name}" }) { tool ->
                    ToolCard(tool = tool, onClick = { onAppClick(tool) })
                }
            }
        }
    }

    if (showTypeDialog) {
        AlertDialog(
            onDismissRequest = { showTypeDialog = false },
            containerColor = Color.White,
            title = { Text("选择类型", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    allCategories.forEach { category ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (selectedCategory == category) Color(0xFFEEF2FF) else Color.Transparent)
                                .clickable { selectedCategory = category; showTypeDialog = false }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Text(category, fontSize = 14.sp, color = if (selectedCategory == category) Color(0xFF1E40AF) else Color(0xFF1F2937))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTypeDialog = false }) {
                    Text("确定", color = Color(0xFF1E40AF))
                }
            }
        )
    }
}

@Composable
private fun ToolCard(tool: ToolItem, onClick: () -> Unit) {
    val serverUrl = AuroraApi.serverUrl
    Column(
        Modifier.widthIn(max = 76.dp).clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (tool.isUserApp) {
                AsyncImage(
                    model = "$serverUrl/api/apps/icon/${tool.userAppId}",
                    contentDescription = tool.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else if (tool.iconRes != null) {
                Image(painter = painterResource(tool.iconRes), contentDescription = tool.name,
                    modifier = Modifier.fillMaxSize().scale(tool.iconContentScale), contentScale = ContentScale.Crop)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(tool.name, fontSize = 11.sp, fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 68.dp))
    }
}
