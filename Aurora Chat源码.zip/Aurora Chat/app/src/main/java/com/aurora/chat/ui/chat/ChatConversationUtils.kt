package com.aurora.chat.ui.chat

import android.content.Context
import androidx.core.content.ContextCompat
import com.aurora.chat.R
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.ui.components.BadgeResources
import com.aurora.chat.data.api.MessageInfo
import com.aurora.chat.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

internal data class Tuple4<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

// ==================== 本地对话（自己 / AI）公共逻辑 ====================
// 自己对话 friendId=0；AI 对话为固定内置的本地对话（friendId=AI_CHAT_ID），不做任何服务端交互
const val AI_CHAT_ID = -2L
// 通知系统：固定内置对话（friendId=NOTIFICATION_CHAT_ID），既非个人对话也非群聊，用户不可发消息
const val NOTIFICATION_CHAT_ID = -3L

/**
 * 把服务器返回的媒体路径拼成客户端可达的完整 URL。
 * 后端现在返回相对路径（/chat-media/xxx），必须用客户端已验证可达的 serverUrl 拼接；
 * 否则若后端在反向代理后、直接用 r.Host 拼出的 http://localhost:8080/... 手机端无法访问，
 * 表现为图片一直加载中转圈 / 空气泡，且对方设备永不可见。
 */
fun resolveMediaUrl(raw: String): String {
    if (raw.isEmpty()) return raw
    val base = com.aurora.chat.data.api.AuroraApi.serverUrl.trimEnd('/')
    if (raw.startsWith("http")) {
        // 后端在反向代理后可能返回内网 host（如 http://localhost:8080/chat-media/...），
        // 手机端无法访问。只要路径含 /chat-media/，就用客户端已知可达的 serverUrl 重写 host。
        val marker = "/chat-media/"
        val idx = raw.indexOf(marker)
        if (idx >= 0) return "$base${raw.substring(idx)}"
        return raw
    }
    return "$base/${raw.removePrefix("/")}"
}
// AI 回复占位（流式返回前显示），不计入发给模型的上下文
const val AI_THINKING = "思考中…"

fun isLocalChat(friendId: Long): Boolean = friendId == 0L || friendId == AI_CHAT_ID
fun isGroupChat(friendId: Long): Boolean = friendId < 0 && friendId != AI_CHAT_ID && friendId != NOTIFICATION_CHAT_ID
fun isNotificationChat(friendId: Long): Boolean = friendId == NOTIFICATION_CHAT_ID
fun localChatKey(friendId: Long): String = if (friendId == AI_CHAT_ID) "ai" else "self"

fun localChatMessagesFile(ctx: android.content.Context, currentUserId: Long, key: String): java.io.File =
    java.io.File(ctx.cacheDir, "${key}_chat_${currentUserId}.json")

fun loadLocalChatMessages(ctx: android.content.Context, currentUserId: Long, key: String): org.json.JSONArray? {
    val f = localChatMessagesFile(ctx, currentUserId, key)
    if (!f.exists()) return null
    return try {
        val arr = org.json.JSONArray(f.readText())
        // 统一在读取入口解密 text（兼容旧明文与 loc:v1: 密文）
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val raw = o.optString("text", "")
            o.put("text", com.aurora.chat.CryptoUtil.decryptLocal(raw))
        }
        arr
    } catch (_: Exception) { null }
}

// 保存本地对话消息：写 JSON 文件（撤回/读取权威存储）+ 同步最后一条消息到 SharedPreferences（会话列表预览）
fun saveLocalChatMessages(ctx: android.content.Context, currentUserId: Long, key: String, msgs: List<IMessageRef>) {
    try {
        val arr = org.json.JSONArray()
        var lastMsg = ""
        for (m in msgs) {
            if (m.text.isNotEmpty()) lastMsg = m.text
            if (m.mediaType.isNotEmpty()) {
                lastMsg = when (m.mediaType) {
                    "image" -> "[图片]"; "video" -> "[视频]"; else -> "[文件]"
                }
            }
            val obj = org.json.JSONObject()
            obj.put("id", m.id)
            obj.put("text", com.aurora.chat.CryptoUtil.encryptLocal(m.text))
            obj.put("is_mine", m.isMine)
            obj.put("from_user_id", m.fromUserId)
            obj.put("sender_name", m.senderName)
            obj.put("revoked", m.isRevoked)
            obj.put("created_at", m.createdAt)
            obj.put("media_type", m.mediaType)
            obj.put("media_url", m.mediaUrl)
            obj.put("reasoning_text", m.reasoningText)
            arr.put(obj)
        }
        localChatMessagesFile(ctx, currentUserId, key).writeText(arr.toString())
        val prefs = ctx.getSharedPreferences("${key}_chat_${currentUserId}", android.content.Context.MODE_PRIVATE)
        prefs.edit().putString("last_msg", com.aurora.chat.CryptoUtil.encryptLocal(lastMsg)).apply()
    } catch (_: Exception) {}
}

fun loadLocalChatLastMsg(ctx: android.content.Context, currentUserId: Long, key: String): String {
    return try {
        val prefs = ctx.getSharedPreferences("${key}_chat_${currentUserId}", android.content.Context.MODE_PRIVATE)
        com.aurora.chat.CryptoUtil.decryptLocal(prefs.getString("last_msg", "") ?: "")
    } catch (_: Exception) { "" }
}

/**
 * 读取本地 AI 对话文件（权威存储，[saveLocalChatMessages] 写入），包装成与「导出/导入对话」一致的官方 JSON。
 * 用于「AI对话分享 → 直接获取当前对话」：直接读磁盘，绕开内存桥接（避免桥接为空导致的「未检测到当前 AI 对话」）。
 * @return 官方 JSON 字符串；本地无对话时返回 null。
 */
internal fun loadAiConversationShareJson(ctx: android.content.Context, currentUserId: Long): String? {
    val arr = loadLocalChatMessages(ctx, currentUserId, "ai") ?: return null
    if (arr.length() == 0) return null
    val root = org.json.JSONObject()
    root.put("app", "AuroraChat")
    root.put("type", "conversation")
    root.put("version", 1)
    root.put("exported_at", System.currentTimeMillis())
    root.put("friend_id", AI_CHAT_ID)
    val meta = org.json.JSONObject()
    meta.put("user_name", "")
    meta.put("ai_name", "")
    root.put("meta", meta)
    val msgs = org.json.JSONArray()
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val m = org.json.JSONObject()
        m.put("text", o.optString("text", ""))
        m.put("is_mine", o.optBoolean("is_mine", false))
        m.put("from_user_id", o.optLong("from_user_id", 0L))
        m.put("sender_name", o.optString("sender_name", ""))
        m.put("created_at", o.optLong("created_at", 0L))
        m.put("media_type", o.optString("media_type", ""))
        m.put("media_url", o.optString("media_url", ""))
        m.put("reply_to_text", "")
        m.put("reply_to_sender", "")
        m.put("reply_to_id", 0L)
        m.put("revoked", o.optInt("revoked", 0))
        m.put("worn_badge", 0)
        m.put("flash_duration", 0)
        m.put("reasoning_text", o.optString("reasoning_text", ""))
        msgs.put(m)
    }
    if (msgs.length() == 0) return null
    root.put("messages", msgs)
    return root.toString()
}

// ==================== 系统通知对话（本地存储，不落服务端） ====================
// 与 self/ai 本地对话共用 saveLocalChatMessages 的区别：系统通知消息本身就是
// isSystemNotice，必须保留（saveLocalChatMessages 会过滤掉 isSystemNotice），故单独实现。

private fun notificationFile(ctx: android.content.Context, currentUserId: Long): java.io.File =
    java.io.File(ctx.cacheDir, "notification_chat_${currentUserId}.json")

fun loadNotificationMessages(ctx: android.content.Context, currentUserId: Long): List<ChatMsg> {
    val f = notificationFile(ctx, currentUserId)
    if (!f.exists()) return emptyList()
    return try {
        val arr = org.json.JSONArray(f.readText())
        val list = mutableListOf<ChatMsg>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            if (obj.optBoolean("revoked", false)) continue
            list.add(ChatMsg.create(
                serverId = obj.optLong("id", 0L),
                text = obj.optString("text", ""),
                isMine = obj.optBoolean("is_mine", false),
                isSystemNotice = obj.optBoolean("is_system_notice", true),
                createdAt = obj.optLong("created_at", 0),
                isNew = false
            ))
        }
        list
    } catch (_: Exception) { emptyList() }
}

/** 追加一条系统通知到本地存储，并更新会话列表预览与未读角标 */
fun appendNotificationMessage(ctx: android.content.Context, currentUserId: Long, msg: ChatMsg) {
    val list = loadNotificationMessages(ctx, currentUserId).toMutableList()
    list.add(msg)
    try {
        val arr = org.json.JSONArray()
        for (m in list) {
            arr.put(org.json.JSONObject().apply {
                put("id", m.id)
                put("text", m.text)
                put("is_mine", m.isMine)
                put("is_system_notice", m.isSystemNotice)
                put("created_at", m.createdAt)
                put("revoked", false)
            })
        }
        notificationFile(ctx, currentUserId).writeText(arr.toString())
        val prefs = ctx.getSharedPreferences("notification_chat_${currentUserId}", android.content.Context.MODE_PRIVATE)
        val preview = when {
            isOrderNotice(msg.text) -> (parseOrderNotice(msg.text)?.title ?: msg.text.take(40))
            parseTransferNotice(msg.text) != null -> (parseTransferNotice(msg.text) ?: msg.text.take(40))
            else -> msg.text.take(40)
        }
        prefs.edit().putString("last_msg", preview).apply()
        prefs.edit().putInt("unread", prefs.getInt("unread", 0) + 1).apply()
    } catch (_: Exception) {}
}

fun getNotificationUnread(ctx: android.content.Context, currentUserId: Long): Int {
    return try {
        ctx.getSharedPreferences("notification_chat_${currentUserId}", android.content.Context.MODE_PRIVATE)
            .getInt("unread", 0)
    } catch (_: Exception) { 0 }
}

fun setNotificationUnread(ctx: android.content.Context, currentUserId: Long, n: Int) {
    try {
        ctx.getSharedPreferences("notification_chat_${currentUserId}", android.content.Context.MODE_PRIVATE)
            .edit().putInt("unread", n).apply()
    } catch (_: Exception) {}
}

/** 用给定列表覆盖写入系统通知本地存储（用于与服务端历史合并后回写，保证离线仍可见） */
fun saveNotificationMessages(ctx: android.content.Context, currentUserId: Long, list: List<ChatMsg>) {
    try {
        val arr = org.json.JSONArray()
        for (m in list) {
            arr.put(org.json.JSONObject().apply {
                put("id", m.id)
                put("text", m.text)
                put("is_mine", m.isMine)
                put("is_system_notice", m.isSystemNotice)
                put("created_at", m.createdAt)
                put("revoked", false)
            })
        }
        notificationFile(ctx, currentUserId).writeText(arr.toString())
        val prefs = ctx.getSharedPreferences("notification_chat_${currentUserId}", android.content.Context.MODE_PRIVATE)
        val last = list.lastOrNull()
        val preview = if (last != null) {
            when {
                isOrderNotice(last.text) -> (parseOrderNotice(last.text)?.title ?: last.text.take(40))
                parseTransferNotice(last.text) != null -> (parseTransferNotice(last.text) ?: last.text.take(40))
                else -> last.text.take(40)
            }
        } else ""
        prefs.edit().putString("last_msg", preview).apply()
    } catch (_: Exception) {}
}

// ==================== 位置卡片 ====================
fun isLocationCardMessage(text: String): Boolean {
    return text.trimStart().startsWith("分享位置")
}

data class LocationCardData(
    val address: String,
    val username: String,
    val lat: Double,
    val lng: Double
)

fun parseLocationCard(text: String): LocationCardData? {
    if (!isLocationCardMessage(text)) return null
    try {
        val lines = text.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        val addrIdx = lines.indexOfFirst { it == "━━━" }
        val endIdx = lines.indexOfLast { it == "━━━" }
        if (addrIdx < 0 || endIdx <= addrIdx || endIdx + 1 >= lines.size) return null
        val addrLine = lines.getOrNull(addrIdx + 1) ?: ""
        val address = if (addrLine.startsWith("我在：") && addrLine.length <= 5) {
            lines.getOrNull(addrIdx + 2) ?: addrLine
        } else {
            addrLine.removePrefix("我在：").trim()
        }
        val fromLine = lines.getOrNull(endIdx + 1) ?: ""
        val username = fromLine.removePrefix("来自").trim()
        val latLine = lines.lastOrNull { it.startsWith("location_lat=") }?.removePrefix("location_lat=")?.trim()?.toDoubleOrNull() ?: 0.0
        val lngLine = lines.lastOrNull { it.startsWith("location_lng=") }?.removePrefix("location_lng=")?.trim()?.toDoubleOrNull() ?: 0.0
        return LocationCardData(address, username, latLine, lngLine)
    } catch (_: Exception) { return null }
}

// 解析拍拍消息文本
internal fun parsePokeText(m: MessageInfo, currentUserId: Long, currentUserName: String): String {
    val pokerName = if (m.fromUserId == currentUserId) "你" else m.fromUserName
    val targetName = if (m.toUserId == currentUserId) "你" else {
        m.targetName.takeIf { it.isNotEmpty() } ?: "对方"
    }
    return if (m.fromUserId == m.toUserId) {
        "${pokerName}拍了拍自己"
    } else if (m.fromUserId == currentUserId) {
        "你拍了拍${targetName}"
    } else if (m.toUserId == currentUserId) {
        "${pokerName}拍了拍你"
    } else {
        "${pokerName}拍了拍${targetName}"
    }
}

// ==================== 转账 ====================
// 视角完全由结构化字段现算，不在服务端写死文案，群聊/私聊天然一致
const val TRANSFER_MSG_PREFIX = "系统转账数据"
const val TRANSFER_NOTICE_PREFIX = "系统转账通知"

data class TransferData(
    val fromUserId: Long,
    val fromName: String,
    val toUserId: Long,
    val toName: String,
    val amount: Long
)

fun isTransferMessage(text: String): Boolean = text.trimStart().startsWith(TRANSFER_MSG_PREFIX)

fun parseTransferMessage(text: String): TransferData? {
    return try {
        val cleaned = text.trim()
        if (!cleaned.startsWith(TRANSFER_MSG_PREFIX)) return null
        val lines = cleaned.split("\n").map { it.trim() }
        fun get(key: String): String {
            val l = lines.firstOrNull { it.startsWith("$key=") } ?: return ""
            return l.removePrefix("$key=").trim()
        }
        val fromUserId = get("from_user_id").toLongOrNull() ?: return null
        val toUserId = get("to_user_id").toLongOrNull() ?: return null
        val amount = get("amount").toLongOrNull() ?: return null
        TransferData(
            fromUserId = fromUserId,
            fromName = get("from_name").ifEmpty { "某人" },
            toUserId = toUserId,
            toName = get("to_name").ifEmpty { "某人" },
            amount = amount
        )
    } catch (_: Exception) { null }
}

/** 视角文案：由结构化字段现算，群聊/私聊统一正确 */
fun transferDisplayLabel(data: TransferData, currentUserId: Long): String {
    return when {
        currentUserId == data.fromUserId -> "你向${data.toName}转账 ${data.amount} token"
        currentUserId == data.toUserId -> "${data.fromName}向你转账 ${data.amount} token"
        else -> "${data.fromName}向${data.toName}转账 ${data.amount} token"
    }
}

/** 构造与后端一致的转账消息正文（用于本地乐观插入，随后会被服务端同步覆盖） */
fun buildTransferContent(fromUserId: Long, fromName: String, toUserId: Long, toName: String, amount: Long): String = buildString {
    appendLine(TRANSFER_MSG_PREFIX)
    appendLine("from_user_id=$fromUserId")
    appendLine("from_name=$fromName")
    appendLine("to_user_id=$toUserId")
    appendLine("to_name=$toName")
    appendLine("amount=$amount")
}

fun formatTransferNotice(desc: String): String = buildString {
    appendLine(TRANSFER_NOTICE_PREFIX)
    appendLine("desc=$desc")
}

fun parseTransferNotice(text: String): String? {
    return try {
        val cleaned = text.trim()
        if (!cleaned.startsWith(TRANSFER_NOTICE_PREFIX)) return null
        cleaned.split("\n").map { it.trim() }.firstOrNull { it.startsWith("desc=") }?.removePrefix("desc=")?.trim()
    } catch (_: Exception) { null }
}

// ==================== 红包 ====================
const val REDPACKET_MSG_PREFIX = "系统红包数据"

data class RedPacketData(
    val packetId: Long,
    val fromUserId: Long,
    val fromName: String,
    val total: Long,
    val count: Int,
    val greeting: String,
    val createdAt: Long,
    val expireAt: Long
)

/** 红包卡片实时状态（来自服务端 detail 接口），用于内联卡片显示进度/过期 */
data class RedPacketStatus(
    val packetId: Long,
    val claimedCount: Int,
    val totalCount: Int,
    val remaining: Long,
    val total: Long,
    val status: String,   // active / full / expired
    val myClaimed: Long
)

fun isRedPacketMessage(text: String): Boolean = text.trimStart().startsWith(REDPACKET_MSG_PREFIX)

fun parseRedPacketMessage(text: String): RedPacketData? {
    return try {
        val cleaned = text.trim()
        if (!cleaned.startsWith(REDPACKET_MSG_PREFIX)) return null
        val lines = cleaned.split("\n").map { it.trim() }
        fun get(key: String): String {
            val l = lines.firstOrNull { it.startsWith("$key=") } ?: return ""
            return l.removePrefix("$key=").trim()
        }
        fun getLong(key: String): Long = get(key).toLongOrNull() ?: 0L
        fun getInt(key: String): Int = get(key).toIntOrNull() ?: 0
        RedPacketData(
            packetId = getLong("packet_id"),
            fromUserId = getLong("from_user_id"),
            fromName = get("from_name"),
            total = getLong("total"),
            count = getInt("count"),
            greeting = get("greeting"),
            createdAt = getLong("created_at"),
            expireAt = getLong("expire_at")
        )
    } catch (_: Exception) { null }
}

/** 构造与后端一致的红包消息正文（用于本地乐观插入，随后会被服务端同步覆盖） */
fun buildRedPacketContent(
    packetId: Long, fromUserId: Long, fromName: String, total: Long, count: Int,
    greeting: String, createdAt: Long, expireAt: Long
): String = buildString {
    appendLine(REDPACKET_MSG_PREFIX)
    appendLine("packet_id=$packetId")
    appendLine("from_user_id=$fromUserId")
    appendLine("from_name=$fromName")
    appendLine("total=$total")
    appendLine("count=$count")
    appendLine("greeting=$greeting")
    appendLine("created_at=$createdAt")
    appendLine("expire_at=$expireAt")
}

/** 根据后端 detail 响应构建内联卡片状态 */
fun redPacketStatusFromJson(json: org.json.JSONObject): RedPacketStatus? {
    return try {
        val p = json.optJSONObject("packet") ?: return null
        RedPacketStatus(
            packetId = p.optLong("id"),
            claimedCount = p.optInt("claimed"),
            totalCount = p.optInt("count"),
            remaining = p.optLong("remaining"),
            total = p.optLong("total"),
            status = json.optString("status", "active"),
            myClaimed = json.optLong("my_claimed")
        )
    } catch (_: Exception) { null }
}


// 获取当前位置并发送位置卡片消息
internal suspend fun sendLocationMessage(
    ctx: android.content.Context,
    currentUserId: Long,
    friendId: Long,
    onMessagesUpdate: (List<IMessageRef>) -> Unit
) {
    try {
        val locationManager = ctx.getSystemService(android.content.Context.LOCATION_SERVICE) as android.location.LocationManager
        // 将权限检查结果存入局部布尔量，并在每次 getLastKnownLocation 调用前用紧邻的 if 守卫，
        // 满足 Lint MissingPermission 检测（when 表达式无法被该检测器可靠识别）。同时包 SecurityException 兜底。
        val hasFine = ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val location = try {
            var loc: android.location.Location? = null
            if (hasFine) loc = locationManager.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
            if (loc == null) {
                if (hasFine) {
                    loc = locationManager.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
                } else if (hasCoarse) {
                    loc = locationManager.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
                }
            }
            loc
        } catch (_: SecurityException) { null }
        if (location == null) {
            android.widget.Toast.makeText(ctx, "未授予位置权限或无法获取当前位置，请打开GPS", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val geocoder = android.location.Geocoder(ctx, java.util.Locale.getDefault())
        val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
        val address = if (!addresses.isNullOrEmpty()) {
            addresses[0].getAddressLine(0) ?: "${location.latitude},${location.longitude}"
        } else {
            "${location.latitude},${location.longitude}"
        }
        val loginPrefs = ctx.getSharedPreferences("aurora_login", android.content.Context.MODE_PRIVATE)
        val username = loginPrefs.getString("username", "") ?: "我"
        val locationText = "分享位置\n━━━\n我在：${address}\n━━━\n来自 ${username}\nlocation_lat=${location.latitude}\nlocation_lng=${location.longitude}"
        val newMsg = ChatMsg.create(text = locationText, isMine = true, fromUserId = currentUserId, isNew = true)
        onMessagesUpdate(emptyList<ChatMsg>() + newMsg)
        if (isLocalChat(friendId)) {
            ChatViewModel.updateConversationPreview(friendId, locationText, System.currentTimeMillis() / 1000)
        } else {
            val sendResult = if (isGroupChat(friendId)) com.aurora.chat.data.repository.ChatRepository.sendGroupMessage(friendId, locationText)
            else com.aurora.chat.data.repository.ChatRepository.sendMessage(friendId, locationText)
            if (!sendResult.success) {
                com.aurora.chat.data.api.AuroraApi.showErrorToast(ctx, "位置发送失败")
            }
            // 用户主动发送位置卡片 → 读取并上报服务器位置
            try {
                com.aurora.chat.data.api.AuroraApi.uploadLocation(location.latitude, location.longitude, address)
                ctx.getSharedPreferences("aurora_location", android.content.Context.MODE_PRIVATE)
                    .edit().putBoolean("uploaded_once", true).apply()
            } catch (_: Exception) { }
        }
    } catch (e: Exception) {
        com.aurora.chat.data.api.AuroraApi.showErrorToast(ctx, "获取位置失败: ${e.message}")
    }
}

// 发送相机拍摄的文件（直接上传，不经过文件选择中转）
internal suspend fun sendCameraFile(
    uri: android.net.Uri,
    ctx: android.content.Context,
    currentUserId: Long,
    friendId: Long,
    scope: CoroutineScope,
    messages: List<IMessageRef>,
    uploadProgressMap: androidx.compose.runtime.snapshots.SnapshotStateMap<Long, Float>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onMessagesUpdate: (List<IMessageRef>) -> Unit
) {
    try {
        val mimeType = ctx.contentResolver.getType(uri) ?: "image/jpeg"
        val fileName = uri.lastPathSegment ?: "camera_capture.jpg"
        val isImage = mimeType.startsWith("image/")
        val isVideo = mimeType.startsWith("video/")

    val extraType = if (isImage) "image" else if (isVideo) "video" else "file"

    // 本地对话（自己 / AI）秒发：直接写原始文件 + 全量写 messages 到 JSON
    if (isLocalChat(friendId)) {
        val key = localChatKey(friendId)
        val localChatDir = java.io.File(ctx.filesDir, "${key}_chat")
        if (!localChatDir.exists()) localChatDir.mkdirs()
        val ext = when { isVideo -> "mp4"; isImage -> "jpg"; else -> "bin" }
        val localFile = java.io.File(localChatDir, "${System.currentTimeMillis()}.${ext}")
        ctx.contentResolver.openInputStream(uri)?.use { rawIn ->
            java.io.FileOutputStream(localFile).use { out -> rawIn.copyTo(out) }
        }
        val localMediaUrl = "file://${localFile.absolutePath}"
        val selfMsgId = System.currentTimeMillis() * 10000 + (0..9999).random()
        val now = System.currentTimeMillis() / 1000
        val updated = messages + ChatMsg.create(
            serverId = selfMsgId, text = "", isMine = true, fromUserId = currentUserId,
            isNew = true, mediaType = extraType, mediaUrl = localMediaUrl, createdAt = now
        )
        MediaDebug.log(ctx, "SEND_LOCAL", "mediaType=$extraType mediaUrl=$localMediaUrl")
        onMessagesUpdate(updated)
        saveLocalChatMessages(ctx, currentUserId, key, updated.filter { !it.isSystemNotice })
        ChatViewModel.updateConversationPreview(friendId, if (isVideo) "[视频]" else "[图片]", System.currentTimeMillis() / 1000)
        listState.animateScrollToItem(updated.size - 1)
        return
    }

    val placeholderId = System.currentTimeMillis() * 10000 + (0..9999).random()
    val placeholderMsg = ChatMsg.create(serverId = placeholderId, text = "", isMine = true, fromUserId = currentUserId, isNew = true, mediaType = extraType, mediaUrl = "", isUploading = true, flashDuration = 0)
        onMessagesUpdate(messages + placeholderMsg)
        uploadProgressMap[placeholderMsg.id] = 0f
        scope.launch {
            kotlinx.coroutines.delay(200)
            if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
        }

        val inputStream = ctx.contentResolver.openInputStream(uri)
        if (inputStream == null) {
            com.aurora.chat.data.api.AuroraApi.showErrorToast(ctx, "无法读取文件")
            uploadProgressMap.remove(placeholderMsg.id)
            onMessagesUpdate(messages.toMutableList().apply { removeAll { it.id == placeholderMsg.id } })
            return
        }
        val fileBytes = inputStream.readBytes()
        inputStream.close()

        val finalBytes = if (isImage) {
            // 先解码图片尺寸，按目标最大 1920px 计算采样率，避免全尺寸解码导致 OOM
            val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeByteArray(fileBytes, 0, fileBytes.size, opts)
            val maxDimension = 1920
            val sampleSize = maxOf(
                (opts.outWidth + maxDimension - 1) / maxDimension,
                (opts.outHeight + maxDimension - 1) / maxDimension,
                1
            )
            val decodeOpts = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
            }
            val bitmap = android.graphics.BitmapFactory.decodeByteArray(fileBytes, 0, fileBytes.size, decodeOpts)
            if (bitmap != null && (fileBytes.size > 500 * 1024 || sampleSize > 1)) {
                val out = java.io.ByteArrayOutputStream()
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
                out.toByteArray()
            } else fileBytes
        } else fileBytes

        if (isLocalChat(friendId)) {
            val key = localChatKey(friendId)
            val localChatDir = java.io.File(ctx.filesDir, "${key}_chat")
            if (!localChatDir.exists()) localChatDir.mkdirs()
            val ext = when {
                isVideo -> "mp4"
                isImage -> "jpg"
                else -> "bin"
            }
            val localFile = java.io.File(localChatDir, "${System.currentTimeMillis()}.${ext}")
            java.io.FileOutputStream(localFile).use { out -> out.write(finalBytes) }
            val localMediaUrl = "file://${localFile.absolutePath}"

            val finalMsg = ChatMsg.create(
                text = "", isMine = true, fromUserId = currentUserId, isNew = true,
                mediaType = if (isVideo) "video" else "image", mediaUrl = localMediaUrl
            )
            MediaDebug.log(ctx, "SEND_LOCAL", "mediaType=${if (isVideo) "video" else "image"} mediaUrl=$localMediaUrl")
            val newMessages = messages.toMutableList().apply { removeAll { it.id == placeholderMsg.id } } + finalMsg
            onMessagesUpdate(newMessages)
            saveLocalChatMessages(ctx, currentUserId, key, newMessages.filter { !it.isSystemNotice })
            ChatViewModel.updateConversationPreview(friendId, if (isVideo) "[视频]" else "[图片]", System.currentTimeMillis() / 1000)
        } else {
            val uploadResult = com.aurora.chat.data.api.AuroraApi.uploadChatMedia(finalBytes, fileName, mimeType)
            if (!uploadResult.success || uploadResult.data == null) {
                com.aurora.chat.data.api.AuroraApi.showErrorToast(ctx, uploadResult.message)
                uploadProgressMap.remove(placeholderMsg.id)
                onMessagesUpdate(messages.toMutableList().apply { removeAll { it.id == placeholderMsg.id } })
                return
            }
            val rawMediaUrl = uploadResult.data!!.optString("url", "")
            val rawMediaType = uploadResult.data!!.optString("media_type", "image")
            if (rawMediaUrl.isEmpty()) {
                com.aurora.chat.data.api.AuroraApi.showErrorToast(ctx, "上传失败")
                uploadProgressMap.remove(placeholderMsg.id)
                onMessagesUpdate(messages.toMutableList().apply { removeAll { it.id == placeholderMsg.id } })
                return
            }

            val fullMediaUrl = resolveMediaUrl(rawMediaUrl)
            MediaDebug.log(ctx, "SEND_SERVER", "mediaType=${if (isVideo) rawMediaType else "image"} mediaUrl=$fullMediaUrl")


            val finalMsg = ChatMsg.create(
                serverId = 0L, text = "", isMine = true, fromUserId = currentUserId,
                isNew = false, mediaType = if (isVideo) rawMediaType else "image", mediaUrl = fullMediaUrl,
                createdAt = System.currentTimeMillis() / 1000
            )
            val baseList = messages.toMutableList().apply { removeAll { it.id == placeholderMsg.id } }
            uploadProgressMap.remove(placeholderMsg.id)
            onMessagesUpdate(baseList)
            ChatViewModel.sendMessage(
                currentUserId = currentUserId,
                friendId = friendId,
                text = "",
                replyTo = 0,
                mediaType = if (isVideo) rawMediaType else "image",
                mediaUrl = fullMediaUrl,
                flashDuration = 0,
                onSuccess = { msgId ->
                    onMessagesUpdate(baseList + finalMsg.copy(id = msgId))
                    // 落盘已验证可用的完整媒体 URL，防止重进对话后变成空气泡
                    scope.launch {
                        try {
                            val info = com.aurora.chat.data.api.MessageInfo(
                                id = msgId, fromUserId = currentUserId, toUserId = friendId,
                                content = "", createdAt = System.currentTimeMillis() / 1000,
                                mediaType = finalMsg.mediaType, mediaUrl = finalMsg.mediaUrl, isRevoked = 0, flashDuration = 0
                            )
                            com.aurora.chat.data.repository.LocalMessageStore.mergeAndSave(ctx, friendId, listOf(info))
                        } catch (_: Exception) { }
                    }
                },
                onError = { msg -> com.aurora.chat.data.api.AuroraApi.showErrorToast(ctx, "发送失败: $msg") },
                context = ctx
            )
            ChatViewModel.loadConversations(force = true)
        }

        scope.launch {
            kotlinx.coroutines.delay(200)
            if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
        }
    } catch (e: Exception) {
        com.aurora.chat.data.api.AuroraApi.showErrorToast(ctx, "发送失败: ${e.message}")
    }
}

// 保存自己对话（friendId=0）的消息到本地（兼容旧调用，内部走通用本地对话存储）
internal fun saveSelfChatMessages(ctx: android.content.Context, currentUserId: Long, msgs: List<IMessageRef>) {
    saveLocalChatMessages(ctx, currentUserId, "self", msgs)
}

internal val badgeResIds = BadgeResources.allBadgeResIds

internal fun formatFileSize(size: Long): String {
    return when {
        size < 1024 -> "$size B"
        size < 1024 * 1024 -> String.format("%.1f KB", size / 1024.0)
        size < 1024 * 1024 * 1024 -> String.format("%.1f MB", size / (1024.0 * 1024.0))
        else -> String.format("%.1f GB", size / (1024.0 * 1024.0 * 1024.0))
    }
}

internal fun isImageFile(name: String): Boolean {
    val ext = name.substringAfterLast('.', "").lowercase()
    return ext in listOf("jpg", "jpeg", "png", "gif", "bmp", "webp")
}
