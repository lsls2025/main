package com.aurora.chat.ui.chat

import android.content.Context
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.chat.data.api.AuroraApi
import com.aurora.chat.data.repository.ChatRepository
import com.aurora.chat.ui.components.GroupAvatar
import kotlinx.coroutines.launch
import org.json.JSONObject

data class GroupSearchResult(val id: Long, val name: String, val displayId: Long, val signature: String)

@Composable
fun SearchGroupScreen(
    currentUserId: Long = 0,
    onDismiss: () -> Unit,
    onOpenGroupChat: (groupConvId: Long, groupName: String) -> Unit,
    initialGroupId: Long = 0  // 非 0 时自动打开该群的详情面板
) {
    val context = LocalContext.current
    var keyword by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<GroupSearchResult>>(emptyList()) }
    var hasSearched by remember { mutableStateOf(false) }
    var isSearching by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    fun hideKeyboard() { imm.hideSoftInputFromWindow(view.windowToken, 0) }

    // 群详情面板状态
    var showInfoPanel by remember { mutableStateOf(false) }
    var selectedGroup by remember { mutableStateOf<GroupSearchResult?>(null) }
    var groupInfo by remember { mutableStateOf<JSONObject?>(null) }
    var memberCount by remember { mutableStateOf(0) }
    var isJoining by remember { mutableStateOf(false) }

    // 入群申请面板状态（提升到顶层，避免 Column 内 Composable 引用不到）
    var showJoinPanel by remember { mutableStateOf(false) }
    var joinReason by remember { mutableStateOf("") }

    // 加载群详情
    LaunchedEffect(selectedGroup) {
        if (selectedGroup != null) {
            val r = AuroraApi.getGroupInfo(selectedGroup!!.id)
            if (r.success && r.data != null) {
                groupInfo = r.data
            } else { groupInfo = null }
            val members = ChatRepository.getGroupMembers(selectedGroup!!.id)
            if (members.success && members.data != null) {
                memberCount = members.data!!.length()
            }
        }
    }

    // 如果有 initialGroupId，自动加载群信息并打开详情面板
    LaunchedEffect(initialGroupId) {
        if (initialGroupId > 0) {
            val r = AuroraApi.getGroupInfo(initialGroupId)
            if (r.success && r.data != null) {
                val data = r.data!!
                val gName = data.optString("name", "")
                val gDisplayId = data.optLong("display_id", 0)
                val gSignature = data.optString("signature", "")
                selectedGroup = GroupSearchResult(initialGroupId, gName, gDisplayId, gSignature)
                showInfoPanel = true
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        // ===== 主搜索界面 =====
            Box(Modifier.fillMaxSize()) {
                // 透明拦截层：阻止事件穿透到下层，但不干扰子组件
                com.aurora.chat.ui.components.EventBlocker()
                Column(
                    modifier = Modifier.fillMaxSize().statusBarsPadding().background(Color.White)
                ) {
                // 顶部栏
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(28.dp).clickable { onDismiss() }, contentAlignment = Alignment.Center) {
                        Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))
                    }
                    Spacer(Modifier.width(12.dp))
                    Text("搜索群聊", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
                }
                // 搜索栏
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(Color(0xFFF3F4F6))
                        .padding(horizontal = 12.dp, vertical = 10.dp)) {
                        BasicTextField(value = keyword, onValueChange = { keyword = it },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp, color = Color(0xFF1F2937)),
                            singleLine = true,
                            decorationBox = { inner ->
                                Box { if (keyword.isEmpty()) Text("输入群ID搜索", fontSize = 13.sp, color = Color(0xFF9CA3AF)); inner() }
                            })
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("搜索", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1E40AF),
                        modifier = Modifier.clickable(enabled = !isSearching) {
                            hasSearched = true
                            if (keyword.isBlank()) { results = emptyList(); return@clickable }
                            isSearching = true
                            scope.launch {
                                val result = ChatRepository.searchGroups(keyword)
                                isSearching = false
                                if (result.success) {
                                    results = mutableListOf()
                                    val arr = result.data ?: return@launch
                                    for (i in 0 until arr.length()) {
                                        val obj = arr.getJSONObject(i)
                                        results = results + GroupSearchResult(
                                            id = obj.optLong("id"), name = obj.optString("name"),
                                            displayId = obj.optLong("display_id"), signature = obj.optString("signature", ""))
                                    }
                                } else { Toast.makeText(context, result.message, Toast.LENGTH_SHORT).show() }
                            }
                        }.padding(horizontal = 12.dp, vertical = 10.dp))
                }
                // 搜索结果
                if (isSearching) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("搜索中...", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                    }
                } else if (hasSearched && results.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("未找到相关群聊", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                        items(results) { group ->
                            Box(Modifier.fillMaxWidth().height(60.dp).padding(vertical = 8.dp)
                                .clickable { selectedGroup = group; showInfoPanel = true; hideKeyboard() },
                                contentAlignment = Alignment.CenterStart) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    GroupAvatar(internalGroupId = group.id, groupName = group.name, size = 48.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(highlightText(group.name, keyword), fontSize = 15.sp, color = Color(0xFF1F2937))
                                        Text("群ID: ${group.displayId}", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                                    }
                                    Text("查看", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1E40AF),
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // ===== 群详情面板（从右侧滑入） =====
        AnimatedVisibility(
            visible = showInfoPanel && selectedGroup != null,
            enter = slideInHorizontally(tween(300)) { it },
            exit = slideOutHorizontally(tween(300)) { it },
            modifier = Modifier.fillMaxSize()
        ) {
            selectedGroup?.let { group ->
            Box(Modifier.fillMaxSize()) {
                com.aurora.chat.ui.components.EventBlocker()
                Column(Modifier.fillMaxSize().statusBarsPadding().background(Color.White)) {
                // 顶栏
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(28.dp).clickable { showInfoPanel = false },
                        contentAlignment = Alignment.Center) {
                        Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))
                    }
                    Spacer(Modifier.width(12.dp))
                    Text("群聊详情", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
                }
                Spacer(Modifier.height(20.dp))
                GroupAvatar(internalGroupId = group.id, groupName = group.name, size = 80.dp,
                    modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(12.dp))
                Text(group.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937),
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                Text("群ID: ${group.displayId}", fontSize = 13.sp, color = Color(0xFF9CA3AF),
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                    Text("群签名", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF6B7280))
                    Spacer(Modifier.height(4.dp))
                    Text(group.signature.ifEmpty { "无" }, fontSize = 14.sp, color = Color(0xFF1F2937))
                    Spacer(Modifier.height(12.dp))
                    Text("创建时间", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF6B7280))
                    Spacer(Modifier.height(4.dp))
                    val createTime = groupInfo?.optLong("created_at", 0) ?: 0L
                    val timeText = if (createTime > 0) {
                        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                        sdf.format(java.util.Date(createTime * 1000))
                    } else "未知"
                    Text(timeText, fontSize = 14.sp, color = Color(0xFF1F2937))
                    Spacer(Modifier.height(12.dp))
                    Text("群人数", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF6B7280))
                    Spacer(Modifier.height(4.dp))
                    Text("${memberCount} 人", fontSize = 14.sp, color = Color(0xFF1F2937))
                }
                Spacer(Modifier.weight(1f))
                // ── 入群申请面板（从右侧滑入）──
                val isAlreadyMember = selectedGroup != null && chatAlreadyJoined[selectedGroup!!.id] == true
                val needJoinReview = groupInfo?.optBoolean("join_required", false) == true
                Box(Modifier.fillMaxWidth().padding(24.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF1E40AF))
                    .clickable {
                        hideKeyboard()
                        if (isAlreadyMember) {
                            selectedGroup?.let { onOpenGroupChat(-(1000 + it.id), it.name) }
                        } else if (needJoinReview) {
                            showJoinPanel = true // 需审核 → 弹出申请面板
                        } else {
                            // 无需审核 → 直接加入
                            isJoining = true
                            scope.launch {
                                val r = ChatRepository.submitJoinRequest(selectedGroup?.id ?: 0, "")
                                isJoining = false
                                if (r.success) {
                                    Toast.makeText(context, "已加入群聊", Toast.LENGTH_SHORT).show()
                                    selectedGroup?.let { onOpenGroupChat(-(1000 + it.id), it.name) }
                                } else if (r.message.contains("已在群")) {
                                    Toast.makeText(context, "你已在群聊中", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, r.message, Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                    Text(if (isJoining) "加入中..." else "进入群聊", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White)
                }
                }
            }
            }
            // ── 入群申请填写面板（从右侧滑入，全屏）──
            AnimatedVisibility(
                visible = showJoinPanel,
                enter = slideInHorizontally(tween(300)) { it },
                exit = slideOutHorizontally(tween(300)) { it },
                modifier = Modifier.fillMaxSize()
            ) {
                Box(Modifier.fillMaxSize()) {
                    com.aurora.chat.ui.components.EventBlocker()
                    Column(Modifier.fillMaxSize().statusBarsPadding().background(Color.White)) {
                        // 顶栏
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(28.dp).clickable { showJoinPanel = false },
                                contentAlignment = Alignment.Center) {
                                Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))
                            }
                            Spacer(Modifier.width(12.dp))
                            Text("提交入群申请", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
                        }
                        Spacer(Modifier.height(8.dp))
                        // 大输入框（固定5行高度，超出可滑动）
                        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).heightIn(0.dp, 120.dp)
                            .clip(RoundedCornerShape(10.dp)).background(Color(0xFFF3F4F6)).padding(14.dp)) {
                            BasicTextField(value = joinReason, onValueChange = { joinReason = it },
                                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                                textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp, color = Color(0xFF1F2937)),
                                singleLine = false,
                                decorationBox = { inner ->
                                    Box {
                                        if (joinReason.isEmpty()) Text("请输入入群原因（可选）", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                                        inner()
                                    }
                                })
                        }
                        Spacer(Modifier.height(20.dp))
                        // 提交按钮
                        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(48.dp)
                            .clip(RoundedCornerShape(10.dp)).background(Color(0xFF1E40AF))
                            .clickable(enabled = !isJoining) {
                                isJoining = true
                                scope.launch {
                                    val r = ChatRepository.submitJoinRequest(selectedGroup?.id ?: 0, joinReason)
                                    isJoining = false
                                    if (r.success) {
                                        if (r.data?.contains("入群申请") == true || r.data?.contains("等待审批") == true) {
                                            Toast.makeText(context, "入群申请已提交，群主同意后将进入此群", Toast.LENGTH_LONG).show()
                                            showJoinPanel = false
                                        } else {
                                            val gid = selectedGroup?.id ?: 0
                                            val gname = selectedGroup?.name ?: ""
                                            Toast.makeText(context, "已加入群聊", Toast.LENGTH_SHORT).show()
                                            showJoinPanel = false
                                            onOpenGroupChat(-(1000 + gid), gname)
                                        }
                                    } else if (r.message.contains("已在群")) {
                                        Toast.makeText(context, "你已在群聊中", Toast.LENGTH_SHORT).show()
                                        chatAlreadyJoined[selectedGroup?.id ?: 0] = true
                                        showJoinPanel = false
                                    } else {
                                        Toast.makeText(context, r.message, Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            contentAlignment = Alignment.Center) {
                            Text(if (isJoining) "提交中..." else "提交申请", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

// 缓存：已加入的群（避免重复申请）
private val chatAlreadyJoined = mutableMapOf<Long, Boolean>()

/** 构建带关键字蓝高亮的 AnnotatedString */
private fun highlightText(text: String, keyword: String): androidx.compose.ui.text.AnnotatedString {
    if (keyword.isBlank()) return buildAnnotatedString { append(text) }
    return buildAnnotatedString {
        var start = 0
        while (true) {
            val index = text.indexOf(keyword, start, ignoreCase = true)
            if (index < 0) { append(text.substring(start)); break }
            if (index > start) append(text.substring(start, index))
            withStyle(SpanStyle(color = Color(0xFF1E40AF), fontWeight = FontWeight.Bold)) { append(text.substring(index, index + keyword.length)) }
            start = index + keyword.length
        }
    }
}
