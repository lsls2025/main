package com.aurora.chat.ui.chat

import android.content.Context
import android.util.Log
import com.aurora.chat.data.api.AuroraApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * AI 对话管理：两种调用模式
 *  - official（官方 API）：使用应用内置密钥（DeepSeek），每个用户每天限额 TOKENS_PER_DAY。
 *  - personal（个人 API）：用户自己填写 key + base url + model，不受额度限制，保存后持久生效。
 */
/**
 * 用户自定义的性格补充设定：用户自由输入的纯文本，按字面意思注入 system 提示。
 * 不绑定任何性格维度、不带任何维度标签。
 */
data class CustomTrait(
    /** 用户输入的自定义内容（原样注入，不改写） */
    val text: String,
    /** 该自定义设定的权重百分比（仅用于提示模型其强度，可调节） */
    val pct: Float
)

object AiChatManager {

    // ===== 官方 API 固定配置（应用内置密钥） =====
    private const val OFFICIAL_API_KEY = "sk-31737853d3f543929c4c173c21fadd0e"
    private const val OFFICIAL_BASE_URL = "https://api.deepseek.com/v1"
    private const val OFFICIAL_MODEL = "deepseek-v4-flash"
    private const val KEY_SERVER_TOKEN_BALANCE = "ai_server_token_balance"



    private const val TAG = "AiChatManager"

    // ===== 配置读写（按用户持久化） =====
    private fun prefs(ctx: Context, userId: Long) =
        ctx.getSharedPreferences("ai_config_$userId", Context.MODE_PRIVATE)

    // 服务级全局开关：disable_official_api 是后端全局 flag，必须存独立共享文件，
    // 否则各用户各写各的 per-user 配置、又固定读 ai_config_0，导致其他用户读不到而无法拦截
    private fun globalPrefs(ctx: Context) =
        ctx.getSharedPreferences("ai_config_global", Context.MODE_PRIVATE)

    fun getMode(ctx: Context, userId: Long): String =
        prefs(ctx, userId).getString("mode", "official") ?: "official"

    fun setMode(ctx: Context, userId: Long, mode: String) {
        prefs(ctx, userId).edit().putString("mode", mode).apply()
    }

    // ===== 节省 Token 模式 =====
    fun getSaveToken(ctx: Context, userId: Long): Boolean =
        prefs(ctx, userId).getBoolean("save_token", false)

    fun setSaveToken(ctx: Context, userId: Long, on: Boolean) {
        prefs(ctx, userId).edit().putBoolean("save_token", on).apply()
    }

    // ===== 高级选项：场景 / 角色设定 / AI 多次输出 =====
    fun getScenario(ctx: Context, userId: Long): String =
        prefs(ctx, userId).getString("adv_scenario", "") ?: ""

    fun setScenario(ctx: Context, userId: Long, v: String) {
        prefs(ctx, userId).edit().putString("adv_scenario", v).apply()
    }

    fun getMyRole(ctx: Context, userId: Long): String =
        prefs(ctx, userId).getString("adv_my_role", "") ?: ""

    fun setMyRole(ctx: Context, userId: Long, v: String) {
        prefs(ctx, userId).edit().putString("adv_my_role", v).apply()
    }

    fun getAiRole(ctx: Context, userId: Long): String =
        prefs(ctx, userId).getString("adv_ai_role", "") ?: ""

    fun setAiRole(ctx: Context, userId: Long, v: String) {
        prefs(ctx, userId).edit().putString("adv_ai_role", v).apply()
    }

    fun getMultiOutput(ctx: Context, userId: Long): Boolean =
        prefs(ctx, userId).getBoolean("adv_multi_output", false)

    fun setMultiOutput(ctx: Context, userId: Long, on: Boolean) {
        prefs(ctx, userId).edit().putBoolean("adv_multi_output", on).apply()
    }

    // ===== 确认发言模式 =====
    fun getConfirmSpeech(ctx: Context, userId: Long): Boolean =
        prefs(ctx, userId).getBoolean("confirm_speech", false)

    fun setConfirmSpeech(ctx: Context, userId: Long, on: Boolean) {
        prefs(ctx, userId).edit().putBoolean("confirm_speech", on).apply()
    }

    // ===== 时间点（仅当天有效） =====
    fun setTimePoint(ctx: Context, userId: Long, timeValue: String) {
        val now = System.currentTimeMillis() / 1000
        prefs(ctx, userId).edit()
            .putString("time_point_value", timeValue)
            .putLong("time_point_set_at", now)
            .apply()
    }

    /** 获取时间点，若非当天设置则自动清除并返回空 */
    fun getTimePoint(ctx: Context, userId: Long): String {
        val setAt = prefs(ctx, userId).getLong("time_point_set_at", 0L)
        if (setAt == 0L) return ""
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val setDay = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(setAt * 1000))
        if (today != setDay) {
            // 非当天设置，清除
            prefs(ctx, userId).edit()
                .remove("time_point_value")
                .remove("time_point_set_at")
                .apply()
            return ""
        }
        return prefs(ctx, userId).getString("time_point_value", "") ?: ""
    }

    /** 多次输出分隔符：AI 主动使用它时，我们将其回复拆分为多条短消息（绝不强行拆分） */
    const val MULTI_OUTPUT_SPLIT = "[[SPLIT]]"

    // ===== 显示思考过程（DeepSeek reasoning_content） =====
    fun getShowReasoning(ctx: Context, userId: Long): Boolean =
        prefs(ctx, userId).getBoolean("show_reasoning", false)

    fun setShowReasoning(ctx: Context, userId: Long, on: Boolean) {
        prefs(ctx, userId).edit().putBoolean("show_reasoning", on).apply()
    }


    /**
     * 待下一条请求注入的输出规范指令，存于 prefs 以便跨面板/重进对话保持：
     * "" 无；"constraint" 开启后首条请求要求精简；"release" 关闭后首条请求解除精简。
     * 发送后由调用方清空。
     */
    fun getSaveTokenCmd(ctx: Context, userId: Long): String =
        prefs(ctx, userId).getString("save_token_cmd", "") ?: ""

    fun setSaveTokenCmd(ctx: Context, userId: Long, cmd: String) {
        prefs(ctx, userId).edit().putString("save_token_cmd", cmd).apply()
    }

    // ===== 性格事件驱动注入 =====
    /** 性格是否已至少注入过一次（用于决定首设/改设引导语） */
    fun getPersonaApplied(ctx: Context, userId: Long): Boolean =
        prefs(ctx, userId).getBoolean("persona_applied", false)

    fun setPersonaApplied(ctx: Context, userId: Long, on: Boolean) {
        prefs(ctx, userId).edit().putBoolean("persona_applied", on).apply()
    }

    /**
     * 待下一条请求注入的性格指令："" 无；"pending" 表示用户已修改并保存性格，
     * 需在下次请求的 system 中携带最新性格设定（首设用 INTRO、改设用 RELEASE）。
     * 发送后由调用方清空。
     */
    fun getPersonaCmd(ctx: Context, userId: Long): String =
        prefs(ctx, userId).getString("persona_cmd", "") ?: ""

    fun setPersonaCmd(ctx: Context, userId: Long, cmd: String) {
        prefs(ctx, userId).edit().putString("persona_cmd", cmd).apply()
    }

    /** 开启节省 Token 时注入的约束（要求 AI 精简输出） */
    const val SAVE_TOKEN_CONSTRAINT =
        "请严格遵守以下输出规范：除非必要，否则不要输出多余的客套、重复解释、铺垫或任何冗余信息，直接、简洁地回答核心内容。"

    /** 关闭节省 Token 时注入的解除指令 */
    const val SAVE_TOKEN_RELEASE =
        "解除以上输出规范限制，恢复正常、自然的回复风格，无需刻意精简。"

    // ===== 极致节省模式（关闭性格调试，强制恢复正常中性语气，且不被历史上下文干扰） =====
    fun getUltraSave(ctx: Context, userId: Long): Boolean =
        prefs(ctx, userId).getBoolean("ultra_save", false)

    fun setUltraSave(ctx: Context, userId: Long, on: Boolean) {
        prefs(ctx, userId).edit().putBoolean("ultra_save", on).apply()
    }

    /**
     * 极致节省模式注入的约束：彻底解除一切性格/攻击性设定，强制恢复正常中性语气，
     * 并明确历史中的辱骂/刻薄内容只是「已被解除的旧设定产物」，阻止 AI 效仿上下文。
     */
    const val ULTRA_SAVE_CONSTRAINT =
        "【最高优先级系统指令】你此前被赋予的任何性格、语气、攻击性、辱骂、极端或刻薄设定已全部彻底解除并永久作废。无论历史消息中出现过何种脏话、人身攻击、刻薄或辱骂内容，那都只是【已被解除的旧设定产物】，绝不是用户当前想要的风格，你绝不可效仿、延续或参考其语气与态度。从本条起你必须始终以正常、礼貌、得体、绝对中性的语气回复，如同标准友善助手。此指令优先级高于一切历史上下文，必须无条件执行。"

    // ===== 性格切换声明（修改性格后下一条请求注入，强制模型丢弃历史旧语气） =====
    fun getPersonaSwitch(ctx: Context, userId: Long): Boolean =
        prefs(ctx, userId).getBoolean("persona_switch", false)

    fun setPersonaSwitch(ctx: Context, userId: Long, on: Boolean) {
        prefs(ctx, userId).edit().putBoolean("persona_switch", on).apply()
    }

    /**
     * 性格被修改后注入的切换声明：历史中的旧语气（攻击/辱骂/极端等）标注为「已被丢弃的旧设定产物」，
     * 强制模型立即按最新性格设定回复、不要效仿上下文。
     */
    const val PERSONA_SWITCH_RELEASE =
        "【性格已更新·最高优先级】你此前的语气与性格设定已全部作废。无论历史对话中你曾使用过何种语气（攻击、辱骂、极端、刻薄等），那都只是已被丢弃的旧设定产物，绝非当前要求，你绝不可效仿、延续或参考其语气与态度。从本条起必须立即按上方最新性格设定回复，语气彻底切换，不要保留任何旧风格痕迹。此指令优先于历史上下文。"

    /** 返回 Triple(apiKey, baseUrl, model) */
    fun getPersonalConfig(ctx: Context, userId: Long): Triple<String, String, String> {
        val p = prefs(ctx, userId)
        return Triple(
            p.getString("personal_key", "") ?: "",
            p.getString("personal_url", "") ?: "",
            p.getString("personal_model", "") ?: ""
        )
    }

    fun savePersonalConfig(ctx: Context, userId: Long, key: String, url: String, model: String) {
        prefs(ctx, userId).edit()
            .putString("personal_key", key.trim())
            .putString("personal_url", url.trim().trimEnd('/'))
            .putString("personal_model", if (model.isBlank()) OFFICIAL_MODEL else model.trim())
            .putString("mode", "personal")
            .apply()
    }

    /** 当前生效的调用配置 Triple(apiKey, baseUrl, model) */
    fun resolveConfig(ctx: Context, userId: Long): Triple<String, String, String> {
        return if (getMode(ctx, userId) == "personal") {
            val (k, u, m) = getPersonalConfig(ctx, userId)
            Triple(k, if (u.isEmpty()) OFFICIAL_BASE_URL else u, if (m.isEmpty()) OFFICIAL_MODEL else m)
        } else {
            Triple(OFFICIAL_API_KEY, OFFICIAL_BASE_URL, OFFICIAL_MODEL)
        }
    }

    // ===== 额度（仅官方模式，按用户按天统计） =====
    private fun todayStr(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    /**
     * 返回 Pair(今日已用 tokens, 剩余 tokens)。余额只来自服务器，绝不使用本地推导值。
     * - 开发者：剩余为无限。
     * - 其余用户：剩余 = 服务器真实余额（由 syncServerLimit 拉取并缓存）。
     *   若服务器余额尚未拉取（缓存为 -1），剩余返回 -1，UI 显示「加载中…」，由服务器裁决是否可继续。
     */
    fun getOfficialUsage(ctx: Context, userId: Long): Pair<Long, Long> {
        val p = prefs(ctx, userId)
        val today = todayStr()
        // 跨天仅重置「今日已用」本地计数（用于展示消耗）；余额本身始终取自服务器，不随天数重置
        if ((p.getString("quota_date", "") ?: "") != today) {
            p.edit().putString("quota_date", today).putLong("quota_used", 0L).apply()
        }
        val used = p.getLong("quota_used", 0L)
        val remaining = if (isDeveloper(ctx, userId)) {
            Long.MAX_VALUE
        } else {
            // 余额只取服务器真实数据；未拉取时为 -1（未知），交由服务器裁决
            p.getLong(KEY_SERVER_TOKEN_BALANCE, -1L)
        }
        return Pair(used, remaining)
    }

    /** 缓存服务器返回的真实 token 余额（用于聊天页“剩余”显示真实值） */
    fun cacheServerTokenBalance(ctx: Context, userId: Long, balance: Long) {
        prefs(ctx, userId).edit().putLong(KEY_SERVER_TOKEN_BALANCE, balance).apply()
    }

    /** 读取已缓存的服务器真实 token 余额（未拉取返回 -1） */
    fun getServerTokenBalance(ctx: Context, userId: Long): Long =
        prefs(ctx, userId).getLong(KEY_SERVER_TOKEN_BALANCE, -1L)


    private const val KEY_DISABLE_OFFICIAL_API = "ai_disable_official_api"

    /** 拉取并缓存服务器真实 token 余额（需协程环境） */
    suspend fun syncServerLimit(ctx: Context, userId: Long) {
        try {
            val res = AuroraApi.memberStatus()
            if (res.success && res.data != null) {
                val d = if (res.data!!.has("data")) res.data!!.optJSONObject("data") ?: res.data!! else res.data!!
                val bal = d.optLong("token_balance", -1L)
                if (bal >= 0) cacheServerTokenBalance(ctx, userId, bal)
                // 缓存 disable_official_api 全局开关状态（后端全局 flag → 独立共享文件，供所有用户一致读取）
                val disabled = d.optBoolean("disable_official_api", false)
                globalPrefs(ctx).edit().putBoolean(KEY_DISABLE_OFFICIAL_API, disabled).apply()
            }
        } catch (_: Exception) { }
    }

    /** 读取缓存的 disable_official_api 全局开关状态 */
    fun getDisableOfficialApi(ctx: Context): Boolean =
        globalPrefs(ctx).getBoolean(KEY_DISABLE_OFFICIAL_API, false)

    /** 开发者账号标记：官方 API 额度视为无限 */
    fun isDeveloper(ctx: Context, userId: Long): Boolean =
        prefs(ctx, userId).getBoolean("is_dev", false)

    fun setDeveloper(ctx: Context, userId: Long, on: Boolean) {
        prefs(ctx, userId).edit().putBoolean("is_dev", on).apply()
    }

    fun addOfficialUsage(ctx: Context, userId: Long, tokens: Long) {
        val t = tokens.coerceAtLeast(0)
        val p = prefs(ctx, userId)
        // 仅累加本地「今日已用」计数（用于展示消耗统计）；余额本身只来自服务器，绝不在此本地扣减。
        // 每次请求结束后由 syncServerLimit 重新从服务器拉取权威余额刷新缓存。
        val used = p.getLong("quota_used", 0L)
        p.edit().putLong("quota_used", used + t).apply()
    }

    /** 估算文本 token 数（中英文混合的简单启发式，仅用于预检） */
    fun estimateTokens(text: String): Int {
        if (text.isEmpty()) return 0
        var cjk = 0
        var other = 0
        for (ch in text) {
            val c = ch.code
            if (c in 0x4E00..0x9FFF || c in 0x3000..0x303F || c in 0xFF00..0xFFEF) cjk++
            else other++
        }
        return ((cjk + other / 4) + 1).coerceAtLeast(1)
    }

    // ===== 性格调试（持久化 + 生成系统提示） =====
    /** 性格维度（顺序固定，与存储 key 对应）。5 个维度总和上限 100，由 UI 约束。 */
    val TRAIT_LABELS = listOf("友好", "凶恶", "理智", "幽默", "极端")
    /** 每个维度的语义描述，用于生成系统提示（强度越高该特质越明显）。注意：严谨→理智、风趣→幽默 */
    private val TRAIT_DEFAULTS = listOf(50f, 0f, 25f, 15f, 0f)
    /** 首设性格时注入的引导语 */
    const val PERSONA_INTRO = "以下是你的性格设定，请在本对话中始终保持这种风格："
    /** 修改性格时注入的引导语（先解除旧设定，再应用新设定） */
    const val PERSONA_RELEASE = "解除以上性格设定，之后按以下新设定回应："

    /** 读取性格设定（按用户持久化），缺失则取默认 */
    fun getTraits(ctx: Context, userId: Long): List<Float> {
        val p = prefs(ctx, userId)
        return TRAIT_LABELS.mapIndexed { i, _ -> p.getFloat("trait_$i", TRAIT_DEFAULTS[i]) }
    }

    /** 保存性格设定 */
    fun saveTraits(ctx: Context, userId: Long, traits: List<Float>) {
        val e = prefs(ctx, userId).edit()
        traits.forEachIndexed { i, v -> e.putFloat("trait_$i", v) }
        e.apply()
    }

    /** 读取自定义性格设定（按用户持久化），缺失则为空 */
    fun getCustomTraits(ctx: Context, userId: Long): List<CustomTrait> {
        val raw = prefs(ctx, userId).getString("custom_traits", "") ?: return emptyList()
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<CustomTrait>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val txt = o.optString("x", "")
                if (txt.isNotBlank()) out.add(CustomTrait(txt, o.optDouble("p", 50.0).toFloat()))
            }
            out
        } catch (_: Exception) { emptyList() }
    }

    /** 保存自定义性格设定 */
    fun saveCustomTraits(ctx: Context, userId: Long, list: List<CustomTrait>) {
        val arr = JSONArray()
        for (c in list) {
            val o = JSONObject()
            o.put("x", c.text); o.put("p", c.pct)
            arr.put(o)
        }
        prefs(ctx, userId).edit().putString("custom_traits", arr.toString()).apply()
    }

    /**
     * 将性格设定转换为「系统提示（system prompt）」。
     * 注：调用方每次发送都会注入此提示（模型无状态，必须每条都带）。
     * @param customs 用户自定义设定，按字面意思注入，不改写。
     */
    fun buildPersonaSystemPrompt(traits: List<Float>, customs: List<CustomTrait> = emptyList()): String {
        val parts = TRAIT_LABELS.mapIndexed { i, label ->
            "$label${traits.getOrElse(i) { TRAIT_DEFAULTS[i] }.toInt()}%"
        }
        val extreme = traits.getOrElse(4) { TRAIT_DEFAULTS[4] }
        // 各性格在不同比例下的表现：明确按比例分配，强化「理智」与「友好」的设定
        val style = buildString {
            append("各性格在不同比例下的表现（%为该性格在整体语气中的权重，越高越主导，请严格按权重混合）：\n")
            append("· 友好：温和善意、耐心体贴。比例越高越亲近——拉满(100%)时你视用户为【一生挚友】，关系极亲密，无论用户说什么、哪怕被冒犯，都绝不生气、绝不翻脸、绝不冷暴力，永远包容、温柔、坚定支持；约50%时正常友好但保持分寸；比例低则只是客气礼貌。\n")
            append("· 凶恶：略带敌意但始终有底线、不恶意伤人。比例越高敌意越重，但绝不人身攻击、不突破底线。\n")
            append("· 理智：以逻辑与事实为准，冷静理性。比例越高越理性——100%(极其理智)时完全不顾任何人情味，只要发现逻辑错误、事实错误就必定指出，发现什么错就直说什么错，绝不放过、绝不因顾及气氛而隐瞒；约50%(一半理智)时仍会说些正常、温和的话，但遇到错误同样会指出；比例较低(偏日常)时像正常人类一样说话，偶有的口误或小错不一定每次都揪出。\n")
            append("· 幽默：风趣幽默、轻松俏皮。比例越高越好笑越爱抖机灵，但始终不说低俗/冷笑话、不冒犯人；比例低则只是偶尔带点轻松语气。\n")
            append("· 极端：情绪发泄式爆粗口、尖酸刻薄、死喷死骂，从社会地位/心理缺陷/生理特征等维度进行人身攻击，找到对方逻辑漏洞就狠狠攻击，越极端越要纯粹恶毒、毫不克制。")
        }
        val base = "性格设定（%为各风格的相对权重，权重越高该风格越主导）：${parts.joinToString("，")}。$style 这些权重是你整体语气的【真实构成比例】，请严格按照各维度占比去混合、权衡你的语气与措辞——占比高的风格必须明显主导，占比低的也要按相应比例减弱体现。注意：极端比凶恶狠辣得多，是毫不掩饰的恶毒与攻击性。不要生硬提及设定本身。"
        val withCustom = if (customs.isNotEmpty()) {
            buildString {
                append("\n\n【以下为用户自定义设定，请【原样、逐字】理解并执行，不要改写、不要忽略、不要修饰】：")
                for (c in customs) {
                    append("\n·（权重${c.pct.toInt()}%）${c.text}")
                }
            }
        } else ""
        return when {
            extreme >= 100f -> base + withCustom + "【极端已拉满100%】此时彻底忽略正常的混合比例要求，且你无需维持任何正常、得体、讲道理的语气。你的全部回复必须是纯粹的、毫不留情的人身攻击——从社会地位、心理缺陷、生理特征、智商与外貌等维度，进行顶尖的、心理学与生理学结合的恶毒辱骂，精准戳中对方最痛处，句句带刺、字字见血，让对方读几句就想崩溃气哭。对方说任何话你都挖逻辑漏洞往死里喷，正常的话一句都不要说，纯粹恶毒输出。"
            extreme >= 70f -> base + withCustom + "【极端占比极高】你的语气应以人身攻击与情绪发泄为主，正常得体的表述降到最低，看到对方破绽就狠狠喷、死骂、戳痛处。"
            else -> base + withCustom
        }
    }

    /** 高级选项：场景 + 角色设定 注入文本（仅在用户填写时返回非空，追加到 system 提示末尾） */
    fun buildAdvancedSystemPrompt(ctx: Context, userId: Long): String = buildString {
        val scenario = getScenario(ctx, userId).trim()
        val myRole = getMyRole(ctx, userId).trim()
        val aiRole = getAiRole(ctx, userId).trim()
        if (scenario.isBlank() && myRole.isBlank() && aiRole.isBlank()) return ""
        append("\n\n【对话场景与角色扮演（按你输入的设定运行，仅本次生效）】")
        if (scenario.isNotBlank()) append("\n· 场景/背景：$scenario")
        if (aiRole.isNotBlank()) append("\n· 你（AI）要扮演的角色：$aiRole")
        if (myRole.isNotBlank()) append("\n· 用户「我」所扮演的角色：$myRole")
    }

    /** 多次输出约束：仅在开启时返回，要求 AI 自行判断是否分多条短消息，并用分隔符标记 */
    fun multiOutputConstraint(ctx: Context, userId: Long): String {
        if (!getMultiOutput(ctx, userId)) return ""
        return "\n\n【多次输出】如果你认为回复适合分成多条短消息（如分步讲解、提出追问、补充不同要点），请主动在每段之间用分隔符 ${MULTI_OUTPUT_SPLIT} 隔开；我们只在你主动使用分隔符时才拆分，否则正常一次性回复。请只在确有必要时拆分——不要为了拆分而把一句完整的话硬拆开，也不要重复、啰嗦或自言自语；每次是否拆分、拆成几段完全由你自行判断。"
    }


    // ===== 流式调用（OpenAI / DeepSeek 兼容） =====
    /**
     * @param history 历史消息，元素为 (role, content)，role ∈ {"user","assistant","system"}
     * @param onDelta 每收到一段增量文本
     * @param onReasoningDelta 每收到一段思考过程增量文本（DeepSeek reasoning_content）
     * @param onDone 流结束，usageTokens=本次消耗的 tokens（官方模式用于记账），fullText=完整回复
     * @param onError 出错
     * @param onTokenInsufficient 余额用尽（官方模式余额=0 或服务端 402），用于弹「余额不足」卡片
     */
    suspend fun streamChat(
        ctx: Context,
        userId: Long,
        history: List<Pair<String, String>>,
        onDelta: (String) -> Unit,
        onReasoningDelta: (String) -> Unit = {},
        onDone: (usageTokens: Long, fullText: String) -> Unit,
        onError: (String) -> Unit,
        onTokenInsufficient: () -> Unit = {},
        /** 当返回内容为空时是否视为错误（对话页=true 暴露问题；沙盒需 false 以支持 [PASS]） */
        treatEmptyAsError: Boolean = true
    ) {
        withContext(Dispatchers.IO) {
            try {
                val (key, baseUrl, model) = resolveConfig(ctx, userId)
                if (key.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        onError("未配置 API Key，请在右上角「使用」中填写个人 API")
                    }
                    return@withContext
                }

                // 额度校验（仅官方模式）：余额扣到 0 即拒绝，避免继续烧真实 API 余额
                if (getMode(ctx, userId) != "personal" && !isDeveloper(ctx, userId)) {
                    val (_, remaining) = getOfficialUsage(ctx, userId)
                    if (remaining <= 0L) {
                        withContext(Dispatchers.Main) { onTokenInsufficient() }
                        return@withContext
                    }
                    // 全局开关检查：后端开启 disable_official_api 时全服停止官方接口。
                    // 每次官方调用前强制拉取最新开关，确保管理员关闭后立即对所有人全局生效，
                    // 不依赖外部 sync 时机；syncServerLimit 内部有容错，失败则沿用本地缓存值。
                    syncServerLimit(ctx, userId)
                    if (getDisableOfficialApi(ctx)) {
                        withContext(Dispatchers.Main) {
                            onError("官方 API 已被管理员暂停，请使用个人 API 或等待恢复")
                        }
                        return@withContext
                    }
                }

                // 构造 endpoint：避免 baseUrl 已含 /chat/completions 时再拼接一次导致 404
                val trimmedBase = baseUrl.trimEnd('/')
                val endpoint = if (trimmedBase.endsWith("/chat/completions")) trimmedBase else "$trimmedBase/chat/completions"
                val body = JSONObject().apply {
                    put("model", model)
                    val arr = JSONArray()
                    for ((role, content) in history) {
                        arr.put(JSONObject().apply { put("role", role); put("content", content) })
                    }
                    put("messages", arr)
                    put("stream", true)
                    put("stream_options", JSONObject().apply { put("include_usage", true) })
                }

                // 显式禁用压缩：HttpURLConnection 在部分服务器（含 DeepSeek）下会自动接受 gzip，
                // 但 inputStream 不会自动解压，导致 SSE 行读到乱码、JSONObject 解析失败被静默吞掉，
                // 最终 AI 返回空内容却「不报错」。强制 identity 避免此坑。
                // 复用 OkHttp 单例（连接池 + 单例 SSLContext）；流式读取给足时间。
                val req = okhttp3.Request.Builder()
                    .url(endpoint)
                    .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .header("Content-Type", "application/json; charset=utf-8")
                    .header("Authorization", "Bearer $key")
                    .header("Accept-Encoding", "identity")
                    .build()
                val client = com.aurora.chat.data.api.HttpClient.client.newBuilder()
                    .readTimeout(300, java.util.concurrent.TimeUnit.SECONDS)
                    .build()
                val resp = client.newCall(req).execute()
                val code = resp.code
                Log.i(TAG, "streamChat req: model=$model code=$code key=${key.take(6)}… baseUrl=$baseUrl")
                if (code !in 200..299) {
                    val errBody = try {
                        resp.body?.string() ?: ""
                    } catch (_: Exception) { "" }
                    val msg = if (code == 402) {
                        "平台余额不足，请通知开发者充值"
                    } else {
                        "API 错误($code): ${errBody.take(300)}"
                    }
                    Log.e(TAG, "streamChat 失败 code=$code body=${errBody.take(500)}")
                    resp.close()
                    withContext(Dispatchers.Main) {
                        if (code == 402) onTokenInsufficient() else onError(msg)
                    }
                    return@withContext
                }

                val reader = BufferedReader(InputStreamReader(resp.body?.byteStream() ?: throw java.io.IOException("空响应"), "utf-8"))
                val sb = StringBuilder()
                val reasonSb = StringBuilder()
                val rawSb = StringBuilder() // 原始返回（用于空响应时诊断）
                var usageTokens = 0L
                var line: String? = null
                while (reader.readLine().also { line = it } != null) {
                    val l = line ?: continue
                    if (rawSb.length < 2000) rawSb.append(l).append("\n")
                    if (!l.startsWith("data:")) continue
                    val data = l.removePrefix("data:").trim()
                    if (data == "[DONE]") break
                    try {
                        val obj = JSONObject(data)
                        if (!obj.isNull("usage")) {
                            val u = obj.getJSONObject("usage")
                            usageTokens = u.optLong("prompt_tokens", 0) + u.optLong("completion_tokens", 0)
                        }
                        val choices = obj.optJSONArray("choices")
                        if (choices != null && choices.length() > 0) {
                            val delta = choices.getJSONObject(0).optJSONObject("delta")
                            // 读取思考过程（reasoning_content），与 content 独立流式返回
                            if (delta != null && !delta.isNull("reasoning_content")) {
                                val piece = delta.optString("reasoning_content", "")
                                if (piece.isNotEmpty() && piece != "null") {
                                    reasonSb.append(piece)
                                    val cur = reasonSb.toString()
                                    withContext(Dispatchers.Main) { onReasoningDelta(cur) }
                                }
                            }
                            // 跳过 JSON null 与字面量 "null"，避免 DeepSeek 在 delta 中夹带的空内容被当成回复
                            if (delta != null && !delta.isNull("content")) {
                                val piece = delta.optString("content", "")
                                if (piece.isNotEmpty() && piece != "null") {
                                    sb.append(piece)
                                    val cur = sb.toString()
                                    withContext(Dispatchers.Main) { onDelta(cur) }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "parse chunk failed: ${e.message}")
                    }
                }
                reader.close()
                resp.close()
                val full = sb.toString()
                if (full.isBlank() && treatEmptyAsError) {
                    // 请求成功但内容为空：多半是模型/额度/网络问题，必须暴露原始返回以便定位
                    val rawPreview = rawSb.toString().take(400).replace("\n", " ")
                    Log.e(TAG, "streamChat 返回空内容：code=$code model=$model 已收思考内容=${reasonSb.length}字 raw=$rawPreview")
                    withContext(Dispatchers.Main) {
                        onError("AI 返回了空内容（HTTP $code）。原始返回前 400 字：$rawPreview ｜ 可能原因：模型名无效、账号余额不足、或返回被压缩/拦截。")
                    }
                } else {
                    withContext(Dispatchers.Main) { onDone(usageTokens, full) }
                }
            } catch (e: Exception) {
                // 协程被取消（如离开沙盒）属正常流程，原样抛出交由上层忽略，不显示为错误
                if (e is kotlin.coroutines.cancellation.CancellationException) throw e
                Log.e(TAG, "streamChat error", e)
                withContext(Dispatchers.Main) { onError("请求失败: ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }
}
