package com.aurora.chat.ui.chat

import com.aurora.chat.ui.components.FriendRequest
import com.aurora.chat.ui.components.LocalShowDividers
import com.aurora.chat.ui.components.RequestStatus
import com.aurora.chat.ui.components.UserAvatar
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class FriendRequestFilter { PENDING, ALL }

private fun formatTime(timeMillis: Long): String {
    val now = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = timeMillis }
    return when {
        now.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) == date.get(Calendar.DAY_OF_YEAR) ->
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timeMillis))
        now.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) - date.get(Calendar.DAY_OF_YEAR) == 1 -> "昨天"
        now.get(Calendar.YEAR) == date.get(Calendar.YEAR) ->
            SimpleDateFormat("M月d日", Locale.getDefault()).format(Date(timeMillis))
        else -> SimpleDateFormat("yyyy年M月d日", Locale.getDefault()).format(Date(timeMillis))
    }
}

@Composable
fun FriendRequestScreen(
    requests: List<FriendRequest>,
    onAccept: (Int) -> Unit,
    onReject: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var keyword by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(FriendRequestFilter.PENDING) }
    var selectedRequest by remember { mutableStateOf<FriendRequest?>(null) }
    var dismissingItems by remember { mutableStateOf(setOf<Int>()) }

    fun computeResults(): List<Pair<Int, FriendRequest>> {
        return requests.mapIndexedNotNull { index, req ->
            if (filter == FriendRequestFilter.PENDING && req.status != RequestStatus.PENDING) null
            else if (keyword.isNotBlank() && !req.name.contains(keyword, ignoreCase = true)) null
            else index to req
        }
    }

    // 直接初始化结果
    var results by remember { mutableStateOf(computeResults()) }
    var exitingResults by remember { mutableStateOf<List<Pair<Int, FriendRequest>>?>(null) }
    var clearedFlags by remember { mutableStateOf(setOf<Int>()) }
    var isTransitioning by remember { mutableStateOf(false) }
    var searchId by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    // 筛选方向: true=正序(PENDING→ALL), false=反序(ALL→PENDING)
    var filterDirectionForward by remember { mutableStateOf(true) }

    // 跳过第一次触发（延迟 400ms 让界面切入动画先播完，再播列表动画）
    var animationEnabled by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(400)
        animationEnabled = true
    }
    var lastKeyword by remember { mutableStateOf(keyword) }
    var lastFilter by remember { mutableStateOf(filter) }

    // 筛选/搜索变化 → 延迟后刷新（不播旧动画，避免冲突）
    LaunchedEffect(keyword, filter) {
        if (!animationEnabled) {
            lastKeyword = keyword; lastFilter = filter
            return@LaunchedEffect
        }
        filterDirectionForward = filter == FriendRequestFilter.ALL
        lastKeyword = keyword; lastFilter = filter
        // 搜索防抖 300ms
        if (!animationEnabled || filter == lastFilter) delay(300)
        searchId++
        val newList = computeResults()
        if (results.isNotEmpty()) {
            val old = results
            exitingResults = old; clearedFlags = emptySet()
            results = newList; isTransitioning = true
            scope.launch {
                old.indices.forEach { i ->
                    launch { delay(i * 80L + 350L); clearedFlags = clearedFlags + i }
                }
                delay(old.size * 80L + 500L)
                exitingResults = null; isTransitioning = false
            }
        } else {
            results = newList
        }
    }

    // 同意/拒绝后即时同步
    LaunchedEffect(Unit) {
        snapshotFlow { requests.toList() }.collect {
            results = computeResults()
        }
    }

    // 详情弹窗
    if (selectedRequest != null) {
        FriendRequestDetailDialog(
            request = selectedRequest!!,
            onDismiss = { selectedRequest = null }
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        com.aurora.chat.ui.components.EventBlocker()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .background(Color.White)
        ) {
            // ========== 顶栏 ==========
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable { onDismiss() })
                Spacer(Modifier.width(12.dp))
                Text("好友申请", fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1F2937))
            }

            // ========== 搜索输入区 ==========
            Box(
                modifier = Modifier
                    .fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color(0xFFF3F4F6))
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                BasicTextField(
                    value = keyword,
                    onValueChange = { keyword = it },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 14.sp, color = Color(0xFF1F2937)
                    ),
                    singleLine = true,
                    decorationBox = { innerTextField ->
                        Box {
                            if (keyword.isEmpty()) Text("搜索好友申请", fontSize = 13.sp, color = Color(0xFF9CA3AF))
                            innerTextField()
                        }
                    }
                )
            }

            // ========== 筛选选项卡 + 提示文字 ==========
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FilterChip("未处理", filter == FriendRequestFilter.PENDING) { filter = FriendRequestFilter.PENDING }
                    FilterChip("所有", filter == FriendRequestFilter.ALL) { filter = FriendRequestFilter.ALL }
                }
                Spacer(Modifier.weight(1f))
                Text("点击列表查看详情", fontSize = 12.sp, color = Color(0xFF1E40AF))
            }

            Spacer(Modifier.height(4.dp))

            // ========== 请求列表 ==========
            if (results.isEmpty() && exitingResults == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("未找到相关好友申请", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                }
            } else {
                val maxCount = maxOf(exitingResults?.size ?: 0, results.size)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp)
                ) {
                    for (i in 0 until maxCount) {
                        val isOld = exitingResults != null && i < exitingResults!!.size && i !in clearedFlags
                        val isNew = i < results.size && (i in clearedFlags || exitingResults == null)

                        if (isOld) {
                            val exitKey = "exit-${exitingResults!![i].second.name}-$searchId-$i"
                            var startExit by remember(exitKey) { mutableStateOf(false) }
                            LaunchedEffect(exitKey) { delay(i * 80L + 50L); startExit = true }
                            val exitDir = if (filterDirectionForward) -800f else 800f
                            val offX by animateFloatAsState(
                                targetValue = if (startExit) exitDir else 0f, animationSpec = tween(300)
                            )
                            val itemA by animateFloatAsState(
                                targetValue = if (startExit) 0f else 1f, animationSpec = tween(300)
                            )
                            FriendRequestItem(
                                req = exitingResults!![i].second,
                                modifier = Modifier.fillMaxWidth()
                                    .graphicsLayer { translationX = offX; this.alpha = itemA },
                                onAccept = null, onReject = null,
                                onClick = { selectedRequest = exitingResults!![i].second }
                            )
                        }

                        if (isNew && isOld) Spacer(Modifier.height(2.dp))

                        if (isNew) {
                            val enterKey = "enter-${results[i].second.name}-$searchId-$i"
                            var show by remember(enterKey) { mutableStateOf(false) }
                            LaunchedEffect(enterKey) {
                                delay(if (exitingResults != null) i * 80L + 320L else i * 80L)
                                show = true
                            }
                            val enterDir = if (filterDirectionForward) 600f else -600f
                            val offX by animateFloatAsState(
                                targetValue = if (show) 0f else enterDir, animationSpec = tween(280)
                            )
                            val itemA by animateFloatAsState(
                                targetValue = if (show) 1f else 0f, animationSpec = tween(250)
                            )
                            FriendRequestItem(
                                req = results[i].second,
                                modifier = Modifier.fillMaxWidth()
                                    .graphicsLayer { translationX = offX; alpha = itemA },
                                onAccept = {
                                    val idx = results[i].first
                                    dismissingItems = dismissingItems + idx
                                    scope.launch {
                                        delay(300)
                                        results = results.filter { it.first != idx }
                                        onAccept(idx)
                                    }
                                },
                                onReject = {
                                    val idx = results[i].first
                                    dismissingItems = dismissingItems + idx
                                    scope.launch {
                                        delay(300)
                                        results = results.filter { it.first != idx }
                                        onReject(idx)
                                    }
                                },
                                onClick = { selectedRequest = results[i].second }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FriendRequestItem(
    req: FriendRequest,
    modifier: Modifier = Modifier,
    onAccept: (() -> Unit)?,
    onReject: (() -> Unit)?,
    onClick: () -> Unit
) {
    val statusText = when (req.status) {
        RequestStatus.PENDING -> "待处理"; RequestStatus.ACCEPTED -> "已同意"; RequestStatus.REJECTED -> "已拒绝"
    }
    val statusColor = when (req.status) {
        RequestStatus.PENDING -> Color(0xFFF59E0B); RequestStatus.ACCEPTED -> Color(0xFF10B981); RequestStatus.REJECTED -> Color(0xFF9CA3AF)
    }
    val timeText = formatTime(req.time)

    Box(modifier = modifier.padding(vertical = 8.dp).clickable { onClick() },
        contentAlignment = Alignment.CenterStart) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // 头像
            UserAvatar(
                userId = req.fromUserId,
                userName = req.name,
                size = 44.dp
            )
            Spacer(Modifier.width(12.dp))

            // 姓名 + 状态 + 时间
            Column(modifier = Modifier.weight(1f)) {
                Text(req.name, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937),
                    maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(statusText, fontSize = 12.sp, color = statusColor,
                        maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Spacer(Modifier.width(8.dp))
                    Text(timeText, fontSize = 12.sp, color = Color(0xFF9CA3AF),
                        maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                }
            }

            if (req.status == RequestStatus.PENDING && onAccept != null && onReject != null) {
                Text("拒绝", fontSize = 13.sp, color = Color(0xFF9CA3AF),
                    modifier = Modifier.clickable { onReject() }.padding(horizontal = 10.dp, vertical = 6.dp))
                Text("同意", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1E40AF),
                    modifier = Modifier.clickable { onAccept() }.padding(horizontal = 10.dp, vertical = 6.dp))
            }
        }
    }
}

@Composable
private fun FriendRequestDetailDialog(request: FriendRequest, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(16.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 头像
            UserAvatar(
                userId = request.fromUserId,
                userName = request.name,
                size = 72.dp,
                modifier = Modifier.clip(RoundedCornerShape(18.dp))
            )

            Spacer(Modifier.height(12.dp))

            // 名字
            Text(request.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1F2937))

            Spacer(Modifier.height(6.dp))

            // 个性签名
            Text(request.signature, fontSize = 13.sp, color = Color(0xFF9CA3AF),
                textAlign = TextAlign.Center)

            Spacer(Modifier.height(16.dp))

            // 分隔线
            if (LocalShowDividers.current) {
                Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE5E7EB)))
            }

            Spacer(Modifier.height(12.dp))

            // 打招呼信息
            Text("打招呼信息", fontSize = 13.sp, fontWeight = FontWeight.Medium,
                color = Color(0xFF6B7280), modifier = Modifier.align(Alignment.Start))

            Spacer(Modifier.height(6.dp))

            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF9FAFB)).padding(12.dp)
            ) {
                Text(
                    if (request.greeting.isNotBlank()) request.greeting else "暂无打招呼信息",
                    fontSize = 14.sp, color = Color(0xFF1F2937)
                )
            }

            Spacer(Modifier.height(20.dp))

            // 关闭按钮
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF3F4F6)).clickable { onDismiss() }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("关闭", fontSize = 15.sp, fontWeight = FontWeight.Medium,
                    color = Color(0xFF1F2937))
            }
        }
    }
}

@Composable
private fun FilterChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color(0xFF1E40AF) else Color(0xFFF3F4F6))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
            color = if (selected) Color.White else Color(0xFF6B7280))
    }
}
