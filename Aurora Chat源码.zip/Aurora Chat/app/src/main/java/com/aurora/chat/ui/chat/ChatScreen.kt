package com.aurora.chat.ui.chat

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import com.aurora.chat.ui.components.WallpaperStorage
import com.aurora.chat.ui.components.WallpaperType
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.aurora.chat.R
import com.aurora.chat.ui.components.BadgeInfoDialog
import com.aurora.chat.ui.components.GroupAvatar
import com.aurora.chat.ui.components.UserAvatar
import com.aurora.chat.data.api.ConversationInfo
import com.aurora.chat.ui.viewmodel.ChatViewModel

@Composable
fun ChatScreen(
    currentUserId: Long = 0,
    refreshKey: Int = 0,
    listState: LazyListState = rememberLazyListState(),
    onOpenChat: (friendId: Long, friendName: String) -> Unit
) {
    val conversations by ChatViewModel.conversations.collectAsState()
    val isLoading by ChatViewModel.conversationsLoading.collectAsState()
    val isOffline by ChatViewModel.isOffline.collectAsState()
    val groupAvatarRefreshKey by ChatViewModel.groupAvatarRefreshKey.collectAsState()
    val context = LocalContext.current
    var badgeDialogId by remember { mutableStateOf(0) }
    // 壁纸模式下置顶项不画灰底，让壁纸完整透出；默认白色模式下用浅灰区分
    val wallpaperType = remember(refreshKey) { WallpaperStorage.getType(context) }
    val hasWallpaper = wallpaperType != WallpaperType.DEFAULT.value

    LaunchedEffect(currentUserId, refreshKey) {
        ChatViewModel.loadConversations(context)
    }

    // 启动时把已保存的 AI 自定义头像 / 名称载入全局状态，保证聊天列表立即生效
    LaunchedEffect(Unit) {
        if (AiAvatarState.bitmap == null) {
            val f = com.aurora.chat.data.local.LocalStorage.getAiAvatarFile(context)
            if (f.exists()) {
                AiAvatarState.bitmap = android.graphics.BitmapFactory.decodeFile(f.absolutePath)
            }
        }
        if (AiNameState.name == null) {
            AiNameState.name = com.aurora.chat.data.local.LocalStorage.getAiName(context)
        }
    }

    // TCP 推送新消息时自动刷新对话列表（强制刷新，绕过新鲜度守卫）
    LaunchedEffect(Unit) {
        com.aurora.chat.ui.viewmodel.ChatViewModel.newMessageReceived.collect {
            ChatViewModel.loadConversations(context, force = true)
        }
    }



    // 构建包含三个特殊对话的完整列表（放在最前面，受置顶排序影响）
    // 用 remember 派生：仅在数据/置顶/用户变化时重算，避免每次重组都全量读 SP 重排；
    // 同步计算，首帧即可用缓存满数据，配合外部 hoisted LazyListState 精确还原滚动位置。
    val selfChatName = com.aurora.chat.data.api.AuroraApi.currentUserName
    val aiChatName = AiNameState.name ?: "DeepSeek"
    val conversationsSnapshot = remember(conversations) { conversations.distinctBy { it.id } }
    // 置顶计数：长按置顶/取消后会自增，作为重排触发条件
    val pinTick by com.aurora.chat.ui.viewmodel.ChatViewModel.pinChanged.collectAsState()
    val expandedConversations = remember(currentUserId, conversationsSnapshot, pinTick, selfChatName, aiChatName) {
        if (currentUserId > 0) {
            val selfLastMsg = loadSelfChatLastMsg(context, currentUserId)
            val aiLastMsg = loadLocalChatLastMsg(context, currentUserId, "ai")
            val notifLastMsg = loadLocalChatLastMsg(context, currentUserId, "notification")
            val special = mutableListOf<ConversationInfo>(
                ConversationInfo(id = 0L, email = "", username = selfChatName, createdAt = 0, lastMessage = selfLastMsg),
                ConversationInfo(id = AI_CHAT_ID, email = "", username = aiChatName, createdAt = 0, lastMessage = aiLastMsg),
                ConversationInfo(id = NOTIFICATION_CHAT_ID, email = "", username = "通知中心", createdAt = 0, lastMessage = notifLastMsg)
            )
            val all = conversations.toMutableList()
            all.removeAll { it.id == 0L || it.id == AI_CHAT_ID || it.id == NOTIFICATION_CHAT_ID }
            all.addAll(0, special)
            val prefs = context.getSharedPreferences("aurora_friend_settings", android.content.Context.MODE_PRIVATE)
            all.sortedByDescending {
                val key = when {
                    it.id == 0L || it.id == AI_CHAT_ID || it.id == NOTIFICATION_CHAT_ID -> "pin_${it.id}"
                    it.id < 0 -> "pin_group_${-(it.id + 1000)}"
                    else -> "pin_${it.id}"
                }
                prefs.getBoolean(key, false)
            }.distinctBy { it.id }
        } else {
            conversationsSnapshot
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        userScrollEnabled = true
    ) {
        // 离线提示条（放在最顶部，在自己的对话上方）
        if (isOffline) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .padding(top = 4.dp)
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp))
                        .background(Color(0xFFFFF3CD))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("当前网络不可用，显示的是缓存的会话列表",
                        fontSize = 12.sp, color = Color(0xFF856404))
                }
             Spacer(Modifier.height(4.dp))
            }
        }

        if (isLoading) {
            item {
                Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(vertical = 48.dp), contentAlignment = Alignment.Center) {
                    Text("加载中...", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                }
            }
        } else if (expandedConversations.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(vertical = 48.dp), contentAlignment = Alignment.Center) {
                    Text("暂无会话", fontSize = 14.sp, color = Color(0xFF9CA3AF))
                }
            }
        } else {
            items(expandedConversations, key = { it.id }) { conv ->
            val internalGroupId = remember(conv.id) {
                if (conv.id < 0 && conv.id != AI_CHAT_ID && conv.id != NOTIFICATION_CHAT_ID) -(conv.id + 1000) else null
            }
            val convRemarkKey = if (internalGroupId != null) "remark_group_$internalGroupId" else "remark_${conv.id}"
            val convRemark = remember(convRemarkKey) {
                context.getSharedPreferences("aurora_friend_settings", android.content.Context.MODE_PRIVATE)
                    .getString(convRemarkKey, "") ?: ""
            }
            val pinItemKey = when {
                internalGroupId != null -> "pin_group_$internalGroupId"
                else -> "pin_${conv.id}"
            }
            val pinnedItem = remember(pinItemKey) {
                context.getSharedPreferences("aurora_friend_settings", android.content.Context.MODE_PRIVATE)
                    .getBoolean(pinItemKey, false)
            }
            // 置顶背景铺满整行（左右贴边、无圆角）；有壁纸时不画灰底，让壁纸完整透出
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (pinnedItem && !hasWallpaper) Modifier.background(Color(0xFFF6F7F8))
                        else Modifier
                    )
            ) {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    ConversationItem(
                avatar = {
                    when (conv.id) {
                        0L -> UserAvatar(userId = currentUserId, userName = conv.username, size = 48.dp)
                        AI_CHAT_ID -> {
                            val aiName = AiNameState.name ?: "DeepSeek"
                            val custom = AiAvatarState.bitmap
                            if (custom != null) {
                                Image(bitmap = custom.asImageBitmap(), contentDescription = aiName,
                                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                            } else {
                                Image(painter = painterResource(R.drawable.ai_avatar), contentDescription = aiName,
                                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                            }
                        }
                        NOTIFICATION_CHAT_ID -> Image(painter = painterResource(R.drawable.wd),
                            contentDescription = "通知", modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                        else -> {
                            if (internalGroupId != null) {
                                GroupAvatar(internalGroupId = internalGroupId, groupName = conv.username, size = 48.dp, refreshKey = groupAvatarRefreshKey)
                            } else {
                                UserAvatar(userId = conv.id, userName = conv.username, size = 48.dp)
                            }
                        }
                    }
                },
                name = conv.username,
                lastMsg = conv.lastMessage,
                wornBadge = if (conv.id == NOTIFICATION_CHAT_ID) getNotificationUnread(context, currentUserId) else if (internalGroupId != null) 0 else conv.wornBadge,
                convId = conv.id,
                context = context,
                internalGroupId = internalGroupId,
                onClick = { onOpenChat(conv.id, convRemark.ifEmpty { conv.username }) },
                onBadgeClick = { bid -> badgeDialogId = bid }
            )
            // 分割线，受"去除分割线"设置控制
            if (com.aurora.chat.ui.components.LocalShowDividers.current) {
                Box(
                    modifier = Modifier
                        .padding(start = 60.dp)
                        .fillMaxWidth()
                        .height(0.5.dp)
                        .background(Color(0xFFE5E7EB))
                )
            }
                }
            }
        }
        }
    }

    // 徽章点击弹窗
    if (badgeDialogId > 0) {
        BadgeInfoDialog(badgeId = badgeDialogId, onDismiss = { badgeDialogId = 0 })
    }
}

@Composable
private fun ConversationItem(
    avatar: @Composable () -> Unit,
    name: String,
    lastMsg: String,
    wornBadge: Int = 0,
    convId: Long = 0,
    context: android.content.Context,
    internalGroupId: Long? = null,
    onClick: () -> Unit,
    onBadgeClick: (Int) -> Unit = {}
) {
    // 缓存预览文本，避免每次重组时重新计算
    val annotatedText = remember(lastMsg) {
        if (lastMsg.isNotEmpty()) buildPreviewText(lastMsg) else null
    }

    val prefs = remember { context.getSharedPreferences("aurora_friend_settings", android.content.Context.MODE_PRIVATE) }

    // 备注
    val remarkKey = if (internalGroupId != null) "remark_group_$internalGroupId" else "remark_$convId"
    var remark by remember(remarkKey) { mutableStateOf(prefs.getString(remarkKey, "") ?: "") }
    LaunchedEffect(remarkKey) { remark = prefs.getString(remarkKey, "") ?: "" }
    val displayName = remark.ifEmpty { name }

    // 置顶
    val pinKey = if (internalGroupId != null) "pin_group_$internalGroupId" else "pin_$convId"
    var pinnedState by remember(pinKey) { mutableStateOf(prefs.getBoolean(pinKey, false)) }
    LaunchedEffect(pinKey) { pinnedState = prefs.getBoolean(pinKey, false) }

    var showMenu by remember { mutableStateOf(false) }
    var showRemarkDialog by remember { mutableStateOf(false) }
    var remarkInput by remember { mutableStateOf("") }

    // 备注弹窗
    if (showRemarkDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showRemarkDialog = false },
            containerColor = Color.White,
            title = { Text("给「$name」备注", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("当前备注：", fontSize = 13.sp, color = Color(0xFF6B7280))
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (remark.isNotEmpty()) remark else "（未设置）",
                        fontSize = 14.sp, color = Color(0xFF1F2937), fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(12.dp))
                    BasicTextField(
                        value = remarkInput,
                        onValueChange = { remarkInput = it },
                        modifier = Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF3F4F6))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp, color = Color(0xFF1F2937)),
                        singleLine = true,
                        decorationBox = { inner ->
                            Box { if (remarkInput.isEmpty()) Text("输入备注名称", fontSize = 13.sp, color = Color(0xFF9CA3AF)); inner() }
                        }
                    )
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    val newRemark = remarkInput.trim()
                    remark = newRemark
                    prefs.edit().putString(remarkKey, newRemark).apply()
                    showRemarkDialog = false
                }) { Text("确定", color = Color(0xFF1E40AF)) }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showRemarkDialog = false }) {
                    Text("取消", color = Color(0xFF6B7280))
                }
            }
        )
    }

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { onClick() },
                        onLongPress = { showMenu = true }
                    )
                }
                .padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 头像点击进入聊天，但移除水波纹特效（indication = null）
            Box(
                Modifier.clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onClick() }
            ) { avatar() }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = displayName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    // 右侧显示佩戴的徽章
                    val bi = wornBadge - 1
                    if (bi in badgeResIds.indices) {
                        Spacer(Modifier.width(6.dp))
                        val badgeHeight = if (bi == 3 || bi == 4 || bi == 9) 18.dp else 15.dp
                        Image(
                            painter = painterResource(badgeResIds[bi]),
                            contentDescription = "徽章",
                            modifier = Modifier.height(badgeHeight).pointerInput(Unit) {
                                detectTapGestures(onTap = { onBadgeClick(wornBadge) })
                            },
                            contentScale = ContentScale.FillHeight
                        )
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                if (annotatedText != null) {
                    Text(
                        text = annotatedText,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // 长按菜单
        DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false }
        ) {
            DropdownMenuItem(
                text = {
                    Text(
                        if (pinnedState) "取消置顶" else "置顶",
                        fontSize = 14.sp,
                        color = if (pinnedState) Color(0xFF6B7280) else Color(0xFF1E40AF)
                    )
                },
                onClick = {
                    val newVal = !pinnedState
                    pinnedState = newVal
                    prefs.edit().putBoolean(pinKey, newVal).apply()
                    ChatViewModel.notifyPinChanged()
                    showMenu = false
                }
            )
            DropdownMenuItem(
                text = {
                    Text("备注", fontSize = 14.sp, color = if (remark.isNotEmpty()) Color(0xFF6B7280) else Color(0xFF1E40AF))
                },
                onClick = {
                    showMenu = false
                    remarkInput = remark
                    showRemarkDialog = true
                }
            )
        }
    }
}

/** 构建预览消息 AnnotatedString：纯文字灰色，表情保持原色 */
private fun buildPreviewText(text: String): androidx.compose.ui.text.AnnotatedString {
    val grayStyle = SpanStyle(color = Color(0xFF9CA3AF))
    return buildAnnotatedString {
        var i = 0
        while (i < text.length) {
            val codePoint = Character.codePointAt(text, i)
            val charCount = Character.charCount(codePoint)
            if (isEmoji(codePoint)) {
                // 表情：不应用任何样式，保持默认颜色
                append(text.substring(i, i + charCount))
            } else {
                // 纯文字：应用灰色
                withStyle(grayStyle) {
                    append(text.substring(i, i + charCount))
                }
            }
            i += charCount
        }
    }
}

/** 从本地加载自己对话的最后一条消息预览 */
private fun loadSelfChatLastMsg(ctx: android.content.Context, currentUserId: Long): String {
    try {
        val prefs = ctx.getSharedPreferences("self_chat_${currentUserId}", android.content.Context.MODE_PRIVATE)
        return prefs.getString("last_msg", "") ?: ""
    } catch (_: Exception) { return "" }
}

/** 判断字符是否为 Emoji */
private fun isEmoji(codePoint: Int): Boolean {
    return (codePoint in 0x1F300..0x1F9FF) ||          // 杂项符号和 pictographs
           (codePoint in 0x1FA00..0x1FA6F) ||          // 象棋符号扩展
           (codePoint in 0x1FA70..0x1FAFF) ||          // 符号扩展-A
           (codePoint in 0x2600..0x27BF) ||            // 杂项符号
           (codePoint in 0xFE00..0xFE0F) ||            // 变体选择符
           (codePoint in 0x1F1E0..0x1F1FF) ||          // 国旗（区域指示符）
           (codePoint in 0x200D..0x200D) ||            // 零宽连字符
           (codePoint in 0x20E3..0x20E3) ||            // 组合围圈键帽
           (codePoint in 0x231A..0x23FF) ||            // 杂项技术符号
           (codePoint in 0x25AA..0x25FF) ||            // 几何形状
           (codePoint in 0x2934..0x2935) ||            // 箭头补充
           (codePoint in 0x2B05..0x2B55) ||            // 杂项符号和箭头
           (codePoint in 0x3030..0x3030) ||            // 波浪线
           (codePoint in 0x3297..0x3299) ||            // 杂项符号
           (codePoint in 0x1F600..0x1F64F) ||          // 表情符号
           (codePoint in 0x2700..0x27BF) ||            // 丁当符号
           (codePoint in 0x1F680..0x1F6FF) ||          // 交通和地图符号
           (codePoint in 0x1F900..0x1F9FF)             // 补充符号和 pictographs
}
