package com.aurora.chat.ui.activity

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.aurora.chat.data.api.AuroraApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AppSubmitScreen(onBack: () -> Unit, onSubmitted: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var downloadUrl by remember { mutableStateOf("") }
    var packageName by remember { mutableStateOf("") }
    var fileSizeStr by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("推荐") }
    var iconUri by remember { mutableStateOf<Uri?>(null) }
    var screenshotUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val iconLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> iconUri = uri }
    val screenshotLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        screenshotUris = (screenshotUris + uris).take(10)
    }

    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 24.sp, color = Color(0xFF1E40AF),
                modifier = Modifier.clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onBack() })
            Spacer(Modifier.weight(1f))
            Text("上传应用", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))
            Spacer(Modifier.weight(1f))
            Box(Modifier.width(48.dp))
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text("应用名称 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp))

            Spacer(Modifier.height(12.dp))
            Text("应用描述", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = description, onValueChange = { description = it }, modifier = Modifier.fillMaxWidth().height(100.dp), shape = RoundedCornerShape(10.dp))

            Spacer(Modifier.height(12.dp))
            Text("下载地址 *", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            OutlinedTextField(value = downloadUrl, onValueChange = { downloadUrl = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp), placeholder = { Text("https://...", fontSize = 13.sp) })

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("包名", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
                    OutlinedTextField(value = packageName, onValueChange = { packageName = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("文件大小(MB)", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
                    OutlinedTextField(value = fileSizeStr, onValueChange = { fileSizeStr = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(10.dp))
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("分类", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("推荐", "实用", "开发", "游戏", "社交", "影音", "购物", "工具", "通讯", "娱乐", "成人").forEach { cat ->
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(if (category == cat) Color(0xFF1E40AF) else Color(0xFFF3F4F6)).clickable { category = cat }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text(cat, fontSize = 13.sp, color = if (category == cat) Color.White else Color(0xFF6B7280), fontWeight = if (category == cat) FontWeight.Medium else FontWeight.Normal)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("应用图标", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151)); Spacer(Modifier.height(4.dp))
            Box(Modifier.size(80.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF3F4F6)).clickable { iconLauncher.launch("image/*") }, contentAlignment = Alignment.Center) {
                if (iconUri != null) AsyncImage(model = iconUri!!, contentDescription = "图标", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text("选择图标", fontSize = 11.sp, color = Color(0xFF6B7280))
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("应用截图 (最多10张)", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF374151))
                Spacer(Modifier.weight(1f))
                if (screenshotUris.size < 10) TextButton(onClick = { screenshotLauncher.launch("image/*") }) { Text("添加", fontSize = 12.sp, color = Color(0xFF1E40AF)) }
            }
            Spacer(Modifier.height(4.dp))
            if (screenshotUris.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF9FAFB)).clickable { screenshotLauncher.launch("image/*") }, contentAlignment = Alignment.Center) { Text("点击选择截图", fontSize = 13.sp, color = Color(0xFF9CA3AF)) }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(screenshotUris.size) { idx ->
                        Box(Modifier.size(80.dp)) {
                            AsyncImage(model = screenshotUris[idx], contentDescription = "截图$idx", modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                            Box(Modifier.align(Alignment.TopEnd).size(20.dp).clip(RoundedCornerShape(50)).background(Color.Red.copy(alpha = 0.8f)).clickable { screenshotUris = screenshotUris.toMutableList().apply { removeAt(idx) } }, contentAlignment = Alignment.Center) { Text("X", fontSize = 10.sp, color = Color.White) }
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            errorMsg?.let { Text(it, fontSize = 13.sp, color = Color.Red); Spacer(Modifier.height(8.dp)) }

            Button(
                onClick = {
                    if (name.isBlank() || downloadUrl.isBlank()) { errorMsg = "应用名称和下载地址为必填"; return@Button }
                    isSubmitting = true; errorMsg = null
                    scope.launch {
                        try {
                            val iconBytes = iconUri?.let { withContext(Dispatchers.IO) { context.contentResolver.openInputStream(it)?.use { s -> s.readBytes() } } }
                            val screenshotBytesList = screenshotUris.mapNotNull { uri -> withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { s -> s.readBytes() } } }
                            val mb = fileSizeStr.toFloatOrNull()?.let { (it * 1_000_000).toLong() } ?: 0L
                            val result = AuroraApi.submitApp(name.trim(), description.trim(), downloadUrl.trim(), category, packageName.trim(), mb, iconBytes, screenshotBytesList)
                            isSubmitting = false
                            if (result.success) { Toast.makeText(context, "提交成功，等待管理员审核", Toast.LENGTH_LONG).show(); onSubmitted() }
                            else errorMsg = result.message
                        } catch (e: Exception) { isSubmitting = false; errorMsg = e.localizedMessage ?: "提交失败" }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)), enabled = !isSubmitting
            ) {
                if (isSubmitting) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                else Text("提交审核", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}
