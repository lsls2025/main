package com.aurora.chat.ui.community

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.chat.ActivityReadStateManager
import com.aurora.chat.PendingCommunityActivity
import com.aurora.chat.R
import com.aurora.chat.TcpService
import com.aurora.chat.ui.components.BadgeInfoDialog
import com.aurora.chat.ui.components.BadgeResources
import com.aurora.chat.data.api.CommunityActivity
import com.aurora.chat.data.api.UserInfo
import com.aurora.chat.data.repository.ChatRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CommunityScreen(
    onOpenSubPage: (String) -> Unit = {},
    onOpenPostDetail: (Long, String) -> Unit = { _, _ -> },
    onOpenChat: (Long, String) -> Unit = { _, _ -> }
) {
    CommunityMain(onOpenSubPage = onOpenSubPage, onOpenPostDetail = onOpenPostDetail, onOpenChat = onOpenChat)
}

@Composable
private fun CommunityMain(onOpenSubPage: (String) -> Unit, onOpenPostDetail: (Long, String) -> Unit, onOpenChat: (Long, String) -> Unit) {
    val configuration = LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val scale = (screenWidthDp / 360f).coerceIn(1f, 2f)

    val spacing = (12 * scale).dp
    val padding = (16 * scale).dp
    val topPadding = (8 * scale).dp

    val touchPos = remember { mutableStateOf<Offset?>(null) }
    val cells = remember { mutableStateListOf<HoneyCell>() }

    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val activities = remember { mutableStateListOf<CommunityActivity>() }
    var currentPage by remember { mutableStateOf(1) }
    var hasMore by remember { mutableStateOf(true) }
    var isLoadingMore by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableStateOf(0) }

    fun loadActivities(page: Int = 1, refresh: Boolean = false) {
        scope.launch {
            if (page > 1) isLoadingMore = true
            val prefs = ctx.getSharedPreferences("community_cache", Context.MODE_PRIVATE)
            try {
                val result = ChatRepository.getCommunityActivities(page = page, limit = 10)
                if (result.success && result.data != null) {
                    val newActivities = result.data.activities
                    val readIds = ActivityReadStateManager.getReadActivityIds(ctx)
                    newActivities.forEach { it.is_read = readIds.contains(it.id) }
                    if (refresh || page == 1) {
                        activities.clear()
                        currentPage = 1
                    }
                    if (newActivities.isNotEmpty()) {
                        activities.addAll(newActivities)
                        currentPage = page
                        hasMore = newActivities.size >= 10
                    }
                    // 缓存活动列表
                    try {
                        val arr = org.json.JSONArray()
                        newActivities.forEach { a ->
                            arr.put(org.json.JSONObject().apply {
                                put("id", a.id); put("user_id", a.user_id); put("username", a.username)
                                put("created_at", a.created_at); put("action_type", a.action_type)
                                put("target_id", a.target_id); put("target_title", a.target_title)
                                put("comment_content", a.comment_content)
                            })
                        }
                        val existingJson = prefs.getString("activities", null)
                        val merged = if (existingJson != null) {
                            val existing = org.json.JSONArray(existingJson)
                            val existingIds = (0 until existing.length()).map { existing.getJSONObject(it).getLong("id") }.toSet()
                            for (i in 0 until arr.length()) {
                                val item = arr.getJSONObject(i)
                                if (item.getLong("id") !in existingIds) existing.put(item)
                            }
                            existing
                        } else arr
                        prefs.edit().putString("activities", merged.toString()).commit()
                    } catch (_: Exception) {}
                }
            } catch (_: Exception) {
                // 离线时从缓存恢复
                val cached = prefs.getString("activities", null)
                if (cached != null && page == 1) {
                    try {
                        val arr = org.json.JSONArray(cached)
                        activities.clear()
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            activities.add(com.aurora.chat.data.api.CommunityActivity(
                                id = obj.getLong("id"),
                                user_id = obj.getLong("user_id"),
                                username = obj.getString("username"),
                                action_type = obj.optString("action_type", ""),
                                target_type = "",
                                target_id = obj.optLong("target_id"),
                                target_title = obj.optString("target_title", ""),
                                comment_content = obj.optString("comment_content", ""),
                                created_at = obj.optLong("created_at")
                            ))
                        }
                        hasMore = false
                    } catch (_: Exception) {}
                }
            }
            isLoadingMore = false
        }
    }

    LaunchedEffect(Unit) {
        loadActivities()
    }

    LaunchedEffect(refreshKey) {
        while (true) {
            delay(3000)
            if (PendingCommunityActivity.hasUpdate) {
                PendingCommunityActivity.hasUpdate = false
                loadActivities()
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(start = padding, end = padding, bottom = padding)) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = topPadding),
                horizontalArrangement = Arrangement.spacedBy(spacing)
            ) {
                CardVisual(
                    title = "资源",
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0xFF1E3A5F), Color(0xFF7C3AED)),
                        start = Offset.Zero,
                        end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                    ),
                    modifier = Modifier.weight(1f).aspectRatio(1f),
                    icon = { CommunityIcon(scale = scale) },
                    scale = scale
                )
                CardVisual(
                    title = "帖子",
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0xFF2563EB), Color(0xFFDB2777)),
                        start = Offset.Zero,
                        end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                    ),
                    modifier = Modifier.weight(1f).aspectRatio(1f),
                    icon = { PostIcon(scale = scale) },
                    scale = scale
                )
            }

            Box(
                modifier = Modifier
                    .matchParentSize()
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val longPressMs = viewConfiguration.longPressTimeoutMillis
                            val released = withTimeoutOrNull(longPressMs) { waitForUpOrCancellation() }

                            if (released != null) {
                                val sp = spacing.toPx()
                                val cardW = (size.width - sp) / 2f
                                if (down.position.x < cardW) onOpenSubPage("资源")
                                else onOpenSubPage("帖子")
                            } else {
                                val grid = honeycombGrid(size.width.toFloat(), size.height.toFloat())
                                cells.clear()
                                cells.addAll(grid)
                                touchPos.value = down.position
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val change = event.changes.firstOrNull() ?: break
                                    if (change.pressed) {
                                        change.consume()
                                        touchPos.value = change.position
                                    } else break
                                }
                                touchPos.value = null
                                cells.clear()
                            }
                        }
                    }
            )

            LaunchedEffect(touchPos.value) {
                if (touchPos.value == null || cells.isEmpty()) return@LaunchedEffect
                var phase = 0f
                val baseAlpha = 0.5f
                while (touchPos.value != null && cells.isNotEmpty()) {
                    phase += 0.06f
                    val fp = touchPos.value!!
                    val updated = cells.map { c ->
                        val dx = c.baseX - fp.x
                        val dy = c.baseY - fp.y
                        val dist = kotlin.math.sqrt(dx * dx + dy * dy)
                        val maxDist = 300f
                        val factor = (1f - (dist / maxDist).coerceIn(0f, 1f))
                        val glow = factor * factor
                        c.copy(
                            size = c.baseSize + glow * 16f,
                            alpha = (baseAlpha + glow * 0.45f) * (sin(phase + c.gridAngle * 4f) * 0.1f + 0.9f),
                            pulse = sin(phase * 0.5f + c.gridAngle * 2f) * 0.15f + 0.85f
                        )
                    }
                    cells.clear()
                    cells.addAll(updated)
                    delay(40)
                }
            }

            Canvas(modifier = Modifier.matchParentSize()) {
                val sp = spacing.toPx()
                val cardW = (size.width - sp) / 2f
                val cardTop = topPadding.toPx()
                val cardBottom = cardTop + cardW
                for (cardIdx in 0..1) {
                    val left = cardIdx * (cardW + sp)
                    clipRect(left = left, top = cardTop, right = left + cardW, bottom = cardBottom) {
                        cells.forEach { cell ->
                            if (cell.alpha > 0.01f) {
                                val r = cell.size * cell.pulse
                                drawCircle(Color.White.copy(alpha = cell.alpha * 0.5f), radius = r, center = Offset(cell.baseX, cell.baseY))
                                drawCircle(Color.White.copy(alpha = cell.alpha * 0.2f), radius = r * 1.6f, center = Offset(cell.baseX, cell.baseY))
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height((20 * scale).dp))

        ActivityCard(
            activities = activities,
            hasMore = hasMore,
            isLoadingMore = isLoadingMore,
            onRefresh = { loadActivities(refresh = true) },
            onLoadMore = { loadActivities(currentPage + 1) },
            onActivityClick = { activity ->
                if (activity.target_type == "post" || activity.target_type == "resource") {
                    onOpenPostDetail(activity.target_id, activity.target_type)
                }
            },
            onMarkAllRead = {
                activities.forEach { it.is_read = true }
                ActivityReadStateManager.markAllRead(ctx, activities.map { it.id })
            },
            onClearAll = {
                // 【暴力清空】必须先请求服务器删除数据库记录，再清空本地 UI
                // 不论刷新多少次都不会再出现（因为数据库里已经彻底删了）
                scope.launch {
                    try {
                        val r = ChatRepository.clearCommunityActivities()
                        if (r.success) {
                            android.widget.Toast.makeText(ctx, "已清空 ${r.data ?: 0} 条动态", android.widget.Toast.LENGTH_SHORT).show()
                        } else {
                            android.widget.Toast.makeText(ctx, "清空失败：${r.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(ctx, "清空失败：${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    // 不论服务器是否成功，都清空本地 UI 避免误显示
                    activities.clear()
                    hasMore = false
                    currentPage = 1
                }
            }
        )
    }
}

@Composable
private fun ActivityCard(
    activities: List<CommunityActivity>,
    hasMore: Boolean,
    isLoadingMore: Boolean,
    onRefresh: () -> Unit,
    onLoadMore: () -> Unit,
    onActivityClick: (CommunityActivity) -> Unit,
    onMarkAllRead: () -> Unit,
    onClearAll: () -> Unit
) {
    val configuration = LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp
    val scale = (screenWidthDp / 360f).coerceIn(1f, 2f)

    var showMarkAllReadDialog by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("最新动态", fontSize = (16 * scale).sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
            
            Row(horizontalArrangement = Arrangement.spacedBy((4 * scale).dp)) {
                IconButton(onClick = { showMarkAllReadDialog = true }) {
                    Icon(androidx.compose.material.icons.Icons.Filled.CheckCircle, contentDescription = "全部已读", tint = Color(0xFF10B981), modifier = Modifier.size((18 * scale).dp))
                }
                IconButton(onClick = { showClearDialog = true }) {
                    Icon(androidx.compose.material.icons.Icons.Filled.Delete, contentDescription = "清空", tint = Color(0xFFEF4444), modifier = Modifier.size((18 * scale).dp))
                }
                IconButton(onClick = { onRefresh() }) {
                    Icon(androidx.compose.material.icons.Icons.Default.Refresh, contentDescription = "刷新", tint = Color(0xFF1E40AF), modifier = Modifier.size((18 * scale).dp))
                }
            }
        }

        Spacer(modifier = Modifier.height((8 * scale).dp))

        if (activities.isEmpty()) {
            Text("暂无动态", fontSize = (13 * scale).sp, color = Color(0xFF9CA3AF))
        } else {
            val listState = rememberLazyListState()
            
            LaunchedEffect(listState) {
                snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index }
                    .collect { lastVisibleIndex ->
                        if (lastVisibleIndex != null && lastVisibleIndex >= activities.size - 2 && !isLoadingMore && hasMore) {
                            onLoadMore()
                        }
                    }
            }

            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy((8 * scale).dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(activities, key = { it.id }) { activity ->
                    ActivityItemText(
                        activity = activity,
                        scale = scale,
                        onClick = { 
                            activity.is_read = true
                            onActivityClick(activity) 
                        }
                    )
                }
                
                if (isLoadingMore) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding((8 * scale).dp), contentAlignment = Alignment.Center) {
                            Text("加载更多...", fontSize = (12 * scale).sp, color = Color(0xFF9CA3AF))
                        }
                    }
                } else if (!hasMore && activities.isNotEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding((8 * scale).dp), contentAlignment = Alignment.Center) {
                            Text("已加载全部", fontSize = (12 * scale).sp, color = Color(0xFF9CA3AF))
                        }
                    }
                }
            }
        }
    }

    if (showMarkAllReadDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showMarkAllReadDialog = false }) {
            androidx.compose.material3.MaterialTheme {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text("确认标记全部已读？", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("标记后所有动态的红点将消失", fontSize = 14.sp, color = Color(0xFF6B7280))
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            androidx.compose.material3.TextButton(onClick = { showMarkAllReadDialog = false }) {
                                Text("取消", fontSize = 14.sp, color = Color(0xFF6B7280))
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            androidx.compose.material3.TextButton(
                                onClick = {
                                    onMarkAllRead()
                                    showMarkAllReadDialog = false
                                },
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Text("确定", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF10B981))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showClearDialog = false }) {
            androidx.compose.material3.MaterialTheme {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text("确认清空所有动态？", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("清空后所有动态将被删除，此操作不可恢复", fontSize = 14.sp, color = Color(0xFFEF4444))
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            androidx.compose.material3.TextButton(onClick = { showClearDialog = false }) {
                                Text("取消", fontSize = 14.sp, color = Color(0xFF6B7280))
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            androidx.compose.material3.TextButton(
                                onClick = {
                                    onClearAll()
                                    showClearDialog = false
                                },
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Text("删除", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFFEF4444))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActivityItemText(
    activity: CommunityActivity,
    scale: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isRead = remember { mutableStateOf(activity.is_read) }
    val ctx = LocalContext.current

    LaunchedEffect(activity.is_read) {
        isRead.value = activity.is_read
    }
    
    val actionText = when (activity.action_type) {
        "like" -> "点赞了你发布的${if (activity.target_type == "resource") "资源" else "帖子"}"
        "comment" -> "评论了你发布的${if (activity.target_type == "resource") "资源" else "帖子"}"
        "reply" -> "回复了你的评论"
        else -> "互动了你的${if (activity.target_type == "resource") "资源" else "帖子"}"
    }

    val displayUsername = if (activity.username.isBlank()) "用户${activity.user_id}" else activity.username.take(6)
    val timeText = formatTimeAgo(activity.created_at)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape((16 * scale).dp))
            .background(Color(0xFFF3F4F6))
            .clickable { 
                if (!isRead.value) {
                    isRead.value = true
                    activity.is_read = true
                    ActivityReadStateManager.markActivityRead(ctx, activity.id)
                }
                onClick() 
            }
            .padding(horizontal = (12 * scale).dp, vertical = (10 * scale).dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!isRead.value) {
                Box(
                    modifier = Modifier
                        .size((6 * scale).dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEF4444))
                )
                Spacer(modifier = Modifier.width((10 * scale).dp))
            }
            
            Text(
                "$displayUsername$actionText",
                fontSize = (13 * scale).sp,
                color = Color(0xFF4B5563),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            
            Text(
                timeText,
                fontSize = (11 * scale).sp,
                color = Color(0xFF9CA3AF),
                modifier = Modifier.padding(start = (8 * scale).dp)
            )
        }
    }
}

private fun formatTimeAgo(timestamp: Long): String {
    if (timestamp == 0L) return ""
    val now = System.currentTimeMillis()
    val diff = now - timestamp * 1000
    
    val minute = 60 * 1000L
    val hour = 60 * minute
    val day = 24 * hour
    
    return when {
        diff < minute -> "刚刚"
        diff < hour -> "${diff / minute}分钟前"
        diff < day -> "${diff / hour}小时前"
        diff < 2 * day -> "昨天"
        diff < 7 * day -> "${diff / day}天前"
        else -> {
            val date = java.util.Date(timestamp * 1000)
            val fmt = java.text.SimpleDateFormat("MM-dd", java.util.Locale.getDefault())
            fmt.format(date)
        }
    }
}

@Composable
private fun ActivityItem(
    activity: CommunityActivity,
    scale: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape((8 * scale).dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape((8 * scale).dp))
            .clickable { onClick() }
            .padding((8 * scale).dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val iconColor = when (activity.action_type) {
            "like" -> Color(0xFFEF4444)
            "comment" -> Color(0xFF3B82F6)
            "reply" -> Color(0xFF10B981)
            else -> Color(0xFF6B7280)
        }

        Canvas(modifier = Modifier.size((24 * scale).dp)) {
            val s = size.minDimension * 0.4f
            val c = center
            when (activity.action_type) {
                "like" -> {
                    drawPath(
                        Path().apply {
                            moveTo(c.x, c.y - s)
                            cubicTo(c.x + s * 1.2f, c.y - s * 0.8f, c.x + s * 1.4f, c.y + s * 0.4f, c.x, c.y + s * 0.9f)
                            cubicTo(c.x - s * 1.4f, c.y + s * 0.4f, c.x - s * 1.2f, c.y - s * 0.8f, c.x, c.y - s)
                        },
                        iconColor
                    )
                }
                "comment" -> {
                    drawPath(
                        Path().apply {
                            moveTo(c.x - s * 0.9f, c.y - s)
                            lineTo(c.x + s * 0.9f, c.y - s)
                            lineTo(c.x + s * 0.9f, c.y + s * 0.5f)
                            lineTo(c.x + s * 0.3f, c.y + s * 0.5f)
                            lineTo(c.x - s * 0.3f, c.y + s * 0.9f)
                            lineTo(c.x - s * 0.3f, c.y + s * 0.5f)
                            lineTo(c.x - s * 0.9f, c.y + s * 0.5f)
                            close()
                        },
                        iconColor
                    )
                }
                "reply" -> {
                    drawLine(iconColor, Offset(c.x - s, c.y), Offset(c.x + s, c.y), 2.dp.toPx())
                    drawLine(iconColor, Offset(c.x - s, c.y), Offset(c.x - s * 0.5f, c.y - s * 0.5f), 2.dp.toPx())
                    drawLine(iconColor, Offset(c.x - s, c.y), Offset(c.x - s * 0.5f, c.y + s * 0.5f), 2.dp.toPx())
                }
                else -> {
                    drawCircle(iconColor, radius = s * 0.5f)
                }
            }
        }

        Spacer(modifier = Modifier.height((4 * scale).dp))

        val displayText = buildString {
            append(activity.username.take(6))
            append("\n")
            when (activity.action_type) {
                "like" -> append("点赞了")
                "comment" -> append("评论了")
                "reply" -> append("回复了")
                else -> append("互动了")
            }
        }

        Text(
            displayText,
            fontSize = (10 * scale).sp,
            color = Color(0xFF4B5563),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = (14 * scale).sp
        )
    }
}

// ===================== 纯视觉卡片（无手势） =====================

@Composable
private fun CardVisual(
    title: String,
    brush: Brush,
    modifier: Modifier = Modifier,
    icon: @Composable () -> Unit,
    scale: Float = 1f
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape((16 * scale).dp))
            .background(brush),
        contentAlignment = Alignment.BottomStart
    ) {
        Column(modifier = Modifier.padding(start = (18 * scale).dp, bottom = (18 * scale).dp)) {
            icon()
            Spacer(modifier = Modifier.height((10 * scale).dp))
            Text(title, fontSize = (20 * scale).sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

// ===================== 蜂窝粒子数据 =====================

private data class HoneyCell(
    val baseX: Float, val baseY: Float,
    val baseSize: Float,
    val gridAngle: Float,
    var size: Float = baseSize,
    var pulse: Float = 1f,
    var alpha: Float = 0.5f
)

/** 生成铺满整个卡片的六边形蜂窝网格 */
private fun honeycombGrid(maxW: Float, maxH: Float): List<HoneyCell> {
    val cells = mutableListOf<HoneyCell>()
    val hSpacing = 30f
    val vSpacing = 26f
    val baseSz = 6f
    var idx = 0
    var y = hSpacing * 0.5f
    while (y < maxH) {
        val rowOffset = if (idx % 2 == 0) 0f else hSpacing * 0.5f
        var x = rowOffset + hSpacing * 0.3f
        while (x < maxW) {
            val angle = (idx * 37 + (x / hSpacing).toInt() * 53).toFloat() * 0.01f
            cells.add(HoneyCell(baseX = x, baseY = y, baseSize = baseSz, gridAngle = angle))
            x += hSpacing
        }
        y += vSpacing
        idx++
    }
    return cells
}

@Composable
private fun CommunityIcon(scale: Float = 1f) {
    Canvas(modifier = Modifier.size((42 * scale).dp)) {
        val sw = 2.8.dp.toPx()
        val c = center
        val s = size.minDimension * 0.36f

        // 等轴测3D立方体 - 三个可见面
        // 顶面坐标
        val tx = c.x; val ty = c.y - s * 1.2f
        val tl = c.x - s * 1.1f; val tly = c.y - s * 0.5f
        val tr = c.x + s * 1.1f; val trY = c.y - s * 0.5f

        // 顶面
        val topPath = Path().apply {
            moveTo(tx, ty)
            lineTo(tl, tly)
            lineTo(c.x, c.y - s * 0.1f)
            lineTo(tr, trY)
            close()
        }
        drawPath(topPath, Color.White.copy(alpha = 0.2f))
        drawPath(topPath, Color.White, style = Stroke(width = sw))

        // 左面
        val leftPath = Path().apply {
            moveTo(tl, tly)
            lineTo(c.x, c.y - s * 0.1f)
            lineTo(c.x, c.y + s * 1.1f)
            lineTo(tl, c.y + s * 0.5f)
            close()
        }
        drawPath(leftPath, Color.White.copy(alpha = 0.35f))
        drawPath(leftPath, Color.White, style = Stroke(width = sw))

        // 右面
        val rightPath = Path().apply {
            moveTo(c.x, c.y - s * 0.1f)
            lineTo(tr, trY)
            lineTo(tr, c.y + s * 0.5f)
            lineTo(c.x, c.y + s * 1.1f)
            close()
        }
        drawPath(rightPath, Color.White.copy(alpha = 0.15f))
        drawPath(rightPath, Color.White, style = Stroke(width = sw))
    }
}

@Composable
private fun PostIcon(scale: Float = 1f) {
    Canvas(modifier = Modifier.size((36 * scale).dp)) {
        val sw = 3.dp.toPx()
        val c = center
        val w = size.width * 0.7f
        val h = size.height * 0.7f
        val left = c.x - w / 2f
        val top = c.y - h / 2f

        // 消息气泡
        val path = Path().apply {
            moveTo(left + w * 0.05f, top)
            lineTo(left + w * 0.95f, top)
            quadraticBezierTo(left + w, top, left + w, top + h * 0.08f)
            lineTo(left + w, top + h * 0.65f)
            quadraticBezierTo(left + w, top + h * 0.73f, left + w * 0.95f, top + h * 0.73f)
            lineTo(left + w * 0.35f, top + h * 0.73f)
            lineTo(left + w * 0.15f, top + h)
            lineTo(left + w * 0.15f, top + h * 0.73f)
            lineTo(left + w * 0.05f, top + h * 0.73f)
            quadraticBezierTo(left, top + h * 0.73f, left, top + h * 0.65f)
            lineTo(left, top + h * 0.08f)
            quadraticBezierTo(left, top, left + w * 0.05f, top)
            close()
        }
        drawPath(path, color = Color.White, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))

        // 三条内容线
        val lineY = top + h * 0.35f
        drawLine(Color.White, Offset(left + w * 0.15f, lineY), Offset(left + w * 0.7f, lineY), sw, StrokeCap.Round)
        drawLine(Color.White, Offset(left + w * 0.15f, lineY + h * 0.22f), Offset(left + w * 0.55f, lineY + h * 0.22f), sw, StrokeCap.Round)
        drawLine(Color.White, Offset(left + w * 0.15f, lineY + h * 0.44f), Offset(left + w * 0.4f, lineY + h * 0.44f), sw, StrokeCap.Round)
    }
}

@Composable
fun SubPage(
    title: String,
    currentUserId: Long = 0,
    onBack: () -> Unit,
    onOpenChat: (Long, String) -> Unit = { _, _ -> }
) {
    if (title == "帖子" || title == "资源") {
        val postType = if (title == "资源") "resource" else "post"
        var showCreatePost by remember { mutableStateOf(false) }
        var showPostDetail by remember { mutableStateOf(false) }
        var showProfile by remember { mutableStateOf(false) }
        var profileUserId by remember { mutableStateOf(0L) }
        var detailPostId by remember { mutableStateOf(0L) }
        var feedRefreshKey by remember { mutableStateOf(0) }
        var searchText by remember { mutableStateOf("") }
        var activeSearch by remember { mutableStateOf("") }
        val placeholder = if (postType == "resource") "搜索你需要的资源" else "搜索你感兴趣的内容"

        Box(Modifier.fillMaxSize()) {
            // 主界面：白色背景 + 搜索栏 + 列表
            Column(
                modifier = Modifier.fillMaxSize().background(Color.White).statusBarsPadding()
            ) {
                // ── 顶部：返回箭头 + 搜索框 ──
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("←", fontSize = 18.sp, color = Color(0xFF1E40AF), fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable { onBack() }.padding(end = 8.dp))
                    val interactionSource = remember { MutableInteractionSource() }
                    val isFocused by interactionSource.collectIsFocusedAsState()
                    val borderColor by androidx.compose.animation.animateColorAsState(
                        targetValue = if (isFocused) Color(0xFF1E40AF) else Color(0xFFD1D5DB),
                        animationSpec = androidx.compose.animation.core.tween(200)
                    )
                    Box(
                        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        BasicTextField(
                            value = searchText, onValueChange = { searchText = it },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp, color = Color(0xFF1F2937)),
                            singleLine = true, interactionSource = interactionSource,
                            cursorBrush = SolidColor(Color(0xFF1E40AF)),
                            keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = { activeSearch = searchText.trim() }),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                            decorationBox = { inner ->
                                Box { if (searchText.isEmpty()) Text(placeholder, fontSize = 13.sp, color = Color(0xFF9CA3AF)); inner() }
                            }
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier.height(36.dp).widthIn(min = 48.dp)
                            .clip(RoundedCornerShape(8.dp)).background(Color(0xFF1E40AF))
                            .clickable { activeSearch = searchText.trim() },
                        contentAlignment = Alignment.Center
                    ) { Text("搜索", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White) }
                }

                // 帖子/资源列表
                Box(Modifier.fillMaxSize()) {
                    CommunityPostFeed(
                        currentUserId = currentUserId,
                        postType = postType,
                        refreshTrigger = feedRefreshKey,
                        searchKeyword = activeSearch,
                        onBack = onBack,
                        onCreatePost = { showCreatePost = true },
                        onPostClick = { id -> detailPostId = id; showPostDetail = true }
                    )
                }
            }

            BackHandler(enabled = showCreatePost) { showCreatePost = false }
            BackHandler(enabled = showPostDetail && detailPostId > 0) { showPostDetail = false }
            BackHandler(enabled = showProfile && profileUserId > 0) { showProfile = false }

            // 创建帖子
            androidx.compose.animation.AnimatedVisibility(
                visible = showCreatePost,
                enter = androidx.compose.animation.slideInHorizontally(animationSpec = androidx.compose.animation.core.tween(300)) { it },
                exit = androidx.compose.animation.slideOutHorizontally(animationSpec = androidx.compose.animation.core.tween(300)) { it },
                modifier = Modifier.fillMaxSize()
            ) {
                CreatePostScreen(
                    currentUserId = currentUserId, isCommunity = postType == "resource",
                    onBack = { showCreatePost = false },
                    onPostCreated = { showCreatePost = false; feedRefreshKey++ }
                )
            }

            // 帖子详情
            androidx.compose.animation.AnimatedVisibility(
                visible = showPostDetail && detailPostId > 0,
                enter = androidx.compose.animation.slideInHorizontally(animationSpec = androidx.compose.animation.core.tween(300)) { it },
                exit = androidx.compose.animation.slideOutHorizontally(animationSpec = androidx.compose.animation.core.tween(300)) { it },
                modifier = Modifier.fillMaxSize()
            ) {
                PostDetailScreen(
                    postId = detailPostId,
                    onBack = { showPostDetail = false },
                    onUserClick = { userId -> profileUserId = userId; showProfile = true }
                )
            }

            // 用户资料（带添加好友功能）
            androidx.compose.animation.AnimatedVisibility(
                visible = showProfile && profileUserId > 0,
                enter = androidx.compose.animation.slideInHorizontally(animationSpec = androidx.compose.animation.core.tween(300)) { it },
                exit = androidx.compose.animation.slideOutHorizontally(animationSpec = androidx.compose.animation.core.tween(300)) { it },
                modifier = Modifier.fillMaxSize()
            ) {
                PostUserDetailScreen(
                    userId = profileUserId,
                    currentUserId = currentUserId,
                    onBack = { showProfile = false },
                    onOpenChat = { uid, name ->
                        showProfile = false
                        showPostDetail = false
                        onOpenChat(uid, name)
                    }
                )
            }
        }
        return
    }

    // "资源" 保留原有搜索样式
    var inputText by remember { mutableStateOf("") }
    val placeholder = "搜索你需要的资源"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color.White)
            .statusBarsPadding()
    ) {
        // ── 顶部：返回箭头 + 搜索框 + 搜索按钮 ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 返回箭头
            Text(
                text = "←",
                fontSize = 18.sp,
                color = Color(0xFF1E40AF),
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable { onBack() }.padding(end = 8.dp)
            )

            // 搜索输入框
            val interactionSource = remember { MutableInteractionSource() }
            val isFocused by interactionSource.collectIsFocusedAsState()
            val borderColor by androidx.compose.animation.animateColorAsState(
                targetValue = if (isFocused) Color(0xFF1E40AF) else Color(0xFFD1D5DB),
                animationSpec = androidx.compose.animation.core.tween(200)
            )
            Box(
                modifier = Modifier
                    .weight(1f).defaultMinSize(minHeight = 36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White, RoundedCornerShape(8.dp))
                    .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                BasicTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.sp, lineHeight = 18.sp, color = Color(0xFF1F2937)
                    ),
                    singleLine = true,
                    interactionSource = interactionSource,
                    cursorBrush = SolidColor(Color(0xFF1E40AF)),
                    decorationBox = { innerTextField ->
                        Box {
                            if (inputText.isEmpty()) Text(placeholder, fontSize = 13.sp, color = Color(0xFF9CA3AF))
                            innerTextField()
                        }
                    }
                )
            }

            Spacer(Modifier.width(8.dp))

            // 搜索按钮
            Box(
                modifier = Modifier
                    .height(36.dp).widthIn(min = 48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E40AF))
                    .clickable {
                        // TODO: 搜索逻辑
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("搜索", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White)
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── 内容区域 ──
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = "资源页面 - 开发中",
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        }
    }
}

// ==================== 从帖子详情点击用户头像/姓名跳转的资料页（带添加好友） ====================

@Composable
private fun PostUserDetailScreen(
    userId: Long,
    currentUserId: Long,
    onBack: () -> Unit,
    onOpenChat: (Long, String) -> Unit = { _, _ -> }
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var showGreeting by remember { mutableStateOf(false) }
    var userInfo by remember { mutableStateOf<UserInfo?>(null) }
    var avatarBmp by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var isFriend by remember { mutableStateOf<Boolean?>(null) }
    var badgeDialogId by remember { mutableStateOf(0) }

    // 加载用户信息
    LaunchedEffect(userId) {
        val info = ChatRepository.getUserInfo(userId)
        if (info.success && info.data != null) {
            userInfo = info.data
            val friendResult = ChatRepository.isFriend(userId)
            isFriend = friendResult.data
        }
        withContext(Dispatchers.IO) {
            avatarBmp = ChatRepository.loadAvatar(ctx, userId)
        }
    }

    if (showGreeting) {
        // 打招呼面板
        Column(
            modifier = Modifier.fillMaxSize().background(Color.White).statusBarsPadding()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E40AF), modifier = Modifier.clickable { showGreeting = false })
                Spacer(Modifier.width(12.dp))
                Text("添加好友", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
            }
            Spacer(Modifier.height(20.dp))
            val userName = userInfo?.username ?: "用户"
            Text("发送好友申请给 $userName", fontSize = 14.sp, color = Color(0xFF6B7280),
                modifier = Modifier.padding(horizontal = 24.dp))
            Spacer(Modifier.height(12.dp))
            var greeting by remember { mutableStateOf("你好，交个朋友吧！") }
            Box(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color(0xFFF9FAFB))
                    .border(1.dp, Color(0xFFD1D5DB), RoundedCornerShape(8.dp)).padding(12.dp)
            ) {
                BasicTextField(
                    value = greeting, onValueChange = { greeting = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(fontSize = 14.sp, color = Color(0xFF1F2937)),
                    cursorBrush = SolidColor(Color(0xFF1E40AF))
                )
            }
            Spacer(Modifier.height(20.dp))
            Box(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color(0xFF1E40AF))
                    .clickable {
                        val email = userInfo?.email ?: return@clickable
                        if (email.isBlank()) return@clickable
                        scope.launch {
                            val result = ChatRepository.sendFriendRequest(email, greeting.trim())
                            android.widget.Toast.makeText(ctx, result.message, android.widget.Toast.LENGTH_SHORT).show()
                            if (result.success) onBack()
                        }
                    }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("发送", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White)
            }
        }
    } else {
        // 用户资料主面板
        Column(
            modifier = Modifier.fillMaxSize().background(Color.White).statusBarsPadding().verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E40AF), modifier = Modifier.clickable { onBack() })
                Spacer(Modifier.width(12.dp))
                Text("用户资料", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
            }

            Spacer(Modifier.height(24.dp))

            // 头像 + 用户名 + 签名
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(72.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFD1D5DB)),
                    contentAlignment = Alignment.Center) {
                    if (avatarBmp != null) {
                        Image(bitmap = avatarBmp!!.asImageBitmap(), contentDescription = null,
                            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Text((userInfo?.username?.take(1) ?: "?"), fontSize = 24.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(userInfo?.username ?: "加载中...", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
                        val bi = (userInfo?.wornBadge ?: 0) - 1
                        if (bi in BadgeResources.bazaarBadgeResIds.indices) {
                            Spacer(Modifier.width(6.dp))
                            val h = if (bi == 9) 26.dp else 22.dp
                            Image(painterResource(BadgeResources.bazaarBadgeResIds[bi]), "徽章",
                                modifier = Modifier.height(h).clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() }
                                ) { badgeDialogId = userInfo?.wornBadge ?: 0 },
                                contentScale = ContentScale.FillHeight)
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    val sig = userInfo?.signature
                    if (!sig.isNullOrEmpty()) {
                        Text(sig, fontSize = 14.sp, color = Color(0xFF6B7280))
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            // ── 详细信息列表 ──
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                InfoRow("ID", "${userInfo?.id ?: userId}")
                InfoRow("QQ号", when {
                    userInfo?.hideQQ == 1 -> "该用户已隐藏 QQ 号"
                    userInfo?.qqNumber.isNullOrBlank() -> "未设置"
                    else -> userInfo?.qqNumber ?: "加载中..."
                })
                InfoRow("个性签名", userInfo?.signature ?: if (userInfo != null) "无" else "加载中...")
                if (userInfo != null && userInfo!!.createdAt > 0) {
                    val since = System.currentTimeMillis() / 1000 - userInfo!!.createdAt
                    val days = since / 86400
                    val platformText = if (days >= 1) "${days} 天" else "${since / 3600} 小时"
                    InfoRow("已在平台", platformText)
                    if (userInfo!!.lastActiveAt > 0) {
                        val diff = System.currentTimeMillis() / 1000 - userInfo!!.lastActiveAt
                        val text = when {
                            userId == currentUserId -> "在线"
                            diff < 60 -> "刚刚"
                            diff < 3600 -> "${diff / 60} 分钟前"
                            diff < 86400 -> "${diff / 3600} 小时前"
                            else -> "${diff / 86400} 天前"
                        }
                        InfoRow("上次活动", text)
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            if (isFriend == true) {
                // 已是好友：显示蓝色发消息按钮（无灰色背景）
                Box(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
                        .padding(vertical = 10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1E40AF))
                        .clickable {
                            onOpenChat(userId, userInfo?.username ?: "用户")
                        }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("发消息", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White)
                }
            } else {
                // 自己或非好友：显示灰色按钮
                Box(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
                        .clip(RoundedCornerShape(8.dp)).background(Color(0xFFF3F4F6))
                        .clickable { if (userId != currentUserId) showGreeting = true }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (userId == currentUserId) {
                        Text("自己", fontSize = 15.sp, fontWeight = FontWeight.Medium,
                            color = Color(0xFF9CA3AF))
                    } else {
                        Text("添加好友", fontSize = 15.sp, fontWeight = FontWeight.Medium,
                            color = Color(0xFF1F2937))
                    }
                }
            }
        }
    }

    // 徽章点击弹窗
    if (badgeDialogId > 0) {
        BadgeInfoDialog(badgeId = badgeDialogId, onDismiss = { badgeDialogId = 0 })
    }
}

// ==================== 信息行组件 ====================

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 14.sp, color = Color(0xFF9CA3AF), modifier = Modifier.width(80.dp))
        Text(value, fontSize = 14.sp, color = Color(0xFF1F2937))
    }
}

private fun formatRegTime(ts: Long): String {
    if (ts <= 0) return ""
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(ts * 1000))
}
