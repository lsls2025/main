package com.aurora.chat.data.store

import androidx.compose.runtime.Stable
import java.util.concurrent.CopyOnWriteArrayList
import com.aurora.chat.ui.chat.IMessageRef

/**
 * ## 消息存储适配器 — 每条对话一个实例
 *
 * 职责：
 * 1. 内部持有 [MessageStore]，管理该对话的全部消息数据
 * 2. 对外提供 [StoreMessageRef] 列表（轻量索引引用），
 *    兼容现有 `itemsIndexed` UI 代码
 * 3. 支持增量更新：只追加新消息，不清空重建
 * 4. 支持 [SnapshotStateList] 级别的同步
 *
 * ### 内存对比 (1000 条消息)
 * | 方案 | 内存 | GC 触发 |
 * |------|:----:|:-------:|
 * | ChatMsg 对象 | ~250KB + String ~100KB | **频繁** |
 * | StoreMessageRef + MessageStore | 1000×24byte + 96KB 数组 = ~120KB | **几乎零** |
 */
class MessageStoreAdapter(initialCapacity: Int = 256) {

    /** 内部存储引擎。public 以允许直接数组访问。 */
    val store = MessageStore(initialCapacity)

    /** 索引列表：[SnapshotStateList] 持有的是 store 索引，而非对象。
     *  每次有消息变化时更新此列表。 */
    private val _indices = CopyOnWriteArrayList<Int>()
    val indices: List<Int> get() = _indices

    // ==================== 状态追踪 ====================
    /** 最后一条消息的 ID，用于快速检测变化 */
    var lastMessageId: Long = 0L
        private set
    /** 最后一条消息的 flags，用于检测撤回变化 */
    var lastMessageFlags: Long = 0L
        private set
    /** 对话是否已加载过初始数据 */
    var loaded: Boolean = false
        private set

    val count: Int get() = store.count
    val visibleCount: Int get() = _indices.size

    // ================================================================
    // 写入
    // ================================================================

    /**
     * 追加单条消息。返回追加后的索引。
     * 自动维护 _indices 和 lastMessage* 状态。
     */
    fun append(
        id: Long, fromUserId: Long, toUserId: Long, content: String,
        createdAt: Long, isMine: Boolean, senderName: String = "",
        targetName: String = "", isNew: Boolean = false,
        isRevoked: Boolean = false, isSystemNotice: Boolean = false,
        isUploading: Boolean = false, flashDuration: Int = 0,
        mediaType: String = "", mediaUrl: String = "",
        replyToId: Long = 0, replyToText: String = "",
        replyToSender: String = "", wornBadge: Int = 0
    ): Int {
        val idx = store.append(
            id, fromUserId, toUserId, content, createdAt,
            isMine, senderName, targetName, isNew, isRevoked,
            isSystemNotice, isUploading, flashDuration, mediaType,
            mediaUrl, replyToId, replyToText, replyToSender, wornBadge
        )
        _indices.add(idx)
        lastMessageId = id
        lastMessageFlags = store.flagsAt(idx)
        return idx
    }

    /**
     * 批量加载（全量初始化用）。
     * 会清空 _indices，重建索引。
     * 仅当消息数量或最后消息 ID/flags 有变化时才触发。
     *
     * @return true = 数据有变化
     */
    fun loadAll(messages: List<MessageData>): Boolean {
        // 快速检测：数量或最后一条 ID+flags 是否变了
        if (loaded && messages.size == _indices.size) {
            if (messages.isNotEmpty() && _indices.isNotEmpty()) {
                val lastIdx = _indices.last()
                val last = messages.last()
                if (last.id == store.idAt(lastIdx) &&
                    last.isRevoked == store.isRevoked(lastIdx)) {
                    // 媒体字段也必须一致，否则视为有变化——
                    // 防止旧磁盘缓存里"空的 mediaUrl"被早退优化冻结成空气泡（网络刷新被整段跳过）
                    var mediaConsistent = true
                    for (i in messages.indices) {
                        if (i >= store.count) { mediaConsistent = false; break }
                        val m = messages[i]
                        if (m.mediaType != store.mediaTypeString(i) || m.mediaUrl != store.mediaUrlAt(i)) {
                            mediaConsistent = false
                            break
                        }
                    }
                    if (mediaConsistent) return false // 无变化，跳过
                }
            }
        }

        // 重建
        store.clear()
        _indices.clear()
        store.appendAll(messages)
        for (i in 0 until store.count) _indices.add(i)
        loaded = true
        if (_indices.isNotEmpty()) {
            val last = _indices.last()
            lastMessageId = store.idAt(last)
            lastMessageFlags = store.flagsAt(last)
        }
        return true
    }

    /**
     * TCP 推送后增量更新：只处理新消息和撤回事件。
     * 不触发清空重建，只追加增量。
     *
     * @param messages 来自服务端的最新消息列表（完整）
     * @param currentUserId 当前用户 ID（用于判断撤回）
     * @param currentUserName 当前用户名（用于撤回通知文本）
     * @return 是否有新消息追加
     */
    fun mergeServerMessages(
        messages: List<MessageData>,
        currentUserId: Long,
        currentUserName: String
    ): Boolean {
        if (messages.isEmpty()) return false

        // ---- 处理撤回：扫描 messages 中已撤回的，更新本地对应 flags ----
        for (msg in messages) {
            if (!msg.isRevoked) continue
            val localIdx = store.indexOf(msg.id)
            if (localIdx >= 0 && !store.isRevoked(localIdx)) {
                store.markRevoked(localIdx)
                // 追加一条系统通知消息
                val sender = if (msg.fromUserId == currentUserId) currentUserName else msg.senderName
                appendSystemNotice("$sender 撤回了一条消息")
            }
        }

        // ---- 处理新消息：只追加不在本地的 ----
        val existingIds = if (_indices.isNotEmpty()) {
            // 用最后一条消息 id 做快速检查
            val lastLocalId = store.idAt(_indices.last())
            var added = false
            for (msg in messages) {
                if (msg.id > lastLocalId && msg.id !in skipIds) {
                    val isPoke = msg.flashDuration == -1
                    val isSystemNotice = msg.isRevoked || isPoke
                    val text = when {
                        isSystemNotice && isPoke -> parsePokeText(msg, currentUserId, currentUserName)
                        isSystemNotice -> {
                            val sender = if (msg.fromUserId == currentUserId) currentUserName else msg.senderName
                            "$sender 撤回了一条消息"
                        }
                        else -> msg.content
                    }
                    append(
                        id = msg.id, fromUserId = msg.fromUserId, toUserId = msg.toUserId,
                        content = text, createdAt = msg.createdAt, isMine = msg.fromUserId == currentUserId,
                        senderName = msg.senderName, wornBadge = msg.wornBadge,
                        isRevoked = msg.isRevoked, isSystemNotice = isSystemNotice,
                        replyToId = msg.replyToId, replyToText = msg.replyToText,
                        replyToSender = msg.replyToSender, mediaType = msg.mediaType,
                        mediaUrl = msg.mediaUrl, flashDuration = msg.flashDuration
                    )
                    added = true
                }
            }
            return added
        } else {
            // 首次加载
            return loadAll(messages)
        }
    }

    /** 本地的、尚未同步到服务端的消息 ID（用于增量合并时跳过）。 */
    private val skipIds = mutableSetOf<Long>()

    /**
     * 追加本地消息（未从服务端获取 ID）。
     * 本地消息 ID 为负值或 >= 10000，与服务端消息区分。
     */
    fun appendLocal(
        localId: Long, text: String, fromUserId: Long, toUserId: Long,
        isMine: Boolean, mediaType: String = "", mediaUrl: String = "",
        flashDuration: Int = 0
    ): Int {
        skipIds.add(localId)
        return append(
            id = localId, fromUserId = fromUserId, toUserId = toUserId,
            content = text, createdAt = System.currentTimeMillis() / 1000,
            isMine = isMine, isUploading = true,
            mediaType = mediaType, mediaUrl = mediaUrl, flashDuration = flashDuration
        )
    }

    /**
     * 追加系统通知消息。
     */
    fun appendSystemNotice(text: String): Int {
        return append(
            id = System.nanoTime() and Long.MAX_VALUE,
            fromUserId = 0, toUserId = 0, content = text,
            createdAt = System.currentTimeMillis() / 1000,
            isMine = false, isSystemNotice = true
        )
    }

    /** 将本地消息的 ID 替换为服务端 ID（发送成功回调时调用）。 */
    fun replaceLocalId(localId: Long, serverId: Long) {
        skipIds.remove(localId)
        val idx = store.indexOf(localId)
        if (idx >= 0) {
            // 直接修改数组，不触发重组 — StoreMessageRef 通过 idAt 读取
            // 但 indices 不需要变，因为 id 变化不会影响顺序
            // 用法：在 SnapshotStateList 中更新对应的 StoreMessageRef
            // 由于 StoreMessageRef.id 是从 store.idAt 读取的，所以立即可见
            // 只需要更新 store 中的 id
            // 其实我们可以直接写：store.ids[idx] = serverId
            // 但 ids 是 private，需要通过反射或增加一个 visibleForTesting 方法
            // 最好在 MessageStore 里加一个 setter
            store.updateId(idx, serverId)
        }
    }

    /** 标记消息为上传完成。 */
    fun markUploaded(localId: Long, serverId: Long) {
        val idx = store.indexOf(localId)
        if (idx >= 0) {
            store.markUploading(idx, false)
            store.updateId(idx, serverId)
        }
    }

    /** 标记消息为已撤回。 */
    fun markRevoked(messageId: Long, senderName: String, currentUserName: String) {
        val idx = store.indexOf(messageId)
        if (idx >= 0) {
            store.markRevoked(idx)
            appendSystemNotice("$senderName 撤回了一条消息")
        }
    }

    // ================================================================
    // 读取
    // ================================================================

    /** 获取第 k 条可见消息的引用。 */
    fun refAt(visibleIndex: Int): StoreMessageRef {
        return StoreMessageRef(store, _indices[visibleIndex])
    }

    /** 清空所有数据。 */
    fun clear() {
        store.clear()
        _indices.clear()
        skipIds.clear()
        loaded = false
        lastMessageId = 0L
        lastMessageFlags = 0L
    }

    // ==================== 内部工具 ====================

    private fun parsePokeText(msg: MessageData, currentUserId: Long, currentUserName: String): String {
        return if (msg.fromUserId == currentUserId)
            "你拍了拍${msg.targetName.ifEmpty { msg.senderName }}"
        else
            "${msg.senderName}拍了拍${if (msg.toUserId == currentUserId) "你" else msg.targetName}"
    }
}

/**
 * ## 轻量消息引用 — 替代 ChatMsg 对象
 *
 * 不持有任何 String 数据，所有属性从 [MessageStore] 的原始数组读取。
 *
 * 内存占用：2 个引用 + 1 个 int = **~24 bytes**
 * 对比 ChatMsg：**~200-300 bytes** + 多个 String
 *
 * 使用 `@Stable` 标记确保 Compose 编译器信任其相等性，
 * 避免因 data class copy 导致的不必要重组。
 */
@Stable
class StoreMessageRef(
    internal val store: MessageStore,
    internal val index: Int
) : IMessageRef {
    override val id: Long get() = store.idAt(index)
    override val text: String get() = store.contentAt(index)
    override val isMine: Boolean get() = store.isMine(index)
    override val fromUserId: Long get() = store.fromUidAt(index)
    override val senderName: String get() = store.senderNameAt(index)
    override val wornBadge: Int get() = store.wornBadge(index)
    override val time: Long get() = System.currentTimeMillis()
    override val isNew: Boolean get() = store.isNew(index)
    override val createdAt: Long get() = store.timestampAt(index)
    override val isRevoked: Int get() = if (store.isRevoked(index)) 1 else 0
    override val isSystemNotice: Boolean get() = store.isSystemNotice(index)
    override val replyToText: String get() = store.replyToTextAt(index)
    override val replyToSender: String get() = store.replyToSenderAt(index)
    override val replyToId: Long get() = store.replyToIdAt(index)
    override val mediaType: String get() = store.mediaTypeString(index)
    override val mediaUrl: String get() = store.mediaUrlAt(index)
    override val isUploading: Boolean get() = store.isUploading(index)
    override val toUserId: Long get() = store.toUidAt(index)
    override val targetName: String get() = store.targetNameAt(index)
    override val flashDuration: Int get() = store.flashDuration(index)

    /** 系统通知是否因撤回。 */
    val isRecallNotice: Boolean get() = isSystemNotice && isRevoked == 1

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        return other is StoreMessageRef && other.store === store && other.index == index
    }

    override fun hashCode(): Int = index
}
