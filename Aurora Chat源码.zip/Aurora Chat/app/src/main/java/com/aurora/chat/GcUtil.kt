package com.aurora.chat

/**
 * ## 极简 GC 工具 — 在用户无感知的窗口主动清扫垃圾
 *
 * 原理：Android 的 GC 在堆压力大时会产生 "Stop-The-World" 暂停，
 * 表现为帧率抖动。在已知的空闲窗口主动触发 GC，把暂停时间转移到
 * 用户不会感知到的时刻。
 *
 * ### 安全窗口
 * - App 进入后台 → `gcNow()` 最多执行 3 轮
 * - 离开对话屏幕 → `gcNow()` 1 轮
 * - 发送完图片/文件后 → `gcNow()` 1 轮（图片解码和压缩产生大量短期对象）
 */
object GcUtil {
    private var lastGcMs = 0L
    private const val MIN_INTERVAL_MS = 2000L  // 2 秒内不重复触发

    /** 立即触发 GC，最多重试 [rounds] 轮（默认 1 轮）。 */
    @JvmStatic
    fun gcNow(rounds: Int = 1) {
        val now = System.currentTimeMillis()
        if (now - lastGcMs < MIN_INTERVAL_MS) return
        lastGcMs = now
        // 多轮 GC 可以更彻底地回收跨代引用
        repeat(rounds) { System.gc() }
    }

    /** App 进入后台时的深度清扫（3 轮）。 */
    @JvmStatic
    fun gcOnBackground() {
        gcNow(rounds = 3)
    }
}
