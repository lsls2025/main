# Default ProGuard rules
-keep class com.aurora.chat.** { *; }
