package main

import (
	"bytes"
	crand "crypto/rand"
	"database/sql"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"log"
	"math/big"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/bcrypt"
)

// API 统一响应格式
type ApiResponse struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Data    interface{} `json:"data,omitempty"`
}

// 登录响应
type LoginResponse struct {
	ID                     int64  `json:"id"`
	Email                  string `json:"email"`
	Username               string `json:"username"`
	Signature              string `json:"signature"`
	Token                  string `json:"token"`
	EmailVerified          bool   `json:"email_verified"`
	NeedsProfileCompletion bool   `json:"needs_profile_completion"`
	QQNumber               string `json:"qq_number"`
}

// needsProfileCompletion 判断用户是否需要完善资料
// 满足任一条件即为 true：占位符邮箱、QQ 号为空、用户名为空
func needsProfileCompletion(user *User) bool {
	if strings.HasPrefix(user.Email, "qq_") || strings.HasPrefix(user.Email, "temp_") {
		return true
	}
	if user.QQNumber == "" {
		return true
	}
	if user.Username == "" {
		return true
	}
	return false
}

func writeJSON(w http.ResponseWriter, code int, msg string, data interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(ApiResponse{
		Code:    code,
		Message: msg,
		Data:    data,
	})
}

// checkDevPermission 检查是否为开发者
func checkDevPermission(r *http.Request) bool {
	return isDeveloperUser(getCurrentUserID(r))
}

// checkAdminOrDevPermission 检查是否为平台管理员或开发者
func checkAdminOrDevPermission(r *http.Request) (int64, bool) {
	userID := getCurrentUserID(r)
	if userID <= 0 {
		return 0, false
	}
	if checkDevPermission(r) {
		return userID, true
	}
	isAdmin, err := isPlatformAdmin(userID)
	if err != nil {
		return 0, false
	}
	return userID, isAdmin
}

// checkAdminPermission 通用管理权限检查（含细粒度权限）
// 返回值: userID, 是否有权限
//   - 开发者永远有权限
//   - 平台管理员需要拥有对应的 permKey 细粒度权限（或没有权限记录时视为有全部权限）
func checkAdminPermission(r *http.Request, permKey string) (int64, bool) {
	userID := getCurrentUserID(r)
	if userID <= 0 {
		return 0, false
	}
	if checkDevPermission(r) {
		return userID, true
	}
	ok, _ := isPlatformAdmin(userID)
	if !ok {
		return 0, false
	}
	if checkUserPermission(userID, permKey) {
		return userID, true
	}
	return 0, false
}

// checkDevOrPerm 检查是否有开发者权限，或平台管理员拥有指定细粒度权限
func checkDevOrPerm(r *http.Request, permKey string) bool {
	if checkDevPermission(r) {
		return true
	}
	userID := getCurrentUserID(r)
	ok, _ := isPlatformAdmin(userID)
	return ok && checkUserPermission(userID, permKey)
}

var emailRegex = regexp.MustCompile(`^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`)

// ==================== 健康检查 ====================

func handleHealth(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":  "ok",
		"service": "Aurora Chat",
		"version": "2.0",
		"time":    time.Now().Unix(),
	})
}

// ==================== APP 版本检查（强制更新） ====================

// 当前最新版本配置（发布新版时更新这里，或在 version.txt 中修改）
var (
	LatestVersionCode = 17 // 发布新版时改成 build.gradle.kts 里的 versionCode
	LatestVersionName = "1.7.0"
	DownloadURL       = "" // APK 下载地址，为空时自动使用 getServerBaseURL() + "/tools/aurora.apk"
	ForceUpdate       = true                                               // 发布新版时改成 true
	UpdateMessage     = "发现新版本，请更新后继续使用。"
)

// GET /api/app/version — 获取最新版本信息（无需登录）
func handleAppVersion(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"code": 200,
		"data": map[string]interface{}{
			"latest_version_code": LatestVersionCode,
			"latest_version_name": LatestVersionName,
			"download_url":        DownloadURL,
			"force_update":        ForceUpdate,
			"update_message":      UpdateMessage,
		},
	})
}

// ==================== 发送验证码 ====================

func handleSendCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	var req struct {
		Email         string `json:"email"`
		CaptchaID     string `json:"captcha_id"`
		CaptchaAnswer string `json:"captcha_answer"`
		Captcha       string `json:"captcha"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}

	// 已移除图形验证码闸门：人机/防刷由"注册必须携带设备指纹 + 发起冷却/频限"承担

	req.Email = strings.TrimSpace(req.Email)
	if req.Email == "" {
		writeJSON(w, 400, "请输入邮箱/用户名/QQ号", nil)
		return
	}

	// 如果不是邮箱格式，则按用户名或 QQ 号反查关联邮箱（兼容旧版邮箱用户找回密码）
	if !emailRegex.MatchString(req.Email) {
		var resolvedEmail string
		if isDigitsOnly(req.Email) {
			if u, _ := findUserByQQNumber(req.Email); u != nil && u.Email != "" && !strings.HasPrefix(u.Email, "qq_") && !strings.HasSuffix(u.Email, "@local") {
				resolvedEmail = u.Email
			}
		} else {
			if u, _ := findUserByUsername(req.Email); u != nil && u.Email != "" && !strings.HasPrefix(u.Email, "qq_") && !strings.HasSuffix(u.Email, "@local") {
				resolvedEmail = u.Email
			}
		}
		if resolvedEmail == "" {
			writeJSON(w, 400, "该账号未绑定邮箱，无法发送验证码", nil)
			return
		}
		req.Email = resolvedEmail
	}


	// 检查是否已被注册
	registered, err := isEmailRegistered(req.Email)
	if err != nil {
		log.Printf("检查邮箱失败: %v", err)
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	if registered {
		writeJSON(w, 409, "该邮箱已被注册", nil)
		return
	}

	// 检查冷却
	ok, wait := checkCodeCoolDown(req.Email)
	if !ok {
		writeJSON(w, 429, fmt.Sprintf("发送过于频繁，请 %d 秒后再试", wait), nil)
		return
	}

	// 生成并保存验证码
	code := generateCode()
	if err := saveVerificationCode(req.Email, code); err != nil {
		log.Printf("保存验证码失败: %v", err)
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}

	// 发送验证码（同步发送，失败则重试，确保用户真正收到邮件后才返回成功）
	var (
		emailSent bool
		emailMsg  string
	)
	for attempt := 0; attempt < 3; attempt++ {
		if attempt > 0 {
			time.Sleep(2 * time.Second)
		}
		emailSent, emailMsg = sendEmailCode(req.Email, code)
		if emailSent {
			break
		}
		log.Printf("[验证码] 第 %d 次发送失败: %s -> %s (%s)", attempt+1, req.Email, code, emailMsg)
	}
	if !emailSent {
		log.Printf("[验证码] 3 次重试均失败: %s", req.Email)
		writeJSON(w, 500, "邮件发送失败，请稍后重试或联系管理员", nil)
		return
	}

	recordCodeSent(req.Email)
	log.Printf("验证码已发送: %s -> %s", req.Email, code)
	writeJSON(w, 200, "验证码已发送至邮箱", nil)
}

// ==================== 注册 ====================

func handleRegister(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	// 抵防：禁止注册 —— 开启后直接切断所有注册请求
	if getFlag("disable_register") {
		writeJSON(w, 403, "注册功能已临时关闭，请稍后再试", nil)
		return
	}

	var req struct {
		Email         string `json:"email"`
		Username      string `json:"username"`
		Password      string `json:"password"`
		Code          string `json:"code"`
		QQNumber      string `json:"qq_number"`
		DeviceID      string `json:"device_id"`
		CaptchaID     string `json:"captcha_id"`
		CaptchaAnswer string `json:"captcha_answer"`
		Captcha       string `json:"captcha"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}

	// 防脚本注册：任何注册请求必须携带真实设备指纹。
	// 设备指纹由客户端本地硬件/标识生成，纯 API 调用方拿不到合法指纹，
	// 缺失即视为非法接口调用，直接拒绝且不返回细节。
	req.DeviceID = strings.TrimSpace(req.DeviceID)
	if req.DeviceID == "" {
		writeJSON(w, 403, "非法请求", nil)
		return
	}

	// 单设备永久账号上限（防批量小号）
	if n, err := count_accounts_by_device(req.DeviceID); err == nil && n >= MAX_ACCOUNTS_PER_DEVICE {
		writeJSON(w, 429, fmt.Sprintf("当前设备最多可注册 %d 个账号，已达上限", MAX_ACCOUNTS_PER_DEVICE), nil)
		return
	}

	req.Email = strings.TrimSpace(req.Email)
	req.Username = html.EscapeString(strings.TrimSpace(req.Username))
	req.Code = strings.TrimSpace(req.Code)
	req.QQNumber = strings.TrimSpace(req.QQNumber)

	// 用户名和密码必填
	if req.Username == "" || req.Password == "" {
		writeJSON(w, 400, "请填写用户名和密码", nil)
		return
	}
	// 校验 QQ 号格式（如有）
	if req.QQNumber != "" && !isDigitsOnly(req.QQNumber) {
		writeJSON(w, 400, "QQ 号格式不正确", nil)
		return
	}

	// IP 频率限制 + 黑名单检查
	clientIP := getClientIP(r)
	if blocked, _ := isIPBlocked(clientIP); blocked {
		writeJSON(w, 403, "该 IP 已被封禁，无法注册", nil)
		return
	}
	if allowed, wait := checkRegisterRateLimit(clientIP); !allowed {
		writeJSON(w, 429, fmt.Sprintf("注册过于频繁，请在 %d 秒后再试", wait), nil)
		return
	}
	if len(req.Username) < 2 || len(req.Username) > 20 {
		writeJSON(w, 400, "用户名长度应在 2-20 个字符之间", nil)
		return
	}
	if len(req.Password) < 8 {
		writeJSON(w, 400, "密码不能少于 8 位", nil)
		return
	}

	hasVerifiedEmail := false

	if req.Email != "" {
		// 有邮箱 → 需要验证码
		if !emailRegex.MatchString(req.Email) {
			writeJSON(w, 400, "邮箱格式不正确", nil)
			return
		}
		if len(req.Code) != 6 {
			writeJSON(w, 400, "验证码格式不正确", nil)
			return
		}
		registered, err := isEmailRegistered(req.Email)
		if err != nil {
			writeJSON(w, 500, "服务器内部错误", nil)
			return
		}
		if registered {
			writeJSON(w, 409, "该邮箱已被注册", nil)
			return
		}
		if !verifyCode(req.Email, req.Code) {
			writeJSON(w, 400, "验证码错误或已过期", nil)
			return
		}
		hasVerifiedEmail = true
		deleteVerificationCode(req.Email)
	}

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}

	ev := 0
	if hasVerifiedEmail {
		ev = 1
	}
	userID, err := createUser(req.Email, req.Username, string(hashedPassword), clientIP, ev)
	if err != nil {
		writeJSON(w, 500, "注册失败，请稍后重试", nil)
		return
	}
	if req.DeviceID != "" {
		db.Exec("UPDATE users SET reg_device = ? WHERE id = ?", req.DeviceID, userID)
	}
	if req.QQNumber != "" {
		db.Exec("UPDATE users SET qq_number = ? WHERE id = ?", req.QQNumber, userID)
	}

	db.Exec("UPDATE users SET token_version = 1 WHERE id = ?", userID)

	userEmail := req.Email
	if userEmail == "" {
		userEmail = fmt.Sprintf("temp_%d@local", userID)
	}
	token, _ := generateToken(userID, userEmail, 1)

	log.Printf("新用户注册成功: ID=%d, Username=%s (邮箱验证=%v)", userID, req.Username, hasVerifiedEmail)
	writeJSON(w, 200, "注册成功", LoginResponse{
		ID:            userID,
		Email:         userEmail,
		Username:      req.Username,
		Signature:     "",
		Token:         token,
		EmailVerified: hasVerifiedEmail,
	})
}

// ==================== 绑定邮箱 ====================

// POST /api/user/bind-email/send-code — 发送绑定邮箱验证码
func handleSendBindCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	currentUserID := getCurrentUserID(r)
	if currentUserID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		Email string `json:"email"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	req.Email = strings.TrimSpace(req.Email)
	if req.Email == "" || !emailRegex.MatchString(req.Email) {
		writeJSON(w, 400, "邮箱格式不正确", nil)
		return
	}
	// 检查邮箱是否已被其他用户绑定
	existing, _ := findUserByEmail(req.Email)
	if existing != nil && existing.ID != currentUserID {
		writeJSON(w, 409, "该邮箱已被其他账号绑定", nil)
		return
	}
	ok, wait := checkCodeCoolDown(req.Email)
	if !ok {
		writeJSON(w, 429, fmt.Sprintf("发送过于频繁，请 %d 秒后再试", wait), nil)
		return
	}
	code := generateCode()
	if err := saveVerificationCode(req.Email, code); err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	success, msg := sendEmailCode(req.Email, code)
	if !success {
		writeJSON(w, 500, msg, nil)
		return
	}
	recordCodeSent(req.Email)
	log.Printf("绑定邮箱验证码已发送: %s -> %s", req.Email, code)
	writeJSON(w, 200, "验证码已发送", nil)
}

// POST /api/user/bind-email — 绑定并验证邮箱
func handleBindEmail(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	currentUserID := getCurrentUserID(r)
	if currentUserID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		Email string `json:"email"`
		Code  string `json:"code"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	req.Email = strings.TrimSpace(req.Email)
	req.Code = strings.TrimSpace(req.Code)
	if req.Email == "" || req.Code == "" {
		writeJSON(w, 400, "请填写邮箱和验证码", nil)
		return
	}
	if !emailRegex.MatchString(req.Email) {
		writeJSON(w, 400, "邮箱格式不正确", nil)
		return
	}
	if len(req.Code) != 6 {
		writeJSON(w, 400, "验证码格式不正确", nil)
		return
	}
	// 检查邮箱是否已被其他用户绑定
	existing, _ := findUserByEmail(req.Email)
	if existing != nil && existing.ID != currentUserID {
		writeJSON(w, 409, "该邮箱已被其他账号绑定", nil)
		return
	}
	if !verifyCode(req.Email, req.Code) {
		writeJSON(w, 400, "验证码错误或已过期", nil)
		return
	}
	deleteVerificationCode(req.Email)

	// 更新用户邮箱和验证状态
	if err := updateUserEmail(currentUserID, req.Email); err != nil {
		log.Printf("绑定邮箱失败: user=%d email=%s err=%v", currentUserID, req.Email, err)
		writeJSON(w, 500, "绑定失败", nil)
		return
	}
	log.Printf("用户绑定邮箱成功: ID=%d, Email=%s", currentUserID, req.Email)
	writeJSON(w, 200, "邮箱绑定成功", nil)
}

// ==================== 登录 ====================

func handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	var req struct {
		Email    string `json:"email"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}

	req.Email = strings.TrimSpace(req.Email)
	if req.Email == "" || req.Password == "" {
		writeJSON(w, 400, "请填写用户名/邮箱/QQ号和密码", nil)
		return
	}
	if len(req.Password) < 8 {
		writeJSON(w, 400, "密码不能少于 8 位", nil)
		return
	}

	// 支持邮箱 / 用户名 / QQ 号登录
	var user *User
	var err error
	if emailRegex.MatchString(req.Email) {
		user, err = findUserByEmail(req.Email)
	} else if isDigitsOnly(req.Email) {
		user, err = findUserByQQNumber(req.Email)
	} else {
		user, err = findUserByUsername(req.Email)
	}
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	if user == nil || bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)) != nil {
		writeJSON(w, 401, "用户名/邮箱/QQ号或密码错误", nil)
		return
	}

	// 清除 kicked_at 标记（用户重新登录后不再显示"已被踢出"提示）
	db.Exec("UPDATE users SET kicked_at = 0 WHERE id = ?", user.ID)
	var currentVersion int64
	db.QueryRow("SELECT token_version FROM users WHERE id = ?", user.ID).Scan(&currentVersion)

	// 生成 JWT token
	token, _ := generateToken(user.ID, user.Email, currentVersion)

	// 更新最近活动时间
	now := time.Now().Unix()
	db.Exec("UPDATE users SET updated_at = ? WHERE id = ?", now, user.ID)
	user.UpdatedAt = now

	log.Printf("用户登录成功: Email=%s, Username=%s", user.Email, user.Username)
	writeJSON(w, 200, "登录成功", LoginResponse{
		ID:                     user.ID,
		Email:                  user.Email,
		Username:               user.Username,
		Signature:              user.Signature,
		Token:                  token,
		EmailVerified:          user.EmailVerified == 1,
		NeedsProfileCompletion: needsProfileCompletion(user),
		QQNumber:               user.QQNumber,
	})
}

// ==================== 完善资料（防重复建号，仅 UPDATE） ====================

func handleCompleteProfile(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	// 1. 从 token 获取当前用户
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未授权", nil)
		return
	}

	// 2. 解析请求体
	var req struct {
		Username string `json:"username"`
		QQNumber string `json:"qq_number"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	req.Username = html.EscapeString(strings.TrimSpace(req.Username))
	req.QQNumber = strings.TrimSpace(req.QQNumber)

	// 3. 校验必填字段
	if req.Username == "" {
		writeJSON(w, 400, "用户名不能为空", nil)
		return
	}
	if req.QQNumber == "" || !isDigitsOnly(req.QQNumber) {
		writeJSON(w, 400, "请输入有效的QQ号", nil)
		return
	}

	// 4. 核心：检查 QQ 号是否已被其他用户占用
	existing, _ := findUserByQQNumber(req.QQNumber)
	if existing != nil && existing.ID != userID {
		writeJSON(w, 409, "该QQ号已被其他账号绑定", nil)
		return
	}

	// 5. 更新当前用户记录（只 UPDATE，不 INSERT）
	now := time.Now().Unix()
	if req.Password != "" {
		hashed, _ := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
		db.Exec("UPDATE users SET username=?, qq_number=?, password=?, updated_at=? WHERE id=?",
			req.Username, req.QQNumber, string(hashed), now, userID)
	} else {
		db.Exec("UPDATE users SET username=?, qq_number=?, updated_at=? WHERE id=?",
			req.Username, req.QQNumber, now, userID)
	}

	// 6. 重新生成 token（资料变了，刷新 token）
	var newVersion int64
	db.QueryRow("SELECT token_version FROM users WHERE id = ?", userID).Scan(&newVersion)
	user, _ := findUserByID(userID)
	if user == nil {
		writeJSON(w, 500, "用户不存在", nil)
		return
	}
	newToken, _ := generateToken(userID, user.Email, newVersion)

	// 7. 返回新 token
	writeJSON(w, 200, "资料完善成功", LoginResponse{
		ID:                     user.ID,
		Email:                  user.Email,
		Username:               req.Username,
		Signature:              user.Signature,
		Token:                  newToken,
		EmailVerified:          user.EmailVerified == 1,
		NeedsProfileCompletion: false,
		QQNumber:               user.QQNumber,
	})
}

// ==================== 用户自主注销 ====================

func handleSelfDeleteUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID <= 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	if req.Password == "" {
		writeJSON(w, 400, "请输入密码", nil)
		return
	}
	// 验证密码
	user, err := findUserByID(userID)
	if err != nil || user == nil {
		writeJSON(w, 500, "用户不存在", nil)
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)) != nil {
		writeJSON(w, 401, "密码错误", nil)
		return
	}
	// 删除账号数据
	if err := deleteUserAllData(userID); err != nil {
		log.Printf("[注销] 用户 %d 注销失败: %v", userID, err)
		writeJSON(w, 500, "注销失败: "+err.Error(), nil)
		return
	}
	log.Printf("[注销] 用户 %d 已成功注销", userID)
	writeJSON(w, 200, "账号已注销", nil)
}

// ==================== 密码重置 ====================

func handleResetPassword(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	var req struct {
		Email       string `json:"email"`
		Code        string `json:"code"`
		NewPassword string `json:"new_password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}

	req.Email = strings.TrimSpace(req.Email)
	req.Code = strings.TrimSpace(req.Code)

	if req.Email == "" || req.Code == "" || req.NewPassword == "" {
		writeJSON(w, 400, "请填写所有字段", nil)
		return
	}
	if !emailRegex.MatchString(req.Email) {
		writeJSON(w, 400, "邮箱格式不正确", nil)
		return
	}
	if len(req.NewPassword) < 8 {
		writeJSON(w, 400, "密码不能少于 8 位", nil)
		return
	}

	// 验证用户存在
	user, err := findUserByEmail(req.Email)
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	if user == nil {
		writeJSON(w, 404, "该邮箱未注册", nil)
		return
	}

	// 验证验证码
	if !verifyCode(req.Email, req.Code) {
		writeJSON(w, 400, "验证码错误或已过期", nil)
		return
	}

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}

	if err := updatePassword(user.ID, string(hashedPassword)); err != nil {
		writeJSON(w, 500, "重置密码失败", nil)
		return
	}

	deleteVerificationCode(req.Email)
	log.Printf("密码重置成功: Email=%s", req.Email)
	writeJSON(w, 200, "密码重置成功", nil)
}

// ==================== 获取所有用户（开发者管理） ====================

func handleGetUsers(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}

	// 开发者或平台管理员均可查看用户列表
	_, ok := checkAdminPermission(r, "users.view_profile")
	if !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	users, err := getAllUsers()
	if err != nil {
		log.Printf("获取用户列表失败: %v", err)
		writeJSON(w, 500, "获取用户列表失败", nil)
		return
	}
	if users == nil {
		users = []User{}
	}
	writeJSON(w, 200, "获取成功", users)
}

// POST /api/user/privacy — 用户隐私设置
func handleUserPrivacy(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}

	var req struct {
		HideEmail *bool `json:"hide_email"`
		HideQQ    *bool `json:"hide_qq"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数格式错误", nil)
		return
	}

	if req.HideEmail != nil {
		val := 0
		if *req.HideEmail {
			val = 1
		}
		if _, err := db.Exec("UPDATE users SET hide_email = ? WHERE id = ?", val, userID); err != nil {
			writeJSON(w, 500, "设置失败", nil)
			return
		}
		log.Printf("用户 %d 隐私设置: hide_email=%d", userID, val)
	}
	if req.HideQQ != nil {
		val := 0
		if *req.HideQQ {
			val = 1
		}
		if _, err := db.Exec("UPDATE users SET hide_qq = ? WHERE id = ?", val, userID); err != nil {
			writeJSON(w, 500, "设置失败", nil)
			return
		}
		log.Printf("用户 %d 隐私设置: hide_qq=%d", userID, val)
	}

	var hideEmail, hideQQ int
	db.QueryRow("SELECT hide_email, hide_qq FROM users WHERE id = ?", userID).Scan(&hideEmail, &hideQQ)
	writeJSON(w, 200, "设置成功", map[string]bool{"hide_email": hideEmail == 1, "hide_qq": hideQQ == 1})
}

// POST /api/user/update — 更新用户名和签名
func handleUpdateProfile(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未授权", nil)
		return
	}
	var body struct {
		Username  string `json:"username"`
		Signature string `json:"signature"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	if len(body.Username) > 50 {
		writeJSON(w, 400, "用户名过长", nil)
		return
	}
	if len(body.Signature) > 200 {
		writeJSON(w, 400, "签名过长", nil)
		return
	}
	now := time.Now().Unix()
	_, err := db.Exec("UPDATE users SET username = ?, signature = ?, updated_at = ? WHERE id = ?",
		body.Username, body.Signature, now, userID)
	if err != nil {
		writeJSON(w, 500, "更新失败", nil)
		return
	}
	writeJSON(w, 200, "更新成功", nil)
}

// POST /api/user/signature — 更新用户个性签名
func handleUpdateSignature(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未授权", nil)
		return
	}
	var body struct {
		Signature string `json:"signature"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	if len(body.Signature) > 200 {
		writeJSON(w, 400, "签名过长（最多200字符）", nil)
		return
	}
	now := time.Now().Unix()
	_, err := db.Exec("UPDATE users SET signature = ?, updated_at = ? WHERE id = ?", body.Signature, now, userID)
	if err != nil {
		writeJSON(w, 500, "更新失败", nil)
		return
	}
	writeJSON(w, 200, "更新成功", nil)
}

// POST /api/user/stats — 同步用户在线时间和发言次数
func handleSyncUserStats(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未授权", nil)
		return
	}
	var body struct {
		OnlineTimeSeconds int64 `json:"online_time_seconds"`
		WordCount         int64 `json:"word_count"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	if err := updateUserStats(userID, body.OnlineTimeSeconds, body.WordCount); err != nil {
		log.Printf("[sync] 更新用户统计失败: userID=%d, err=%v", userID, err)
		writeJSON(w, 500, "同步失败", nil)
		return
	}
	writeJSON(w, 200, "同步成功", nil)
}

// GET /api/user/{userId} — 获取用户基本信息（公开）
func handleGetUserByID(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	// 排除 /api/user/privacy 子路径
	path := strings.TrimPrefix(r.URL.Path, "/api/user/")
	if path == "privacy" || path == "" {
		http.NotFound(w, r)
		return
	}

	// GET /api/user/check-exists?userId=xxx — 安全验证：该用户是否存在于数据库中
	if path == "check-exists" {
		checkUserIDStr := r.URL.Query().Get("userId")
		if checkUserIDStr == "" {
			writeJSON(w, 400, "缺少 userId 参数", nil)
			return
		}
		checkUserID, err := strconv.ParseInt(checkUserIDStr, 10, 64)
		if err != nil {
			writeJSON(w, 400, "userId 格式错误", nil)
			return
		}
		user, err := findUserByID(checkUserID)
		if err != nil {
			writeJSON(w, 500, "服务器错误", nil)
			return
		}
		writeJSON(w, 200, "ok", map[string]bool{"exists": user != nil})
		return
	}

	userID, err := strconv.ParseInt(path, 10, 64)
	if err != nil {
		writeJSON(w, 400, "用户ID格式错误", nil)
		return
	}
	user, err := findUserByID(userID)
	if err != nil {
		writeJSON(w, 500, "服务器错误", nil)
		return
	}
	if user == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}

	// ============ 隐私脱敏：他人查看时隐藏 email/qq/注册IP ============
	currentID := getCurrentUserID(r)
	isSelf := currentID == user.ID
	isDev := isDeveloperUser(currentID)

	email := user.Email
	qqNum := user.QQNumber
	regIP := user.RegIp
	if !isSelf && !isDev {
		// 尊重用户隐私开关：hide_email/hide_qq 时为掩码；注册IP一律不暴露给非本人
		if user.HideEmail != 0 {
			email = maskEmail(email)
		}
		if user.HideQQ != 0 {
			qqNum = maskQQ(qqNum)
		}
		regIP = ""
	}

	writeJSON(w, 200, "获取成功", map[string]interface{}{
		"id":                  user.ID,
		"email":               email,
		"username":            user.Username,
		"qq_number":           qqNum,
		"hide_qq":             user.HideQQ,
		"created_at":          user.CreatedAt,
		"updated_at":          user.UpdatedAt,
		"hide_email":          user.HideEmail,
		"signature":           user.Signature,
		"online_time_seconds": user.OnlineTimeSeconds,
		"word_count":          user.WordCount,
		"worn_badge":          user.WornBadge,
		"token_version":       user.TokenVersion,
		"email_verified":      user.EmailVerified != 0,
		"reg_ip":              regIP,
		"member_level":        user.MemberLevel,
		"member_expires_at":   user.MemberExpiresAt,
		"token_balance":       user.TokenBalance,
	})
}

// ==================== 二维码（扫码加好友） ====================
//
// 二维码内容包含两个独立信息：
//  1. 官网落地页 https://example.com/q.html —— APP 外扫码（QQ/微信/相机/浏览器）
//     打开落地页，页面展示被扫码者的头像/昵称，并可引导去官网下载或在 App 内扫码加好友；
//  2. 用户 ID（一个纯数字）—— 通过 URL 的 query 参数 ?u=<id> 携带，供落地页 / App 内扫码解析。
//
// 格式：<官网>/q.html?u=<用户ID>
// 落地页仅展示公开的无害信息；真正的加好友动作必须由已登录的 APP 内扫码触发
// （调 /api/user/qrcode/resolve），外部扫码只能看到落地页，天然安全。

// 官网落地页域名（用于二维码扫码跳转），可通过 QR_SITE_URL 环境变量修改
// 注意：不能用 getServerBaseURL()（后端 5004 端口），
// 否则扫码会打开 5004 后端地址的 /q.html 而 404。
var qrSiteURL = "https://example.com"

func init() {
	if url := os.Getenv("QR_SITE_URL"); url != "" {
		qrSiteURL = url
	}
}

// GET /api/user/qrcode — 获取当前用户的二维码内容
func handleGetMyQrCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID <= 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	// 落地页 + ?u=用户ID，两个信息分离；落地页走官网裸域（而非后端 5004 端口）
	content := fmt.Sprintf("%s/q.html?u=%d", qrSiteURL, userID)
	writeJSON(w, 200, "ok", map[string]string{"content": content})
}

// POST /api/user/qrcode/resolve — 解析二维码内容，返回目标用户基本信息
// 仅 APP 内扫码调用（需已登录）。从 # 片段提取用户 ID 返回加好友所需信息。
func handleResolveQrCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	var req struct {
		Content string `json:"content"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.Content == "" {
		writeJSON(w, 400, "缺少 content 参数", nil)
		return
	}

	currentID := getCurrentUserID(r)
	if currentID <= 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}

	// 解析出目标用户 ID
	var targetID int64
	content := strings.TrimSpace(req.Content)
	switch {
	case strings.HasPrefix(content, "http://") || strings.HasPrefix(content, "https://"):
		// 最新版：官网落地页 /q.html?u=<用户ID>（query 参数）
		u, err := url.Parse(content)
		if err != nil {
			writeJSON(w, 400, "无效的二维码格式", nil)
			return
		}
		var id int64
		if qv := u.Query().Get("u"); qv != "" {
			id, _ = strconv.ParseInt(qv, 10, 64)
		} else {
			// 兼容历史 # 片段格式：http://.../#<用户ID>
			id, _ = strconv.ParseInt(strings.TrimPrefix(u.Fragment, "#"), 10, 64)
		}
		if id <= 0 {
			writeJSON(w, 400, "用户ID格式错误", nil)
			return
		}
		targetID = id
	case strings.HasPrefix(content, "aurora://user?id="):
		// 兼容旧版 aurora://user?id=xxx（历史已生成的二维码）
		idStr := strings.TrimPrefix(content, "aurora://user?id=")
		id, err := strconv.ParseInt(idStr, 10, 64)
		if err != nil || id <= 0 {
			writeJSON(w, 400, "用户ID格式错误", nil)
			return
		}
		targetID = id
	default:
		writeJSON(w, 400, "无效的二维码格式", nil)
		return
	}

	// 防批量扫描：同一用户 2 秒内最多解析 1 次
	if allowed, wait := checkQrResolveRateLimit(currentID); !allowed {
		writeJSON(w, 429, fmt.Sprintf("操作过于频繁，请 %d 秒后再试", wait), nil)
		return
	}

	// 查询目标用户
	user, err := findUserByID(targetID)
	if err != nil {
		writeJSON(w, 500, "服务器错误", nil)
		return
	}
	if user == nil || isAccountDeleted(user) {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}

	isSelf := currentID == targetID
	if isSelf {
		writeJSON(w, 200, "ok", map[string]interface{}{
			"is_self":   true,
			"id":        user.ID,
			"username":  user.Username,
			"signature": user.Signature,
			"avatar_url": fmt.Sprintf("/api/avatar/%d", user.ID),
			"message":   "这是你自己的二维码",
		})
		return
	}

	avatarUrl := fmt.Sprintf("/api/avatar/%d", targetID)
	writeJSON(w, 200, "ok", map[string]interface{}{
		"is_self":   false,
		"id":        user.ID,
		"username":  user.Username,
		"signature": user.Signature,
		"avatar_url": avatarUrl,
	})
}

// ==================== 获取在线用户（开发者管理） ====================

func handleGetOnlineUsers(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}

	// 开发者或拥有 users.view_profile 权限的管理员可查看
	if !checkDevOrPerm(r, "users.view_profile") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	onlineIDs := GetOnlineUserIDs()

	// 查询在线用户的详细信息
	type OnlineUser struct {
		ID        int64  `json:"id"`
		Email     string `json:"email"`
		Username  string `json:"username"`
		CreatedAt int64  `json:"created_at"`
		UpdatedAt int64  `json:"updated_at"`
	}

	users := make([]OnlineUser, 0, len(onlineIDs))
	for _, id := range onlineIDs {
		u, err := findUserByID(id)
		if err != nil || u == nil {
			continue
		}
		users = append(users, OnlineUser{
			ID:        u.ID,
			Email:     u.Email,
			Username:  u.Username,
			CreatedAt: u.CreatedAt,
			UpdatedAt: u.UpdatedAt,
		})
	}

	writeJSON(w, 200, "获取成功", users)
}

// ==================== 管理员操作：删除用户账号 ====================

func handleAdminDeleteUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	currentEmail := getCurrentEmailFromHeader(r)
	if !checkDevOrPerm(r, "users.delete") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	var req struct {
		UserID     int64 `json:"user_id"`
		BlockEmail bool  `json:"block_email"`
		BlockIP    bool  `json:"block_ip"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误：需要有效的 user_id", nil)
		return
	}

	// 禁止删除开发者自身
	currentUserID := getCurrentUserID(r)
	if req.UserID == currentUserID {
		writeJSON(w, 403, "无法删除自己的账号", nil)
		return
	}

	// 查找目标用户
	targetUser, err := findUserByID(req.UserID)
	if err != nil || targetUser == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}

	// 通过 TCP 推送删除通知给目标用户（含清空本地数据指令）
	PushToUser(req.UserID, "account_deleted", map[string]interface{}{
		"message":    "您的账号已被管理员删除",
		"clear_data": true,
	})

	// 清除封禁/禁言记录
	RemoveBanRecord(req.UserID)

	// 清理数据库
	if err := deleteUserAllData(req.UserID); err != nil {
		log.Printf("[Admin] 删除用户 %d (%s) 失败: %v", req.UserID, targetUser.Email, err)
		writeJSON(w, 500, "删除失败: "+err.Error(), nil)
		return
	}

	log.Printf("[Admin] 用户 %d (%s) 已被 %s 彻底删除", req.UserID, targetUser.Email, currentEmail)

	// 如果勾选了拉黑邮箱
	if req.BlockEmail {
		if err := blockEmail(targetUser.QQNumber, currentUserID); err != nil {
			log.Printf("[Admin] 拉黑 QQ %s 失败: %v", targetUser.QQNumber, err)
		} else {
			log.Printf("[Admin] QQ %s 已被拉黑", targetUser.QQNumber)
		}
	}
	// 如果勾选了拉黑IP
	if req.BlockIP && targetUser.RegIp != "" {
		if err := blockIP(targetUser.RegIp, currentUserID); err != nil {
			log.Printf("[Admin] 拉黑 IP %s 失败: %v", targetUser.RegIp, err)
		} else {
			log.Printf("[Admin] IP %s 已被拉黑", targetUser.RegIp)
		}
	}

	writeJSON(w, 200, "已删除用户 "+targetUser.QQNumber, nil)
}

// ==================== 管理员操作：修改用户密码（重置） ====================

func handleAdminResetUserPassword(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	if !checkDevOrPerm(r, "users.delete") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	var req struct {
		UserID      int64  `json:"user_id"`
		NewPassword string `json:"new_password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 || req.NewPassword == "" {
		writeJSON(w, 400, "参数错误：需要 user_id 与新密码", nil)
		return
	}
	if len([]rune(req.NewPassword)) < 8 {
		writeJSON(w, 400, "新密码不能少于 8 位", nil)
		return
	}

	targetUser, err := findUserByID(req.UserID)
	if err != nil || targetUser == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}

	// 与注册/重置密码完全一致的哈希算法（bcrypt），保证登录/鉴权能识别
	hashed, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		writeJSON(w, 500, "密码加密失败", nil)
		return
	}
	if err := updatePassword(req.UserID, string(hashed)); err != nil {
		log.Printf("[Admin] 重置用户 %d (%s) 密码失败: %v", req.UserID, targetUser.Email, err)
		writeJSON(w, 500, "重置密码失败", nil)
		return
	}

	log.Printf("[Admin] 用户 %d (%s) 的密码已被 %s 重置", req.UserID, targetUser.Email, getCurrentEmailFromHeader(r))
	writeJSON(w, 200, "密码已重置", nil)
}

// ==================== 管理员操作：封禁用户 ====================

func handleAdminBanUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	currentUserID, ok := checkAdminPermission(r, "users.ban")
	if !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	var req struct {
		UserID            int64  `json:"user_id"`
		Reason            string `json:"reason"`
		Duration          int64  `json:"duration"`
		UnbanPopupMessage string `json:"unban_popup_message"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误：需要有效的 user_id", nil)
		return
	}
	if req.Duration <= 0 {
		req.Duration = 100 * 365 * 24 * 60 * 60
	}

	if req.UserID == currentUserID {
		writeJSON(w, 403, "无法封禁自己的账号", nil)
		return
	}

	targetUser, err := findUserByID(req.UserID)
	if err != nil || targetUser == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}

	// 保护管理员和开发者：不可被封禁
	if isDeveloperUserObj(targetUser) {
		writeJSON(w, 403, "无法封禁开发者账号", nil)
		return
	}
	isTargetAdmin, _ := isPlatformAdmin(req.UserID)
	if isTargetAdmin && !checkDevPermission(r) {
		writeJSON(w, 403, "无法封禁管理员账号，请先取消其管理员权限", nil)
		return
	}

	if err := banUser(req.UserID, req.Reason, req.Duration, currentUserID, req.UnbanPopupMessage); err != nil {
		log.Printf("[Admin] 封禁用户 %d 失败: %v", req.UserID, err)
		writeJSON(w, 500, "封禁失败", nil)
		return
	}

	AddBanRecord(req.UserID, req.Reason, time.Now().Unix()+req.Duration)

	PushToUser(req.UserID, "account_banned", map[string]interface{}{
		"reason":              req.Reason,
		"duration":            req.Duration,
		"expires_at":          time.Now().Unix() + req.Duration,
		"unban_popup_message": req.UnbanPopupMessage,
	})

	DisconnectUser(req.UserID)

	// 记录操作日志
	adminUsername := getCurrentEmailFromHeader(r)
	targetUsername := targetUser.Username
	details, _ := json.Marshal(map[string]interface{}{
		"reason":     req.Reason,
		"duration":   req.Duration,
		"expires_at": time.Now().Unix() + req.Duration,
	})
	addAdminOperationLog(currentUserID, adminUsername, "ban", req.UserID, targetUsername, string(details))

	log.Printf("[Admin] 用户 %d (%s) 已被 %s 封禁 %d 秒，原因: %s",
		req.UserID, targetUser.Email, adminUsername, req.Duration, req.Reason)
	writeJSON(w, 200, "已封禁用户 "+targetUser.Email, nil)
}

// ==================== 用户请求解封通知 ====================

func handleBanNotify(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	if err := setUnbanNotify(userID); err != nil {
		log.Printf("[封禁] 用户 %d 设置解封通知失败: %v", userID, err)
		writeJSON(w, 500, "设置解封通知失败", nil)
		return
	}
	log.Printf("[封禁] 用户 %d 已请求解封邮件通知", userID)
	writeJSON(w, 200, "解封后将发送邮件通知", nil)
}

// ==================== 用户查询自己的封禁状态（不受封禁影响） ====================

func handleCheckBanStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	ban, err := getBanStatus(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if ban != nil {
		writeJSON(w, 200, "查询成功", ban)
	} else {
		writeJSON(w, 200, "未封禁", map[string]interface{}{})
	}
}

// ==================== 用户查询自己的禁言状态（不受禁言影响） ====================

func handleCheckMuteStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	mute, err := getMuteStatus(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if mute != nil {
		writeJSON(w, 200, "查询成功", mute)
	} else {
		writeJSON(w, 200, "未禁言", map[string]interface{}{})
	}
}

// ==================== 用户查询自己是否为平台管理员 ====================

func handleCheckIsPlatformAdmin(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	if checkDevPermission(r) {
		writeJSON(w, 200, "ok", map[string]bool{"is_admin": false})
		return
	}
	isAdmin, err := isPlatformAdmin(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]bool{"is_admin": isAdmin})
}

// ==================== 闪照查看记录API ====================

// POST /api/flash/view — 记录用户已查看闪照
func handleRecordFlashView(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		MessageID int64 `json:"message_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.MessageID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	recordFlashView(userID, req.MessageID)
	writeJSON(w, 200, "ok", nil)
}

// GET /api/flash/viewed-ids — 获取用户已查看的闪照ID列表
func handleGetViewedFlashIDs(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	ids := getViewedFlashIDs(userID)
	if ids == nil {
		ids = []int64{}
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"ids": ids})
}

// ==================== 管理员操作：解封用户 ====================

func handleAdminUnbanUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	currentUserID, ok := checkAdminPermission(r, "users.ban")
	if !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		UserID int64 `json:"user_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误：需要有效的 user_id", nil)
		return
	}
	ban, _ := getBanStatus(req.UserID)
	popupMsg := ""
	targetUsername := ""
	if ban != nil {
		popupMsg = ban.UnbanPopupMessage
		targetUser, _ := findUserByID(req.UserID)
		if targetUser != nil {
			targetUsername = targetUser.Username
		}
	}
	if err := unbanUser(req.UserID); err != nil {
		log.Printf("[Admin] 解封用户 %d 失败: %v", req.UserID, err)
		writeJSON(w, 500, "解封失败", nil)
		return
	}
	RemoveBanRecord(req.UserID)
	PushToUser(req.UserID, "account_unbanned", map[string]interface{}{
		"message":             "您的账号已被解封",
		"unban_popup_message": popupMsg,
	})

	// 记录操作日志
	adminUsername := getCurrentEmailFromHeader(r)
	details, _ := json.Marshal(map[string]interface{}{
		"action": "unban",
	})
	addAdminOperationLog(currentUserID, adminUsername, "unban", req.UserID, targetUsername, string(details))

	log.Printf("[Admin] 用户 %d 已被 %s 解封", req.UserID, adminUsername)
	writeJSON(w, 200, "已解封用户", nil)
}

// ==================== 管理员查询用户封禁状态 ====================

func handleAdminCheckBanStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	_, ok := checkAdminPermission(r, "users.ban")
	if !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	userIDStr := r.URL.Query().Get("user_id")
	if userIDStr == "" {
		writeJSON(w, 400, "参数错误：需要 user_id", nil)
		return
	}
	var userID int64
	fmt.Sscanf(userIDStr, "%d", &userID)
	if userID <= 0 {
		writeJSON(w, 400, "参数错误：无效的 user_id", nil)
		return
	}
	ban, err := getBanStatus(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if ban != nil {
		writeJSON(w, 200, "查询成功", ban)
	} else {
		writeJSON(w, 200, "未封禁", map[string]interface{}{})
	}
}

// ==================== 管理员操作：禁言用户 ====================

func handleAdminMuteUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	currentUserID, ok := checkAdminPermission(r, "users.mute")
	if !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	var req struct {
		UserID   int64 `json:"user_id"`
		Duration int64 `json:"duration"`
		MuteType int   `json:"mute_type"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误：需要有效的 user_id", nil)
		return
	}
	if req.MuteType < 1 || req.MuteType > 3 {
		req.MuteType = 3
	}
	if req.Duration <= 0 {
		req.Duration = 100 * 365 * 24 * 60 * 60
	}

	if req.UserID == currentUserID {
		writeJSON(w, 403, "无法禁言自己的账号", nil)
		return
	}

	targetUser, err := findUserByID(req.UserID)
	if err != nil || targetUser == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}

	// 保护管理员和开发者：不可被禁言
	if isDeveloperUserObj(targetUser) {
		writeJSON(w, 403, "无法禁言开发者账号", nil)
		return
	}
	isTargetAdmin, _ := isPlatformAdmin(req.UserID)
	if isTargetAdmin && !checkDevPermission(r) {
		writeJSON(w, 403, "无法禁言管理员账号，请先取消其管理员权限", nil)
		return
	}

	if err := muteUser(req.UserID, req.Duration, currentUserID, req.MuteType); err != nil {
		log.Printf("[Admin] 禁言用户 %d 失败: %v", req.UserID, err)
		writeJSON(w, 500, "禁言失败", nil)
		return
	}

	AddMuteRecord(req.UserID, time.Now().Unix()+req.Duration)

	PushToUser(req.UserID, "account_muted", map[string]interface{}{
		"duration":   req.Duration,
		"expires_at": time.Now().Unix() + req.Duration,
		"mute_type":  req.MuteType,
	})

	DisconnectUser(req.UserID)

	// 记录操作日志
	adminUsername := getCurrentEmailFromHeader(r)
	muteTypeStr := "全部"
	if req.MuteType == 1 {
		muteTypeStr = "评论"
	} else if req.MuteType == 2 {
		muteTypeStr = "对话"
	}
	details, _ := json.Marshal(map[string]interface{}{
		"mute_type":       req.MuteType,
		"mute_type_label": muteTypeStr,
		"duration":        req.Duration,
		"expires_at":      time.Now().Unix() + req.Duration,
	})
	addAdminOperationLog(currentUserID, adminUsername, "mute", req.UserID, targetUser.Username, string(details))

	log.Printf("[Admin] 用户 %d (%s) 已被 %s 禁言 %d 秒，类型: %s",
		req.UserID, targetUser.Email, adminUsername, req.Duration, muteTypeStr)
	writeJSON(w, 200, "已禁言用户 "+targetUser.Email, nil)
}

// ==================== 管理员操作：解除禁言 ====================

func handleAdminUnmuteUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	currentUserID, ok := checkAdminPermission(r, "users.mute")
	if !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		UserID int64 `json:"user_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误：需要有效的 user_id", nil)
		return
	}
	targetUser, _ := findUserByID(req.UserID)
	targetUsername := ""
	if targetUser != nil {
		targetUsername = targetUser.Username
	}
	if err := unmuteUser(req.UserID); err != nil {
		log.Printf("[Admin] 解除禁言用户 %d 失败: %v", req.UserID, err)
		writeJSON(w, 500, "解除禁言失败", nil)
		return
	}
	RemoveMuteRecord(req.UserID)
	PushToUser(req.UserID, "account_unmuted", map[string]interface{}{
		"message": "您的账号已被解除禁言",
	})

	// 记录操作日志
	adminUsername := getCurrentEmailFromHeader(r)
	details, _ := json.Marshal(map[string]interface{}{
		"action": "unmute",
	})
	addAdminOperationLog(currentUserID, adminUsername, "unmute", req.UserID, targetUsername, string(details))

	log.Printf("[Admin] 用户 %d 已被 %s 解除禁言", req.UserID, adminUsername)
	writeJSON(w, 200, "已解除禁言", nil)
}

// ==================== 管理员查询用户禁言状态 ====================

func handleAdminCheckMuteStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	_, ok := checkAdminPermission(r, "users.mute")
	if !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	userIDStr := r.URL.Query().Get("user_id")
	if userIDStr == "" {
		writeJSON(w, 400, "参数错误：需要 user_id", nil)
		return
	}
	var userID int64
	fmt.Sscanf(userIDStr, "%d", &userID)
	if userID <= 0 {
		writeJSON(w, 400, "参数错误：无效的 user_id", nil)
		return
	}
	mute, err := getMuteStatus(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if mute != nil {
		writeJSON(w, 200, "查询成功", mute)
	} else {
		writeJSON(w, 200, "未禁言", map[string]interface{}{})
	}
}

// ==================== 群内禁言 ====================

// POST /api/group/mute — 群内禁言成员（仅群主/管理员）
func handleGroupMuteUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	currentUserID := getCurrentUserID(r)
	if currentUserID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		GroupID  int64 `json:"group_id"`
		UserID   int64 `json:"user_id"`
		Duration int64 `json:"duration"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.GroupID <= 0 || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if req.Duration <= 0 {
		req.Duration = 3600
	}
	// 验证当前用户是群主或管理员
	var role string
	db.QueryRow("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?", req.GroupID, currentUserID).Scan(&role)
	if role != "owner" && role != "admin" {
		// 检查是否开发者（可绕过）
		if !isDeveloperUser(currentUserID) {
			writeJSON(w, 403, "仅群主和管理员可禁言成员", nil)
			return
		}
	}
	// 验证目标用户在群内
	var memberCount int
	db.QueryRow("SELECT COUNT(*) FROM group_members WHERE group_id = ? AND user_id = ?", req.GroupID, req.UserID).Scan(&memberCount)
	if memberCount == 0 {
		writeJSON(w, 404, "该用户不在群中", nil)
		return
	}
	if err := groupMuteUser(req.GroupID, req.UserID, req.Duration, currentUserID); err != nil {
		log.Printf("[群禁言] 禁言失败: group=%d, user=%d, err=%v", req.GroupID, req.UserID, err)
		writeJSON(w, 500, "禁言失败", nil)
		return
	}
	log.Printf("[群禁言] 用户 %d 在群 %d 被禁言 %d 秒", req.UserID, req.GroupID, req.Duration)

	// 以群身份发送禁言提示消息
	convID := -(1000 + req.GroupID)
	duration := req.Duration
	var durationStr string
	if duration >= 86400 {
		durationStr = fmt.Sprintf("%d天", duration/86400)
	} else if duration >= 3600 {
		durationStr = fmt.Sprintf("%d小时", duration/3600)
	} else {
		durationStr = fmt.Sprintf("%d分钟", duration/60)
	}
	var operatorName, targetName string
	db.QueryRow("SELECT username FROM users WHERE id = ?", currentUserID).Scan(&operatorName)
	db.QueryRow("SELECT username FROM users WHERE id = ?", req.UserID).Scan(&targetName)
	if operatorName == "" {
		operatorName = fmt.Sprintf("用户%d", currentUserID)
	}
	if targetName == "" {
		targetName = fmt.Sprintf("用户%d", req.UserID)
	}
	content := fmt.Sprintf("@%s 将 @%s 禁言了%s", operatorName, targetName, durationStr)
	if msgID, err := saveMessage(convID, convID, content, 0, "", "", 0); err == nil {
		PushToGroup(convID, msgID, convID, "", convID, content, time.Now().Unix(), "", "", 0, 0, "", "")
	}

	writeJSON(w, 200, "已禁言", nil)
}

// POST /api/group/unmute — 解除群内禁言（仅群主/管理员）
func handleGroupUnmuteUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	currentUserID := getCurrentUserID(r)
	if currentUserID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		GroupID int64 `json:"group_id"`
		UserID  int64 `json:"user_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.GroupID <= 0 || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var role string
	db.QueryRow("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?", req.GroupID, currentUserID).Scan(&role)
	if role != "owner" && role != "admin" {
		if !isDeveloperUser(currentUserID) {
			writeJSON(w, 403, "仅群主和管理员可解除禁言", nil)
			return
		}
	}
	if err := groupUnmuteUser(req.GroupID, req.UserID); err != nil {
		log.Printf("[群禁言] 解除禁言失败: group=%d, user=%d, err=%v", req.GroupID, req.UserID, err)
		writeJSON(w, 500, "解除禁言失败", nil)
		return
	}
	log.Printf("[群禁言] 用户 %d 在群 %d 已解除禁言", req.UserID, req.GroupID)

	// 以群身份发送解除禁言提示消息
	convID := -(1000 + req.GroupID)
	var operatorName, targetName string
	db.QueryRow("SELECT username FROM users WHERE id = ?", currentUserID).Scan(&operatorName)
	db.QueryRow("SELECT username FROM users WHERE id = ?", req.UserID).Scan(&targetName)
	if operatorName == "" {
		operatorName = fmt.Sprintf("用户%d", currentUserID)
	}
	if targetName == "" {
		targetName = fmt.Sprintf("用户%d", req.UserID)
	}
	content := fmt.Sprintf("@%s 已将 @%s 解除禁言", operatorName, targetName)
	if msgID, err := saveMessage(convID, convID, content, 0, "", "", 0); err == nil {
		PushToGroup(convID, msgID, convID, "", convID, content, time.Now().Unix(), "", "", 0, 0, "", "")
	}

	writeJSON(w, 200, "已解除禁言", nil)
}

// GET /api/group/mute-members?group_id= — 批量获取群内被禁言成员列表
func handleGroupMuteMembers(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	currentUserID := getCurrentUserID(r)
	if currentUserID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	groupIDStr := r.URL.Query().Get("group_id")
	if groupIDStr == "" {
		writeJSON(w, 400, "缺少 group_id 参数", nil)
		return
	}
	var groupID int64
	fmt.Sscanf(groupIDStr, "%d", &groupID)
	if groupID <= 0 {
		writeJSON(w, 400, "无效的群ID", nil)
		return
	}
	// 验证用户是群成员
	_, err := getMemberRole(groupID, currentUserID)
	if err != nil {
		writeJSON(w, 403, "你不是该群成员", nil)
		return
	}
	members, err := getGroupMuteMembers(groupID)
	if err != nil {
		log.Printf("[群禁言] 获取禁言成员列表失败: group=%d, err=%v", groupID, err)
		writeJSON(w, 500, "获取失败", nil)
		return
	}
	if members == nil {
		members = []map[string]interface{}{}
	}
	writeJSON(w, 200, "获取成功", members)
}

// GET /api/group/mute-status?group_id=&user_id= — 查询用户在群内的禁言状态
func handleGroupCheckMuteStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	currentUserID := getCurrentUserID(r)
	if currentUserID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	groupIDStr := r.URL.Query().Get("group_id")
	userIDStr := r.URL.Query().Get("user_id")
	if groupIDStr == "" || userIDStr == "" {
		writeJSON(w, 400, "参数错误：需要 group_id 和 user_id", nil)
		return
	}
	var groupID, targetUserID int64
	fmt.Sscanf(groupIDStr, "%d", &groupID)
	fmt.Sscanf(userIDStr, "%d", &targetUserID)
	if groupID <= 0 || targetUserID <= 0 {
		writeJSON(w, 400, "参数错误：无效的 ID", nil)
		return
	}
	isMuted, expiresAt := isGroupMuted(groupID, targetUserID)
	if isMuted {
		writeJSON(w, 200, "查询成功", map[string]interface{}{
			"is_muted":   true,
			"expires_at": expiresAt,
		})
	} else {
		writeJSON(w, 200, "未禁言", map[string]interface{}{
			"is_muted": false,
		})
	}
}

// ==================== 平台管理员授权/撤销/列表 ====================

// POST /api/admin/platform-admin/grant — 授权平台管理员（仅开发者）
func handleGrantPlatformAdmin(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	if !checkDevOrPerm(r, "admin.grant") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		UserID int64 `json:"user_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	currentUserID := getCurrentUserID(r)
	if req.UserID == currentUserID {
		writeJSON(w, 400, "不能授权自己", nil)
		return
	}
	targetUser, err := findUserByID(req.UserID)
	if err != nil || targetUser == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}
	if err := grantPlatformAdmin(req.UserID, currentUserID); err != nil {
		log.Printf("[Admin] 授权平台管理员失败: %v", err)
		writeJSON(w, 500, "授权失败", nil)
		return
	}
	log.Printf("[Admin] 用户 %d (%s) 被授权为平台管理员", req.UserID, targetUser.Email)
	writeJSON(w, 200, "已授权 "+targetUser.Username+" 为平台管理员", nil)
}

// POST /api/admin/platform-admin/revoke — 撤销平台管理员（仅开发者）
func handleRevokePlatformAdmin(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	if !checkDevPermission(r) {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		UserID int64 `json:"user_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if err := revokePlatformAdmin(req.UserID); err != nil {
		log.Printf("[Admin] 撤销平台管理员失败: %v", err)
		writeJSON(w, 500, "撤销失败", nil)
		return
	}
	log.Printf("[Admin] 用户 %d 的平台管理员权限已被撤销", req.UserID)
	writeJSON(w, 200, "已撤销平台管理员", nil)
}

// GET /api/admin/platform-admin/list — 获取所有平台管理员列表（仅开发者）
func handleListPlatformAdmins(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	if !checkDevOrPerm(r, "admin.grant") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	admins, err := getAllPlatformAdmins()
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	// 补充用户信息
	type AdminInfo struct {
		UserID    int64  `json:"user_id"`
		Username  string `json:"username"`
		Email     string `json:"email"`
		GrantedBy int64  `json:"granted_by"`
		GrantedAt int64  `json:"granted_at"`
	}
	var result []AdminInfo
	for _, a := range admins {
		u, _ := findUserByID(a.UserID)
		username := ""
		email := ""
		if u != nil {
			username = u.Username
			email = u.Email
		}
		result = append(result, AdminInfo{
			UserID: a.UserID, Username: username, Email: email,
			GrantedBy: a.GrantedBy, GrantedAt: a.GrantedAt,
		})
	}
	writeJSON(w, 200, "查询成功", result)
}

// POST /api/admin/permissions/revoke-admin — 撤销管理员的全部权限（需要 admin.revoke 权限）
func handleRevokeAdminPermissions(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	currentUserID := getCurrentUserID(r)
	// 开发者直接放行；否则检查 admin.revoke 权限
	if !checkDevPermission(r) && !hasPermission(currentUserID, "admin.revoke") {
		writeJSON(w, 403, "无权执行此操作", nil)
		return
	}
	var req struct {
		UserID int64 `json:"user_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if req.UserID == currentUserID {
		writeJSON(w, 400, "不能撤销自己的权限", nil)
		return
	}
	targetUser, err := findUserByID(req.UserID)
	if err != nil || targetUser == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}
	// 不能撤销开发者
	if isDeveloperUserObj(targetUser) {
		writeJSON(w, 403, "不能撤销开发者的权限", nil)
		return
	}
	// 撤销平台管理员身份
	if err := revokePlatformAdmin(req.UserID); err != nil {
		writeJSON(w, 500, "撤销管理员身份失败", nil)
		return
	}
	// 同时清除该用户的所有细粒度权限
	if err := saveUserPermissions(req.UserID, []string{}); err != nil {
		log.Printf("[Admin] 清除用户 %d 权限时出错: %v", req.UserID, err)
		// 不阻断主流程
	}
	// 记录操作日志
	adminID := getCurrentUserID(r)
	adminUsername := ""
	if u, _ := findUserByID(adminID); u != nil {
		adminUsername = u.Username
	}
	addAdminOperationLog(adminID, adminUsername, "revoke_admin", req.UserID, targetUser.Username, `{"target_email":"`+targetUser.Email+`"}`)
	writeJSON(w, 200, "已撤销该管理员的全部权限", nil)
}

// GET /api/admin/permissions?user_id=xxx — 获取用户细粒度权限（仅开发者）
func handleGetUserPermissions(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevPermission(r) {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	userIDStr := r.URL.Query().Get("user_id")
	requestedUserID, err := strconv.ParseInt(userIDStr, 10, 64)
	if err != nil || requestedUserID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	keys, err := getUserPermissions(requestedUserID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", keys)
}

// GET /api/admin/my-permissions — 获取当前用户自己的权限列表（平台管理员可用）
func handleGetMyPermissions(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID <= 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	keys, err := getUserPermissions(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", keys)
}

// POST /api/admin/permissions/save — 保存用户细粒度权限（仅开发者）
func handleSaveUserPermissions(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevPermission(r) {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		UserID int64    `json:"user_id"`
		Perms  []string `json:"perms"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.UserID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if err := saveUserPermissions(req.UserID, req.Perms); err != nil {
		writeJSON(w, 500, "保存权限失败", nil)
		return
	}
	// 关键修复：保存权限的同时，确保该用户是平台管理员
	// 否则客户端 isPlatformAdmin() 返回 false，看不到开发者管理入口
	if len(req.Perms) > 0 {
		isAdmin, err := isPlatformAdmin(req.UserID)
		if err != nil || !isAdmin {
			currentUserID := getCurrentUserID(r)
			if err := grantPlatformAdmin(req.UserID, currentUserID); err != nil {
				log.Printf("[Admin] 保存权限时自动授权平台管理员失败: %v", err)
				// 不阻断主流程，权限已保存
			}
		}
	}
	writeJSON(w, 200, "已保存", nil)
}

// GET /api/admin/admin-logs — 获取管理员操作日志（仅开发者）
func handleGetAdminLogs(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	if !checkDevOrPerm(r, "admin.logs") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	limitStr := r.URL.Query().Get("limit")
	offsetStr := r.URL.Query().Get("offset")
	adminIDStr := r.URL.Query().Get("admin_user_id")
	limit := 50
	offset := 0
	if n, err := fmt.Sscanf(limitStr, "%d", &limit); err != nil || n == 0 {
		limit = 50
	}
	if n, err := fmt.Sscanf(offsetStr, "%d", &offset); err != nil || n == 0 {
		offset = 0
	}

	var logs []AdminOperationLog
	var total int
	var err error
	if adminIDStr != "" {
		var adminID int64
		fmt.Sscanf(adminIDStr, "%d", &adminID)
		logs, total, err = getAdminOperationLogsByAdmin(adminID, limit, offset)
	} else {
		logs, total, err = getAdminOperationLogs(limit, offset)
	}
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if logs == nil {
		logs = []AdminOperationLog{}
	}
	writeJSON(w, 200, "查询成功", map[string]interface{}{
		"logs":   logs,
		"total":  total,
		"limit":  limit,
		"offset": offset,
	})
}

// POST /api/admin/admin-logs/clear — 清空所有管理员操作日志（仅开发者）
func handleClearAdminLogs(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	if !checkDevPermission(r) {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	if _, err := db.Exec("DELETE FROM admin_operation_logs"); err != nil {
		log.Printf("[Admin] 清空操作日志失败: %v", err)
		writeJSON(w, 500, "清空失败", nil)
		return
	}
	log.Printf("[Admin] 开发者清空了所有操作日志")
	writeJSON(w, 200, "已清空所有操作日志", nil)
}

// POST /api/admin/admin-logs/revert — 撤回管理员操作（仅开发者）
func handleRevertAdminOperation(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	if !checkDevOrPerm(r, "admin.logs") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	var req struct {
		LogID int64 `json:"log_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.LogID <= 0 {
		writeJSON(w, 400, "参数错误：需要有效的 log_id", nil)
		return
	}

	// 查询日志记录
	var opType string
	var targetUserID int64
	err := db.QueryRow("SELECT operation_type, target_user_id FROM admin_operation_logs WHERE id = ?", req.LogID).
		Scan(&opType, &targetUserID)
	if err != nil {
		writeJSON(w, 404, "日志记录不存在", nil)
		return
	}
	if targetUserID <= 0 {
		writeJSON(w, 400, "日志中未记录目标用户", nil)
		return
	}

	// 根据操作类型执行反向操作
	switch opType {
	case "ban":
		// 撤销封禁 = 解封
		if err := unbanUser(targetUserID); err != nil {
			writeJSON(w, 500, "解封失败", nil)
			return
		}
		RemoveBanRecord(targetUserID)
		PushToUser(targetUserID, "account_unbanned", map[string]interface{}{
			"message": "管理员已撤销对你的封禁",
		})
		// 删除原日志记录（撤回后直接消失）
		db.Exec("DELETE FROM admin_operation_logs WHERE id = ?", req.LogID)
		log.Printf("[Admin] 开发者撤回封禁: 用户 %d, 来源日志ID=%d（已删除原日志）", targetUserID, req.LogID)
		writeJSON(w, 200, "已撤销封禁，用户已恢复使用", nil)

	case "mute":
		// 撤销禁言 = 解除禁言
		if err := unmuteUser(targetUserID); err != nil {
			writeJSON(w, 500, "解除禁言失败", nil)
			return
		}
		RemoveMuteRecord(targetUserID)
		PushToUser(targetUserID, "account_unmuted", map[string]interface{}{
			"message": "管理员已撤销对你的禁言",
		})
		// 删除原日志记录（撤回后直接消失）
		db.Exec("DELETE FROM admin_operation_logs WHERE id = ?", req.LogID)
		log.Printf("[Admin] 开发者撤回禁言: 用户 %d, 来源日志ID=%d（已删除原日志）", targetUserID, req.LogID)
		writeJSON(w, 200, "已撤销禁言，用户已恢复使用", nil)

	default:
		writeJSON(w, 400, "该操作类型不支持撤回: "+opType, nil)
	}
}

// ==================== 开发者修改用户资料（ID/用户名/QQ/注册时间） ====================

// isUserRefColumn 判断某列是否为"用户ID引用"列，用于改 ID 时级联更新所有相关表。
func isUserRefColumn(name string) bool {
	n := strings.ToLower(name)
	if n == "user_id" || strings.HasSuffix(n, "_user_id") {
		return true
	}
	switch n {
	case "sender_id", "receiver_id", "owner_id", "operator_id", "invited_by",
		"friend_id", "added_by", "actor_id", "creator_id", "reported_by", "handled_by":
		return true
	}
	return false
}

// reassignUserID 将用户从 oldID 迁移到 newID（单事务、自包含）。
//
// 根因：SQLite 的 INTEGER PRIMARY KEY 就是 rowid 的别名，无法用
//   UPDATE users SET id = ? WHERE id = ?
// 直接改主键（要么静默影响 0 行、要么在嵌套事务里造成 newID 重复 → UNIQUE 冲突回滚）。
// 正确做法：复制整行到新 ID → 把引用 oldID 的外键列全部改为 newID → 删除旧行。
// 全程在【一个】事务里完成，避免再次出现嵌套事务导致的新 ID 重复/回滚问题。
func reassignUserID(oldID, newID int64) error {
	tx, err := db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	now := time.Now().Unix()

	// 1) 把旧用户整行复制为新 ID（rowid 别名无法 UPDATE，只能 INSERT+DELETE）
	if _, err = tx.Exec(
		`INSERT INTO users (id, email, username, password, created_at, updated_at, hide_email, hide_qq, qq_number, signature, online_time_seconds, word_count, worn_badge, token_version, email_verified, member_level, member_expires_at, token_balance, token_balance_perm, token_balance_free, reg_ip, qq_openid)
		 SELECT ?, email, username, password, created_at, ?, hide_email, hide_qq, qq_number, signature, online_time_seconds, word_count, worn_badge, token_version, email_verified, member_level, member_expires_at, token_balance, token_balance_perm, token_balance_free, reg_ip, qq_openid FROM users WHERE id = ?`,
		newID, now, oldID); err != nil {
		return fmt.Errorf("复制用户行失败: %w", err)
	}

	// 2) 遍历所有业务表，把引用 oldID 的外键列改为 newID
	rows, err := tx.Query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
	if err != nil {
		return err
	}
	var tables []string
	for rows.Next() {
		var t string
		if err := rows.Scan(&t); err == nil {
			tables = append(tables, t)
		}
	}
	rows.Close()
	for _, t := range tables {
		cols, err := tx.Query(fmt.Sprintf("PRAGMA table_info(%s)", t))
		if err != nil {
			continue
		}
		var colNames []string
		for cols.Next() {
			var cid int
			var cname, ctype string
			var notnull int
			var dflt sql.NullString
			var pk int
			if err := cols.Scan(&cid, &cname, &ctype, &notnull, &dflt, &pk); err == nil && isUserRefColumn(cname) {
				colNames = append(colNames, cname)
			}
		}
		cols.Close()
		for _, c := range colNames {
			if _, err := tx.Exec(fmt.Sprintf("UPDATE %s SET %s = ? WHERE %s = ?", t, c, c), newID, oldID); err != nil {
				return fmt.Errorf("更新表 %s.%s 失败: %w", t, c, err)
			}
		}
	}

	// 3) 外键已全部指向 newID，删除旧行（users.id 不在此处 UPDATE，避免重复 newID）
	if _, err := tx.Exec("DELETE FROM users WHERE id = ?", oldID); err != nil {
		return fmt.Errorf("删除旧用户失败: %w", err)
	}

	return tx.Commit()
}

// POST /api/admin/user/update — 开发者修改目标用户的 ID / 用户名 / QQ号 / 注册时间
func handleAdminUpdateUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	if !checkDevPermission(r) {
		writeJSON(w, 403, "仅开发者可操作", nil)
		return
	}
	var req struct {
		UserID    int64  `json:"user_id"`
		NewID     int64  `json:"new_id"`
		Username  string `json:"username"`
		QQNumber  string `json:"qq_number"`
		CreatedAt int64  `json:"created_at"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	if req.UserID == 0 {
		writeJSON(w, 400, "缺少 user_id", nil)
		return
	}
	target, err := findUserByID(req.UserID)
	if err != nil || target == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}
	// 修改 ID（需唯一）
	if req.NewID != 0 && req.NewID != req.UserID {
		if req.NewID <= 0 {
			writeJSON(w, 400, "ID 必须为正数", nil)
			return
		}
		var cnt int
		if err := db.QueryRow("SELECT COUNT(*) FROM users WHERE id = ?", req.NewID).Scan(&cnt); err != nil || cnt > 0 {
			writeJSON(w, 409, "该ID已存在", nil)
			return
		}
		// SQLite 不允许直接 UPDATE INTEGER PRIMARY KEY，reassignUserID 内部用
		// 单事务「复制行→更新外键→删除旧行」完成迁移。
		if err := reassignUserID(req.UserID, req.NewID); err != nil {
			writeJSON(w, 500, "修改ID失败: "+err.Error(), nil)
			return
		}
		req.UserID = req.NewID
	}
	// 修改用户名
	if req.Username != "" {
		if len(req.Username) > 50 {
			writeJSON(w, 400, "用户名过长", nil)
			return
		}
		if _, err := db.Exec("UPDATE users SET username = ?, updated_at = ? WHERE id = ?", req.Username, time.Now().Unix(), req.UserID); err != nil {
			writeJSON(w, 500, "修改用户名失败", nil)
			return
		}
	}
	// 修改 QQ 号
	if req.QQNumber != "" {
		if existing, _ := findUserByQQNumber(req.QQNumber); existing != nil && existing.ID != req.UserID {
			writeJSON(w, 409, "该QQ号已被其他账号绑定", nil)
			return
		}
		if _, err := db.Exec("UPDATE users SET qq_number = ?, updated_at = ? WHERE id = ?", req.QQNumber, time.Now().Unix(), req.UserID); err != nil {
			writeJSON(w, 500, "修改QQ失败", nil)
			return
		}
	}
	// 修改注册时间
	if req.CreatedAt > 0 {
		if _, err := db.Exec("UPDATE users SET created_at = ? WHERE id = ?", req.CreatedAt, req.UserID); err != nil {
			writeJSON(w, 500, "修改注册时间失败", nil)
			return
		}
	}
	writeJSON(w, 200, "更新成功", nil)
}

// POST /api/admin/user/kick — 踢出指定用户（强制其退出登录状态）
func handleAdminKickUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	if !checkDevOrPerm(r, "kick.single") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	var req struct {
		UserID int64 `json:"user_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if req.UserID <= 0 {
		writeJSON(w, 400, "无效的用户ID", nil)
		return
	}
	if req.UserID == 1 {
		writeJSON(w, 400, "不能踢出开发者自己", nil)
		return
	}

	now := time.Now().Unix()
	_, err := db.Exec("UPDATE users SET token_version = token_version + 1, kicked_at = ? WHERE id = ?", now, req.UserID)
	if err != nil {
		log.Printf("[踢出] 踢出用户失败: userID=%d, err=%v", req.UserID, err)
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	log.Printf("[踢出] 开发者踢出用户: target=%d", req.UserID)
	writeJSON(w, 200, fmt.Sprintf("已踢出用户 #%d", req.UserID), nil)
}

// POST /api/admin/user/kick-all — 踢出全部用户（除开发者 ID=1 外）
func handleAdminKickAll(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	if !checkDevOrPerm(r, "kick.all") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	now := time.Now().Unix()
	result, err := db.Exec("UPDATE users SET token_version = token_version + 1, kicked_at = ? WHERE id != 1", now)
	if err != nil {
		log.Printf("[踢出] 踢出全部用户失败: %v", err)
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	affected, _ := result.RowsAffected()
	log.Printf("[踢出] 开发者踢出全部用户: count=%d", affected)
	writeJSON(w, 200, fmt.Sprintf("已踢出 %d 个用户", affected), nil)
}

// ==================== 管理员查询用户服务器信息 ====================

func handleAdminGetUserServer(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	if !checkDevPermission(r) {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	userIDStr := r.URL.Query().Get("user_id")
	userID, err := strconv.ParseInt(userIDStr, 10, 64)
	if err != nil || userID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}

	server, err := findServerByOwner(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if server == nil {
		writeJSON(w, 200, "该用户暂未注册服务器", map[string]interface{}{
			"has_server": false,
			"server":     nil,
		})
		return
	}

	status := computeServerStatus(server.ID)
	password := server.Password // bcrypt hash，直接返回给开发者

	writeJSON(w, 200, "查询成功", map[string]interface{}{
		"has_server": true,
		"server": map[string]interface{}{
			"id":             server.ID,
			"owner_user_id":  server.OwnerUserID,
			"owner_username": server.OwnerName,
			"name":           server.Name,
			"domain":         server.Domain,
			"password":       password,
			"server_url":     getServerBaseURL(),
			"created_at":     server.CreatedAt,
			"status":         status,
		},
	})
}

// ==================== 开发者模拟登录（无需密码） ====================

func handleAdminLoginAsUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	var req struct {
		TargetUserID int64 `json:"target_user_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	if req.TargetUserID <= 0 {
		writeJSON(w, 400, "无效的用户ID", nil)
		return
	}
	if !checkDevPermission(r) {
		writeJSON(w, 403, "仅开发者可执行此操作", nil)
		return
	}

	user, err := findUserByID(req.TargetUserID)
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	if user == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}

	token, _ := generateToken(user.ID, user.Email, user.TokenVersion)
	log.Printf("[开发者模拟登录] 开发者登录用户: target_user_id=%d, target_email=%s", user.ID, user.Email)

	writeJSON(w, 200, "ok", LoginResponse{
		ID:        user.ID,
		Email:     user.Email,
		Username:  user.Username,
		Signature: user.Signature,
		Token:     token,
	})
}

// ==================== 管理员操作：获取用户最近的位置消息 ====================

func handleAdminGetUserLocation(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	if !checkDevOrPerm(r, "users.location") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	userIDStr := r.URL.Query().Get("user_id")
	userID, err := strconv.ParseInt(userIDStr, 10, 64)
	if err != nil || userID <= 0 {
		writeJSON(w, 400, "参数错误：需要有效的 user_id", nil)
		return
	}

	// 查询该用户最近一条分享位置消息
	var id int64
	var content string
	var createdAt int64
	err = db.QueryRow(
		"SELECT id, content, created_at FROM messages WHERE from_user_id = ? AND content LIKE '分享位置%' ORDER BY created_at DESC LIMIT 1",
		userID,
	).Scan(&id, &content, &createdAt)

	if err == sql.ErrNoRows {
		writeJSON(w, 200, "未找到位置消息", map[string]interface{}{
			"found": false,
		})
		return
	}
	if err != nil {
		log.Printf("[Admin] 查询用户 %d 位置消息失败: %v", userID, err)
		writeJSON(w, 500, "查询失败", nil)
		return
	}

	writeJSON(w, 200, "成功", map[string]interface{}{
		"found":      true,
		"content":    content,
		"created_at": createdAt,
	})
}

// ==================== 用户位置上报 ====================

// POST /api/location/upload — 用户自动上报位置（登录态）
func handleUploadLocation(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	currentUserID := getCurrentUserID(r)
	if currentUserID <= 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}

	var req struct {
		Lat     float64 `json:"lat"`
		Lng     float64 `json:"lng"`
		Address string  `json:"address"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}

	if err := addUserLocation(currentUserID, req.Lat, req.Lng, req.Address); err != nil {
		log.Printf("[位置] 保存用户 %d 位置失败: %v", currentUserID, err)
		writeJSON(w, 500, "保存失败", nil)
		return
	}
	log.Printf("[位置] 用户 %d 上报位置: %.6f, %.6f", currentUserID, req.Lat, req.Lng)
	writeJSON(w, 200, "位置已上报", nil)
}

// GET /api/admin/user/locations — 获取用户全部位置历史（仅开发者）
func handleAdminGetUserLocations(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	if !checkDevOrPerm(r, "users.location") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	userIDStr := r.URL.Query().Get("user_id")
	userID, err := strconv.ParseInt(userIDStr, 10, 64)
	if err != nil || userID <= 0 {
		writeJSON(w, 400, "参数错误：需要有效的 user_id", nil)
		return
	}

	records, err := getUserLocations(userID)
	if err != nil {
		log.Printf("[Admin] 查询用户 %d 位置历史失败: %v", userID, err)
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if records == nil {
		records = []UserLocationRecord{}
	}

	writeJSON(w, 200, "成功", map[string]interface{}{
		"records": records,
		"total":   len(records),
	})
}

// ==================== 体验版卡密系统 ====================

// 获取体验版模式状态
func handleAdminGetTrialMode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "trial.view") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var val string
	db.QueryRow("SELECT setting_value FROM app_settings WHERE setting_key = 'trial_mode_enabled'").Scan(&val)
	writeJSON(w, 200, "成功", map[string]interface{}{
		"enabled": val == "1",
	})
}

// 设置体验版模式（开关）
func handleAdminSetTrialMode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "trial.toggle") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		Enabled bool `json:"enabled"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	val := "0"
	if req.Enabled {
		val = "1"
	}
	db.Exec("UPDATE app_settings SET setting_value = ? WHERE setting_key = 'trial_mode_enabled'", val)
	status := "关闭"
	if req.Enabled {
		status = "开启"
	}
	log.Printf("[体验版] 开发者 %s 体验版模式", status)
	writeJSON(w, 200, "已"+status+"体验版模式", nil)
}

// 生成卡密
func handleAdminGenerateCardKey(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "card_keys.generate") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		Category        string `json:"category"` // trial(体验卡密) | reward(奖励卡密) | site(站点卡密)
		DurationMinutes int    `json:"duration_minutes"`
		CardType        string `json:"card_type"`   // reward: personal | public
		RewardType      string `json:"reward_type"` // reward: token | member
		TokenAmount     int64  `json:"token_amount"`
		MemberLevel     int    `json:"member_level"`
		BindUserID      int64  `json:"bind_user_id"`
		Domain string `json:"domain"` // site: 绑定的域名
	Password string `json:"password"` // site: 卡密密码
	CustomKey string `json:"custom_key"` // site: 自定义卡密（可选）
	PermissionLevel string `json:"permission_level"` // site: 权限等级 A/B/C
	DangerQuota int `json:"danger_quota"` // site: 危险操作次数
	BackupBalance int `json:"backup_balance"` // site: 备份额度（可同时保留的备份数），省略默认 1
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	category := req.Category
	if category != "reward" && category != "site" {
		category = "trial"
	}
	if category == "trial" {
		if req.DurationMinutes < 1 || req.DurationMinutes > 1440 {
			writeJSON(w, 400, "时长范围 5-1440 分钟（5分钟-24小时）", nil)
			return
		}
	} else if category == "reward" {
		// 奖励卡密校验
		if req.CardType != "personal" && req.CardType != "public" {
			writeJSON(w, 400, "卡密类型必须为 personal 或 public", nil)
			return
		}
		if req.RewardType != "token" && req.RewardType != "member" {
			writeJSON(w, 400, "奖励类型必须为 token 或 member", nil)
			return
		}
		if req.CardType == "personal" {
			if req.BindUserID <= 0 {
				writeJSON(w, 400, "个人卡密必须填写有效的绑定账号ID", nil)
				return
			}
		}
		if req.RewardType == "token" && req.TokenAmount <= 0 {
			writeJSON(w, 400, "Token 数量必须大于 0", nil)
			return
		}
		if req.RewardType == "member" && (req.MemberLevel < 1 || req.MemberLevel > 3) {
			writeJSON(w, 400, "会员等级必须为 1-3", nil)
			return
		}
	} else if category == "site" {
		if req.CustomKey == "" {
			writeJSON(w, 400, "站点卡密必须填写卡密", nil)
			return
		}
		if req.Password == "" {
			writeJSON(w, 400, "站点卡密必须填写密码", nil)
			return
		}
		if req.Domain == "" {
			writeJSON(w, 400, "站点卡密必须填写至少一个域名", nil)
			return
		}
	}
	// 生成卡密：site 类型用自定义卡密，其他类型随机生成
	var keyStr string
	if category == "site" {
		keyStr = req.CustomKey
		// 检查是否已存在
		var existing int
		db.QueryRow("SELECT COUNT(*) FROM license_keys WHERE key_str = ?", keyStr).Scan(&existing)
		if existing > 0 {
			writeJSON(w, 400, "卡密已存在，请更换", nil)
			return
		}
	} else {
		const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
		rand.Seed(time.Now().UnixNano())
		keyBytes := make([]byte, 12)
		for i := range keyBytes {
			keyBytes[i] = chars[rand.Intn(len(chars))]
		}
		keyStr = string(keyBytes)
	}
	now := time.Now().Unix()
	dur := req.DurationMinutes
	if category == "reward" || category == "site" {
		dur = 0 // 奖励卡密和站点卡密默认永久有效
	}
	backupBalance := req.BackupBalance
	if category == "site" && backupBalance < 1 {
		backupBalance = 1 // 站点卡默认 1 个备份额度
	}
	_, err := db.Exec(`INSERT INTO license_keys
	(key_str, duration_hours, duration_minutes, created_at, category, card_type, reward_type, token_amount, member_level, bind_user_id, domain, password, permission_level, danger_quota, backup_balance)
	VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
	keyStr, dur/60, dur, now, category, req.CardType, req.RewardType, req.TokenAmount, req.MemberLevel, req.BindUserID, req.Domain, req.Password, req.PermissionLevel, req.DangerQuota, backupBalance)
	if err != nil {
		writeJSON(w, 500, "生成失败", nil)
		return
	}
	logPrefix := "[体验版]"
	if category == "reward" {
		logPrefix = "[卡密]"
	}
	log.Printf("%s 开发者生成卡密: %s (类型=%s)", logPrefix, keyStr, category)
	writeJSON(w, 200, "生成成功", map[string]interface{}{
		"key":              keyStr,
		"category":         category,
		"duration_minutes": dur,
	})
}

// 获取所有卡密列表
func handleAdminListCardKeys(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "card_keys.view") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	category := r.URL.Query().Get("category") // trial | reward | site | 空(全部)
	query := `SELECT lk.id, lk.key_str, lk.duration_hours, lk.created_at, COALESCE(lk.activated_at, 0), COALESCE(lk.expires_at, 0),
	COALESCE(lk.used_by_user_id, 0), lk.is_active, COALESCE(u.username, ''),
	COALESCE(lk.category, 'trial'), COALESCE(lk.card_type, ''), COALESCE(lk.reward_type, ''),
	COALESCE(lk.token_amount, 0), COALESCE(lk.member_level, 0), COALESCE(lk.bind_user_id, 0),
	COALESCE(lk.domain, ''), COALESCE(lk.password, ''), COALESCE(lk.permission_level, 'B'), COALESCE(lk.danger_quota, 0), COALESCE(lk.danger_used, 0), COALESCE(lk.backup_balance, 0)
	FROM license_keys lk LEFT JOIN users u ON lk.used_by_user_id = u.id`
	args := []interface{}{}
	if category == "trial" || category == "reward" || category == "site" {
		query += " WHERE lk.category = ?"
		args = append(args, category)
	}
	query += " ORDER BY lk.id DESC LIMIT 200"
	rows, err := db.Query(query, args...)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	defer rows.Close()
	type KeyItem struct {
		ID            int64  `json:"id"`
		KeyStr        string `json:"key_str"`
		DurationHours int    `json:"duration_hours"`
		CreatedAt     int64  `json:"created_at"`
		ActivatedAt   int64  `json:"activated_at"`
		ExpiresAt     int64  `json:"expires_at"`
		UsedByUserID  int64  `json:"used_by_user_id"`
		IsActive      int    `json:"is_active"`
		UserName      string `json:"user_name"`
		Category      string `json:"category"`
		CardType      string `json:"card_type"`
		RewardType    string `json:"reward_type"`
		TokenAmount   int64  `json:"token_amount"`
		MemberLevel   int    `json:"member_level"`
		BindUserID    int64  `json:"bind_user_id"`
		Domain        string `json:"domain"`
		Password      string `json:"password"`
		PermissionLevel string `json:"permission_level"`
		DangerQuota   int    `json:"danger_quota"`
		DangerUsed    int    `json:"danger_used"`
		BackupBalance int    `json:"backup_balance"`
	}
	var keys []KeyItem
	for rows.Next() {
		var k KeyItem
		rows.Scan(&k.ID, &k.KeyStr, &k.DurationHours, &k.CreatedAt, &k.ActivatedAt, &k.ExpiresAt, &k.UsedByUserID, &k.IsActive, &k.UserName, &k.Category, &k.CardType, &k.RewardType, &k.TokenAmount, &k.MemberLevel, &k.BindUserID, &k.Domain, &k.Password, &k.PermissionLevel, &k.DangerQuota, &k.DangerUsed, &k.BackupBalance)
		keys = append(keys, k)
	}
	writeJSON(w, 200, "成功", map[string]interface{}{
		"keys": keys,
	})
}

// 管理员取消卡密使用（重置激活状态）
func handleAdminCancelCardKey(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "card_keys.cancel") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		ID int64 `json:"id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.ID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	_, err := db.Exec("UPDATE license_keys SET activated_at = 0, expires_at = 0, used_by_user_id = 0 WHERE id = ? AND is_active = 1", req.ID)
	if err != nil {
		writeJSON(w, 500, "取消失败", nil)
		return
	}
	log.Printf("[体验版] 管理员取消卡密使用: ID=%d", req.ID)
	writeJSON(w, 200, "已取消使用", nil)
}

// 管理员删除卡密
func handleAdminDeleteCardKey(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "card_keys.delete") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		ID int64 `json:"id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.ID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	_, err := db.Exec("DELETE FROM license_keys WHERE id = ?", req.ID)
	if err != nil {
		writeJSON(w, 500, "删除失败", nil)
		return
	}
	log.Printf("[体验版] 管理员删除卡密: ID=%d", req.ID)
	writeJSON(w, 200, "已删除", nil)
}

// 验证卡密（公开接口，用户输入卡密时调用）
func handleValidateCardKey(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	var req struct {
		Key      string `json:"key"`
		UserID   int64  `json:"user_id"`
		Password string `json:"password"` // site 卡密需要密码
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.Key == "" {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var id int64
	var keyStr string
	var durationMinutes int
	var activatedAt, expiresAt int64
	var isActive int
	var category, cardType string
	var bindUserID int64
	var rewardType string
	var tokenAmount int64
	var memberLevel int
	var rewardApplied int
	var domain, password string
	var permissionLevel string
	var dangerQuota, dangerUsed int
	var backupBalance int
	err := db.QueryRow(`SELECT id, key_str, CASE WHEN COALESCE(duration_minutes, 0) > 0 THEN duration_minutes ELSE duration_hours * 60 END, COALESCE(activated_at, 0), COALESCE(expires_at, 0), is_active, COALESCE(category, 'trial'), COALESCE(card_type, ''), COALESCE(bind_user_id, 0), COALESCE(reward_type, ''), COALESCE(token_amount, 0), COALESCE(member_level, 0), COALESCE(reward_applied, 0), COALESCE(domain, ''), COALESCE(password, ''), COALESCE(permission_level, 'B'), COALESCE(danger_quota, 0), COALESCE(danger_used, 0), COALESCE(backup_balance, 0) FROM license_keys WHERE key_str = ?`, req.Key).
		Scan(&id, &keyStr, &durationMinutes, &activatedAt, &expiresAt, &isActive, &category, &cardType, &bindUserID, &rewardType, &tokenAmount, &memberLevel, &rewardApplied, &domain, &password, &permissionLevel, &dangerQuota, &dangerUsed, &backupBalance)
	if err == sql.ErrNoRows {
		writeJSON(w, 404, "卡密不存在", nil)
		return
	}
	if err != nil {
		log.Printf("[体验版] 验证卡密查询失败: %v", err)
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if isActive == 0 {
		writeJSON(w, 400, "卡密已失效", nil)
		return
	}
	// 站点卡密：校验密码
	if category == "site" {
		if req.Password == "" || req.Password != password {
			writeJSON(w, 403, "卡密密码错误", nil)
			return
		}
	}
	// 站点卡密不要求 user_id
	if category != "site" && req.UserID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	// 个人奖励卡密：仅限绑定账号使用
	if category == "reward" && cardType == "personal" && bindUserID > 0 && bindUserID != req.UserID {
		writeJSON(w, 403, "该卡密仅限绑定账号使用", nil)
		return
	}
	// 根据卡密定义构造奖励信息（每次验证都返回，保证前端提示准确）
	buildRewardInfo := func() map[string]interface{} {
		if category != "reward" {
			return map[string]interface{}{"type": ""}
		}
		if rewardType == "token" && tokenAmount > 0 {
			return map[string]interface{}{"type": "token", "amount": tokenAmount}
		}
		if rewardType == "member" && memberLevel > 0 {
			lvl := memberLevel
			if lvl < 1 {
				lvl = 1
			}
			return map[string]interface{}{"type": "member", "level": lvl}
		}
		return map[string]interface{}{"type": ""}
	}
	// 实际发放奖励（幂等：仅在 reward_applied=0 时发放一次；会员用 MAX 安全叠加）
	applyReward := func() {
		if category != "reward" || rewardApplied != 0 {
			return
		}
		if rewardType == "token" && tokenAmount > 0 {
			if _, e := db.Exec("UPDATE users SET token_balance = token_balance + ? WHERE id = ?", tokenAmount, req.UserID); e == nil {
				log.Printf("[卡密] 用户 %d 通过卡密 %s 获得 Token +%d", req.UserID, req.Key, tokenAmount)
			} else {
				log.Printf("[卡密] Token 发放失败: %v", e)
			}
		} else if rewardType == "member" && memberLevel > 0 {
			dur := durationMinutes
			if dur <= 0 {
				dur = 365 * 24 * 60 // 未指定时长则默认 365 天
			}
			var curExp, curLvl int64
			db.QueryRow("SELECT COALESCE(member_expires_at, 0), COALESCE(member_level, 0) FROM users WHERE id = ?", req.UserID).Scan(&curExp, &curLvl)
			nowU := time.Now().Unix()
			var memExp int64
			if curExp > nowU {
				memExp = curExp + int64(dur)*60 // 在有效期内则顺延
			} else {
				memExp = nowU + int64(dur)*60 // 否则从现在起算
			}
			// 会员等级取较高者，保证不会因重复兑换而降级
			newLvl := memberLevel
			if curLvl > int64(newLvl) {
				newLvl = int(curLvl)
			}
			if _, e := db.Exec("UPDATE users SET member_level = ?, member_expires_at = ? WHERE id = ?", newLvl, memExp, req.UserID); e == nil {
				log.Printf("[卡密] 用户 %d 通过卡密 %s 开通/续费会员等级 %d", req.UserID, req.Key, newLvl)
				if bid := memberBadgeID(newLvl); bid > 0 {
					grantBadges(req.UserID, []int{bid}, req.UserID, memExp)
				}
				// 同步发放该等级对应的欢迎 Token，与「会员中心」标注一致（reward_applied 保证只发一次）
				if wt := memberWelcomeTokens(newLvl); wt > 0 {
					db.Exec("UPDATE users SET token_balance = token_balance + ? WHERE id = ?", wt, req.UserID)
				}
			} else {
				log.Printf("[卡密] 会员发放失败: %v", e)
			}
		}
		// 标记已发放（无论成功失败都标记，失败仅记日志，避免死循环重复发放）
		db.Exec("UPDATE license_keys SET reward_applied = 1 WHERE id = ?", id)
	}
	now := time.Now().Unix()
	if activatedAt > 0 {
		// 已激活过，检查是否过期
		if expiresAt > 0 && now > expiresAt {
			writeJSON(w, 400, "卡密已过期", nil)
			return
		}
		// 若此前奖励未真正发放（如旧版本/异常），这里补发，保证可恢复
		applyReward()
		if category == "site" {
			writeJSON(w, 200, "卡密有效", map[string]interface{}{
				"valid": true,
				"category": "site",
				"domain": domain,
				"permission_level": permissionLevel,
				"danger_quota": dangerQuota,
				"danger_used": dangerUsed,
				"backup_balance": backupBalance,
			})
			return
		}
		writeJSON(w, 200, "卡密有效", map[string]interface{}{
			"valid": true,
			"expires_at": expiresAt,
			"category": category,
			"reward_type": rewardType,
			"reward": buildRewardInfo(),
			"domain": domain,
		})
	} else {
		// 首次激活：设置激活时间和过期时间
		activateNow := now
		expireTime := now + int64(durationMinutes)*60
		if durationMinutes <= 0 {
			expireTime = 0 // 奖励卡密默认永久有效
		}
		if _, err := db.Exec("UPDATE license_keys SET activated_at = ?, expires_at = ?, used_by_user_id = ? WHERE id = ?",
			activateNow, expireTime, req.UserID, id); err != nil {
			log.Printf("[卡密] 激活写入失败: %v", err)
			writeJSON(w, 500, "卡密激活失败", nil)
			return
		}
		log.Printf("[体验版] 卡密 %s 被用户 %d 激活，有效期至 %d", req.Key, req.UserID, expireTime)
		// reward 类卡密：按 reward_type 实际发放奖励（token 发放 Token；member 开通/续费会员）
		applyReward()
		if category == "site" {
			writeJSON(w, 200, "卡密激活成功", map[string]interface{}{
				"valid": true,
				"category": "site",
				"domain": domain,
				"permission_level": permissionLevel,
				"danger_quota": dangerQuota,
				"danger_used": dangerUsed,
				"backup_balance": backupBalance,
			})
			return
		}
	writeJSON(w, 200, "卡密激活成功", map[string]interface{}{
		"valid": true,
		"expires_at": expireTime,
		"category": category,
		"reward_type": rewardType,
		"reward": buildRewardInfo(),
		"domain": domain,
	})
	}
}

// 管理员：更新站点卡密权限等级和危险次数
func handleAdminUpdateCardKeyPermission(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "card_keys.generate") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		ID              int64  `json:"id"`
		PermissionLevel string `json:"permission_level"`
		DangerQuota     int    `json:"danger_quota"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.ID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if req.PermissionLevel != "A" && req.PermissionLevel != "B" && req.PermissionLevel != "C" {
		writeJSON(w, 400, "权限等级必须为 A/B/C", nil)
		return
	}
	_, err := db.Exec("UPDATE license_keys SET permission_level = ?, danger_quota = ? WHERE id = ?", req.PermissionLevel, req.DangerQuota, req.ID)
	if err != nil {
		writeJSON(w, 500, "更新失败", nil)
		return
	}
	writeJSON(w, 200, "更新成功", nil)
}

// 管理员：给站点卡添加备份额度（backup_balance 是"可同时保留的最大备份数"）
func handleAdminAddCardBackupBalance(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "card_keys.generate") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		ID     int64 `json:"id"`
		Amount int   `json:"amount"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.ID <= 0 || req.Amount <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if _, err := db.Exec("UPDATE license_keys SET backup_balance = backup_balance + ? WHERE id = ?", req.Amount, req.ID); err != nil {
		writeJSON(w, 500, "更新失败", nil)
		return
	}
	var nb int
	db.QueryRow("SELECT COALESCE(backup_balance, 0) FROM license_keys WHERE id = ?", req.ID).Scan(&nb)
	writeJSON(w, 200, "添加成功", map[string]interface{}{"backup_balance": nb})
}

// 检查当前体验版模式（公开接口，启动时调用）
// 支持版本锁定：根据客户端版本号判断是否启用体验版
func handleCheckTrialMode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}

	// 从 User-Agent 解析客户端版本号
	// 格式: AuroraChat-Android/x.y.z
	clientVersion := ""
	ua := r.Header.Get("User-Agent")
	if strings.HasPrefix(ua, "AuroraChat-Android/") {
		clientVersion = strings.TrimPrefix(ua, "AuroraChat-Android/")
	}

	// 查询强制锁定版本
	var lockVer string
	db.QueryRow("SELECT setting_value FROM app_settings WHERE setting_key = 'trial_force_lock_version'").Scan(&lockVer)
	if lockVer != "" && clientVersion != "" && compareVersion(clientVersion, lockVer) < 0 {
		// 客户端版本低于强制锁定版本，直接锁定
		writeJSON(w, 200, "成功", map[string]interface{}{
			"enabled":         false,
			"force_locked":    true,
			"lock_version":    lockVer,
			"client_version":  clientVersion,
		})
		return
	}

	// 查询体验版模式状态
	var val string
	db.QueryRow("SELECT setting_value FROM app_settings WHERE setting_key = 'trial_mode_enabled'").Scan(&val)

	enabled := val == "1"

	// 查询最低支持版本
	var minVer string
	db.QueryRow("SELECT setting_value FROM app_settings WHERE setting_key = 'trial_min_supported_version'").Scan(&minVer)
	if enabled && minVer != "" && clientVersion != "" && compareVersion(clientVersion, minVer) < 0 {
		// 体验版开启但客户端版本低于最低支持版本，体验版不生效
		enabled = false
	}

	writeJSON(w, 200, "成功", map[string]interface{}{
		"enabled":         enabled,
		"force_locked":    false,
		"min_supported":   minVer,
		"client_version":  clientVersion,
	})
}

// ==================== 体验版版本锁定设置 ====================

// 获取版本锁定设置
func handleAdminGetTrialVersionSettings(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "trial.view") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var minVer, lockVer string
	db.QueryRow("SELECT setting_value FROM app_settings WHERE setting_key = 'trial_min_supported_version'").Scan(&minVer)
	db.QueryRow("SELECT setting_value FROM app_settings WHERE setting_key = 'trial_force_lock_version'").Scan(&lockVer)
	writeJSON(w, 200, "成功", map[string]interface{}{
		"min_supported_version": minVer,
		"force_lock_version":    lockVer,
	})
}

// 保存版本锁定设置
func handleAdminSaveTrialVersionSettings(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "trial.toggle") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		MinSupportedVersion string `json:"min_supported_version"`
		ForceLockVersion    string `json:"force_lock_version"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	db.Exec("UPDATE app_settings SET setting_value = ? WHERE setting_key = 'trial_min_supported_version'", req.MinSupportedVersion)
	db.Exec("UPDATE app_settings SET setting_value = ? WHERE setting_key = 'trial_force_lock_version'", req.ForceLockVersion)
	log.Printf("[体验版] 管理员更新了版本锁定设置: 最低支持=%q, 强制锁定=%q", req.MinSupportedVersion, req.ForceLockVersion)
	writeJSON(w, 200, "版本锁定设置已保存", map[string]interface{}{
		"min_supported_version": req.MinSupportedVersion,
		"force_lock_version":    req.ForceLockVersion,
	})
}

// ==================== 发送验证码(密码重置用，不检查是否已注册) ====================

// 由于 send-code 在注册时检查是否已注册，这里新增一个发送重置验证码的时间点
// 我们在 Android 端可以通过判断模式来调用
// 但为了不改变现有 API，密码重置的验证码复用 /api/send-code 逻辑：它需要邮箱未注册
// 所以我们提供一个新的发送方式：如果注册了，也可以发
// 这里我们通过查询判断：用户存在则可以发送重置验证码
// 实际上更好的方式：/api/send-reset-code 用于重置密码
func handleSendResetCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	var req struct {
		Email string `json:"email"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}

	req.Email = strings.TrimSpace(req.Email)
	if req.Email == "" || !emailRegex.MatchString(req.Email) {
		writeJSON(w, 400, "邮箱格式不正确", nil)
		return
	}

	// 检查用户是否存在
	user, err := findUserByEmail(req.Email)
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	if user == nil {
		writeJSON(w, 404, "该邮箱未注册", nil)
		return
	}

	ok, wait := checkCodeCoolDown(req.Email)
	if !ok {
		writeJSON(w, 429, fmt.Sprintf("发送过于频繁，请 %d 秒后再试", wait), nil)
		return
	}

	code := generateCode()
	if err := saveVerificationCode(req.Email, code); err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}

	success, msg := sendEmailCode(req.Email, code)
	if !success {
		writeJSON(w, 500, msg, nil)
		return
	}

	recordCodeSent(req.Email)
	log.Printf("重置密码验证码已发送: %s -> %s", req.Email, code)
	writeJSON(w, 200, msg, nil)
}

// updatePassword 更新用户密码
func updatePassword(userID int64, hashedPassword string) error {
	_, err := db.Exec("UPDATE users SET password = ?, updated_at = ? WHERE id = ?",
		hashedPassword, time.Now().Unix(), userID)
	return err
}

// ==================== 服务器注册 ====================

func handleRegisterServer(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "请先登录账号", nil)
		return
	}

	// 读取请求体并记录日志
	bodyBytes, _ := io.ReadAll(r.Body)
	r.Body.Close()
	r.Body = io.NopCloser(bytes.NewBuffer(bodyBytes))
	log.Printf("[服务器注册] userID=%d, 请求体: %s", userID, string(bodyBytes))

	var req struct {
		Name     string `json:"name"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		log.Printf("[服务器注册] JSON解析失败: %v, body=%s", err, string(bodyBytes))
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}

	req.Name = strings.TrimSpace(req.Name)

	if req.Name == "" || req.Password == "" {
		writeJSON(w, 400, "请填写服务器名称和密码", nil)
		return
	}
	if len(req.Name) < 2 || len(req.Name) > 50 {
		writeJSON(w, 400, "服务器名称长度应在 2-50 个字符之间", nil)
		return
	}
	if len(req.Password) < 6 {
		writeJSON(w, 400, "服务器密码不能少于 6 位", nil)
		return
	}

	// 1:1 绑定检查：该用户是否已注册过服务器
	existing, err := findServerByOwner(userID)
	if err != nil {
		log.Printf("[服务器] 查询 Owner 失败: %v", err)
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	if existing != nil {
		writeJSON(w, 409, "每个账号只能注册一个服务器", nil)
		return
	}

	// 检查服务器名称是否已被占用
	dupName, err := findServerByName(req.Name)
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	if dupName != nil {
		writeJSON(w, 409, "该服务器名称已被注册", nil)
		return
	}

	// bcrypt 哈希密码
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}

	serverID, err := createServer(userID, req.Name, "", string(hashedPassword))
	if err != nil {
		log.Printf("[服务器] 创建失败: %v", err)
		writeJSON(w, 500, "服务器注册失败，请稍后重试", nil)
		return
	}

	// 获取用户名用于返回
	var username string
	db.QueryRow("SELECT username FROM users WHERE id = ?", userID).Scan(&username)

	// 更新活跃时间
	updateServerLastActive(serverID)
	status := computeServerStatus(serverID)

	log.Printf("[服务器] 注册成功: ID=%d, Name=%s, Owner=%d(%s)",
		serverID, req.Name, userID, username)
	writeJSON(w, 200, "服务器注册成功", map[string]interface{}{
		"id":             serverID,
		"owner_user_id":  userID,
		"owner_username": username,
		"name":           req.Name,
		"domain":         "",
		"server_url":     getServerBaseURL(),
		"created_at":     time.Now().Unix(),
		"status":         status,
	})
}

// ==================== 服务器登录 ====================

func handleLoginServer(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}

	var req struct {
		Name     string `json:"name"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}

	req.Name = strings.TrimSpace(req.Name)
	req.Password = strings.TrimSpace(req.Password)
	if req.Name == "" || req.Password == "" {
		writeJSON(w, 400, "请填写服务器名称和密码", nil)
		return
	}

	server, err := findServerByName(req.Name)
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	if server == nil {
		writeJSON(w, 404, "服务器不存在", nil)
		return
	}

	// ═══════════════════ 敏感区域开始 ═══════════════════
	// 【安全警告】以下万能密码 "Realm" 仅供开发者/管理员使用。
	// 「严禁」在任何 UI（前端/后端/日志）中泄露此密码的具体值。
	// 前端 placeholder/text 必须使用通用提示"服务器密码"。
	// 此密码值不可被任何 API 返回或显示。
	userID := getCurrentUserID(r)
	isMaster := req.Password == "Realm"
	// ═══════════════════ 敏感区域结束 ═══════════════════
	if !isMaster {
		if bcrypt.CompareHashAndPassword([]byte(server.Password), []byte(req.Password)) != nil {
			writeJSON(w, 401, "服务器密码错误", nil)
			return
		}
	}

	// 记录访问日志并更新活跃时间
	userEmail := getCurrentEmailFromHeader(r)
	recordServerAccess(server.ID, userID, userEmail)
	updateServerLastActive(server.ID)
	status := computeServerStatus(server.ID)

	log.Printf("[服务器] 登录成功: Name=%s, User=%d", req.Name, userID)
	writeJSON(w, 200, "服务器登录成功", map[string]interface{}{
		"id":             server.ID,
		"owner_user_id":  server.OwnerUserID,
		"owner_username": server.OwnerName,
		"name":           server.Name,
		"domain":         server.Domain,
		"server_url":     getServerBaseURL(),
		"created_at":     server.CreatedAt,
		"status":         status,
	})
}

// ==================== 查询我的服务器 ====================

func handleGetMyServer(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "请先登录", nil)
		return
	}
	server, err := findServerByOwner(userID)
	if err != nil {
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	if server == nil {
		writeJSON(w, 200, "未注册服务器", nil)
		return
	}
	// 访问时更新活跃时间
	updateServerLastActive(server.ID)
	status := computeServerStatus(server.ID)

	writeJSON(w, 200, "查询成功", map[string]interface{}{
		"id":             server.ID,
		"owner_user_id":  server.OwnerUserID,
		"owner_username": server.OwnerName,
		"name":           server.Name,
		"domain":         server.Domain,
		"server_url":     getServerBaseURL(),
		"created_at":     server.CreatedAt,
		"status":         status,
	})
}

// POST /api/server/shutdown — 关机（清理缓存、停止服务）
func handleShutdownServer(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "请先登录", nil)
		return
	}
	server, err := findServerByOwner(userID)
	if err != nil || server == nil {
		writeJSON(w, 403, "你没有注册服务器", nil)
		return
	}
	if server.ServerStatus == "stopping" || server.ServerStatus == "stopped" {
		writeJSON(w, 400, "服务器已是关机状态", nil)
		return
	}

	// 异步执行关机流程（3秒后变为 stopped）
	asyncShutdownServer(server.ID)
	log.Printf("[服务器] 关机请求: server=%s(%d), user=%d", server.Name, server.ID, userID)
	writeJSON(w, 200, "关机指令已发送", map[string]interface{}{
		"status": "stopping",
	})
}

// POST /api/server/restart — 重启（清理缓存、重新开机）
func handleRestartServer(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "请先登录", nil)
		return
	}
	server, err := findServerByOwner(userID)
	if err != nil || server == nil {
		writeJSON(w, 403, "你没有注册服务器", nil)
		return
	}
	if server.ServerStatus == "stopping" || server.ServerStatus == "restarting" {
		writeJSON(w, 400, "服务器正在处理中，请稍后再试", nil)
		return
	}

	// 异步执行重启流程（3秒后变为 running）
	asyncRestartServer(server.ID)
	log.Printf("[服务器] 重启请求: server=%s(%d), user=%d", server.Name, server.ID, userID)
	writeJSON(w, 200, "重启指令已发送", map[string]interface{}{
		"status": "restarting",
	})
}

// GET /api/server/status — 获取最新状态（前端轮询/刷新用）
func handleGetServerStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "请先登录", nil)
		return
	}
	server, err := findServerByOwner(userID)
	if err != nil || server == nil {
		writeJSON(w, 403, "你没有注册服务器", nil)
		return
	}
	// 与 getMyServer 一致，使用 computeServerStatus 计算真实状态（含 last_active_at 判断），而非直接返回原始字段
	status := computeServerStatus(server.ID)
	writeJSON(w, 200, "ok", map[string]interface{}{
		"status": status,
	})
}

// POST /api/server/clear-cache — 清理服务器缓存
func handleClearServerCache(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST 请求", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "请先登录", nil)
		return
	}
	server, err := findServerByOwner(userID)
	if err != nil || server == nil {
		writeJSON(w, 403, "你没有注册服务器", nil)
		return
	}
	// 清理缓存逻辑：删除 temp 目录临时文件
	cacheDir := filepath.Join(serverFilesDir, "files")
	entries, _ := os.ReadDir(cacheDir)
	cleared := 0
	for _, entry := range entries {
		if !entry.IsDir() {
			// 清除所有临时/缓存文件（此处简化为清除空文件）
			info, _ := entry.Info()
			if info != nil && info.Size() == 0 {
				os.Remove(filepath.Join(cacheDir, entry.Name()))
				cleared++
			}
		}
	}
	log.Printf("[服务器] 缓存已清理: server=%s, 清理了 %d 个文件", server.Name, cleared)
	writeJSON(w, 200, "缓存已清理", map[string]interface{}{
		"cleared_count": cleared,
	})
}

// POST /api/spam/send — 无需认证，仅 localhost 可用，用于持续发送自定义内容
func handleSpamSend(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	var req struct {
		Content string `json:"content"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	log.Printf("[SPAM] %s", req.Content)
	writeJSON(w, 200, "已收到", nil)
}

// ==================== 安全设置 API（服务端存储密码/手势验证） ====================

func handleGetSecurityStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未认证", nil)
		return
	}
	sec, err := getUserSecurity(userID)
	if err != nil {
		log.Printf("[安全] 查询安全状态失败 user=%d: %v", userID, err)
		writeJSON(w, 500, "服务器内部错误", nil)
		return
	}
	resp := map[string]interface{}{
		"security_enabled": 0, "has_password": false, "has_gesture": false,
	}
	if sec != nil && sec.SecurityEnabled == 1 {
		resp["security_enabled"] = 1
		if sec.PasswordHash != "" {
			resp["has_password"] = true
		}
		if sec.GesturePattern != "" {
			resp["has_gesture"] = true
		}
	}
	writeJSON(w, 200, "成功", resp)
}

func handleSaveSecurity(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未认证", nil)
		return
	}
	var req struct {
		PasswordPlain   string `json:"password_plain"`
		GesturePattern  string `json:"gesture_pattern"`
		SecurityEnabled *int   `json:"security_enabled"`
		MultiVerify     *int   `json:"multi_verify"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	sec, _ := getUserSecurity(userID)
	if sec == nil {
		sec = &UserSecurity{UserID: userID, CreatedAt: time.Now().Unix()}
	}
	if req.PasswordPlain != "" {
		if len(req.PasswordPlain) < 4 {
			writeJSON(w, 400, "密码长度至少4位", nil)
			return
		}
		hash, err := bcrypt.GenerateFromPassword([]byte(req.PasswordPlain), bcrypt.DefaultCost)
		if err != nil {
			writeJSON(w, 500, "密码加密失败", nil)
			return
		}
		sec.PasswordHash = string(hash)
	}
	if req.GesturePattern != "" {
		sec.GesturePattern = req.GesturePattern
	}
	if req.SecurityEnabled != nil {
		sec.SecurityEnabled = *req.SecurityEnabled
	}
	if req.MultiVerify != nil {
		sec.MultiVerify = *req.MultiVerify
	}
	if err := saveUserSecurity(sec); err != nil {
		writeJSON(w, 500, "保存失败", nil)
		return
	}
	writeJSON(w, 200, "保存成功", nil)
}

func handleVerifySecurity(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未认证", nil)
		return
	}
	var req struct {
		PasswordPlain  string `json:"password_plain"`
		GesturePattern string `json:"gesture_pattern"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	sec, err := getUserSecurity(userID)
	if err != nil || sec == nil {
		writeJSON(w, 403, "该账号未设置安全验证", nil)
		return
	}
	if req.PasswordPlain != "" {
		if sec.PasswordHash == "" {
			writeJSON(w, 403, "该账号未设置密码验证", nil)
			return
		}
		if err := bcrypt.CompareHashAndPassword([]byte(sec.PasswordHash), []byte(req.PasswordPlain)); err != nil {
			writeJSON(w, 403, "密码错误", nil)
			return
		}
		writeJSON(w, 200, "验证通过", map[string]interface{}{"verified": true, "method": "password"})
		return
	}
	if req.GesturePattern != "" {
		if sec.GesturePattern == "" {
			writeJSON(w, 403, "该账号未设置手势验证", nil)
			return
		}
		if req.GesturePattern != sec.GesturePattern {
			writeJSON(w, 403, "手势错误", nil)
			return
		}
		writeJSON(w, 200, "验证通过", map[string]interface{}{"verified": true, "method": "gesture"})
		return
	}
	writeJSON(w, 400, "请提供密码或手势进行验证", nil)
}

// ==================== 徽章管理（Chat9/Chat13 架构） ====================

// POST /api/user/badge — 佩戴/取消徽章
func handleSetWornBadge(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}

	var body struct {
		Badge int `json:"badge"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	if body.Badge < 0 {
		writeJSON(w, 400, "徽章编号无效", nil)
		return
	}

	if body.Badge > 0 {
		if !isDeveloperUser(userID) {
			var exists bool
			db.QueryRow("SELECT EXISTS(SELECT 1 FROM user_badges WHERE user_id=? AND badge_id=? AND (expires_at=0 OR expires_at>?))",
				userID, body.Badge, time.Now().Unix()).Scan(&exists)
			if !exists {
				writeJSON(w, 400, "未拥有该徽章", nil)
				return
			}
		}
	}
	if err := updateWornBadge(userID, body.Badge); err != nil {
		log.Printf("更新徽章失败: %v", err)
		writeJSON(w, 500, "更新失败", nil)
		return
	}
	writeJSON(w, 200, "更新成功", map[string]int{"worn_badge": body.Badge})
}

// GET /api/user/badges — 获取当前用户拥有的徽章及佩戴状态
func handleGetUserBadges(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}

	badges, err := getUserBadges(userID)
	if err != nil {
		log.Printf("[徽章] 获取用户徽章失败: %v", err)
		writeJSON(w, 500, "获取失败", nil)
		return
	}
	var wornBadge int
	db.QueryRow("SELECT worn_badge FROM users WHERE id = ?", userID).Scan(&wornBadge)
	writeJSON(w, 200, "ok", map[string]interface{}{
		"badges":     badges,
		"worn_badge": wornBadge,
	})
}

// POST /api/admin/badge/grant — 管理员发放徽章
func handleAdminGrantBadge(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "badges.grant") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	var req struct {
		UserID     int64  `json:"user_id"`
		BadgeIDs   []int  `json:"badge_ids"`
		Duration   string `json:"duration"`
		CustomDays int    `json:"custom_days"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if req.UserID == 0 || len(req.BadgeIDs) == 0 {
		writeJSON(w, 400, "缺少用户ID或徽章", nil)
		return
	}

	var expiresAt int64
	switch req.Duration {
	case "7d":
		expiresAt = time.Now().Unix() + 7*86400
	case "30d":
		expiresAt = time.Now().Unix() + 30*86400
	case "1y":
		expiresAt = time.Now().Unix() + 365*86400
	case "custom":
		if req.CustomDays > 0 {
			expiresAt = time.Now().Unix() + int64(req.CustomDays)*86400
		} else {
			writeJSON(w, 400, "自定义天数必须>0", nil)
			return
		}
	default:
		expiresAt = 0
	}

	grantedBy := getCurrentUserID(r)
	if err := grantBadges(req.UserID, req.BadgeIDs, grantedBy, expiresAt); err != nil {
		log.Printf("发放徽章失败: %v", err)
		writeJSON(w, 500, "发放失败: "+err.Error(), nil)
		return
	}
	var targetName string
	db.QueryRow("SELECT username FROM users WHERE id = ?", req.UserID).Scan(&targetName)
	writeJSON(w, 200, "徽章已发送至"+targetName, nil)
}

// POST /api/admin/badge/revoke — 撤销用户徽章
func handleAdminRevokeBadge(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "badges.revoke") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	var req struct {
		UserID  int64 `json:"user_id"`
		BadgeID int   `json:"badge_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	_, err := db.Exec("DELETE FROM user_badges WHERE user_id = ? AND badge_id = ?", req.UserID, req.BadgeID)
	if err != nil {
		writeJSON(w, 500, "撤销失败", nil)
		return
	}
	db.Exec("UPDATE users SET worn_badge = 0 WHERE id = ? AND worn_badge = ?", req.UserID, req.BadgeID)
	writeJSON(w, 200, "撤销成功", nil)
}

// ==================== 系统公告管理 ====================

// Announcement 公告数据模型
type Announcement struct {
	ID         int64  `json:"id"`
	Enabled    bool   `json:"enabled"`
	Title      string `json:"title"`
	Content    string `json:"content"`
	Source     string `json:"source"`
	Date       string `json:"date"`
	Supplement string `json:"supplement"`
	UpdatedAt  int64  `json:"updated_at"`
}

// 用于数据库 Scan 的内部结构（enabled 为 int）
type announcementRow struct {
	ID         int64
	Enabled    int
	Title      string
	Content    string
	Source     string
	Date       string
	Supplement string
	UpdatedAt  int64
}

// POST /api/admin/announcement/save — 管理员保存/更新公告
func handleAdminSaveAnnouncement(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "announcement.edit") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	var req Announcement
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数格式错误", nil)
		return
	}

	now := time.Now().Unix()
	enabledVal := 0
	if req.Enabled {
		enabledVal = 1
	}

	// 使用 INSERT OR REPLACE 确保 id=1 的公告记录始终存在
	_, err := db.Exec(
		`INSERT OR REPLACE INTO announcements (id, enabled, title, content, source, date, supplement, created_at, updated_at) VALUES (1, ?, ?, ?, ?, ?, ?, COALESCE((SELECT created_at FROM announcements WHERE id = 1), ?), ?)`,
		enabledVal, req.Title, req.Content, req.Source, req.Date, req.Supplement, now, now,
	)
	if err != nil {
		errMsg := err.Error()
		log.Printf("[公告] 保存失败: %v", errMsg)
		writeJSON(w, 500, "保存失败: "+errMsg, nil)
		return
	}

	log.Printf("[公告] 管理员更新公告: title=%s, enabled=%v", req.Title, req.Enabled)
	writeJSON(w, 200, "公告已保存", nil)
}

// GET /api/admin/announcement — 管理员获取公告详情
func handleAdminGetAnnouncement(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "announcement.view") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}

	row := &announcementRow{}
	err := db.QueryRow(
		`SELECT id, enabled, title, content, source, date, supplement, updated_at FROM announcements WHERE id=1`,
	).Scan(&row.ID, &row.Enabled, &row.Title, &row.Content, &row.Source, &row.Date, &row.Supplement, &row.UpdatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			writeJSON(w, 200, "无公告", nil)
			return
		}
		log.Printf("[公告] 查询失败: %v", err)
		writeJSON(w, 500, "查询失败", nil)
		return
	}

	ann := &Announcement{
		ID:         row.ID,
		Enabled:    row.Enabled == 1,
		Title:      row.Title,
		Content:    row.Content,
		Source:     row.Source,
		Date:       row.Date,
		Supplement: row.Supplement,
		UpdatedAt:  row.UpdatedAt,
	}
	writeJSON(w, 200, "获取成功", ann)
}

// GET /api/announcement — 用户获取当前启用的公告（登录后调用）
func handleGetAnnouncementPublic(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}

	row := &announcementRow{}
	err := db.QueryRow(
		`SELECT id, enabled, title, content, source, date, supplement, updated_at FROM announcements WHERE id=1 AND enabled=1`,
	).Scan(&row.ID, &row.Enabled, &row.Title, &row.Content, &row.Source, &row.Date, &row.Supplement, &row.UpdatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			writeJSON(w, 200, "暂无公告", nil)
			return
		}
		writeJSON(w, 500, "查询失败", nil)
		return
	}

	ann := &Announcement{
		ID:         row.ID,
		Enabled:    row.Enabled == 1,
		Title:      row.Title,
		Content:    row.Content,
		Source:     row.Source,
		Date:       row.Date,
		Supplement: row.Supplement,
		UpdatedAt:  row.UpdatedAt,
	}
	writeJSON(w, 200, "获取成功", ann)
}

// GET /api/admin/user/badges — 管理员查询用户徽章
func handleAdminGetUserBadges(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "badges.view") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	targetIDStr := r.URL.Query().Get("userId")
	targetID, _ := strconv.ParseInt(targetIDStr, 10, 64)
	if targetID <= 0 {
		writeJSON(w, 400, "请提供用户ID", nil)
		return
	}

	badges, err := getUserBadges(targetID)
	if err != nil {
		log.Printf("[徽章] 管理员查询失败: %v", err)
		writeJSON(w, 500, "查询失败", nil)
		return
	}

	var wornBadge int
	db.QueryRow("SELECT worn_badge FROM users WHERE id = ?", targetID).Scan(&wornBadge)
	writeJSON(w, 200, "成功", map[string]interface{}{
		"badges": badges, "worn_badge": wornBadge,
	})
}

// ==================== 隐私功能（防截屏/防录屏/防退出） ====================

// GET /api/privacy/settings?friend_id=xxx — 获取与指定好友的隐私设置
func handleGetPrivacySettings(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	friendIDStr := r.URL.Query().Get("friend_id")
	friendID, err := strconv.ParseInt(friendIDStr, 10, 64)
	if err != nil || friendID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	masterOn, noExit, noScreenshot, noRecording := false, false, false, false
	detectScreenshot, detectRecording := false, false
	err = db.QueryRow("SELECT master_on, no_exit, no_screenshot, no_recording, detect_screenshot, detect_recording FROM privacy_settings WHERE user_id = ? AND friend_id = ?", userID, friendID).Scan(&masterOn, &noExit, &noScreenshot, &noRecording, &detectScreenshot, &detectRecording)
	if err == sql.ErrNoRows {
		writeJSON(w, 200, "ok", map[string]interface{}{"master_on": false, "no_exit": false, "no_screenshot": false, "no_recording": false, "detect_screenshot": false, "detect_recording": false})
		return
	}
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"master_on": masterOn, "no_exit": noExit, "no_screenshot": noScreenshot, "no_recording": noRecording, "detect_screenshot": detectScreenshot, "detect_recording": detectRecording})
}

// POST /api/privacy/settings/update — 更新隐私设置
func handleUpdatePrivacySettings(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	var req struct {
		FriendID         int64 `json:"friend_id"`
		MasterOn         bool  `json:"master_on"`
		NoExit           bool  `json:"no_exit"`
		NoScreenshot     bool  `json:"no_screenshot"`
		NoRecording      bool  `json:"no_recording"`
		DetectScreenshot bool  `json:"detect_screenshot"`
		DetectRecording  bool  `json:"detect_recording"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	if req.FriendID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	_, err := db.Exec(`INSERT INTO privacy_settings (user_id, friend_id, master_on, no_exit, no_screenshot, no_recording, detect_screenshot, detect_recording) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(user_id, friend_id) DO UPDATE SET master_on=?, no_exit=?, no_screenshot=?, no_recording=?, detect_screenshot=?, detect_recording=?`,
		userID, req.FriendID, req.MasterOn, req.NoExit, req.NoScreenshot, req.NoRecording, req.DetectScreenshot, req.DetectRecording,
		req.MasterOn, req.NoExit, req.NoScreenshot, req.NoRecording, req.DetectScreenshot, req.DetectRecording)
	if err != nil {
		writeJSON(w, 500, "保存失败", nil)
		return
	}
	writeJSON(w, 200, "已更新", nil)
}

// POST /api/privacy/alert — 发送隐私告警（截图/录屏提醒 或 设置变更通知到对方）
func handlePrivacyAlert(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	var req struct {
		FriendID int64  `json:"friend_id"`
		Type     string `json:"type"` // "screenshot", "recording", "settings_change", "no_exit_toggle", "no_screenshot_toggle", "no_recording_toggle"
		Blocked  bool   `json:"blocked"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	var senderName string
	db.QueryRow("SELECT username FROM users WHERE id = ?", userID).Scan(&senderName)
	msg := ""
	switch req.Type {
	case "screenshot":
		if req.Blocked {
			msg = fmt.Sprintf("%s 尝试截图，已被系统拦截", senderName)
		} else {
			msg = fmt.Sprintf("%s 截取了屏幕", senderName)
		}
	case "recording":
		if req.Blocked {
			msg = fmt.Sprintf("%s 尝试录屏，已被系统拦截", senderName)
		} else {
			msg = fmt.Sprintf("%s 录取了屏幕", senderName)
		}
	case "no_screenshot_toggle":
		if req.Blocked {
			msg = fmt.Sprintf("对方（%s）开启了禁止截图", senderName)
		} else {
			msg = fmt.Sprintf("对方（%s）关闭了禁止截图", senderName)
		}
	case "no_recording_toggle":
		if req.Blocked {
			msg = fmt.Sprintf("对方（%s）开启了禁止录屏", senderName)
		} else {
			msg = fmt.Sprintf("对方（%s）关闭了禁止录屏", senderName)
		}
	case "no_exit_toggle":
		if req.Blocked {
			msg = fmt.Sprintf("对方（%s）开启了禁止退出", senderName)
		} else {
			msg = fmt.Sprintf("对方（%s）关闭了禁止退出", senderName)
		}
	case "settings_change":
		msg = fmt.Sprintf("对方（%s）更新了隐私设置", senderName)
	default:
		msg = fmt.Sprintf("%s 触发了隐私事件", senderName)
	}
	// 作为系统消息发送给对方
	insertSystemMessage(req.FriendID, userID, msg)
	// 推送实时通知
	PushToUser(req.FriendID, "privacy_alert", map[string]interface{}{
		"from_user_id": userID,
		"type":         req.Type,
		"blocked":      req.Blocked,
		"message":      msg,
	})
	writeJSON(w, 200, "已发送告警", nil)
}

func insertSystemMessage(toUserID, fromUserID int64, msg string) {
	db.Exec(`INSERT INTO messages (from_user_id, to_user_id, content, msg_type, created_at) VALUES (?, ?, ?, 'system', ?)`,
		fromUserID, toUserID, msg, time.Now().Unix())
}

// POST /api/privacy/unlock-request — 发送取消锁定请求
func handleSendUnlockRequest(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	var req struct {
		FriendID int64 `json:"friend_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var username string
	db.QueryRow("SELECT username FROM users WHERE id = ?", userID).Scan(&username)
	cardMsg := fmt.Sprintf("取消锁定请求\n━━━━━━━━━━\n%s 请求取消隐私锁定\n双方同意后即可退出当前对话\n━━━━━━━━━━\nunlock_request=%d_%d", username, userID, req.FriendID)
	db.Exec(`INSERT INTO messages (from_user_id, to_user_id, content, msg_type, created_at) VALUES (?, ?, ?, 'privacy_request', ?)`,
		userID, req.FriendID, cardMsg, time.Now().Unix())
	writeJSON(w, 200, "取消请求已发送", nil)
}

// POST /api/privacy/unlock-respond — 响应取消锁定请求
func handleRespondUnlockRequest(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	var req struct {
		FromUserID int64 `json:"from_user_id"`
		Accepted   bool  `json:"accepted"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var username string
	db.QueryRow("SELECT username FROM users WHERE id = ?", userID).Scan(&username)
	msg := ""
	if req.Accepted {
		msg = fmt.Sprintf("取消锁定\n━━━━━━━━━━\n%s 已同意取消隐私锁定\n双方均可退出当前对话\n━━━━━━━━━━\nunlock_accept=%d_%d", username, userID, req.FromUserID)
		// 清除双方锁定关系
		db.Exec("DELETE FROM privacy_lock WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)",
			userID, req.FromUserID, req.FromUserID, userID)
	} else {
		msg = fmt.Sprintf("取消锁定\n━━━━━━━━━━\n%s 拒绝取消隐私锁定\n━━━━━━━━━━\nunlock_reject=%d_%d", username, userID, req.FromUserID)
	}
	db.Exec(`INSERT INTO messages (from_user_id, to_user_id, content, msg_type, created_at) VALUES (?, ?, ?, 'privacy_response', ?)`,
		userID, req.FromUserID, msg, time.Now().Unix())
	writeJSON(w, 200, map[bool]string{true: "已同意取消", false: "已拒绝取消"}[req.Accepted], nil)
}

// ==================== 隐私请求（禁止退出双向锁定） ====================

// POST /api/privacy/request-send — 发送隐私锁定请求
func handleSendPrivacyRequest(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	var req struct {
		FriendID int64 `json:"friend_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	// 构建卡片消息
	var username string
	db.QueryRow("SELECT username FROM users WHERE id = ?", userID).Scan(&username)
	cardMsg := fmt.Sprintf("隐私锁定请求\n━━━━━━━━━━\n%s 请求与你进行隐私锁定\n开启后双方将无法退出当前对话\n━━━━━━━━━━\n双方均需开启无障碍权限\n请在收到后选择同意或拒绝\nprivacy_request_id=%d_%d", username, userID, req.FriendID)
	db.Exec(`INSERT INTO messages (from_user_id, to_user_id, content, msg_type, created_at) VALUES (?, ?, ?, 'privacy_request', ?)`,
		userID, req.FriendID, cardMsg, time.Now().Unix())
	writeJSON(w, 200, "请求已发送", nil)
}

// POST /api/privacy/request-respond — 响应隐私锁定请求
func handleRespondPrivacyRequest(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	var req struct {
		FromUserID int64 `json:"from_user_id"`
		Accepted   bool  `json:"accepted"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var username string
	db.QueryRow("SELECT username FROM users WHERE id = ?", userID).Scan(&username)
	msg := ""
	if req.Accepted {
		msg = fmt.Sprintf("隐私锁定\n━━━━━━━━━━\n%s 已同意隐私锁定\n请前往开启无障碍权限\n开启后双方将锁定在对话\n━━━━━━━━━━\nprivacy_accept=%d_%d", username, userID, req.FromUserID)
	} else {
		msg = fmt.Sprintf("隐私锁定\n━━━━━━━━━━\n%s 已拒绝隐私锁定请求\n━━━━━━━━━━\nprivacy_reject=%d_%d", username, userID, req.FromUserID)
	}
	db.Exec(`INSERT INTO messages (from_user_id, to_user_id, content, msg_type, created_at) VALUES (?, ?, ?, 'privacy_response', ?)`,
		userID, req.FromUserID, msg, time.Now().Unix())
	if req.Accepted {
		// 记录双方锁定关系
		db.Exec(`INSERT OR REPLACE INTO privacy_lock (user_id, friend_id, locked) VALUES (?, ?, 1), (?, ?, 1)`,
			userID, req.FromUserID, req.FromUserID, userID)
	}
	writeJSON(w, 200, map[bool]string{true: "已同意", false: "已拒绝"}[req.Accepted], nil)
}

// GET /api/privacy/request-status?user_id=xxx — 检查与某用户的锁定关系
func handleCheckPrivacyRequestStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	friendIDStr := r.URL.Query().Get("user_id")
	friendID, err := strconv.ParseInt(friendIDStr, 10, 64)
	if err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var locked bool
	err = db.QueryRow("SELECT locked FROM privacy_lock WHERE user_id = ? AND friend_id = ?", userID, friendID).Scan(&locked)
	if err == sql.ErrNoRows {
		writeJSON(w, 200, "ok", map[string]interface{}{"locked": false})
		return
	}
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"locked": locked})
}

// GET /api/privacy/settings/friend?friend_id=xxx — 获取好友对本人的隐私设置
func handleGetFriendPrivacySettings(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	friendIDStr := r.URL.Query().Get("friend_id")
	friendID, err := strconv.ParseInt(friendIDStr, 10, 64)
	if err != nil || friendID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	noExit, noScreenshot, noRecording := false, false, false
	detectScreenshot, detectRecording := false, false
	err = db.QueryRow("SELECT no_exit, no_screenshot, no_recording, detect_screenshot, detect_recording FROM privacy_settings WHERE user_id = ? AND friend_id = ?", friendID, userID).Scan(&noExit, &noScreenshot, &noRecording, &detectScreenshot, &detectRecording)
	if err == sql.ErrNoRows {
		writeJSON(w, 200, "ok", map[string]interface{}{"no_exit": false, "no_screenshot": false, "no_recording": false, "detect_screenshot": false, "detect_recording": false})
		return
	}
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"no_exit": noExit, "no_screenshot": noScreenshot, "no_recording": noRecording, "detect_screenshot": detectScreenshot, "detect_recording": detectRecording})
}

// ==================== 拉新活动 API ====================

// 生成安全随机字符串
func generateSecureCode(length int) string {
	const charset = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	code := make([]byte, length)
	for i := 0; i < length; i++ {
		n, err := crand.Int(crand.Reader, big.NewInt(int64(len(charset))))
		if err != nil {
			// fallback
			code[i] = charset[rand.Intn(len(charset))]
		} else {
			code[i] = charset[n.Int64()]
		}
	}
	return string(code)
}

// POST /api/activity/generate-code — 生成激活码（消费制：最多5个同时存在，用掉一个腾一个）
func handleGenerateActivationCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)

	// 限制频率：每次生成间隔至少10秒
	var lastGen int64
	_ = db.QueryRow("SELECT COALESCE(MAX(created_at), 0) FROM activation_codes WHERE user_id = ?", userID).Scan(&lastGen)
	if lastGen > 0 && time.Now().Unix()-lastGen < 10 {
		writeJSON(w, 429, "操作太频繁，请10秒后再试", nil)
		return
	}

	// 消费制：最多同时存在5个未使用的激活码
	count, err := countUserActiveCodes(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if count >= 5 {
		writeJSON(w, 400, "当前已有5个未使用的激活码，请等待好友使用后再生成", nil)
		return
	}

	// 生成唯一激活码（AURORA-XXXX-XXXX 格式）
	var code string
	for attempts := 0; attempts < 10; attempts++ {
		part1 := generateSecureCode(4)
		part2 := generateSecureCode(6)
		code = fmt.Sprintf("AURORA-%s-%s", part1, part2)
		existing, _ := findActivationCode(code)
		if existing == nil {
			break
		}
	}

	if err := createActivationCode(userID, code); err != nil {
		writeJSON(w, 500, "生成失败", nil)
		return
	}

	writeJSON(w, 200, "ok", map[string]interface{}{
		"code":         code,
		"active_count": count + 1,
		"max_active":   5,
	})
}

// GET /api/activity/my-codes — 获取我的所有激活码
func handleGetMyActivationCodes(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	codes, err := getMyActivationCodes(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if codes == nil {
		codes = []ActivationCode{}
	}

	// 补充被谁使用的用户名
	type CodeWithUsedBy struct {
		ActivationCode
		UsedByUsername string `json:"used_by_username,omitempty"`
	}
	result := make([]CodeWithUsedBy, 0, len(codes))
	for _, c := range codes {
		item := CodeWithUsedBy{ActivationCode: c}
		if c.UsedByUserID > 0 {
			var username string
			db.QueryRow("SELECT username FROM users WHERE id = ?", c.UsedByUserID).Scan(&username)
			item.UsedByUsername = username
		}
		result = append(result, item)
	}

	writeJSON(w, 200, "ok", map[string]interface{}{
		"codes": result,
	})
}

// POST /api/activity/redeem-code — 兑换激活码（多重防作弊校验）
func handleRedeemActivationCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)

	var req struct {
		Code              string `json:"code"`
		DeviceFingerprint string `json:"device_fingerprint"`
		DeviceInfo        string `json:"device_info"`
		IsEmulator        bool   `json:"is_emulator"`
		AppInstallSeconds int64  `json:"app_install_seconds"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求参数错误", nil)
		return
	}

	if req.Code == "" {
		writeJSON(w, 400, "请输入激活码", nil)
		return
	}
	if req.DeviceFingerprint == "" {
		writeJSON(w, 400, "设备信息缺失", nil)
		return
	}

	// ===== 第1层：激活码有效性校验 =====

	// 查找激活码
	ac, err := findActivationCode(req.Code)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if ac == nil {
		writeJSON(w, 404, "激活码不存在", nil)
		return
	}
	if ac.Status != "active" {
		writeJSON(w, 400, "该激活码已被使用", nil)
		return
	}
	if ac.UserID == userID {
		writeJSON(w, 400, "不能使用自己的激活码", nil)
		return
	}

	// ===== 第2层：校验邀请方（生成码的人）的账号成熟度 =====
	// 新用户兑换不应受限，但要防止秒注册的号批量生成码自刷
	var inviterCreatedAt int64
	_ = db.QueryRow("SELECT created_at FROM users WHERE id = ?", ac.UserID).Scan(&inviterCreatedAt)
	if inviterCreatedAt > 0 && time.Now().Unix()-inviterCreatedAt < 3600 {
		writeJSON(w, 400, "邀请方账号注册时间过短，暂时无法生效", nil)
		return
	}

	// ===== 第3层：校验兑换方（当前用户）是否为注册 7 天内的新用户 =====
	var redeemerCreatedAt int64
	_ = db.QueryRow("SELECT created_at FROM users WHERE id = ?", userID).Scan(&redeemerCreatedAt)
	if redeemerCreatedAt > 0 && time.Now().Unix()-redeemerCreatedAt > 7*24*3600 {
		writeJSON(w, 400, "仅限注册7天内的新用户兑换", nil)
		return
	}

	// ===== 第4层：模拟器检测 =====
	if req.IsEmulator {
		writeJSON(w, 400, "模拟器环境不支持兑换激活码，请使用真实设备", nil)
		return
	}

	// ===== 第6层：IP 维度防刷 =====
	clientIP := r.RemoteAddr
	if idx := strings.LastIndex(clientIP, ":"); idx > 0 {
		clientIP = clientIP[:idx]
	}
	var ipRedeemCount int
	db.QueryRow(
		"SELECT COUNT(*) FROM device_fingerprints WHERE device_info LIKE ? AND created_at > ?",
		"%"+clientIP+"%", time.Now().Unix()-3600,
	).Scan(&ipRedeemCount)
	if ipRedeemCount >= 5 {
		writeJSON(w, 400, "此网络环境下兑换过于频繁，请稍后再试", nil)
		return
	}

	// ===== 第7层：设备指纹深度校验 =====

	// 5.1 该指纹是否已被其他用户使用过
	existingFP, err := findDeviceFingerprint(req.DeviceFingerprint)
	if err == nil && existingFP != nil && existingFP.UserID != userID {
		writeJSON(w, 400, "该设备已被其他账号使用过激活码，请更换设备", nil)
		return
	}

	// 5.2 同一用户多设备检测
	userFPs, err := getDeviceFingerprintsByUser(userID)
	if err == nil && len(userFPs) > 0 {
		found := false
		for _, fp := range userFPs {
			if fp.FingerprintHash == req.DeviceFingerprint {
				found = true
				break
			}
		}
		if !found {
			log.Printf("[活动] 用户 %d 使用新设备兑换激活码（非首个设备）", userID)
			if len(userFPs) >= 2 {
				writeJSON(w, 400, "检测到多设备操作，为保障平台安全已拒绝本次兑换", nil)
				return
			}
		}
	}

	// ===== 通过所有校验，执行兑换 =====

	// 在设备信息后追加IP（便于审计）
	enrichedDeviceInfo := req.DeviceInfo
	if len(enrichedDeviceInfo) > 2 {
		enrichedDeviceInfo = enrichedDeviceInfo[:len(enrichedDeviceInfo)-1] + fmt.Sprintf(`,"client_ip":"%s"}`, clientIP)
	}

	// 保存设备指纹
	if err := saveDeviceFingerprint(userID, req.DeviceFingerprint, enrichedDeviceInfo, "redeem"); err != nil {
		log.Printf("[活动] 保存设备指纹失败: %v", err)
	}

	// 标记激活码为已使用
	if err := redeemActivationCode(ac.ID, userID); err != nil {
		writeJSON(w, 500, "兑换失败，请重试", nil)
		return
	}

	// ===== 创建邀请追踪记录（新用户需连续3天打卡+每日10分钟在线才算达标） =====
	if err := createInviteTracking(ac.UserID, userID, ac.ID); err != nil {
		log.Printf("[活动] 创建邀请追踪记录失败: %v", err)
		// 不阻止兑换流程
	}

	// 立即执行一次达标检查
	checkInviteQualification(userID)

	writeJSON(w, 200, "激活成功！欢迎加入 Aurora Chat", map[string]interface{}{
		"code_id":    ac.ID,
		"inviter_id": ac.UserID,
		"note":       "新用户需连续3天登录且每日在线满10分钟，邀请方才能获得奖励",
	})
}

// ==================== 邀请达标检查 ====================

// checkInviteQualification 检查指定用户的邀请达标进度
// 验证流程（隐藏监控期，用户仅可见"连续3日登录+每日10分钟"规则）：
//
//	Phase 1（第 1-3 天，用户可见）: 连续 3 天每天在线≥600秒 → 阶段通过
//	Phase 2（第 4-7 天，隐藏监控）: 至少 2 天有登录（不计时长）→ 最终确认
//	若任一阶段未通过 → 标记为 failed（不增加邀请数）
func checkInviteQualification(userID int64) {
	trackings, err := getPendingInviteTrackingsByUserID(userID)
	if err != nil || len(trackings) == 0 {
		return
	}

	var currentOnline int64
	_ = db.QueryRow("SELECT online_time_seconds FROM users WHERE id = ?", userID).Scan(&currentOnline)

	today := time.Now().Format("2006-01-02")
	createdBase := time.Now().Truncate(24 * time.Hour)

	for _, t := range trackings {
		// 计算创建至今的天数（按自然日）
		createdDay := time.Unix(t.CreatedAt, 0).Truncate(24 * time.Hour)
		daysSince := int(createdBase.Sub(createdDay).Hours() / 24)

		// 记录今日在线数据
		var baselineOnline int64
		_ = db.QueryRow("SELECT COALESCE(SUM(online_seconds), 0) FROM invite_daily_logs WHERE tracking_id = ?", t.ID).Scan(&baselineOnline)

		todayOnline := currentOnline - baselineOnline
		if todayOnline < 0 {
			todayOnline = 0
		}

		isQualified := 0
		if todayOnline >= 600 {
			isQualified = 1
		}
		if err := upsertTodayLog(t.ID, userID, today, todayOnline, isQualified); err != nil {
			log.Printf("[活动] 记录每日日志失败: %v", err)
			continue
		}

		// Phase 1: 检查最近 3 天是否全部达标（每天 ≥600 秒）
		qualifiedCount := 0
		for i := 0; i < 3; i++ {
			d := time.Now().AddDate(0, 0, -i).Format("2006-01-02")
			logEntry, _ := getTodayLog(t.ID, d)
			if logEntry != nil && logEntry.IsQualified == 1 {
				qualifiedCount++
			}
		}

		phase1Passed := qualifiedCount >= 3

		if daysSince < 7 {
			// 仍在完整验证期内（1-6 天）
			if phase1Passed {
				updateInviteTrackingConsecutive(t.ID, qualifiedCount, today, "pending")
				log.Printf("[活动] 用户 %d 阶段1达标（连续3天≥10min），进入监控期（追踪ID: %d）", userID, t.ID)
			} else {
				updateInviteTrackingConsecutive(t.ID, qualifiedCount, today, "pending")
			}
		} else {
			// 第 7 天及以后 → 做最终裁决
			if !phase1Passed {
				// 阶段1未通过 → 直接失败
				updateInviteTrackingConsecutive(t.ID, 0, today, "failed")
				log.Printf("[活动] 用户 %d 邀请失败：前3天未全部达标（追踪ID: %d）", userID, t.ID)
			} else {
				// 阶段1通过 → 检查监控期（第 4-7 天，至少 2 天有登录记录）
				monitoringLoginDays := 0
				for i := 3; i < 7; i++ {
					d := createdDay.AddDate(0, 0, i).Format("2006-01-02")
					logEntry, _ := getTodayLog(t.ID, d)
					if logEntry != nil && logEntry.OnlineSeconds > 0 {
						monitoringLoginDays++
					}
				}
				if monitoringLoginDays >= 2 {
					updateInviteTrackingConsecutive(t.ID, 3, today, "confirmed")
					log.Printf("[活动] 用户 %d 邀请已确认（前3天达标+监控期 %d/4 天登录）", userID, monitoringLoginDays)
				} else {
					updateInviteTrackingConsecutive(t.ID, 0, today, "failed")
					log.Printf("[活动] 用户 %d 邀请未达标：监控期仅 %d/4 天登录（疑似刷量）", userID, monitoringLoginDays)
				}
			}
		}
	}
}

// ==================== 管理员：拉新活动管理 ====================

// GET /api/admin/activity/referral/list?keyword=&page=&limit= — 搜索/查看邀请记录
func handleAdminGetReferralList(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "referral.view") {
		writeJSON(w, 403, "仅开发者可操作", nil)
		return
	}

	keyword := r.URL.Query().Get("keyword")
	pageStr := r.URL.Query().Get("page")
	limitStr := r.URL.Query().Get("limit")

	page := 1
	limit := 20
	if p, err := strconv.Atoi(pageStr); err == nil && p > 0 {
		page = p
	}
	if l, err := strconv.Atoi(limitStr); err == nil && l > 0 && l <= 100 {
		limit = l
	}
	offset := (page - 1) * limit

	results, total, err := searchInviteTrackings(keyword, limit, offset)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if results == nil {
		results = []map[string]interface{}{}
	}

	writeJSON(w, 200, "ok", map[string]interface{}{
		"records": results,
		"total":   total,
		"page":    page,
		"limit":   limit,
	})
}

// POST /api/admin/activity/referral/update — 手动修改邀请记录状态
func handleAdminUpdateReferral(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "referral.edit") {
		writeJSON(w, 403, "仅开发者可操作", nil)
		return
	}

	var req struct {
		ID     int64  `json:"id"`
		Status string `json:"status"` // pending / confirmed / rejected
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求参数错误", nil)
		return
	}
	if req.ID <= 0 || (req.Status != "pending" && req.Status != "confirmed" && req.Status != "rejected") {
		writeJSON(w, 400, "参数错误", nil)
		return
	}

	if err := adminUpdateInviteTracking(req.ID, req.Status); err != nil {
		writeJSON(w, 500, "更新失败", nil)
		return
	}

	writeJSON(w, 200, "ok", nil)
}
func handleGetActivityStats(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)

	activeCount, _ := countUserActiveCodes(userID)
	invitedCount, _ := getInvitedCount(userID)
	redeemedCount, _ := getUserRedeemedCount(userID)
	totalGenerated, _ := getTotalGeneratedCount(userID)

	writeJSON(w, 200, "ok", map[string]interface{}{
		"active_count":    activeCount,
		"invited_count":   invitedCount,
		"redeemed_count":  redeemedCount,
		"total_generated": totalGenerated,
		"max_active":      5,
	})
}

// ==================== 应用分享 API ====================

// POST /api/apps/submit — 用户提交应用
func handleSubmitApp(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}

	r.ParseMultipartForm(50 << 20) // 支持最大 50MB

	name := r.FormValue("name")
	description := r.FormValue("description")
	downloadURL := r.FormValue("download_url")
	category := r.FormValue("category")
	packageName := r.FormValue("package_name")
	fileSizeStr := r.FormValue("file_size")
	apkType := r.FormValue("apk_type") // "url" 或 "upload"

	if name == "" {
		writeJSON(w, 400, "应用名称为必填", nil)
		return
	}
	if apkType == "" {
		apkType = "url" // 默认直链
	}
	if apkType == "url" {
		if downloadURL == "" {
			writeJSON(w, 400, "请填写安装包直链", nil)
			return
		}
		// 校验直链格式：必须以 http:// 或 https:// 开头，路径以 .apk 结尾
		cleanURL := strings.SplitN(downloadURL, "?", 2)[0]
		cleanURL = strings.SplitN(cleanURL, "#", 2)[0]
		if !strings.HasPrefix(downloadURL, "http://") && !strings.HasPrefix(downloadURL, "https://") {
			writeJSON(w, 400, "安装包直链必须以 http:// 或 https:// 开头", nil)
			return
		}
		if !strings.HasSuffix(strings.ToLower(cleanURL), ".apk") {
			writeJSON(w, 400, "安装包直链必须以 .apk 结尾", nil)
			return
		}
	}

	var fileSize int64
	fmt.Sscanf(fileSizeStr, "%d", &fileSize)
	validCats := map[string]bool{"推荐": true, "实用": true, "开发": true, "游戏": true, "社交": true, "影音": true, "阅读": true, "购物": true, "生活": true, "工具": true, "通讯": true, "娱乐": true, "成人": true}
	if !validCats[category] {
		category = "推荐"
	}

	// ===== 限流：10分钟内最多1次，一天最多3次 =====
	var recentCount int
	db.QueryRow("SELECT COUNT(*) FROM user_apps WHERE user_id = ? AND created_at > ?", userID, time.Now().Unix()-600).Scan(&recentCount)
	if recentCount >= 1 {
		writeJSON(w, 429, "提交过于频繁，请10分钟后再试", nil)
		return
	}
	todayStart := time.Now().Unix() - int64(time.Now().Hour())*3600 - int64(time.Now().Minute())*60 - int64(time.Now().Second())
	var todayCount int
	db.QueryRow("SELECT COUNT(*) FROM user_apps WHERE user_id = ? AND created_at > ?", userID, todayStart).Scan(&todayCount)
	if todayCount >= 3 {
		writeJSON(w, 429, "今日提交已达上限（3次/天）", nil)
		return
	}

	apkPath := ""
	// 如果是上传 APK 模式
	if apkType == "upload" {
		apkFile, apkHeader, err := r.FormFile("apk_file")
		if err != nil || apkHeader == nil {
			writeJSON(w, 400, "请选择要上传的APK文件", nil)
			return
		}

		execPath, _ := os.Executable()
		dataDir := filepath.Join(filepath.Dir(execPath), "data")
		apksDir := filepath.Join(dataDir, "apps", "apks")
		os.MkdirAll(apksDir, 0755)

		ext := filepath.Ext(apkHeader.Filename)
		if ext == "" {
			ext = ".apk"
		}
		//  先保存到临时文件，成功后 INSERT 数据库，再重命名为正式名
		tmpName := fmt.Sprintf("_tmp_%d%s", time.Now().UnixNano(), ext)
		tmpPath := filepath.Join(apksDir, tmpName)
		out, err := os.Create(tmpPath)
		if err != nil {
			apkFile.Close()
			writeJSON(w, 500, "保存APK失败", nil)
			return
		}
		written, _ := io.Copy(out, apkFile)
		out.Close()
		apkFile.Close()

		if written == 0 {
			os.Remove(tmpPath)
			writeJSON(w, 500, "APK文件内容为空", nil)
			return
		}

		// 获取实际文件大小覆盖前端提交的值（更准确）
		if fi, err := os.Stat(tmpPath); err == nil {
			fileSize = fi.Size()
		}

		// 文件保存成功后才创建数据库记录（避免失败占用次数风控）
		appID, err := createUserApp(userID, name, description, "", category, "", "[]", packageName, fileSize, "", "")
		if err != nil {
			os.Remove(tmpPath)
			writeJSON(w, 500, "创建失败", nil)
			return
		}
		appIDStr := fmt.Sprintf("%d", appID)
		apkPath = appIDStr + ext

		// 重命名为最终名称
		os.Rename(tmpPath, filepath.Join(apksDir, apkPath))
		db.Exec("UPDATE user_apps SET apk_path = ? WHERE id = ?", apkPath, appID)

		// 处理图标
		iconsDir := filepath.Join(dataDir, "apps", "icons")
		os.MkdirAll(iconsDir, 0755)
		iconPath := ""
		iconFile, iconHeader, err := r.FormFile("icon")
		if err == nil && iconHeader != nil {
			iconExt := filepath.Ext(iconHeader.Filename)
			if iconExt == "" {
				iconExt = ".png"
			}
			iconPath = appIDStr + iconExt
			out, _ := os.Create(filepath.Join(iconsDir, iconPath))
			io.Copy(out, iconFile)
			out.Close()
			iconFile.Close()
		}

		// 处理截图
		var ssPaths []string
		ssFiles := r.MultipartForm.File["screenshots"]
		ssDir := filepath.Join(dataDir, "apps", "screenshots")
		os.MkdirAll(ssDir, 0755)
		for idx, fh := range ssFiles {
			if idx >= 10 {
				break
			}
			file, _ := fh.Open()
			if file != nil {
				ssExt := filepath.Ext(fh.Filename)
				if ssExt == "" {
					ssExt = ".png"
				}
				name := fmt.Sprintf("%s_%d%s", appIDStr, idx, ssExt)
				out, _ := os.Create(filepath.Join(ssDir, name))
				io.Copy(out, file)
				out.Close()
				file.Close()
				ssPaths = append(ssPaths, name)
			}
		}

		ssJSON, _ := json.Marshal(ssPaths)
		db.Exec("UPDATE user_apps SET icon_path = ?, screenshots = ? WHERE id = ?", iconPath, string(ssJSON), appID)
		writeJSON(w, 200, "提交成功，等待管理员审核", map[string]interface{}{"app_id": appID})
		return
	}

	// 直链模式（原有逻辑）
	appID, err := createUserApp(userID, name, description, downloadURL, category, "", "[]", packageName, fileSize, "", "")
	if err != nil {
		writeJSON(w, 500, "创建失败", nil)
		return
	}

	appIDStr := fmt.Sprintf("%d", appID)
	execPath, _ := os.Executable()
	dataDir := filepath.Join(filepath.Dir(execPath), "data")
	iconsDir := filepath.Join(dataDir, "apps", "icons")
	ssDir := filepath.Join(dataDir, "apps", "screenshots")
	os.MkdirAll(iconsDir, 0755)
	os.MkdirAll(ssDir, 0755)

	// 保存图标
	iconPath := ""
	iconFile, iconHeader, err := r.FormFile("icon")
	if err == nil && iconHeader != nil {
		ext := filepath.Ext(iconHeader.Filename)
		if ext == "" {
			ext = ".png"
		}
		iconPath = appIDStr + ext
		out, _ := os.Create(filepath.Join(iconsDir, iconPath))
		io.Copy(out, iconFile)
		out.Close()
		iconFile.Close()
	}

	// 保存截图
	var ssPaths []string
	ssFiles := r.MultipartForm.File["screenshots"]
	for idx, fh := range ssFiles {
		if idx >= 10 {
			break
		}
		file, _ := fh.Open()
		if file != nil {
			ext := filepath.Ext(fh.Filename)
			if ext == "" {
				ext = ".png"
			}
			name := fmt.Sprintf("%s_%d%s", appIDStr, idx, ext)
			out, _ := os.Create(filepath.Join(ssDir, name))
			io.Copy(out, file)
			out.Close()
			file.Close()
			ssPaths = append(ssPaths, name)
		}
	}

	ssJSON, _ := json.Marshal(ssPaths)
	db.Exec("UPDATE user_apps SET icon_path = ?, screenshots = ? WHERE id = ?", iconPath, string(ssJSON), appID)
	writeJSON(w, 200, "提交成功，等待管理员审核", map[string]interface{}{"app_id": appID})
}

// 将所有应用的下载地址统一指向本站计数端点 /api/apps/apk/{id}：
//   - 上传型应用：该端点直接返回服务器上的 APK 文件；
//   - 外链型应用（download_url 为外部直链）：该端点先计数再 302 跳转到真实直链。
// 这样无论哪种类型，下载行为都会经过本站，download_count 才能被统一统计，
// 否则外链型应用由客户端直连外部站点，服务端永远收不到下载请求、计数恒为 0。
func fillDownloadURL(app *UserApp) {
	app.DownloadURL = fmt.Sprintf("/api/apps/apk/%d", app.ID)
}

// GET /api/apps/list — 获取已审核通过的应用列表（公开）
func handleGetAppList(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	apps, err := getApprovedApps(r.URL.Query().Get("category"))
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if apps == nil {
		apps = []UserApp{}
	}
	for i := range apps {
		fillDownloadURL(&apps[i])
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"apps": apps})
}

// GET /api/apps/icon/{appId} — 获取应用图标（公开）
func handleGetAppIcon(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/apps/icon/")
	parts := strings.SplitN(path, "/", 2)
	appID, _ := strconv.ParseInt(parts[0], 10, 64)
	if appID <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	execPath, _ := os.Executable()
	var fp string
	if len(parts) == 2 && parts[1] != "" {
		fp = filepath.Join(filepath.Dir(execPath), "data", "apps", "icons", parts[1])
	} else {
		app, err := getUserAppByID(appID)
		if err != nil || app == nil || app.IconPath == "" {
			writeJSON(w, 404, "不存在", nil)
			return
		}
		fp = filepath.Join(filepath.Dir(execPath), "data", "apps", "icons", app.IconPath)
	}
	if _, err := os.Stat(fp); os.IsNotExist(err) {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	http.ServeFile(w, r, fp)
}

// GET /api/apps/screenshot/{appId}/{index} — 获取应用截图（公开）
func handleGetAppScreenshot(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/apps/screenshot/")
	parts := strings.SplitN(path, "/", 2)
	if len(parts) != 2 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	appID, _ := strconv.ParseInt(parts[0], 10, 64)
	if appID <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	app, _ := getUserAppByID(appID)
	if app == nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	execPath, _ := os.Executable()
	fp := filepath.Join(filepath.Dir(execPath), "data", "apps", "screenshots", parts[1])
	if _, err := os.Stat(fp); os.IsNotExist(err) {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	http.ServeFile(w, r, fp)
}

// GET /api/apps/apk/{appId} — 应用安装包下载（统一下载计数端点）
//   - 上传型应用：直接返回服务器上的 APK 文件；
//   - 外链型应用（download_url 为外部直链）：先计数，再 302 跳转到真实直链；
//   - 支持 ?v=versionId 指定历史版本（仅上传型版本有效，外链型历史版本回退到最新直链）。
// 无论哪种类型，下载行为都经过本站，download_count 才能被统一统计。
func handleGetAppApk(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	appIDStr := strings.TrimPrefix(r.URL.Path, "/api/apps/apk/")
	appID, _ := strconv.ParseInt(appIDStr, 10, 64)
	if appID <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	execPath, _ := os.Executable()
	apksDir := filepath.Join(filepath.Dir(execPath), "data", "apps", "apks")
	app, _ := getUserAppByID(appID)
	if app == nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}

	// 统一全局下载计数 +1（所有类型都在这里计一次，避免重复或漏计）
	if _, err := db.Exec("UPDATE user_apps SET download_count = download_count + 1 WHERE id = ? AND status = 'approved'", appID); err != nil {
		log.Printf("[下载] 更新下载计数失败: %v", err)
	}

	versionIDStr := r.URL.Query().Get("v")
	var fp string
	if versionIDStr != "" {
		versionID, _ := strconv.ParseInt(versionIDStr, 10, 64)
		if versionID <= 0 {
			writeJSON(w, 404, "版本不存在", nil)
			return
		}
		var apkPath string
		err := db.QueryRow("SELECT apk_path FROM app_versions WHERE id=? AND app_id=?", versionID, appID).Scan(&apkPath)
		if err != nil || apkPath == "" {
			// 历史版本无本地文件：外链型回退到最新直链，否则 404
			if strings.HasPrefix(app.DownloadURL, "http://") || strings.HasPrefix(app.DownloadURL, "https://") {
				http.Redirect(w, r, app.DownloadURL, http.StatusFound)
				return
			}
			writeJSON(w, 404, "版本文件不存在", nil)
			return
		}
		fp = filepath.Join(apksDir, apkPath)
	} else {
		if app.ApkPath == "" {
			// 外链型：本地无文件，计数已在上面完成，跳转到开发者直链
			if strings.HasPrefix(app.DownloadURL, "http://") || strings.HasPrefix(app.DownloadURL, "https://") {
				http.Redirect(w, r, app.DownloadURL, http.StatusFound)
				return
			}
			writeJSON(w, 404, "文件不存在", nil)
			return
		}
		fp = filepath.Join(apksDir, app.ApkPath)
	}
	if _, err := os.Stat(fp); os.IsNotExist(err) {
		writeJSON(w, 404, "文件不存在", nil)
		return
	}

	w.Header().Set("Content-Type", "application/vnd.android.package-archive")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s.apk\"", app.Name))
	http.ServeFile(w, r, fp)
}

// ==================== 开发者应用管理接口 ====================

// 简单版本号比较（支持 x.y 或 x.y.z），a>b返回1，a==b返回0，a<b返回-1
func compareVersion(a, b string) int {
	va, vb := a, b
	if va == "" {
		va = "0"
	}
	if vb == "" {
		vb = "0"
	}
	pa := strings.Split(va, ".")
	pb := strings.Split(vb, ".")
	maxLen := len(pa)
	if len(pb) > maxLen {
		maxLen = len(pb)
	}
	for i := 0; i < maxLen; i++ {
		var na, nb int64
		if i < len(pa) {
			na, _ = strconv.ParseInt(pa[i], 10, 64)
		}
		if i < len(pb) {
			nb, _ = strconv.ParseInt(pb[i], 10, 64)
		}
		if na > nb {
			return 1
		}
		if na < nb {
			return -1
		}
	}
	return 0
}

// GET /api/apps/my — 获取当前用户提交的所有应用
func handleGetMyApps(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	apps, err := getUserAppsByUserID(userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if apps == nil {
		apps = []UserApp{}
	}
	for i := range apps {
		fillDownloadURL(&apps[i])
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"apps": apps})
}

// POST /api/apps/v/{id} — 版本更新
func handleUpdateAppVersion(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	appIDStr := strings.TrimPrefix(r.URL.Path, "/api/apps/v/")
	appID, _ := strconv.ParseInt(appIDStr, 10, 64)
	if appID <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}

	app, err := getUserAppByID(appID)
	if err != nil || app == nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	if app.UserID != userID {
		writeJSON(w, 403, "无权操作", nil)
		return
	}

	r.ParseMultipartForm(50 << 20)
	version := r.FormValue("version")
	apkType := r.FormValue("apk_type")
	downloadURL := r.FormValue("download_url")
	fileSizeStr := r.FormValue("file_size")

	if version == "" {
		writeJSON(w, 400, "版本号不能为空", nil)
		return
	}
	if compareVersion(version, app.Version) <= 0 {
		writeJSON(w, 400, "新版本号必须大于当前版本", nil)
		return
	}
	if apkType == "url" {
		if downloadURL == "" {
			writeJSON(w, 400, "请填写安装包直链", nil)
			return
		}
		cleanURL := strings.SplitN(downloadURL, "?", 2)[0]
		cleanURL = strings.SplitN(cleanURL, "#", 2)[0]
		if !strings.HasPrefix(downloadURL, "http://") && !strings.HasPrefix(downloadURL, "https://") {
			writeJSON(w, 400, "安装包直链必须以 http:// 或 https:// 开头", nil)
			return
		}
		if !strings.HasSuffix(strings.ToLower(cleanURL), ".apk") {
			writeJSON(w, 400, "安装包直链必须以 .apk 结尾", nil)
			return
		}
	}

	var fileSize int64
	fmt.Sscanf(fileSizeStr, "%d", &fileSize)
	apkPath := ""
	changelog := r.FormValue("changelog")
	allowOld := 0
	if r.FormValue("allow_old") == "1" {
		allowOld = 1
	}

	if apkType == "upload" {
		apkFile, apkHeader, err := r.FormFile("apk_file")
		if err != nil || apkHeader == nil {
			writeJSON(w, 400, "请选择APK文件", nil)
			return
		}
		execPath, _ := os.Executable()
		apksDir := filepath.Join(filepath.Dir(execPath), "data", "apps", "apks")
		os.MkdirAll(apksDir, 0755)
		ext := filepath.Ext(apkHeader.Filename)
		if ext == "" {
			ext = ".apk"
		}
		tmpPath := filepath.Join(apksDir, fmt.Sprintf("_upd_%d%s", time.Now().UnixNano(), ext))
		out, err := os.Create(tmpPath)
		if err != nil {
			apkFile.Close()
			writeJSON(w, 500, "保存APK失败", nil)
			return
		}
		io.Copy(out, apkFile)
		out.Close()
		apkFile.Close()
		if fi, err := os.Stat(tmpPath); err == nil {
			fileSize = fi.Size()
		}
		// 支持旧版本：把旧 APK 重命名为版本特定文件名再保存
		if app.ApkPath != "" && allowOld != 0 {
			versionedName := fmt.Sprintf("%d_v%s%s", app.ID, app.Version, ext)
			os.Rename(filepath.Join(apksDir, app.ApkPath), filepath.Join(apksDir, versionedName))
			db.Exec("UPDATE app_versions SET apk_path=? WHERE app_id=? AND version=?", versionedName, appID, app.Version)
		} else if app.ApkPath != "" && allowOld == 0 {
			os.Remove(filepath.Join(apksDir, app.ApkPath))
		}
		apkPath = fmt.Sprintf("%d%s", app.ID, ext)
		os.Rename(tmpPath, filepath.Join(apksDir, apkPath))
	}

	// 处理元数据（从 updateAppInfo 搬过来）
	name := r.FormValue("name")
	if name == "" {
		name = app.Name
	}
	description := r.FormValue("description")
	category := r.FormValue("category")
	if category == "" {
		category = app.Category
	}
	allCats := map[string]bool{"推荐": true, "实用": true, "开发": true, "游戏": true, "社交": true, "影音": true, "阅读": true, "购物": true, "生活": true, "工具": true, "通讯": true, "娱乐": true, "成人": true}
	if !allCats[category] {
		category = "推荐"
	}
	execPath, _ := os.Executable()
	dataDir := filepath.Join(filepath.Dir(execPath), "data")
	appIDStrFull := fmt.Sprintf("%d", appID)
	iconPath := app.IconPath
	iconFile, iconHeader, iconErr := r.FormFile("icon")
	if iconErr == nil && iconHeader != nil {
		iconsDir := filepath.Join(dataDir, "apps", "icons")
		os.MkdirAll(iconsDir, 0755)
		ext := filepath.Ext(iconHeader.Filename)
		if ext == "" {
			ext = ".png"
		}
		iconPath = fmt.Sprintf("%s_%d%s", appIDStrFull, time.Now().Unix(), ext)
		out, _ := os.Create(filepath.Join(iconsDir, iconPath))
		io.Copy(out, iconFile)
		out.Close()
		iconFile.Close()
	}
	var ssPaths []string
	json.Unmarshal([]byte(app.Screenshots), &ssPaths)
	deletedSs := r.FormValue("deleted_screenshots")
	if deletedSs != "" {
		for _, fName := range strings.Split(deletedSs, ",") {
			fName = strings.TrimSpace(fName)
			if fName == "" {
				continue
			}
			for i := len(ssPaths) - 1; i >= 0; i-- {
				if ssPaths[i] == fName {
					ssPaths = append(ssPaths[:i], ssPaths[i+1:]...)
				}
			}
		}
	}
	ssFiles := r.MultipartForm.File["screenshots"]
	if len(ssFiles) > 0 {
		ssDir := filepath.Join(dataDir, "apps", "screenshots")
		os.MkdirAll(ssDir, 0755)
		for _, fh := range ssFiles {
			if len(ssPaths) >= 10 {
				break
			}
			file, _ := fh.Open()
			if file != nil {
				ext := filepath.Ext(fh.Filename)
				if ext == "" {
					ext = ".png"
				}
				name := fmt.Sprintf("%s_%d%s", appIDStrFull, time.Now().UnixNano(), ext)
				out, _ := os.Create(filepath.Join(ssDir, name))
				io.Copy(out, file)
				out.Close()
				file.Close()
				ssPaths = append(ssPaths, name)
			}
		}
	}
	ssJSON, _ := json.Marshal(ssPaths)

	if err := updateAppVersion(appID, userID, version, downloadURL, apkPath, fileSize, changelog, allowOld, name, description, category, iconPath, string(ssJSON)); err != nil {
		writeJSON(w, 500, "版本更新失败", nil)
		return
	}
	writeJSON(w, 200, "版本更新成功", nil)
}

// GET /api/apps/versions/{id} — 获取应用版本历史
func handleGetAppVersions(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	appIDStr := strings.TrimPrefix(r.URL.Path, "/api/apps/versions/")
	appID, _ := strconv.ParseInt(appIDStr, 10, 64)
	if appID <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	versions, err := getAppVersions(appID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if versions == nil {
		versions = []AppVersion{}
	}
	// 填充下载 URL
	for i := range versions {
		if versions[i].ApkPath != "" {
			versions[i].DownloadURL = fmt.Sprintf("/api/apps/apk/%d", appID)
		}
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"versions": versions})
}

// POST /api/apps/i/{id} — 修改应用信息
func handleUpdateAppInfo(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	appIDStr := strings.TrimPrefix(r.URL.Path, "/api/apps/i/")
	appID, _ := strconv.ParseInt(appIDStr, 10, 64)
	if appID <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}

	app, err := getUserAppByID(appID)
	if err != nil || app == nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	if app.UserID != userID {
		writeJSON(w, 403, "无权操作", nil)
		return
	}

	r.ParseMultipartForm(50 << 20)
	name := r.FormValue("name")
	description := r.FormValue("description")
	category := r.FormValue("category")
	if name == "" {
		writeJSON(w, 400, "应用名称不能为空", nil)
		return
	}
	allCats := map[string]bool{"推荐": true, "实用": true, "开发": true, "游戏": true, "社交": true, "影音": true, "阅读": true, "购物": true, "生活": true, "工具": true, "通讯": true, "娱乐": true, "成人": true}
	if !allCats[category] {
		category = "推荐"
	}

	execPath, _ := os.Executable()
	dataDir := filepath.Join(filepath.Dir(execPath), "data")
	appIDStrFull := fmt.Sprintf("%d", appID)

	// 处理图标
	iconPath := app.IconPath
	iconFile, iconHeader, err := r.FormFile("icon")
	if err == nil && iconHeader != nil {
		iconsDir := filepath.Join(dataDir, "apps", "icons")
		os.MkdirAll(iconsDir, 0755)
		ext := filepath.Ext(iconHeader.Filename)
		if ext == "" {
			ext = ".png"
		}
		iconPath = fmt.Sprintf("%s_%d%s", appIDStrFull, time.Now().Unix(), ext)
		out, _ := os.Create(filepath.Join(iconsDir, iconPath))
		io.Copy(out, iconFile)
		out.Close()
		iconFile.Close()
	}

	// 处理截图：先保留原截图列表
	var ssPaths []string
	json.Unmarshal([]byte(app.Screenshots), &ssPaths)
	// 删除用户标记删除的截图
	deletedSs := r.FormValue("deleted_screenshots")
	if deletedSs != "" {
		for _, fName := range strings.Split(deletedSs, ",") {
			fName = strings.TrimSpace(fName)
			if fName == "" {
				continue
			}
			for i := len(ssPaths) - 1; i >= 0; i-- {
				if ssPaths[i] == fName {
					ssPaths = append(ssPaths[:i], ssPaths[i+1:]...)
				}
			}
		}
	}
	// 添加上传的新截图
	ssFiles := r.MultipartForm.File["screenshots"]
	if len(ssFiles) > 0 {
		ssDir := filepath.Join(dataDir, "apps", "screenshots")
		os.MkdirAll(ssDir, 0755)
		for _, fh := range ssFiles {
			if len(ssPaths) >= 10 {
				break
			}
			file, _ := fh.Open()
			if file != nil {
				ext := filepath.Ext(fh.Filename)
				if ext == "" {
					ext = ".png"
				}
				name := fmt.Sprintf("%s_%d%s", appIDStrFull, time.Now().UnixNano(), ext)
				out, _ := os.Create(filepath.Join(ssDir, name))
				io.Copy(out, file)
				out.Close()
				file.Close()
				ssPaths = append(ssPaths, name)
			}
		}
	}

	ssJSON, _ := json.Marshal(ssPaths)
	if err := updateAppInfo(appID, userID, name, description, category, iconPath, string(ssJSON)); err != nil {
		writeJSON(w, 500, "更新信息失败", nil)
		return
	}
	writeJSON(w, 200, "应用信息已更新", nil)
}

// GET /api/apps/pending — 获取待审核应用列表（管理员）
func handleGetPendingApps(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if _, ok := checkAdminOrDevPermission(r); !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	apps, err := getPendingApps()
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if apps == nil {
		apps = []UserApp{}
	}
	for i := range apps {
		fillDownloadURL(&apps[i])
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"apps": apps})
}

// GET /api/admin/apps/list — 获取全部应用列表（管理员）
func handleAdminGetAppList(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if _, ok := checkAdminOrDevPermission(r); !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	apps, err := getAllUserApps()
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	if apps == nil {
		apps = []UserApp{}
	}
	for i := range apps {
		fillDownloadURL(&apps[i])
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"apps": apps})
}

// POST /api/admin/apps/review — 管理员审核应用
func handleAdminReviewApp(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	var req struct {
		AppID  int64  `json:"app_id"`
		Action string `json:"action"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.AppID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if req.Action != "approve" && req.Action != "reject" && req.Action != "remove" {
		writeJSON(w, 400, "action 必须为 approve/reject/remove", nil)
		return
	}
	// 根据 action 检查对应权限
	var permKey string
	switch req.Action {
	case "approve":
		permKey = "apps.approve"
	case "reject":
		permKey = "apps.reject"
	case "remove":
		permKey = "apps.remove"
	}
	currentUserID, ok := checkAdminPermission(r, permKey)
	if !ok {
		writeJSON(w, 403, "无权执行此操作", nil)
		return
	}
	status := "approved"
	if req.Action == "reject" {
		status = "rejected"
	}
	if req.Action == "remove" {
		status = "removed"
	}
	if err := reviewUserApp(req.AppID, status, currentUserID); err != nil {
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	writeJSON(w, 200, "操作成功", nil)
}

// POST /api/admin/apps/delete — 管理员删除应用
func handleAdminDeleteApp(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if _, ok := checkAdminPermission(r, "apps.remove"); !ok {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		AppID int64 `json:"app_id"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.AppID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if err := reviewUserApp(req.AppID, "deleted", 0); err != nil {
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	writeJSON(w, 200, "已删除", nil)
}

// ==================== 应用评论 ====================

// GET /api/apps/comments/{appId} — 获取应用评论
func handleAppGetComments(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}

	idStr := strings.TrimPrefix(r.URL.Path, "/api/apps/comments/")
	appID, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil || appID <= 0 {
		writeJSON(w, 400, "应用ID无效", nil)
		return
	}

	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if limit < 1 || limit > 50 {
		limit = 20
	}
	offset := (page - 1) * limit

	rows, err := db.Query(`SELECT c.id, c.user_id, u.username, c.content, c.created_at
		FROM app_comments c JOIN users u ON c.user_id = u.id
		WHERE c.app_id = ? ORDER BY c.created_at ASC LIMIT ? OFFSET ?`, appID, limit, offset)
	if err != nil {
		log.Printf("查询应用评论失败: %v", err)
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	defer rows.Close()

	type AppCommentItem struct {
		ID        int64  `json:"id"`
		UserID    int64  `json:"user_id"`
		Username  string `json:"username"`
		Content   string `json:"content"`
		CreatedAt int64  `json:"created_at"`
	}
	var comments []AppCommentItem
	for rows.Next() {
		var c AppCommentItem
		if err := rows.Scan(&c.ID, &c.UserID, &c.Username, &c.Content, &c.CreatedAt); err != nil {
			continue
		}
		comments = append(comments, c)
	}
	if comments == nil {
		comments = []AppCommentItem{}
	}

	var total int
	db.QueryRow("SELECT COUNT(*) FROM app_comments WHERE app_id = ?", appID).Scan(&total)

	writeJSON(w, 200, "ok", map[string]interface{}{"comments": comments, "total": total})
}

// POST /api/apps/comment/add — 添加应用评论
func handleAppAddComment(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}

	var req struct {
		AppID   int64  `json:"app_id"`
		Content string `json:"content"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "请求格式错误", nil)
		return
	}
	req.Content = strings.TrimSpace(req.Content)
	if req.AppID <= 0 || req.Content == "" {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if len(req.Content) > 500 {
		writeJSON(w, 400, "评论内容不能超过500字", nil)
		return
	}
	// 评论频率限制（防灌水）
	if allowed, wait := checkCommentRateLimit(userID); !allowed {
		writeJSON(w, 429, fmt.Sprintf("评论过于频繁，请 %d 秒后再试", wait), nil)
		return
	}
	req.Content = html.EscapeString(req.Content)

	now := time.Now().Unix()
	_, err := db.Exec("INSERT INTO app_comments (app_id, user_id, content, created_at) VALUES (?, ?, ?, ?)",
		req.AppID, userID, req.Content, now)
	if err != nil {
		log.Printf("添加应用评论失败: %v", err)
		writeJSON(w, 500, "评论失败", nil)
		return
	}
	writeJSON(w, 200, "评论成功", nil)
}

// ==================== 会员体系 ====================

// memberBadgeID 根据会员等级返回对应徽章 id（1→13 普通, 2→14 高级, 3→15 尊享）
func memberBadgeID(level int) int {
	if level < 1 || level > 3 {
		return 0
	}
	return level + 12
}

// memberDurationBadgeID 根据会员时长（天）返回对应的时长徽章：
// 永久(<=0 或 >=330 天)=永久会员(19)；年费(>=330)=年度(18)；季(90~329)=季度(17)；月(<90)=月度(16)。
// 与等级徽章(13/14/15)互补：等级体现档位、时长体现购买周期。
func memberDurationBadgeID(durationDays int) int {
	switch {
	case durationDays <= 0:
		return 19
	case durationDays >= 330:
		return 18
	case durationDays >= 90:
		return 17
	default:
		return 16
	}
}

// memberWelcomeTokens 返回某会员等级开通时应发放的欢迎 Token 数量，
// 必须与前端「会员中心」三档标注的赠送 Token 完全一致：
// 普通(1)=200万 / 高级(2)=1000万 / 尊享(3)=3500万。
// 标注多少就实发多少，杜绝「前端写 200万、后端只给一点点」的落差。
func memberWelcomeTokens(level int) int64 {
	switch level {
	case 1:
		return 2000000
	case 2:
		return 10000000
	case 3:
		return 35000000
	default:
		return 0
	}
}

// parseMemberReq 解析并校验会员开通/续费请求，返回等级与天数
func parseMemberReq(r *http.Request) (int, int, bool) {
	var req struct {
		Level    int `json:"level"`
		Duration int `json:"duration"` // 有效期天数
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		return 0, 0, false
	}
	if req.Level < 1 || req.Level > 3 {
		return 0, 0, false
	}
	if req.Duration <= 0 {
		return 0, 0, false
	}
	return req.Level, req.Duration, true
}

// computeMemberExpiry 计算新的会员等级与过期时间戳（不允许降级，有效期内顺延）
func computeMemberExpiry(curLevel int, curExpires int64, reqLevel, durationDays int, now int64) (int, int64) {
	newLevel := reqLevel
	if curLevel > newLevel {
		newLevel = curLevel // 不允许降级
	}
	var newExpires int64
	if curLevel > 0 && (curExpires == 0 || curExpires > now) {
		// 已有有效会员：续期（原永久会员保持永久）
		if curExpires == 0 {
			newExpires = 0
		} else {
			newExpires = curExpires + int64(durationDays)*86400
		}
	} else {
		// 无有效会员：从当前时间起算
		newExpires = now + int64(durationDays)*86400
	}
	return newLevel, newExpires
}

// respondMemberStatus 查询并返回当前用户会员状态
func respondMemberStatus(w http.ResponseWriter, userID int64) {
	user, err := findUserByID(userID)
	if err != nil || user == nil {
		writeJSON(w, 500, "查询会员状态失败", nil)
		return
	}
	now := time.Now().Unix()
	expired := user.MemberExpiresAt != 0 && now > user.MemberExpiresAt
	writeJSON(w, 200, "ok", map[string]interface{}{
		"member_level":       user.MemberLevel,
		"member_expires_at":  user.MemberExpiresAt,
		"is_expired":         expired,
		"is_member":          user.MemberLevel > 0 && !expired,
		"token_balance":      getEffectiveTokenBalance(userID),
		"badge_id":           memberBadgeID(user.MemberLevel),
		"disable_official_api": getFlag("disable_official_api"),
	})
}

// POST /api/member/open — 开通会员
func handleMemberOpen(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	level, durationDays, ok := parseMemberReq(r)
	if !ok {
		writeJSON(w, 400, "参数错误（level 须为 1-3，duration 须大于 0）", nil)
		return
	}
	user, err := findUserByID(userID)
	if err != nil || user == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}
	now := time.Now().Unix()
	newLevel, newExpires := computeMemberExpiry(user.MemberLevel, user.MemberExpiresAt, level, durationDays, now)
	// 开通欢迎 Token 奖励：与「会员中心」对应等级标注的赠送 Token 完全一致
	welcome := memberWelcomeTokens(level)
	if _, err := db.Exec("UPDATE users SET member_level = ?, member_expires_at = ?, token_balance = token_balance + ? WHERE id = ?",
		newLevel, newExpires, welcome, userID); err != nil {
		log.Printf("[会员] 开通失败: %v", err)
		writeJSON(w, 500, "开通失败", nil)
		return
	}
	if bid := memberBadgeID(newLevel); bid > 0 {
		if err := grantBadges(userID, []int{bid}, userID, newExpires); err != nil {
			log.Printf("[会员] 授予会员徽章失败: %v", err)
		}
	}
	log.Printf("[会员] 用户 %d 开通会员等级 %d，有效期至 %d，赠送 Token %d", userID, newLevel, newExpires, welcome)
	respondMemberStatus(w, userID)
}

// POST /api/member/renew — 会员续费
func handleMemberRenew(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	level, durationDays, ok := parseMemberReq(r)
	if !ok {
		writeJSON(w, 400, "参数错误（level 须为 1-3，duration 须大于 0）", nil)
		return
	}
	user, err := findUserByID(userID)
	if err != nil || user == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}
	now := time.Now().Unix()
	newLevel, newExpires := computeMemberExpiry(user.MemberLevel, user.MemberExpiresAt, level, durationDays, now)
	if _, err := db.Exec("UPDATE users SET member_level = ?, member_expires_at = ? WHERE id = ?",
		newLevel, newExpires, userID); err != nil {
		log.Printf("[会员] 续费失败: %v", err)
		writeJSON(w, 500, "续费失败", nil)
		return
	}
	log.Printf("[会员] 用户 %d 续费会员等级 %d，有效期至 %d", userID, newLevel, newExpires)
	respondMemberStatus(w, userID)
}

// GET /api/member/status — 查询会员状态
func handleMemberStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	respondMemberStatus(w, userID)
}

// POST /api/member/order/submit — 用户提交会员开通订单（扫码支付后凭订单号提交）
// validateOrderNo 校验微信个人转账单号：二维码转账为 32 位、直接转账为 31 位，仅允许字母 / 数字 / 下划线 / 连字符。
// 微信规则：第 11~18 位为转账日期 YYYYMMDD（年4 + 月2 + 日2）。
// 若年份不是今年，或日期距今天超过 3 天、为未来日期，则判定为异常单号，返回「请输入正确的转账单号」。
func validateOrderNo(no string) (bool, string) {
	if len(no) != 31 && len(no) != 32 {
		return false, "转账单号应为 31 或 32 位（微信转账单号）"
	}
	for _, r := range no {
		if !(r == '_' || r == '-' || (r >= '0' && r <= '9') || (r >= 'A' && r <= 'Z') || (r >= 'a' && r <= 'z')) {
			return false, "转账单号仅允许字母、数字、下划线和连字符"
		}
	}
	// 解析微信交易日期（第 11~18 位，字符串 0-based 切片为 [10:18]）
	datePart := no[10:18]
	year, errY := strconv.Atoi(datePart[0:4])
	month, errM := strconv.Atoi(datePart[4:6])
	day, errD := strconv.Atoi(datePart[6:8])
	now := time.Now()
	if errY != nil || errM != nil || errD != nil || year != now.Year() {
		return false, "请输入正确的转账单号"
	}
	if month < 1 || month > 12 || day < 1 || day > 31 {
		return false, "请输入正确的转账单号"
	}
	t := time.Date(year, time.Month(month), day, 0, 0, 0, 0, now.Location())
	diff := now.Sub(t)
	if diff < 0 || diff > 3*24*time.Hour {
		return false, "请输入正确的转账单号"
	}
	return true, ""
}

// ensureMemberOrderColumns 幂等地为 member_orders 补上 recharge 功能所需的扩展列。
// 早期仅支持会员订单的表没有这些列；若运行中的库未执行迁移就直接 INSERT/SELECT 含
// 这两列的语句，会整批失败，表现为「开发者管理看不到任何新订单」。这里在相关接口
// 入口自愈，确保列一定存在（列已存在时 ALTER 报错被忽略，幂等安全）。
func ensureMemberOrderColumns() {
	_, _ = db.Exec(`ALTER TABLE member_orders ADD COLUMN type TEXT NOT NULL DEFAULT 'member'`)
	_, _ = db.Exec(`ALTER TABLE member_orders ADD COLUMN tokens BIGINT NOT NULL DEFAULT 0`)
	_, _ = db.Exec(`ALTER TABLE member_orders ADD COLUMN reject_reason TEXT NOT NULL DEFAULT ''`)
}

// ensureSystemNoticesTable 幂等地创建系统通知表并补上 order_id 列（老库兼容）。
func ensureSystemNoticesTable() {
	if _, err := db.Exec(`CREATE TABLE IF NOT EXISTS system_notices (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		user_id INTEGER NOT NULL,
		title TEXT NOT NULL DEFAULT '',
		desc TEXT NOT NULL DEFAULT '',
		tag TEXT NOT NULL DEFAULT '',
		order_id INTEGER NOT NULL DEFAULT 0,
		created_at INTEGER NOT NULL DEFAULT 0
	)`); err != nil {
		log.Printf("[通知] 建表失败: %v", err)
		return
	}
	// 幂等补列：老库可能还没有 order_id 列，补上即可（列已存在时 ALTER 报错被忽略）
	_, _ = db.Exec(`ALTER TABLE system_notices ADD COLUMN order_id INTEGER NOT NULL DEFAULT 0`)
}

// saveSystemNotice 将系统通知持久化到数据库，确保用户离线或后端重启后仍可拉取历史，
// 不再依赖仅存于内存的 TCP 离线队列（进程重启即丢）。
// orderID 为关联的订单 ID（无关联时传 0），用于通知中心「查看订单」跳转。
func saveSystemNotice(userID int64, title, desc, tag string, orderID int64) {
	ensureSystemNoticesTable()
	if _, err := db.Exec("INSERT INTO system_notices (user_id, title, desc, tag, order_id, created_at) VALUES (?, ?, ?, ?, ?, ?)",
		userID, title, desc, tag, orderID, time.Now().Unix()); err != nil {
		log.Printf("[通知] 保存系统通知失败: %v", err)
	}
}

func handleSubmitMemberOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	ensureMemberOrderColumns()
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		Level        int     `json:"level"`
		DurationDays int     `json:"duration_days"`
		Amount       float64 `json:"amount"`
		OrderNo      string  `json:"order_no"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if req.Level < 1 || req.Level > 3 || req.DurationDays <= 0 {
		writeJSON(w, 400, "参数错误（level 须为 1-3，duration 须大于 0）", nil)
		return
	}
	orderNo := strings.TrimSpace(req.OrderNo)
	if orderNo == "" {
		writeJSON(w, 400, "请填写订单号", nil)
		return
	}
	if ok, msg := validateOrderNo(orderNo); !ok {
		writeJSON(w, 400, msg, nil)
		return
	}
	user, err := findUserByID(userID)
	if err != nil || user == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}
	// 频率限制：单个用户 10 分钟内最多提交 1 笔订单
	if allowed, wait := checkOrderSubmitRateLimit(userID); !allowed {
		writeJSON(w, 429, fmt.Sprintf("提交订单过于频繁，请于 %d 分钟后再试", (wait+59)/60), nil)
		return
	}
	now := time.Now().Unix()
	res, err := db.Exec(`INSERT INTO member_orders (user_id, username, level, duration_days, amount, order_no, status, created_at, type, tokens)
		VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, 'member', 0)`,
		userID, user.Username, req.Level, req.DurationDays, req.Amount, orderNo, now)
	if err != nil {
		log.Printf("[订单] 提交失败: %v", err)
		writeJSON(w, 500, "提交失败", nil)
		return
	}
	affected, _ := res.RowsAffected()
	var total int
	db.QueryRow(`SELECT COUNT(*) FROM member_orders`).Scan(&total)
	log.Printf("[订单] 用户 %d 提交会员订单 level=%d duration=%d 订单号=%s | 影响行数=%d 当前总订单数=%d", userID, req.Level, req.DurationDays, orderNo, affected, total)
	writeJSON(w, 200, "订单已提交，等待审核", map[string]interface{}{"status": "pending"})
}

// POST /api/orders/recharge/submit — 用户提交 Token 充值订单
func handleSubmitRechargeOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	ensureMemberOrderColumns()
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		Tokens  int64   `json:"tokens"`
		Amount  float64 `json:"amount"`
		OrderNo string  `json:"order_no"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if req.Tokens <= 0 {
		writeJSON(w, 400, "请填写要充值的 Token 数量", nil)
		return
	}
	if req.Amount < 1.0 {
		writeJSON(w, 400, "最低 1 元起充", nil)
		return
	}
	orderNo := strings.TrimSpace(req.OrderNo)
	if orderNo == "" {
		writeJSON(w, 400, "请填写订单号", nil)
		return
	}
	if ok, msg := validateOrderNo(orderNo); !ok {
		writeJSON(w, 400, msg, nil)
		return
	}
	user, err := findUserByID(userID)
	if err != nil || user == nil {
		writeJSON(w, 404, "用户不存在", nil)
		return
	}
	// 频率限制：单个用户 10 分钟内最多提交 1 笔订单（与会员订单共用）
	if allowed, wait := checkOrderSubmitRateLimit(userID); !allowed {
		writeJSON(w, 429, fmt.Sprintf("提交订单过于频繁，请于 %d 分钟后再试", (wait+59)/60), nil)
		return
	}
	now := time.Now().Unix()
	if _, err := db.Exec(`INSERT INTO member_orders (user_id, username, level, duration_days, amount, order_no, status, created_at, type, tokens)
		VALUES (?, ?, 0, 0, ?, ?, 'pending', ?, 'recharge', ?)`,
		userID, user.Username, req.Amount, orderNo, now, req.Tokens); err != nil {
		log.Printf("[充值] 提交失败: %v", err)
		writeJSON(w, 500, "提交失败", nil)
		return
	}
	log.Printf("[充值] 用户 %d 提交充值订单 tokens=%d 金额=%.2f 订单号=%s", userID, req.Tokens, req.Amount, orderNo)
	writeJSON(w, 200, "订单已提交，等待审核", map[string]interface{}{"status": "pending"})
}

// GET /api/admin/member-orders — 管理员查看所有会员订单
func handleAdminListMemberOrders(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	ensureMemberOrderColumns()
	if !checkDevOrPerm(r, "apps.review") {
		log.Printf("[订单列表] 拦截：无 apps.review 权限")
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	// COALESCE 兜底：老库 processed_at 可能为 NULL，直接扫进 int64 会报错导致整行被丢弃，
	// 表现为「新提交的 pending 订单在开发者管理看不到，只有审核过的旧订单能看到」。
	rows, err := db.Query(`SELECT id, user_id, username, level, duration_days, amount, order_no, status, created_at, COALESCE(processed_at, 0) AS processed_at, type, tokens, COALESCE(reject_reason, '') AS reject_reason
		FROM member_orders ORDER BY created_at DESC`)
	if err != nil {
		log.Printf("[订单列表] 查询失败: %v", err)
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	defer rows.Close()
	type orderItem struct {
		ID           int64   `json:"id"`
		UserID       int64   `json:"user_id"`
		Username     string  `json:"username"`
		Level        int     `json:"level"`
		DurationDays int     `json:"duration_days"`
		Amount       float64 `json:"amount"`
		OrderNo      string  `json:"order_no"`
		Status       string  `json:"status"`
		CreatedAt    int64   `json:"created_at"`
		ProcessedAt  int64   `json:"processed_at"`
		Type         string  `json:"type"`
		Tokens       int64   `json:"tokens"`
		RejectReason string  `json:"reject_reason"`
	}
	list := []orderItem{}
	skipped := 0
	for rows.Next() {
		var o orderItem
		if err := rows.Scan(&o.ID, &o.UserID, &o.Username, &o.Level, &o.DurationDays, &o.Amount, &o.OrderNo, &o.Status, &o.CreatedAt, &o.ProcessedAt, &o.Type, &o.Tokens, &o.RejectReason); err != nil {
			log.Printf("[订单列表] 跳过一行(Scan失败): %v", err)
			skipped++
			continue
		}
		list = append(list, o)
	}
	log.Printf("[订单列表] 返回订单数=%d, 跳过=%d", len(list), skipped)
	writeJSON(w, 200, "ok", map[string]interface{}{"orders": list})
}

// POST /api/admin/member-order/process — 管理员处理订单：approve / reject / delete
func handleAdminProcessMemberOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "apps.review") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		ID     int64  `json:"id"`
		Action string `json:"action"`
		Reason string `json:"reason"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if req.ID <= 0 {
		writeJSON(w, 400, "订单 ID 无效", nil)
		return
	}
	switch req.Action {
	case "delete":
		if _, err := db.Exec("DELETE FROM member_orders WHERE id = ?", req.ID); err != nil {
			writeJSON(w, 500, "删除失败", nil)
			return
		}
		writeJSON(w, 200, "已删除", nil)
	case "reject":
		var o struct {
			UserID int64
			Type   string
		}
		if err := db.QueryRow("SELECT user_id, type FROM member_orders WHERE id = ?", req.ID).
			Scan(&o.UserID, &o.Type); err != nil {
			writeJSON(w, 404, "订单不存在", nil)
			return
		}
		reason := strings.TrimSpace(req.Reason)
		if reason == "" {
			reason = "管理员未填写拒绝原因"
		}
		if _, err := db.Exec("UPDATE member_orders SET status = 'rejected', processed_at = ?, reject_reason = ? WHERE id = ?", time.Now().Unix(), reason, req.ID); err != nil {
			writeJSON(w, 500, "操作失败", nil)
			return
		}
		// 推送系统通知卡片到「通知中心」对话（在线走 TCP，离线进离线队列），附拒绝原因
		PushToUser(o.UserID, "system_notice", map[string]interface{}{
			"title":    "您的订单被拒绝",
			"desc":     "拒绝原因：" + reason,
			"tag":      "订单拒绝",
			"order_id": req.ID,
		})
		// 持久化到数据库，避免后端重启/用户离线导致通知丢失
		saveSystemNotice(o.UserID, "您的订单被拒绝", "拒绝原因："+reason, "订单拒绝", req.ID)
		log.Printf("[订单] 管理员拒绝订单 %d，用户 %d，原因：%s", req.ID, o.UserID, reason)
		writeJSON(w, 200, "已拒绝", nil)
	case "approve":
		var o struct {
			UserID       int64
			Level        int
			DurationDays int
			Status       string
			Type         string
			Tokens       int64
		}
		if err := db.QueryRow("SELECT user_id, level, duration_days, status, type, tokens FROM member_orders WHERE id = ?", req.ID).
			Scan(&o.UserID, &o.Level, &o.DurationDays, &o.Status, &o.Type, &o.Tokens); err != nil {
			writeJSON(w, 404, "订单不存在", nil)
			return
		}
		if o.Status == "approved" {
			writeJSON(w, 400, "该订单已处理", nil)
			return
		}
		user, uerr := findUserByID(o.UserID)
		if uerr != nil || user == nil {
			writeJSON(w, 404, "用户不存在", nil)
			return
		}
		now := time.Now().Unix()
		// 充值订单：审核通过后直接发放 Token
		if o.Type == "recharge" {
			if o.Tokens > 0 {
				if _, err := db.Exec("UPDATE users SET token_balance = token_balance + ? WHERE id = ?", o.Tokens, o.UserID); err != nil {
					writeJSON(w, 500, "充值失败", nil)
					return
				}
			}
		if _, err := db.Exec("UPDATE member_orders SET status = 'approved', processed_at = ?, reject_reason = '' WHERE id = ?", now, req.ID); err != nil {
			log.Printf("[充值] 更新订单状态失败: %v", err)
		}
		log.Printf("[充值] 管理员批准充值订单 %d，用户 %d 获得 Token %d", req.ID, o.UserID, o.Tokens)
		// 推送系统通知卡片到「系统通知」对话
		PushToUser(o.UserID, "system_notice", map[string]interface{}{
			"title":    "您的订单已通过",
			"desc":     fmt.Sprintf("您提交的充值订单已审核通过，%d 个 Token 已下发至您的账户", o.Tokens),
			"tag":      "充值到账",
			"order_id": req.ID,
		})
		saveSystemNotice(o.UserID, "您的订单已通过", fmt.Sprintf("您提交的充值订单已审核通过，%d 个 Token 已下发至您的账户", o.Tokens), "充值到账", req.ID)
		writeJSON(w, 200, "已同意，Token 已到账", nil)
		return
		}
		// 会员订单：审核通过后开通会员并发放赠送 Token
		newLevel, newExpires := computeMemberExpiry(user.MemberLevel, user.MemberExpiresAt, o.Level, o.DurationDays, now)
		welcome := memberWelcomeTokens(o.Level)
		if _, err := db.Exec("UPDATE users SET member_level = ?, member_expires_at = ?, token_balance = token_balance + ? WHERE id = ?",
			newLevel, newExpires, welcome, o.UserID); err != nil {
			writeJSON(w, 500, "开通失败", nil)
			return
		}
		if bid := memberBadgeID(newLevel); bid > 0 {
			_ = grantBadges(o.UserID, []int{bid}, o.UserID, newExpires)
		}
		// 按会员时长额外发放时长徽章（月度/季度/年度/永久），到期与会员同步
		if bid := memberDurationBadgeID(o.DurationDays); bid > 0 {
			_ = grantBadges(o.UserID, []int{bid}, o.UserID, newExpires)
		}
		if _, err := db.Exec("UPDATE member_orders SET status = 'approved', processed_at = ?, reject_reason = '' WHERE id = ?", now, req.ID); err != nil {
			log.Printf("[订单] 更新订单状态失败: %v", err)
		}
		log.Printf("[订单] 管理员批准订单 %d，用户 %d 开通会员等级 %d", req.ID, o.UserID, newLevel)
		// 推送系统通知卡片到「系统通知」对话
		PushToUser(o.UserID, "system_notice", map[string]interface{}{
			"title":    "您的订单已通过",
			"desc":     fmt.Sprintf("您提交的会员订单已审核通过，赠送的 %d 个 Token 已下发至您的账户", welcome),
			"tag":      "会员开通",
			"order_id": req.ID,
		})
		saveSystemNotice(o.UserID, "您的订单已通过", fmt.Sprintf("您提交的会员订单已审核通过，赠送的 %d 个 Token 已下发至您的账户", welcome), "会员开通", req.ID)
		writeJSON(w, 200, "已同意，会员已生效", nil)
	default:
		writeJSON(w, 400, "无效的操作", nil)
	}
}

// ==================== 开发者通知中心（系统通知下发） ====================

// POST /api/admin/notify — 开发者/管理员向用户发送系统通知（通知中心）
// 范围 scope: "user"(按用户名列表) | "all"(全部在线+离线) | "range"(ID 区块)
func handleAdminSendNotification(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "notify.send") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		Scope     string    `json:"scope"`
		Usernames []string  `json:"usernames"`
		Ranges    [][]int64 `json:"ranges"`
		Title     string    `json:"title"`
		Content   string    `json:"content"`
		Extra     string    `json:"extra"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数解析失败", nil)
		return
	}
	title := strings.TrimSpace(req.Title)
	content := strings.TrimSpace(req.Content)
	if title == "" {
		title = "通知中心"
	}
	if content == "" {
		writeJSON(w, 400, "通知内容不能为空", nil)
		return
	}

	targetSet := map[int64]bool{}
	addID := func(id int64) {
		if id > 0 {
			targetSet[id] = true
		}
	}
	switch req.Scope {
	case "user":
		for _, un := range req.Usernames {
			un = strings.TrimSpace(un)
			if un == "" {
				continue
			}
			// 纯数字 → 按用户 ID 匹配（兼容"按 ID 发送"）
			if id, err := strconv.ParseInt(un, 10, 64); err == nil && id > 0 {
				var exists int
				if e := db.QueryRow("SELECT 1 FROM users WHERE id = ? AND "+notDeletedCond, id).Scan(&exists); e == nil {
					addID(id)
					continue
				}
			}
			// 否则按用户名匹配：LOWER 使其大小写不敏感，避免"明明存在却查不到"
			var id int64
			if err := db.QueryRow("SELECT id FROM users WHERE LOWER(username) = LOWER(?) AND "+notDeletedCond, un).Scan(&id); err == nil {
				addID(id)
			}
		}
	case "all":
		rows, err := db.Query("SELECT id FROM users WHERE " + notDeletedCond)
		if err == nil {
			for rows.Next() {
				var id int64
				if rows.Scan(&id) == nil {
					addID(id)
				}
			}
			rows.Close()
		}
	case "range":
		for _, rg := range req.Ranges {
			if len(rg) < 2 {
				continue
			}
			mn, mx := rg[0], rg[1]
			if mn > mx {
				mn, mx = mx, mn
			}
			rows, err := db.Query("SELECT id FROM users WHERE id BETWEEN ? AND ? AND "+notDeletedCond, mn, mx)
			if err == nil {
				for rows.Next() {
					var id int64
					if rows.Scan(&id) == nil {
						addID(id)
					}
				}
				rows.Close()
			}
		}
	default:
		writeJSON(w, 400, "未知的通知范围", nil)
		return
	}

	if len(targetSet) == 0 {
		writeJSON(w, 400, "未找到匹配的用户（请检查用户名/ID 是否正确，或账号是否已注销）", nil)
		return
	}

	sent := 0
	for uid := range targetSet {
		PushToUser(uid, "system_notice", map[string]interface{}{
			"title": title,
			"desc":  content,
			"tag":   strings.TrimSpace(req.Extra),
		})
		saveSystemNotice(uid, title, content, strings.TrimSpace(req.Extra), 0)
		sent++
	}
	writeJSON(w, 200, "已发送", map[string]interface{}{"sent": sent})
}

// GET /api/system-notices — 返回当前登录用户的系统通知历史（持久化存储，重启/离线不丢）
func handleGetSystemNotices(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	tokenStr := extractToken(r)
	if tokenStr == "" {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	userID, _, _, err := validateToken(tokenStr)
	if err != nil || userID <= 0 {
		writeJSON(w, 401, "登录状态异常", nil)
		return
	}
	ensureSystemNoticesTable()
	rows, qerr := db.Query("SELECT id, title, desc, tag, order_id, created_at FROM system_notices WHERE user_id = ? ORDER BY created_at ASC, id ASC", userID)
	if qerr != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	defer rows.Close()
	list := []map[string]interface{}{}
	for rows.Next() {
		var id int64
		var title, desc, tag string
		var orderID, createdAt int64
		if err := rows.Scan(&id, &title, &desc, &tag, &orderID, &createdAt); err != nil {
			continue
		}
		list = append(list, map[string]interface{}{
			"id":         id,
			"title":      title,
			"desc":       desc,
			"tag":        tag,
			"order_id":   orderID,
			"created_at": createdAt,
		})
	}
	writeJSON(w, 200, "ok", list)
}

// GET /api/orders/<id> — 用户查看自己的某笔订单详情（仅能查看属于自己的订单）
func handleGetOrder(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID, _, _, err := validateToken(extractToken(r))
	if err != nil || userID <= 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	// 从路径 /api/orders/<id> 解析订单 ID
	idStr := strings.TrimPrefix(r.URL.Path, "/api/orders/")
	idStr = strings.Trim(idStr, "/")
	orderID, perr := strconv.ParseInt(idStr, 10, 64)
	if perr != nil || orderID <= 0 {
		writeJSON(w, 400, "订单 ID 无效", nil)
		return
	}
	ensureMemberOrderColumns()
	var o struct {
		ID           int64
		UserID       int64
		Username     string
		Level        int
		DurationDays int
		Amount       float64
		OrderNo      string
		Status       string
		CreatedAt    int64
		ProcessedAt  int64
		Type         string
		Tokens       int64
		RejectReason string
	}
	// COALESCE 兜底老库 NULL 列
	if err := db.QueryRow(`SELECT id, user_id, username, level, duration_days, amount, order_no, status, created_at, COALESCE(processed_at, 0), type, tokens, COALESCE(reject_reason, '')
		FROM member_orders WHERE id = ?`, orderID).Scan(
		&o.ID, &o.UserID, &o.Username, &o.Level, &o.DurationDays, &o.Amount, &o.OrderNo, &o.Status, &o.CreatedAt, &o.ProcessedAt, &o.Type, &o.Tokens, &o.RejectReason); err != nil {
		writeJSON(w, 404, "订单不存在", nil)
		return
	}
	// 仅允许查看属于自己的订单，避免越权
	if o.UserID != userID {
		writeJSON(w, 403, "无权查看该订单", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{
		"id":            o.ID,
		"user_id":       o.UserID,
		"username":      o.Username,
		"level":         o.Level,
		"duration_days": o.DurationDays,
		"amount":        o.Amount,
		"order_no":      o.OrderNo,
		"status":        o.Status,
		"created_at":    o.CreatedAt,
		"processed_at":  o.ProcessedAt,
		"type":          o.Type,
		"tokens":        o.Tokens,
		"reject_reason": o.RejectReason,
	})
}

// POST /api/admin/balance/adjust — 调整指定用户 Token 余额（开发者管理-余额）
// POST /api/admin/balance/adjust — 按范围批量调整用户 Token 余额（加/扣/清空）
func handleAdminAdjustBalance(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "balance.manage") {
		writeJSON(w, 403, "无权访问", nil)
		return
	}
	var req struct {
		Scope     string    `json:"scope"`     // user | all | range
		Usernames []string  `json:"usernames"` // scope=user 时有效
		Ranges    [][]int64 `json:"ranges"`    // scope=range 时有效，每项为 [min,max]
		Op        string    `json:"op"`        // add | deduct | reset
		Amount    int64     `json:"amount"`    // add/deduct 时有效，须 >0
		Reason    string    `json:"reason"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, 400, "参数解析失败", nil)
		return
	}
	op := req.Op
	if op != "add" && op != "deduct" && op != "reset" {
		writeJSON(w, 400, "无效的操作类型", nil)
		return
	}
	if op != "reset" && req.Amount <= 0 {
		writeJSON(w, 400, "调整数量必须大于 0", nil)
		return
	}

	// 解析目标用户集合（排除已注销用户，与通知/封禁保持一致）
	targetSet := map[int64]bool{}
	addID := func(id int64) {
		if id > 0 {
			targetSet[id] = true
		}
	}
	switch req.Scope {
	case "user":
		for _, un := range req.Usernames {
			un = strings.TrimSpace(un)
			if un == "" {
				continue
			}
			var id int64
			if err := db.QueryRow("SELECT id FROM users WHERE username = ? AND "+notDeletedCond, un).Scan(&id); err == nil {
				addID(id)
			}
		}
	case "all":
		rows, err := db.Query("SELECT id FROM users WHERE " + notDeletedCond)
		if err == nil {
			for rows.Next() {
				var id int64
				if rows.Scan(&id) == nil {
					addID(id)
				}
			}
			rows.Close()
		}
	case "range":
		for _, rg := range req.Ranges {
			if len(rg) < 2 {
				continue
			}
			mn, mx := rg[0], rg[1]
			if mn > mx {
				mn, mx = mx, mn
			}
			rows, err := db.Query("SELECT id FROM users WHERE id BETWEEN ? AND ? AND "+notDeletedCond, mn, mx)
			if err == nil {
				for rows.Next() {
					var id int64
					if rows.Scan(&id) == nil {
						addID(id)
					}
				}
				rows.Close()
			}
		}
	default:
		writeJSON(w, 400, "未知的调整范围", nil)
		return
	}
	if len(targetSet) == 0 {
		writeJSON(w, 400, "未找到任何目标用户", nil)
		return
	}

	// 构造 IN 占位符与参数（金额作为首个参数）
	ids := make([]int64, 0, len(targetSet))
	for id := range targetSet {
		ids = append(ids, id)
	}
	placeholders := make([]string, len(ids))
	args := make([]interface{}, 0, len(ids)+1)
	for i, id := range ids {
		placeholders[i] = "?"
		args = append(args, id)
	}
	inClause := strings.Join(placeholders, ",")

	var sqlStr string
	switch op {
	case "add":
		sqlStr = "UPDATE users SET token_balance = token_balance + ? WHERE id IN (" + inClause + ")"
		args = append([]interface{}{req.Amount}, args...)
	case "deduct":
		sqlStr = "UPDATE users SET token_balance = MAX(0, token_balance - ?) WHERE id IN (" + inClause + ")"
		args = append([]interface{}{req.Amount}, args...)
	case "reset":
		sqlStr = "UPDATE users SET token_balance = 0 WHERE id IN (" + inClause + ")"
	}

	res, err := db.Exec(sqlStr, args...)
	if err != nil {
		writeJSON(w, 500, "调整失败: "+err.Error(), nil)
		return
	}
	affected, _ := res.RowsAffected()
	writeJSON(w, 200, "已调整", map[string]interface{}{"affected": affected})
}

// ==================== 每日签到 ====================

// 连续签到每日奖励：每天固定 5000 Token（不随天数变化）
var checkinDailyRewards = []int64{5000, 5000, 5000, 5000, 5000, 5000, 5000}

// checkinRewardForDay 返回第 day 天（从 1 起）的签到奖励，每天固定 5000
func checkinRewardForDay(day int) int64 {
	if day < 1 {
		day = 1
	}
	return checkinDailyRewards[(day-1)%7]
}

// respondCheckinStatus 返回当前用户签到状态
// grantedReward：本次签到实际发放的奖励（非签到动作时传 0）
func respondCheckinStatus(w http.ResponseWriter, userID int64, grantedReward int64) {
	tokenBalance := getEffectiveTokenBalance(userID)
	now := time.Now()
	todayStr := now.Format("2006-01-02")

	var checkedToday int
	db.QueryRow("SELECT COUNT(*) FROM checkin_logs WHERE user_id = ? AND checkin_date = ?", userID, todayStr).Scan(&checkedToday)

	// 当前连续天数：从今天（若未签则从昨天）往前连续计数
	startD := now
	if checkedToday == 0 {
		startD = now.AddDate(0, 0, -1)
	}
	streak := 0
	d := startD
	for {
		ds := d.Format("2006-01-02")
		var c int
		db.QueryRow("SELECT COUNT(*) FROM checkin_logs WHERE user_id = ? AND checkin_date = ?", userID, ds).Scan(&c)
		if c == 0 {
			break
		}
		streak++
		d = d.AddDate(0, 0, -1)
		if streak > 366 {
			break
		}
	}

	// 本月签到记录
	monthPrefix := now.Format("2006-01") + "-"
	rows, err := db.Query("SELECT checkin_date, streak, reward_tokens FROM checkin_logs WHERE user_id = ? AND checkin_date LIKE ? ORDER BY checkin_date ASC", userID, monthPrefix)
	var records []map[string]interface{}
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var ds string
			var st, rw int
			if rows.Scan(&ds, &st, &rw) == nil {
				records = append(records, map[string]interface{}{"date": ds, "streak": st, "reward": rw})
			}
		}
	}
	if records == nil {
		records = []map[string]interface{}{}
	}

	var total int
	db.QueryRow("SELECT COUNT(*) FROM checkin_logs WHERE user_id = ?", userID).Scan(&total)

	// 首次签到日期（锚点）：作为前端展示窗口最左第一天，固定不动
	var firstCheckin sql.NullString
	db.QueryRow("SELECT MIN(checkin_date) FROM checkin_logs WHERE user_id = ?", userID).Scan(&firstCheckin)

	// 展示窗口内已签到的日期列表（锚点 .. 锚点+6，共 7 天）
	checkedDates := []string{}
	if firstCheckin.Valid {
		if anchor, err := time.Parse("2006-01-02", firstCheckin.String); err == nil {
			endStr := anchor.AddDate(0, 0, 6).Format("2006-01-02")
			if rows2, e2 := db.Query("SELECT checkin_date FROM checkin_logs WHERE user_id = ? AND checkin_date >= ? AND checkin_date <= ? ORDER BY checkin_date ASC", userID, firstCheckin.String, endStr); e2 == nil {
				defer rows2.Close()
				for rows2.Next() {
					var ds string
					if rows2.Scan(&ds) == nil {
						checkedDates = append(checkedDates, ds)
					}
				}
			}
		}
	}

	var firstCheckinDate interface{}
	if firstCheckin.Valid {
		firstCheckinDate = firstCheckin.String
	}

	writeJSON(w, 200, "ok", map[string]interface{}{
		"checked_today":      checkedToday > 0,
		"streak":             streak,
		"token_balance":      tokenBalance,
		"first_checkin_date": firstCheckinDate,
		"checked_dates":      checkedDates,
		"month_records":      records,
		"total":              total,
		"daily_rewards":      checkinDailyRewards,
		"reward":             grantedReward,
	})
}

// POST /api/activity/checkin — 每日签到
func handleCheckin(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	now := time.Now()
	todayStr := now.Format("2006-01-02")
	nowUnix := now.Unix()

	// 幂等：今天已签则直接返回当前状态
	var cnt int
	db.QueryRow("SELECT COUNT(*) FROM checkin_logs WHERE user_id = ? AND checkin_date = ?", userID, todayStr).Scan(&cnt)
	if cnt > 0 {
		respondCheckinStatus(w, userID, 0)
		return
	}

	// 计算连续天数：看昨天是否有记录
	yesterdayStr := now.AddDate(0, 0, -1).Format("2006-01-02")
	var yStreak int
	db.QueryRow("SELECT COALESCE(MAX(streak), 0) FROM checkin_logs WHERE user_id = ? AND checkin_date = ?", userID, yesterdayStr).Scan(&yStreak)
	streak := yStreak + 1

	reward := checkinRewardForDay(streak) // 按连续天数额外档位发放

	tx, err := db.Begin()
	if err != nil {
		writeJSON(w, 500, "签到失败", nil)
		return
	}
	if _, err := tx.Exec("INSERT INTO checkin_logs (user_id, checkin_date, checkin_at, streak, reward_tokens) VALUES (?, ?, ?, ?, ?)",
		userID, todayStr, nowUnix, streak, reward); err != nil {
		tx.Rollback()
		// 并发重复签到：主键 (user_id, checkin_date) 已存在 → 视为已签到，直接返回当前状态，不报错、不重复发奖
		var c int
		db.QueryRow("SELECT COUNT(*) FROM checkin_logs WHERE user_id = ? AND checkin_date = ?", userID, todayStr).Scan(&c)
		if c > 0 {
			respondCheckinStatus(w, userID, 0)
			return
		}
		writeJSON(w, 500, "签到记录失败", nil)
		return
	}
	if _, err := tx.Exec("UPDATE users SET token_balance = token_balance + ? WHERE id = ?", reward, userID); err != nil {
		tx.Rollback()
		writeJSON(w, 500, "签到奖励发放失败", nil)
		return
	}
	if err := tx.Commit(); err != nil {
		writeJSON(w, 500, "签到提交失败", nil)
		return
	}
	log.Printf("[签到] 用户 %d 签到成功，连续 %d 天，奖励 %d 计入永久余额", userID, streak, reward)
	respondCheckinStatus(w, userID, reward)
}

// GET /api/activity/checkin/status — 查询签到状态
func handleCheckinStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	respondCheckinStatus(w, userID, 0)
}
