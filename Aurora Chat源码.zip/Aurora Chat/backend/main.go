package main

import (
	"fmt"
	"log"
	"net/http"
	"net/http/pprof"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// handleTCPStatusDebug 用于客户端诊断：返回 TCP 服务器配置端口
func handleTCPStatusDebug(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{
		"tcp_port": getTCPPort(),
		"hint":     "客户端应连接此端口；若仍连不上，请检查防火墙/安全组/网络运营商是否放行",
	})
}

func main() {
	execPath, _ := os.Executable()
	baseDir := filepath.Dir(execPath)
	dataDir := filepath.Join(baseDir, "data")
	os.MkdirAll(dataDir, 0755)

	// 初始化 JWT 密钥（必须在任何 token 校验前；建议设置 JWT_SECRET 环境变量固定）
	setJWTSecret()

	// 初始化服务端静态加密密钥（必须在 db 读写前）
	initServerSecurity(dataDir)

	// 初始化数据库
	dbPath := filepath.Join(dataDir, "aurora_chat.db")
	initDB(dbPath)
	defer db.Close()

	// 初始化用户数据库目录（每个用户一个独立文件）
	initUserDB(dataDir)

	// 加载版本配置（从 version.txt）
	loadVersionConfig()

	// 启动时自动为开发者发放徽章
	autoGrantDeveloperBadges()

	// 初始化路由
	mux := http.NewServeMux()

	// ==================== pprof 性能观测（/debug/pprof/*） ====================
	// 注意：pprof 接口未做鉴权，可 dump 堆/CPU/goroutine 信息，公网部署建议用防火墙
	// 或反代限制仅内网可访问，或用 authMiddleware 包裹后按需开放。
	mux.HandleFunc("/debug/pprof/", pprof.Index)
	mux.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
	mux.HandleFunc("/debug/pprof/profile", pprof.Profile)
	mux.HandleFunc("/debug/pprof/symbol", pprof.Symbol)
	mux.HandleFunc("/debug/pprof/trace", pprof.Trace)

	// ==================== 公开接口（无需登录） ====================
	mux.HandleFunc("/api/send-code", handleSendCode)
	mux.HandleFunc("/api/register", handleRegister)
	mux.HandleFunc("/api/login", handleLogin)
	mux.HandleFunc("/api/reset-password", handleResetPassword)
	mux.HandleFunc("/api/send-reset-code", handleSendResetCode)
	mux.HandleFunc("/api/user/self-delete", authMiddleware(handleSelfDeleteUser))
	// 服务器登录（需要JWT用于开发者/管理员身份验证）
	mux.HandleFunc("/api/server/login", handleLoginServer) // 开放登录，无需 JWT
	mux.HandleFunc("/api/health", handleHealth)
	mux.HandleFunc("/api/app/version", handleAppVersion)
	mux.HandleFunc("/api/apps/comments/", handleAppGetComments)
	mux.HandleFunc("/api/apps/comment/add", authMiddleware(handleAppAddComment))
	mux.HandleFunc("/api/qq/login", handleQQLogin)
	mux.HandleFunc("/qrlogin", handleQRCodeLoginPage)
	mux.HandleFunc("/api/qr/user", handlePublicQrUser) // 落地页公开信息（无需登录）
    mux.HandleFunc("/api/qrcode-login/create", handleQRCodeLoginCreate)
	mux.HandleFunc("/api/qrcode-login/status/", handleQRCodeLoginStatus)
	mux.HandleFunc("/api/qrcode-login/scan", authMiddleware(handleQRCodeLoginScan))
	mux.HandleFunc("/api/qrcode-login/confirm", authMiddleware(handleQRCodeLoginConfirm))
	mux.HandleFunc("/api/user/db-path", authMiddleware(handleGetUserDbPath))
	mux.HandleFunc("/api/user/data/save", authMiddleware(handleUserDataSave))
	mux.HandleFunc("/api/user/data", authMiddleware(handleUserDataGet))
	mux.HandleFunc("/api/user/quota", authMiddleware(handleGetUserQuota))
	mux.HandleFunc("/api/check-trial", handleCheckTrialMode)
	mux.HandleFunc("/api/validate-card-key", handleValidateCardKey)
	mux.HandleFunc("/api/debug/tcp-status", handleTCPStatusDebug)

	// ==================== 业务接口（需要 JWT 认证） ====================
	mux.HandleFunc("/api/search-users", authMiddleware(handleSearchUsers))
	mux.HandleFunc("/api/friend-request/send", authMiddleware(handleSendFriendRequest))
	mux.HandleFunc("/api/friend-request/respond", authMiddleware(handleRespondFriendRequest))
	mux.HandleFunc("/api/friend-requests/", authMiddleware(handleGetFriendRequests))
	mux.HandleFunc("/api/friends/", authMiddleware(handleGetFriends))
	mux.HandleFunc("/api/friend/delete", authMiddleware(handleDeleteFriend))
	mux.HandleFunc("/api/messages/send", authMiddleware(handleSendMessage))
	mux.HandleFunc("/api/transfer", authMiddleware(handleTransfer))
	mux.HandleFunc("/api/redpacket/create", authMiddleware(handleRedPacketCreate))
	mux.HandleFunc("/api/redpacket/grab", authMiddleware(handleRedPacketGrab))
	mux.HandleFunc("/api/redpacket/detail", authMiddleware(handleRedPacketDetail))
	mux.HandleFunc("/api/messages/upload-media", authMiddleware(handleUploadChatMedia))
	mux.HandleFunc("/api/messages/poke", authMiddleware(handlePoke))
	mux.HandleFunc("/api/messages/recall", authMiddleware(handleRecallMessage))
	mux.HandleFunc("/api/messages/read", authMiddleware(handleMarkMessageRead))
	mux.HandleFunc("/api/messages/read-batch", authMiddleware(handleMarkMessagesReadBatch))
	mux.HandleFunc("/api/messages/info/", authMiddleware(handleMessageInfo))
	mux.HandleFunc("/api/messages/", authMiddleware(handleGetMessages))
	mux.HandleFunc("/api/conversations/", authMiddleware(handleGetConversations))
	mux.HandleFunc("/api/keys/upload", authMiddleware(handleUploadKey))
	mux.HandleFunc("/api/keys/", authMiddleware(handleGetKey))
	mux.HandleFunc("/api/avatar/upload", authMiddleware(handleAvatarUpload))
	mux.HandleFunc("/api/avatar/", handleAvatarGet) // GET 头像保持公开（用于展示）
	mux.HandleFunc("/api/user/privacy", authMiddleware(handleUserPrivacy))
	mux.HandleFunc("/api/user/signature", authMiddleware(handleUpdateSignature))
	mux.HandleFunc("/api/user/update", authMiddleware(handleUpdateProfile))
	mux.HandleFunc("/api/user/stats", authMiddleware(handleSyncUserStats))
	mux.HandleFunc("/api/user/badges", authMiddleware(handleGetUserBadges))
	mux.HandleFunc("/api/user/badge", authMiddleware(handleSetWornBadge))
	mux.HandleFunc("/api/user/bind-email/send-code", authMiddleware(handleSendBindCode))
	mux.HandleFunc("/api/user/bind-email", authMiddleware(handleBindEmail))
	mux.HandleFunc("/api/user/complete-profile", authMiddleware(handleCompleteProfile))
	mux.HandleFunc("/api/user/qrcode", authMiddleware(handleGetMyQrCode))
	mux.HandleFunc("/api/user/qrcode/resolve", authMiddleware(handleResolveQrCode))
	mux.HandleFunc("/api/user/", authMiddleware(handleGetUserByID))
	mux.HandleFunc("/api/users", authMiddleware(handleGetUsers))
	mux.HandleFunc("/api/users/online", authMiddleware(handleGetOnlineUsers))
	mux.HandleFunc("/api/admin/badge/grant", authMiddleware(handleAdminGrantBadge))
	mux.HandleFunc("/api/admin/badge/revoke", authMiddleware(handleAdminRevokeBadge))
	mux.HandleFunc("/api/admin/user/badges", authMiddleware(handleAdminGetUserBadges))
	mux.HandleFunc("/api/admin/user/delete", authMiddleware(handleAdminDeleteUser))
	mux.HandleFunc("/api/admin/user/reset-password", authMiddleware(handleAdminResetUserPassword))
	mux.HandleFunc("/api/admin/cleanup-bots", authMiddleware(handleAdminCleanupBots)) // 一键清理异常 QQ 机器人账号
	mux.HandleFunc("/api/admin/user/ban", authMiddleware(handleAdminBanUser))
	mux.HandleFunc("/api/admin/user/unban", authMiddleware(handleAdminUnbanUser))
	mux.HandleFunc("/api/admin/user/ban-status", authMiddleware(handleAdminCheckBanStatus))
	mux.HandleFunc("/api/admin/user/mute", authMiddleware(handleAdminMuteUser))
	mux.HandleFunc("/api/admin/user/unmute", authMiddleware(handleAdminUnmuteUser))
	mux.HandleFunc("/api/admin/user/mute-status", authMiddleware(handleAdminCheckMuteStatus))
	mux.HandleFunc("/api/group/mute", authMiddleware(handleGroupMuteUser))
	mux.HandleFunc("/api/group/unmute", authMiddleware(handleGroupUnmuteUser))
	mux.HandleFunc("/api/group/mute-status", authMiddleware(handleGroupCheckMuteStatus))
	mux.HandleFunc("/api/group/mute-members", authMiddleware(handleGroupMuteMembers))
	mux.HandleFunc("/api/admin/user/kick", authMiddleware(handleAdminKickUser))
	mux.HandleFunc("/api/admin/user/kick-all", authMiddleware(handleAdminKickAll))
	mux.HandleFunc("/api/admin/user/location", authMiddleware(handleAdminGetUserLocation))
	mux.HandleFunc("/api/admin/user/locations", authMiddleware(handleAdminGetUserLocations))
	mux.HandleFunc("/api/admin/user/update", authMiddleware(handleAdminUpdateUser))
	mux.HandleFunc("/api/admin/notify", authMiddleware(handleAdminSendNotification))
	mux.HandleFunc("/api/system-notices", handleGetSystemNotices) // 拉取系统通知历史（JWT 内置校验）
	mux.HandleFunc("/api/admin/balance/adjust", authMiddleware(handleAdminAdjustBalance))
	mux.HandleFunc("/api/location/upload", authMiddleware(handleUploadLocation))
	mux.HandleFunc("/api/user/ban-status", authMiddleware(handleCheckBanStatus))
	mux.HandleFunc("/api/user/mute-status", authMiddleware(handleCheckMuteStatus))
	mux.HandleFunc("/api/user/is-platform-admin", authMiddleware(handleCheckIsPlatformAdmin))
	mux.HandleFunc("/api/flash/view", authMiddleware(handleRecordFlashView))
	mux.HandleFunc("/api/flash/viewed-ids", authMiddleware(handleGetViewedFlashIDs))
	mux.HandleFunc("/api/user/ban-notify", authMiddleware(handleBanNotify))

	// ==================== 安全设置接口（需要 JWT 认证） ====================
	mux.HandleFunc("/api/security/status", authMiddleware(handleGetSecurityStatus))
	mux.HandleFunc("/api/security/save", authMiddleware(handleSaveSecurity))
	mux.HandleFunc("/api/security/verify", authMiddleware(handleVerifySecurity))

	// ==================== 服务器接口（需要 JWT 认证） ====================
	mux.HandleFunc("/api/server/register", authMiddleware(handleRegisterServer))
	mux.HandleFunc("/api/server/my", authMiddleware(handleGetMyServer))
	mux.HandleFunc("/api/server/status", authMiddleware(handleGetServerStatus))
	mux.HandleFunc("/api/server/shutdown", authMiddleware(handleShutdownServer))
	mux.HandleFunc("/api/server/restart", authMiddleware(handleRestartServer))
	mux.HandleFunc("/api/server/clear-cache", authMiddleware(handleClearServerCache))
	// 服务器文件管理
	mux.HandleFunc("/api/server/files/create", authMiddleware(handleCreateServerFile))
	mux.HandleFunc("/api/server/files/create-folder", authMiddleware(handleCreateServerFolder))
	mux.HandleFunc("/api/server/files/upload", authMiddleware(handleUploadServerFile))
	mux.HandleFunc("/api/server/files/list", authMiddleware(handleListServerFiles))
	mux.HandleFunc("/api/server/files/download/", authMiddleware(handleDownloadServerFile))
	mux.HandleFunc("/api/server/files/delete", authMiddleware(handleDeleteServerFile))
	mux.HandleFunc("/api/server/files/move", authMiddleware(handleMoveServerFile))
	mux.HandleFunc("/api/server/files/breadcrumb", authMiddleware(handleGetFolderBreadcrumb))
	mux.HandleFunc("/api/server/files/update", authMiddleware(handleUpdateServerFile))
	mux.HandleFunc("/api/server/files/rename", authMiddleware(handleRenameServerFile))
	mux.HandleFunc("/api/server/files/search", authMiddleware(handleSearchServerFiles))
	mux.HandleFunc("/api/server/dashboard", authMiddleware(handleServerDashboard))

	// 公共文件访问（通过域名直接访问，无需认证）
	mux.HandleFunc("/serve/", handlePublicServeFile)

	// 群聊路由 — 全部通过统一调度器 handleGetGroups 处理，避免 Go 1.21 路由不匹配
	mux.HandleFunc("/api/groups/", authMiddleware(handleGetGroups))
	mux.HandleFunc("/api/search-groups", authMiddleware(handleSearchGroups))
	mux.HandleFunc("/api/users/search", authMiddleware(handleSearchUsersForGroup))
	mux.HandleFunc("/api/groups/add-member", authMiddleware(handleAddGroupMember))
	mux.HandleFunc("/api/groups/remove-member", authMiddleware(handleRemoveGroupMember))
	mux.HandleFunc("/api/groups/ignore-join", authMiddleware(handleIgnoreJoinRequest))
	mux.HandleFunc("/api/admin/groups/update-display-id", authMiddleware(handleAdminUpdateGroupDisplayId))
	mux.HandleFunc("/api/admin/groups/send-message", authMiddleware(handleAdminDeveloperSendMessage))
	mux.HandleFunc("/api/admin/groups/messages/", authMiddleware(handleAdminGetGroupMessages))
	mux.HandleFunc("/api/admin/platform-admin/grant", authMiddleware(handleGrantPlatformAdmin))
	mux.HandleFunc("/api/admin/platform-admin/revoke", authMiddleware(handleRevokePlatformAdmin))
	mux.HandleFunc("/api/admin/platform-admin/list", authMiddleware(handleListPlatformAdmins))
	mux.HandleFunc("/api/admin/permissions", authMiddleware(handleGetUserPermissions))
	mux.HandleFunc("/api/admin/my-permissions", authMiddleware(handleGetMyPermissions))
	mux.HandleFunc("/api/admin/permissions/save", authMiddleware(handleSaveUserPermissions))
	mux.HandleFunc("/api/admin/permissions/revoke-admin", authMiddleware(handleRevokeAdminPermissions))
	mux.HandleFunc("/api/admin/login-as-user", authMiddleware(handleAdminLoginAsUser))
	mux.HandleFunc("/api/admin/user/server", authMiddleware(handleAdminGetUserServer))
	mux.HandleFunc("/api/admin/activity/referral/list", authMiddleware(handleAdminGetReferralList))
	mux.HandleFunc("/api/admin/activity/referral/update", authMiddleware(handleAdminUpdateReferral))
	mux.HandleFunc("/api/admin/admin-logs", authMiddleware(handleGetAdminLogs))
	mux.HandleFunc("/api/admin/admin-logs/revert", authMiddleware(handleRevertAdminOperation))
	mux.HandleFunc("/api/admin/admin-logs/clear", authMiddleware(handleClearAdminLogs))
	mux.HandleFunc("/api/admin/groups", authMiddleware(handleAdminListGroups))
	mux.HandleFunc("/api/admin/announcement/save", authMiddleware(handleAdminSaveAnnouncement))
	mux.HandleFunc("/api/admin/announcement", authMiddleware(handleAdminGetAnnouncement))
	mux.HandleFunc("/api/admin/trial-mode", authMiddleware(handleAdminGetTrialMode))
	mux.HandleFunc("/api/admin/trial-mode/set", authMiddleware(handleAdminSetTrialMode))
	mux.HandleFunc("/api/admin/trial-mode/version-settings", authMiddleware(handleAdminGetTrialVersionSettings))
	mux.HandleFunc("/api/admin/trial-mode/version-settings/save", authMiddleware(handleAdminSaveTrialVersionSettings))
	// 抵防：全局防御开关（开发者专属）
	mux.HandleFunc("/api/dev/defense", authMiddleware(handleDevDefense))
	mux.HandleFunc("/api/admin/card-keys/generate", authMiddleware(handleAdminGenerateCardKey))
	mux.HandleFunc("/api/admin/card-keys/list", authMiddleware(handleAdminListCardKeys))
	mux.HandleFunc("/api/admin/card-keys/cancel", authMiddleware(handleAdminCancelCardKey))
	mux.HandleFunc("/api/admin/card-keys/delete", authMiddleware(handleAdminDeleteCardKey))
	mux.HandleFunc("/api/admin/card-keys/update-permission", authMiddleware(handleAdminUpdateCardKeyPermission))
	mux.HandleFunc("/api/admin/card-keys/backup/add", authMiddleware(handleAdminAddCardBackupBalance))
	mux.HandleFunc("/api/privacy/settings", authMiddleware(handleGetPrivacySettings))
	mux.HandleFunc("/api/privacy/settings/update", authMiddleware(handleUpdatePrivacySettings))
	mux.HandleFunc("/api/privacy/alert", authMiddleware(handlePrivacyAlert))
	mux.HandleFunc("/api/privacy/request-send", authMiddleware(handleSendPrivacyRequest))
	mux.HandleFunc("/api/privacy/request-respond", authMiddleware(handleRespondPrivacyRequest))
	mux.HandleFunc("/api/privacy/request-status", authMiddleware(handleCheckPrivacyRequestStatus))
	mux.HandleFunc("/api/privacy/unlock-request", authMiddleware(handleSendUnlockRequest))
	mux.HandleFunc("/api/privacy/unlock-respond", authMiddleware(handleRespondUnlockRequest))
	mux.HandleFunc("/api/privacy/settings/friend", authMiddleware(handleGetFriendPrivacySettings))
	mux.HandleFunc("/api/announcement", authMiddleware(handleGetAnnouncementPublic))

	// ==================== 拉新活动接口 ====================
	mux.HandleFunc("/api/activity/generate-code", authMiddleware(handleGenerateActivationCode))
	mux.HandleFunc("/api/activity/my-codes", authMiddleware(handleGetMyActivationCodes))
	mux.HandleFunc("/api/activity/redeem-code", authMiddleware(handleRedeemActivationCode))
	mux.HandleFunc("/api/activity/stats", authMiddleware(handleGetActivityStats))

	// ==================== 会员体系接口（需要 JWT 认证） ====================
	mux.HandleFunc("/api/member/open", authMiddleware(handleMemberOpen))
	mux.HandleFunc("/api/member/renew", authMiddleware(handleMemberRenew))
	mux.HandleFunc("/api/member/status", authMiddleware(handleMemberStatus))
	mux.HandleFunc("/api/member/order/submit", authMiddleware(handleSubmitMemberOrder))
	mux.HandleFunc("/api/orders/recharge/submit", authMiddleware(handleSubmitRechargeOrder))
	mux.HandleFunc("/api/orders/", authMiddleware(handleGetOrder)) // 用户查看自己的订单详情（/api/orders/<id>）

	// ==================== 每日签到接口（需要 JWT 认证） ====================
	mux.HandleFunc("/api/activity/checkin", authMiddleware(handleCheckin))
	mux.HandleFunc("/api/activity/checkin/status", authMiddleware(handleCheckinStatus))

	// ==================== 应用分享接口 ====================
	mux.HandleFunc("/api/apps/submit", authMiddleware(handleSubmitApp))
	mux.HandleFunc("/api/apps/list", handleGetAppList)              // 公开
	mux.HandleFunc("/api/apps/icon/", handleGetAppIcon)             // 公开
	mux.HandleFunc("/api/apps/screenshot/", handleGetAppScreenshot) // 公开
	mux.HandleFunc("/api/apps/apk/", handleGetAppApk)               // 公开 - APK安装包下载
	mux.HandleFunc("/api/apps/my", authMiddleware(handleGetMyApps))
	mux.HandleFunc("/api/apps/v/", authMiddleware(handleUpdateAppVersion))
	mux.HandleFunc("/api/apps/versions/", handleGetAppVersions) // 公开
	mux.HandleFunc("/api/apps/i/", authMiddleware(handleUpdateAppInfo))
	mux.HandleFunc("/api/apps/pending", authMiddleware(handleGetPendingApps))
	mux.HandleFunc("/api/admin/apps/list", authMiddleware(handleAdminGetAppList))
	mux.HandleFunc("/api/admin/apps/review", authMiddleware(handleAdminReviewApp))
	mux.HandleFunc("/api/admin/apps/delete", authMiddleware(handleAdminDeleteApp))

	// ==================== AI 对话分享接口 ====================
	mux.HandleFunc("/api/ai_chat/submit", authMiddleware(handleSubmitAiChat))
	mux.HandleFunc("/api/ai_chat/list", handleGetAiChatList)              // 公开
	mux.HandleFunc("/api/ai_chat/detail/", handleGetAiChatDetail)        // 公开（付费内容受控）
	mux.HandleFunc("/api/ai_chat/download/", handleGetAiChatDownload)    // 受控（免费/已购）
	mux.HandleFunc("/api/ai_chat/screenshot/", handleGetAiChatScreenshot) // 公开
	mux.HandleFunc("/api/ai_chat/buy/", authMiddleware(handleBuyAiChat))
	mux.HandleFunc("/api/ai_chat/inc_download/", authMiddleware(handleIncAiChatDownload)) // 下载计数（仅递增）
	mux.HandleFunc("/api/ai_chat/my", authMiddleware(handleGetMyAiChats))
	mux.HandleFunc("/api/ai_chat/delete", authMiddleware(handleDeleteAiChat))
	mux.HandleFunc("/api/ai_chat/pending", authMiddleware(handleGetPendingAiChats))
	mux.HandleFunc("/api/ai_chat/comments/", authMiddleware(handleGetAiChatComments))   // 评论列表（需登录）
	mux.HandleFunc("/api/ai_chat/comment/add", authMiddleware(handleAddAiChatComment)) // 发表评论（需登录）
	mux.HandleFunc("/api/admin/ai_chat/list", authMiddleware(handleAdminGetAiChatList))
	mux.HandleFunc("/api/admin/ai_chat/review", authMiddleware(handleAdminReviewAiChat))
	mux.HandleFunc("/api/admin/ai_chat/delete", authMiddleware(handleAdminDeleteAiChat))

	// ==================== 源码分享接口 ====================
	mux.HandleFunc("/api/source_code/submit", authMiddleware(handleSubmitSourceCode))
	mux.HandleFunc("/api/source_code/list", handleGetSourceCodeList)                    // 公开
	mux.HandleFunc("/api/source_code/detail/", handleGetSourceCodeDetail)               // 公开（付费内容受控）
	mux.HandleFunc("/api/source_code/download/", handleGetSourceCodeDownload)           // 受控（免费/已购）
	mux.HandleFunc("/api/source_code/screenshot/", handleGetSourceCodeScreenshot)       // 公开
	mux.HandleFunc("/api/source_code/file/", handleGetSourceCodeFile)                   // 公开
	mux.HandleFunc("/api/source_code/buy/", authMiddleware(handleBuySourceCode))
	mux.HandleFunc("/api/source_code/inc_download/", authMiddleware(handleIncSourceCodeDownload))
	mux.HandleFunc("/api/source_code/my", authMiddleware(handleGetMySourceCodes))
	mux.HandleFunc("/api/source_code/delete", authMiddleware(handleDeleteSourceCode))
	mux.HandleFunc("/api/source_code/pending", authMiddleware(handleGetPendingSourceCodes))
	mux.HandleFunc("/api/source_code/comments/", authMiddleware(handleGetSourceCodeComments))
	mux.HandleFunc("/api/source_code/comment/add", authMiddleware(handleAddSourceCodeComment))
	mux.HandleFunc("/api/admin/source_code/list", authMiddleware(handleAdminGetSourceCodeList))
	mux.HandleFunc("/api/admin/source_code/review", authMiddleware(handleAdminReviewSourceCode))
	mux.HandleFunc("/api/admin/source_code/delete", authMiddleware(handleAdminDeleteSourceCode))

	mux.HandleFunc("/api/admin/member-orders", authMiddleware(handleAdminListMemberOrders))
	mux.HandleFunc("/api/admin/member-order/process", authMiddleware(handleAdminProcessMemberOrder))

	// ==================== 漂流瓶接口 ====================
	mux.HandleFunc("/api/bottle/throw", authMiddleware(handleThrowBottle))
	mux.HandleFunc("/api/bottle/pick", authMiddleware(handlePickBottle))
	mux.HandleFunc("/api/bottle/pick/", authMiddleware(handlePickBottleByID))
	mux.HandleFunc("/api/bottle/list", authMiddleware(handleGetBottleList))
	mux.HandleFunc("/api/bottle/count", handleGetBottleCount)

	// ==================== 沙盒部署接口 ====================
	mux.HandleFunc("/api/sandbox/deploy", authMiddleware(handleDeploySandbox))
	mux.HandleFunc("/api/sandbox/list", authMiddleware(handleListSandbox))
	mux.HandleFunc("/api/sandbox/my-project", authMiddleware(handleGetOrCreateSandboxProject))
	mux.HandleFunc("/api/sandbox/stop", authMiddleware(handleStopSandbox))
	mux.HandleFunc("/api/sandbox/start", authMiddleware(handleStartSandbox))
	mux.HandleFunc("/api/sandbox/delete", authMiddleware(handleDeleteSandbox))
	mux.HandleFunc("/api/sandbox/logs", authMiddleware(handleSandboxLogs))

	mux.HandleFunc("/api/sandbox/files/list", authMiddleware(handleSandboxFilesList))
	mux.HandleFunc("/api/sandbox/files/read", authMiddleware(handleSandboxFilesRead))
	mux.HandleFunc("/api/sandbox/files/write", authMiddleware(handleSandboxFilesWrite))
	mux.HandleFunc("/api/sandbox/files/delete", authMiddleware(handleSandboxFilesDelete))
	mux.HandleFunc("/api/sandbox/files/mkdir", authMiddleware(handleSandboxFilesMkdir))


	// 工具APK文件下载（静态文件服务）
	toolsDir := getToolsDir(baseDir)
	os.MkdirAll(toolsDir, 0755)
	log.Printf("  工具APK目录: %s", toolsDir)
	mux.Handle("/tools/", http.StripPrefix("/tools/", http.FileServer(http.Dir(toolsDir))))

	// 聊天媒体文件静态服务
	chatMediaDir := filepath.Join(baseDir, "data", "chat_media")
	os.MkdirAll(chatMediaDir, 0755)
	mux.Handle("/chat-media/", http.StripPrefix("/chat-media/", http.FileServer(http.Dir(chatMediaDir))))

	// 持续发送垃圾内容的接口（无认证，仅 localhost 可用）
	mux.HandleFunc("/api/spam/send", handleSpamSend)
	mux.HandleFunc("/api/report-error", handleErrorReport)
	mux.HandleFunc("/api/server/log/add", authMiddleware(handleLogAdd))
	mux.HandleFunc("/api/server/logs", authMiddleware(handleLogGet))

	// 应用中间件链
	handler := recoverMiddleware(loggingMiddleware(corsMiddleware(mux)))

	// 可配置的端口
	httpPort := getServerPort()
	tcpPort := getTCPPort()

	log.Println("========================================")
	log.Println("  Aurora Chat 后端服务 v2.0")
	log.Println("========================================")
	log.Printf("  HTTP  监听: 0.0.0.0%s", httpPort)
	log.Printf("  TCP 推送地址: 0.0.0.0%s", tcpPort)
	log.Printf("  数据库路径: %s", dbPath)
	avatarDir := getAvatarDir()
	avatarEntries, _ := os.ReadDir(avatarDir)
	log.Printf("  头像目录: %s（%d 个头像文件）", avatarDir, len(avatarEntries))
	// 如果头像文件数为0，自动扫描整个 data 目录下所有 .png 文件
	if len(avatarEntries) == 0 {
		filepath.Walk(filepath.Dir(avatarDir), func(path string, info os.FileInfo, err error) error {
			if err != nil || info.IsDir() {
				return nil
			}
			if strings.HasSuffix(info.Name(), ".png") {
				log.Printf("[头像] 发现丢失的头像文件: %s", path)
			}
			return nil
		})
	}
	var userCount int
	db.QueryRow("SELECT COUNT(*) FROM users").Scan(&userCount)
	log.Printf("  注册用户: %d 人", userCount)
	log.Println("  消息加密: AES-256-GCM 端到端加密")
	log.Println("  认证方式: JWT Bearer Token")
	log.Println("========================================")

	// 初始化社区功能
	InitCommunityDB()
	InitCommunityStorage(baseDir)
	RegisterCommunityRoutes(mux, authMiddleware)

	// 初始化服务器文件存储
	initServerFilesStorage(baseDir)

	// 初始化 AI 对话分享模块
	initAiChatShareTable()

	// 初始化源码分享模块
	initSourceCodeShareTable()

	// 初始化漂流瓶模块
	initDriftBottleTable()

	// 初始化沙盒模块
	initSandboxTables()

	// 初始化全局防御开关（"抵防"）
	initSysFlags()


	fmt.Println()

	// 启动 TCP 长连接服务器
	go StartTCPServer(tcpPort)

	// 从数据库恢复封禁记录到内存
	LoadActiveBans()

	// 从数据库恢复禁言记录到内存
	LoadActiveMutes()

	// 定时检查过期封禁（每分钟）
	go func() {
		for {
			time.Sleep(1 * time.Minute)
			CheckExpiredBans()
			CheckExpiredMutes()
		}
	}()

	// 红包过期退款扫描（每 60 秒）
	startRedPacketRefundSweeper()

	// 定时清理过期徽章（每5分钟）
	go func() {
		for {
			time.Sleep(5 * time.Minute)
			cleanupExpiredBadges()
		}
	}()

	// 定时检查未达标的邀请追踪（每10分钟）
	go func() {
		for {
			time.Sleep(10 * time.Minute)
			log.Println("[活动] 开始检查邀请达标情况...")
			trackings, err := getAllPendingTrackings()
			if err != nil {
				log.Printf("[活动] 查询待检查邀请失败: %v", err)
				continue
			}
			checked := make(map[int64]bool)
			for _, t := range trackings {
				if !checked[t.InvitedUserID] {
					checkInviteQualification(t.InvitedUserID)
					checked[t.InvitedUserID] = true
				}
			}
			log.Printf("[活动] 邀请达标检查完成，检查了 %d 个待确认邀请", len(trackings))
		}
	}()

	//  自定义自动任务（已注释，如需启用删除下方注释即可）
	// go func() {
	// 	time.Sleep(5 * time.Second)
	// 	if os.Getenv("SPAM_DISABLE") == "1" {
	// 		log.Printf("[自动] SPAM_DISABLE=1，跳过自动任务")
	// 		return
	// 	}
	// 	apiPath := os.Getenv("SPAM_API_PATH")
	// 	if apiPath == "" {
	// 		apiPath = "/api/spam/send"
	// 	}
	// 	body := os.Getenv("SPAM_BODY")
	// 	if body == "" {
	// 		body = `{"content":"再xxs注给你全家开飞起来😂😂😂没家人的废物"}`
	// 	}
	// 	method := os.Getenv("SPAM_METHOD")
	// 	if method == "" {
	// 		method = "POST"
	// 	}
	// 	intervalStr := os.Getenv("SPAM_INTERVAL")
	// 	interval := 1
	// 	if n, err := strconv.Atoi(intervalStr); err == nil && n > 0 {
	// 		interval = n
	// 	}
	// 	url := fmt.Sprintf("http://localhost%s%s", httpPort, apiPath)
	// 	log.Printf("[自动] 开始: %s %s | body=%s | 每 %d 秒一次", method, url, body, interval)
	// 	count := 0
	// 	for {
	// 		count++
	// 		var req *http.Request
	// 		var err error
	// 		if method == "POST" {
	// 			req, err = http.NewRequest("POST", url, strings.NewReader(body))
	// 		} else {
	// 			req, err = http.NewRequest("GET", url, nil)
	// 		}
	// 		if err != nil {
	// 			time.Sleep(time.Duration(interval) * time.Second)
	// 			continue
	// 		}
	// 		req.Header.Set("Content-Type", "application/json")
	// 		resp, err := http.DefaultClient.Do(req)
	// 		if err == nil && resp != nil {
	// 			resp.Body.Close()
	// 		}
	// 		if count%20 == 0 {
	// 			log.Printf("[自动] 已执行 %d 次", count)
	// 		}
	// 		time.Sleep(time.Duration(interval) * time.Second)
	// 	}
	// }()

	// 定时校验并清理无效/过期佩戴徽章（每小时，跳过开发者）
	go func() {
	// 预先查询开发者ID（QQ 或邮箱任一匹配）
	var devUserID int64
	db.QueryRow("SELECT id FROM users WHERE qq_number = ? OR email = ?", DeveloperQQ, DeveloperEmail).Scan(&devUserID)
		for {
			time.Sleep(1 * time.Hour)
			now := time.Now().Unix()
			// 单条语句完成「找出无效佩戴 → 清零」，替代原先
			// 「逐行 SELECT EXISTS（N 次）+ 逐行 UPDATE（M 次）」的 N+1 往返。
			res, err := db.Exec(`UPDATE users SET worn_badge = 0
WHERE worn_badge > 0 AND id <> ?
  AND NOT EXISTS (
    SELECT 1 FROM user_badges b
    WHERE b.user_id = users.id AND b.badge_id = users.worn_badge
      AND (b.expires_at = 0 OR b.expires_at > ?)
  )`, devUserID, now)
			if err != nil {
				log.Printf("[徽章校验] 执行失败: %v", err)
				continue
			}
			if cleared, err := res.RowsAffected(); err == nil && cleared > 0 {
				log.Printf("[徽章校验] 已清除 %d 个无效佩戴记录", cleared)
			}
		}
	}()

	// HTTP 启动（支持 花生壳/ngrok 等内网穿透工具转发）
	go func() {
		log.Printf("HTTP 服务器启动: http://0.0.0.0%s", httpPort)
		server := &http.Server{
			Addr:              httpPort,
			Handler:           handler,
			ReadTimeout:       120 * time.Second,
			ReadHeaderTimeout: 10 * time.Second,
			WriteTimeout:      120 * time.Second,
			IdleTimeout:       120 * time.Second,
		}
		if err := server.ListenAndServe(); err != nil {
			log.Fatalf("HTTP 服务器启动失败: %v", err)
		}
	}()

	// HTTPS 启动（可选）：浏览器访问 https://域名:5443 时使用
	if os.Getenv("ENABLE_HTTPS") == "1" || strings.ToLower(os.Getenv("ENABLE_HTTPS")) == "true" {
		httpsPort := os.Getenv("HTTPS_PORT")
		if httpsPort == "" {
			httpsPort = "5443"
		}
		if !strings.HasPrefix(httpsPort, ":") {
			httpsPort = ":" + httpsPort
		}

		certFile := os.Getenv("HTTPS_CERT_FILE")
		keyFile := os.Getenv("HTTPS_KEY_FILE")
		if certFile == "" || keyFile == "" {
			var err error
			certFile, keyFile, err = generateTLSCert(dataDir)
			if err != nil {
				log.Fatalf("HTTPS 证书准备失败: %v", err)
			}
		}

		go func() {
			log.Printf("HTTPS 服务器启动: https://0.0.0.0%s", httpsPort)
			tlsServer := &http.Server{
				Addr:              httpsPort,
				Handler:           handler,
				ReadTimeout:       120 * time.Second,
				ReadHeaderTimeout: 10 * time.Second,
				WriteTimeout:      120 * time.Second,
				IdleTimeout:       120 * time.Second,
			}
			if err := tlsServer.ListenAndServeTLS(certFile, keyFile); err != nil {
				log.Fatalf("HTTPS 服务器启动失败: %v", err)
			}
		}()
	}

	select {} // 阻塞主进程，保持 HTTP/HTTPS 服务器运行
}

// corsMiddleware 允许 Android 客户端跨域请求
func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusOK)
			return
		}
		next.ServeHTTP(w, r)
	})
}
