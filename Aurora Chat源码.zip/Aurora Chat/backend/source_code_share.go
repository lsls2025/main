package main

import (
	"archive/zip"
	"bytes"
	"database/sql"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// SourceCodeShare 源码分享记录
type SourceCodeShare struct {
	ID            int64  `json:"id"`
	UserID        int64  `json:"user_id"`
	Username      string `json:"username"`
	Title         string `json:"title"`
	Description   string `json:"description"`
	FilePath      string `json:"file_path"` // 压缩后的 zip 文件相对路径
	FileSize      int64  `json:"file_size"`
	IsFree        int    `json:"is_free"`     // 1=免费 0=收费
	PriceTokens   int64  `json:"price_tokens"` // 收费时的 token 数量
	Screenshots   string `json:"screenshots"` // JSON 数组：文件名列表
	Status        string `json:"status"`
	DownloadCount int    `json:"download_count"`
	PurchaseCount int    `json:"purchase_count"`
	ViewCount     int    `json:"view_count"`
	CreatedAt     int64  `json:"created_at"`
}

// initSourceCodeShareTable 初始化源码分享相关数据表
func initSourceCodeShareTable() {
	db.Exec(`CREATE TABLE IF NOT EXISTS source_code_shares (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		user_id INTEGER NOT NULL,
		title TEXT NOT NULL DEFAULT '',
		description TEXT NOT NULL DEFAULT '',
		file_path TEXT NOT NULL DEFAULT '',
		file_size BIGINT NOT NULL DEFAULT 0,
		is_free INTEGER NOT NULL DEFAULT 1,
		price_tokens BIGINT NOT NULL DEFAULT 0,
		screenshots TEXT NOT NULL DEFAULT '[]',
		status TEXT NOT NULL DEFAULT 'approved',
		download_count INTEGER NOT NULL DEFAULT 0,
		purchase_count INTEGER NOT NULL DEFAULT 0,
		view_count INTEGER NOT NULL DEFAULT 0,
		comment_count INTEGER NOT NULL DEFAULT 0,
		created_at BIGINT NOT NULL DEFAULT 0
	)`)
	db.Exec(`CREATE TABLE IF NOT EXISTS source_code_purchases (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		user_id INTEGER NOT NULL,
		share_id INTEGER NOT NULL,
		created_at BIGINT NOT NULL DEFAULT 0,
		UNIQUE(user_id, share_id)
	)`)
	db.Exec("CREATE INDEX IF NOT EXISTS idx_source_code_shares_status ON source_code_shares(status)")
	db.Exec("CREATE INDEX IF NOT EXISTS idx_source_code_shares_created ON source_code_shares(created_at)")
	// 源码分享评论表
	db.Exec(`CREATE TABLE IF NOT EXISTS source_code_comments (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		share_id INTEGER NOT NULL,
		user_id INTEGER NOT NULL,
		content TEXT NOT NULL,
		parent_id INTEGER NOT NULL DEFAULT 0,
		created_at INTEGER NOT NULL DEFAULT 0
	)`)
	db.Exec("CREATE INDEX IF NOT EXISTS idx_source_code_comments_share ON source_code_comments(share_id)")
	db.Exec("CREATE INDEX IF NOT EXISTS idx_source_code_comments_parent ON source_code_comments(parent_id)")
	log.Println("  [源码分享] 数据表初始化完成")
}

// ==================== 提交（multipart） ====================

// POST /api/source_code/submit — 提交一条源码分享（需登录）
func handleSubmitSourceCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}

	// 频率/数量限制
	if ok, msg := checkShareRateLimit(userID); !ok {
		writeJSON(w, 429, msg, nil)
		return
	}

	r.ParseMultipartForm(50 << 20) // 最大 50MB
	title := strings.TrimSpace(r.FormValue("title"))
	description := strings.TrimSpace(r.FormValue("description"))
	isFreeStr := r.FormValue("is_free")
	priceStr := r.FormValue("price_tokens")

	if title == "" {
		writeJSON(w, 400, "标题为必填", nil)
		return
	}

	isFree := 1
	if isFreeStr == "0" {
		isFree = 0
	}
	var priceTokens int64
	if isFree == 0 {
		fmt.Sscanf(priceStr, "%d", &priceTokens)
		if priceTokens <= 0 {
			writeJSON(w, 400, "收费内容需设置有效的 token 数量", nil)
			return
		}
	}

	now := time.Now().Unix()
	res, err := db.Exec("INSERT INTO source_code_shares (user_id, title, description, file_path, is_free, price_tokens, screenshots, status, created_at) VALUES (?, ?, ?, '', ?, ?, '[]', 'approved', ?)",
		userID, title, description, isFree, priceTokens, now)
	if err != nil {
		writeJSON(w, 500, "提交失败", nil)
		return
	}
	shareID, _ := res.LastInsertId()

	// 保存上传的源码文件（压缩为 zip）
	execPath, _ := os.Executable()
	filesDir := filepath.Join(filepath.Dir(execPath), "data", "source_code", "files")
	os.MkdirAll(filesDir, 0755)

	var fileSize int64
	var zipPath string

	// 处理上传的文件（支持单个文件或多个文件/文件夹）
	if r.MultipartForm != nil {
		fileHeaders := r.MultipartForm.File["files"]
		if len(fileHeaders) > 0 {
			zipName := fmt.Sprintf("%d.zip", shareID)
			zipFullPath := filepath.Join(filesDir, zipName)
			zipFile, err := os.Create(zipFullPath)
			if err == nil {
				zipWriter := zip.NewWriter(zipFile)
				for _, fh := range fileHeaders {
					file, e := fh.Open()
					if e != nil {
						continue
					}
					// 在 zip 中保留原始文件名
					header := &zip.FileHeader{
						Name:   fh.Filename,
						Method: zip.Deflate,
					}
					w, e2 := zipWriter.CreateHeader(header)
					if e2 == nil {
						io.Copy(w, file)
					}
					file.Close()
				}
				zipWriter.Close()
				zipFile.Close()

				// 获取 zip 文件大小
				if fi, e := os.Stat(zipFullPath); e == nil {
					fileSize = fi.Size()
				}
				zipPath = zipName
			}
		}
	}

	// 保存截图（最多 2 张）
	ssDir := filepath.Join(filepath.Dir(execPath), "data", "source_code", "screenshots")
	os.MkdirAll(ssDir, 0755)
	var ssPaths []string
	if r.MultipartForm != nil {
		ssFiles := r.MultipartForm.File["screenshots"]
		for idx, fh := range ssFiles {
			if idx >= 2 {
				break
			}
			file, e := fh.Open()
			if e != nil || file == nil {
				continue
			}
			ext := filepath.Ext(fh.Filename)
			if ext == "" {
				ext = ".png"
			}
			name := fmt.Sprintf("%d_%d%s", shareID, idx, ext)
			out, e2 := os.Create(filepath.Join(ssDir, name))
			if e2 == nil {
				io.Copy(out, file)
				out.Close()
				ssPaths = append(ssPaths, name)
			}
			file.Close()
		}
	}

	db.Exec("UPDATE source_code_shares SET file_path = ?, file_size = ?, screenshots = ? WHERE id = ?",
		zipPath, fileSize, toJSONString(ssPaths), shareID)

	writeJSON(w, 200, "提交成功", map[string]interface{}{"share_id": shareID})
}

// ==================== 公开列表 / 我的 ====================

func scanSourceCodeShares(rows *sql.Rows) ([]map[string]interface{}, error) {
	defer rows.Close()
	var list []map[string]interface{}
	for rows.Next() {
		var s SourceCodeShare
		if err := rows.Scan(&s.ID, &s.UserID, &s.Username, &s.Title, &s.Description,
			&s.FilePath, &s.FileSize, &s.IsFree, &s.PriceTokens, &s.Screenshots, &s.Status,
			&s.DownloadCount, &s.PurchaseCount, &s.ViewCount, &s.CreatedAt); err != nil {
			return nil, err
		}
		list = append(list, map[string]interface{}{
			"id":             s.ID,
			"user_id":        s.UserID,
			"username":       s.Username,
			"title":          s.Title,
			"description":    s.Description,
			"file_path":      s.FilePath,
			"file_size":      s.FileSize,
			"is_free":        s.IsFree,
			"price_tokens":   s.PriceTokens,
			"screenshots":    json.RawMessage(s.Screenshots),
			"status":         s.Status,
			"download_count": s.DownloadCount,
			"purchase_count": s.PurchaseCount,
			"view_count":     s.ViewCount,
			"created_at":     s.CreatedAt,
		})
	}
	if list == nil {
		list = []map[string]interface{}{}
	}
	return list, nil
}

// GET /api/source_code/list — 已通过列表（公开，支持 keyword 搜索）
func handleGetSourceCodeList(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	keyword := r.URL.Query().Get("keyword")
	isFree := r.URL.Query().Get("is_free") // "1" 免费, "0" 收费, "" 不限
	minTokens, _ := strconv.ParseInt(r.URL.Query().Get("min_tokens"), 10, 64)
	maxTokens, _ := strconv.ParseInt(r.URL.Query().Get("max_tokens"), 10, 64)
	sortBy := r.URL.Query().Get("sort") // "time" 最新, "download" 下载量最高
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if limit < 1 || limit > 50 {
		limit = 20
	}
	offset := (page - 1) * limit

	query := "SELECT scs.id, scs.user_id, COALESCE(u.username,''), scs.title, scs.description, scs.file_path, scs.file_size, scs.is_free, scs.price_tokens, scs.screenshots, scs.status, scs.download_count, scs.purchase_count, scs.view_count, scs.created_at FROM source_code_shares scs JOIN users u ON scs.user_id = u.id WHERE scs.status = 'approved'"
	args := []interface{}{}
	if keyword != "" {
		query += " AND (scs.title LIKE ? OR scs.description LIKE ?)"
		like := "%" + keyword + "%"
		args = append(args, like, like)
	}
	if isFree == "1" {
		query += " AND scs.is_free = 1"
	} else if isFree == "0" {
		query += " AND scs.is_free = 0"
	}
	if minTokens >= 0 {
		query += " AND scs.price_tokens >= ?"
		args = append(args, minTokens)
	}
	if maxTokens > 0 {
		query += " AND scs.price_tokens <= ?"
		args = append(args, maxTokens)
	}
	if sortBy == "download" {
		query += " ORDER BY scs.download_count DESC"
	} else {
		query += " ORDER BY scs.created_at DESC"
	}
	query += " LIMIT ? OFFSET ?"
	args = append(args, limit, offset)

	rows, err := db.Query(query, args...)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	list, err := scanSourceCodeShares(rows)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"shares": list, "page": page, "limit": limit})
}

// GET /api/source_code/my — 我提交的（需登录，含状态）
func handleGetMySourceCodes(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	rows, err := db.Query("SELECT scs.id, scs.user_id, COALESCE(u.username,''), scs.title, scs.description, scs.file_path, scs.file_size, scs.is_free, scs.price_tokens, scs.screenshots, scs.status, scs.download_count, scs.purchase_count, scs.view_count, scs.created_at FROM source_code_shares scs JOIN users u ON scs.user_id = u.id WHERE scs.user_id = ? ORDER BY scs.created_at DESC", userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	list, err := scanSourceCodeShares(rows)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"shares": list})
}

// ==================== 详情 / 下载 / 截图 ====================

// GET /api/source_code/detail/{id}
func handleGetSourceCodeDetail(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/source_code/detail/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	var s SourceCodeShare
	var commentCount int
	err := db.QueryRow(`SELECT scs.id, scs.user_id, COALESCE(u.username,''), scs.title, scs.description, scs.file_path, scs.file_size, scs.is_free, scs.price_tokens, scs.screenshots, scs.status, scs.download_count, scs.purchase_count, scs.view_count, scs.created_at,
		(SELECT COUNT(*) FROM source_code_comments WHERE share_id = scs.id) AS comment_count
		FROM source_code_shares scs JOIN users u ON scs.user_id = u.id WHERE scs.id = ?`, id).
		Scan(&s.ID, &s.UserID, &s.Username, &s.Title, &s.Description, &s.FilePath, &s.FileSize, &s.IsFree, &s.PriceTokens, &s.Screenshots, &s.Status, &s.DownloadCount, &s.PurchaseCount, &s.ViewCount, &s.CreatedAt, &commentCount)
	if err != nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	db.Exec("UPDATE source_code_shares SET view_count = view_count + 1 WHERE id = ?", id)
	s.ViewCount++
	requester := getCurrentUserID(r)
	purchased := false
	if requester == s.UserID {
		purchased = true
	} else if requester != 0 && s.IsFree == 0 {
		var cnt int
		db.QueryRow("SELECT COUNT(*) FROM source_code_purchases WHERE user_id = ? AND share_id = ?", requester, id).Scan(&cnt)
		purchased = cnt > 0
	}
	writeJSON(w, 200, "ok", map[string]interface{}{
		"id":             s.ID,
		"user_id":        s.UserID,
		"username":       s.Username,
		"title":          s.Title,
		"description":    s.Description,
		"file_path":      s.FilePath,
		"file_size":      s.FileSize,
		"is_free":        s.IsFree,
		"price_tokens":   s.PriceTokens,
		"screenshots":    json.RawMessage(s.Screenshots),
		"status":         s.Status,
		"download_count": s.DownloadCount,
		"purchase_count": s.PurchaseCount,
		"view_count":     s.ViewCount,
		"comment_count":  commentCount,
		"created_at":     s.CreatedAt,
		"purchased":      purchased,
	})
}

// GET /api/source_code/download/{id} — 下载源码 zip（免费直接下；收费需已购）
func handleGetSourceCodeDownload(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/source_code/download/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	var s SourceCodeShare
	err := db.QueryRow("SELECT id, user_id, file_path, is_free FROM source_code_shares WHERE id = ?", id).
		Scan(&s.ID, &s.UserID, &s.FilePath, &s.IsFree)
	if err != nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	requester := getCurrentUserID(r)
	allowed := s.IsFree == 1
	if !allowed && requester != 0 {
		if requester == s.UserID {
			allowed = true
		} else {
			var cnt int
			db.QueryRow("SELECT COUNT(*) FROM source_code_purchases WHERE user_id = ? AND share_id = ?", requester, id).Scan(&cnt)
			allowed = cnt > 0
		}
	}
	if !allowed {
		writeJSON(w, 403, "请先购买后下载", nil)
		return
	}
	if s.FilePath == "" {
		writeJSON(w, 404, "文件不存在", nil)
		return
	}
	execPath, _ := os.Executable()
	fp := filepath.Join(filepath.Dir(execPath), "data", "source_code", "files", s.FilePath)
	if _, err := os.Stat(fp); os.IsNotExist(err) {
		writeJSON(w, 404, "文件不存在", nil)
		return
	}
	db.Exec("UPDATE source_code_shares SET download_count = download_count + 1 WHERE id = ?", id)
	w.Header().Set("Content-Type", "application/zip")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"source_code_%d.zip\"", id))
	http.ServeFile(w, r, fp)
}

// POST /api/source_code/inc_download/{id} — 仅递增下载次数
func handleIncSourceCodeDownload(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/source_code/inc_download/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	res, err := db.Exec("UPDATE source_code_shares SET download_count = download_count + 1 WHERE id = ? AND status = 'approved'", id)
	if err != nil {
		writeJSON(w, 500, "更新失败", nil)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	writeJSON(w, 200, "ok", nil)
}

// GET /api/source_code/file/{id}/{filename} — 直接获取源码文件内容（前端预览用）
func handleGetSourceCodeFile(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/source_code/file/")
	parts := strings.SplitN(path, "/", 2)
	if len(parts) != 2 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	id, _ := strconv.ParseInt(parts[0], 10, 64)
	fileName := parts[1]
	if id <= 0 || fileName == "" {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	execPath, _ := os.Executable()
	fp := filepath.Join(filepath.Dir(execPath), "data", "source_code", "files", fileName)
	if _, err := os.Stat(fp); os.IsNotExist(err) {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	http.ServeFile(w, r, fp)
}

// GET /api/source_code/screenshot/{id}/{filename}
func handleGetSourceCodeScreenshot(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/source_code/screenshot/")
	parts := strings.SplitN(path, "/", 2)
	if len(parts) != 2 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	id, _ := strconv.ParseInt(parts[0], 10, 64)
	fileName := parts[1]
	if id <= 0 || fileName == "" {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	if !strings.HasPrefix(fileName, fmt.Sprintf("%d_", id)) {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	execPath, _ := os.Executable()
	fp := filepath.Join(filepath.Dir(execPath), "data", "source_code", "screenshots", fileName)
	if _, err := os.Stat(fp); os.IsNotExist(err) {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	http.ServeFile(w, r, fp)
}

// ==================== 购买（token 扣减） ====================

// POST /api/source_code/buy/{id}
func handleBuySourceCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/source_code/buy/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var s SourceCodeShare
	err := db.QueryRow("SELECT id, user_id, is_free, price_tokens FROM source_code_shares WHERE id = ?", id).
		Scan(&s.ID, &s.UserID, &s.IsFree, &s.PriceTokens)
	if err != nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	if s.IsFree == 1 {
		writeJSON(w, 400, "该内容免费，无需购买", nil)
		return
	}
	if userID == s.UserID {
		writeJSON(w, 400, "不能购买自己的内容", nil)
		return
	}
	balance := getEffectiveTokenBalance(userID)
	if balance < s.PriceTokens {
		writeJSON(w, 400, "token 余额不足", map[string]interface{}{"balance": balance, "need": s.PriceTokens})
		return
	}
	var cnt int
	db.QueryRow("SELECT COUNT(*) FROM source_code_purchases WHERE user_id = ? AND share_id = ?", userID, id).Scan(&cnt)
	if cnt > 0 {
		writeJSON(w, 200, "已购买", map[string]interface{}{"balance": balance})
		return
	}
	tx, err := db.Begin()
	if err != nil {
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	if _, e1 := tx.Exec("UPDATE users SET token_balance = token_balance - ? WHERE id = ? AND token_balance >= ?", s.PriceTokens, userID, s.PriceTokens); e1 != nil {
		tx.Rollback()
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	if _, e2 := tx.Exec("INSERT OR IGNORE INTO source_code_purchases (user_id, share_id, created_at) VALUES (?, ?, ?)", userID, id, time.Now().Unix()); e2 != nil {
		tx.Rollback()
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	if _, e3 := tx.Exec("UPDATE source_code_shares SET purchase_count = purchase_count + 1 WHERE id = ?", id); e3 != nil {
		tx.Rollback()
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	if err := tx.Commit(); err != nil {
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	writeJSON(w, 200, "购买成功", map[string]interface{}{"balance": balance - s.PriceTokens})
}

// ==================== 评论 ====================

// GET /api/source_code/comments/{id}
func handleGetSourceCodeComments(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/source_code/comments/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var exists int
	db.QueryRow("SELECT COUNT(*) FROM source_code_shares WHERE id = ? AND status = 'approved'", id).Scan(&exists)
	if exists == 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if limit < 1 || limit > 50 {
		limit = 20
	}
	offset := (page - 1) * limit
	rows, err := db.Query(`SELECT c.id, c.user_id, u.username, c.content, c.parent_id, c.created_at
		FROM source_code_comments c JOIN users u ON c.user_id = u.id
		WHERE c.share_id = ? ORDER BY c.created_at ASC LIMIT ? OFFSET ?`, id, limit, offset)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	defer rows.Close()
	type CommentItem struct {
		ID         int64  `json:"id"`
		UserID     int64  `json:"user_id"`
		Username   string `json:"username"`
		Content    string `json:"content"`
		ParentID   int64  `json:"parent_id"`
		CreatedAt  int64  `json:"created_at"`
		ReplyCount int    `json:"reply_count"`
	}
	var comments []CommentItem
	for rows.Next() {
		var c CommentItem
		rows.Scan(&c.ID, &c.UserID, &c.Username, &c.Content, &c.ParentID, &c.CreatedAt)
		db.QueryRow("SELECT COUNT(*) FROM source_code_comments WHERE parent_id = ?", c.ID).Scan(&c.ReplyCount)
		comments = append(comments, c)
	}
	if comments == nil {
		comments = []CommentItem{}
	}
	var total int
	db.QueryRow("SELECT COUNT(*) FROM source_code_comments WHERE share_id = ?", id).Scan(&total)
	writeJSON(w, 200, "ok", map[string]interface{}{"comments": comments, "total": total})
}

// POST /api/source_code/comment/add
func handleAddSourceCodeComment(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		ShareID  int64  `json:"share_id"`
		Content  string `json:"content"`
		ParentID int64  `json:"parent_id"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	req.Content = strings.TrimSpace(req.Content)
	if req.Content == "" {
		writeJSON(w, 400, "评论内容不能为空", nil)
		return
	}
	if req.ShareID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var exists int
	db.QueryRow("SELECT COUNT(*) FROM source_code_shares WHERE id = ? AND status = 'approved'", req.ShareID).Scan(&exists)
	if exists == 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	if allowed, wait := checkCommentRateLimit(userID); !allowed {
		writeJSON(w, 429, fmt.Sprintf("评论过于频繁，请 %d 秒后再试", wait), nil)
		return
	}
	req.Content = html.EscapeString(req.Content)
	if req.ParentID > 0 {
		var parentExists int
		db.QueryRow("SELECT COUNT(*) FROM source_code_comments WHERE id = ? AND share_id = ?", req.ParentID, req.ShareID).Scan(&parentExists)
		if parentExists == 0 {
			writeJSON(w, 400, "被回复的评论不存在", nil)
			return
		}
	}
	now := time.Now().Unix()
	result, err := db.Exec("INSERT INTO source_code_comments (share_id, user_id, content, parent_id, created_at) VALUES (?, ?, ?, ?, ?)",
		req.ShareID, userID, req.Content, req.ParentID, now)
	if err != nil {
		writeJSON(w, 500, "添加失败", nil)
		return
	}
	commentID, _ := result.LastInsertId()
	db.Exec("UPDATE source_code_shares SET comment_count = (SELECT COUNT(*) FROM source_code_comments WHERE share_id = ?) WHERE id = ?", req.ShareID, req.ShareID)
	log.Printf("用户 %d 评论源码分享 %d (parent_id=%d, comment_id=%d)", userID, req.ShareID, req.ParentID, commentID)
	writeJSON(w, 200, "ok", map[string]interface{}{"comment_id": commentID})
}

// ==================== 删除 ====================

// POST /api/source_code/delete
func handleDeleteSourceCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var body struct {
		ShareID int64 `json:"share_id"`
	}
	json.NewDecoder(r.Body).Decode(&body)
	if body.ShareID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var ownerID int64
	if err := db.QueryRow("SELECT user_id FROM source_code_shares WHERE id = ?", body.ShareID).Scan(&ownerID); err != nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	if ownerID != userID && !isDeveloperUser(userID) {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	if _, err := db.Exec("UPDATE source_code_shares SET status = 'deleted' WHERE id = ?", body.ShareID); err != nil {
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	writeJSON(w, 200, "ok", nil)
}

// ==================== 管理端 ====================

// GET /api/admin/source_code/list
func handleAdminGetSourceCodeList(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "apps.manage") {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	rows, err := db.Query("SELECT scs.id, scs.user_id, COALESCE(u.username,''), scs.title, scs.description, scs.file_path, scs.file_size, scs.is_free, scs.price_tokens, scs.screenshots, scs.status, scs.download_count, scs.purchase_count, scs.view_count, scs.created_at FROM source_code_shares scs JOIN users u ON scs.user_id = u.id ORDER BY scs.created_at DESC")
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	list, err := scanSourceCodeShares(rows)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"shares": list})
}

// POST /api/admin/source_code/review
func handleAdminReviewSourceCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "apps.manage") {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	var body struct {
		ShareID int64  `json:"share_id"`
		Action  string `json:"action"`
	}
	json.NewDecoder(r.Body).Decode(&body)
	if body.ShareID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	status := "approved"
	if body.Action == "reject" {
		status = "rejected"
	}
	if _, err := db.Exec("UPDATE source_code_shares SET status = ? WHERE id = ?", status, body.ShareID); err != nil {
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	writeJSON(w, 200, "ok", nil)
}

// POST /api/admin/source_code/delete
func handleAdminDeleteSourceCode(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "apps.manage") {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	var body struct {
		ShareID int64 `json:"share_id"`
	}
	json.NewDecoder(r.Body).Decode(&body)
	if body.ShareID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if _, err := db.Exec("UPDATE source_code_shares SET status = 'deleted' WHERE id = ?", body.ShareID); err != nil {
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	writeJSON(w, 200, "ok", nil)
}

// GET /api/source_code/pending — 待审核（需登录，开发者/管理员）
func handleGetPendingSourceCodes(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "apps.manage") {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	rows, err := db.Query("SELECT scs.id, scs.user_id, COALESCE(u.username,''), scs.title, scs.description, scs.file_path, scs.file_size, scs.is_free, scs.price_tokens, scs.screenshots, scs.status, scs.download_count, scs.purchase_count, scs.view_count, scs.created_at FROM source_code_shares scs JOIN users u ON scs.user_id = u.id WHERE scs.status = 'pending' ORDER BY scs.created_at DESC")
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	list, err := scanSourceCodeShares(rows)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"shares": list})
}

// ==================== 工具函数 ====================

func toJSONString(v interface{}) string {
	b, _ := json.Marshal(v)
	return string(b)
}

// 将上传的 zip 文件解压到临时目录供客户端逐个文件预览（暂不实现，直接用 zip 下载）
func extractZipForPreview(zipPath string) ([]map[string]interface{}, error) {
	r, err := zip.OpenReader(zipPath)
	if err != nil {
		return nil, err
	}
	defer r.Close()
	var files []map[string]interface{}
	for _, f := range r.File {
		if f.FileInfo().IsDir() {
			continue
		}
		rc, err := f.Open()
		if err != nil {
			continue
		}
		buf := new(bytes.Buffer)
		io.Copy(buf, rc)
		rc.Close()
		files = append(files, map[string]interface{}{
			"name": f.Name,
			"size": f.FileInfo().Size(),
		})
		// 限制预览文件列表数量，避免超大 zip 导致内存溢出
		if len(files) >= 100 {
			break
		}
	}
	return files, nil
}