# Aurora Chat 后端服务

Go 语言编写的后端服务，提供即时通讯 API 和 TCP 推送。

## 环境要求

- Go 1.21 或更高版本
- 下载地址：https://go.dev/dl/

## 本地开发启动

```bash
cd backend
go mod tidy
go run .
```

默认端口：
- HTTP API: `:5004`（可通过 `SERVER_PORT` 环境变量修改）
- TCP 推送: `:5005`（可通过 `TCP_PORT` 环境变量修改）

健康检查：
```bash
curl http://localhost:5004/api/health
```

## 环境变量配置

所有敏感配置均通过环境变量传入，无需修改代码：

| 环境变量 | 说明 | 默认值 |
|---------|------|--------|
| `SERVER_PORT` | HTTP API 端口 | `5004` |
| `TCP_PORT` | TCP 推送端口 | `5005` |
| `JWT_SECRET` | JWT 签名密钥（建议设置，至少 32 位） | 自动生成并持久化到 `data/jwt_secret` |
| `SERVER_PUBLIC_URL` | 服务器对外公开 URL（用于文件下载链接等） | `http://localhost:5004` |
| `QR_SITE_URL` | 二维码扫码落地页域名 | `https://example.com` |
| `MAIL_DOMAIN` | 临时邮箱域名 | `example.com` |
| `SMTP_USERNAME` | SMTP 邮箱账号（逗号分隔多账号） | 空（开发模式，验证码打印到日志） |
| `SMTP_PASSWORD` | SMTP 邮箱密码（逗号分隔，与账号一一对应） | 空 |
| `SMTP_ADDR` | SMTP 服务器地址 | `smtp.qq.com:465` |
| `TOOLS_DIR` | 工具 APK 存放目录 | `data/tools` |
| `ENABLE_HTTPS` | 是否启用 HTTPS（`1`=启用） | 空（禁用） |
| `HTTPS_PORT` | HTTPS 端口 | `5443` |
| `HTTPS_CERT_FILE` | SSL 证书路径 | 空（自动生成自签名证书） |
| `HTTPS_KEY_FILE` | SSL 证书私钥路径 | 空 |
| `SERVER_DOMAIN` | 服务器域名（用于自签名证书） | 空 |

### 开发者配置

编辑 `config.go` 修改开发者标识：
```go
const DeveloperQQ = "1234567890"       // 改为你的 QQ 号
const DeveloperEmail = "your_email@example.com"  // 改为你的邮箱
```

QQ 号或邮箱任一匹配即视为开发者账号，拥有管理权限。

## 部署到服务器

### 1. 编译 Linux 版本

```bash
# Windows PowerShell
$env:GOOS="linux"; $env:GOARCH="amd64"; go build -o aurora-server .

# Linux / macOS
GOOS=linux GOARCH=amd64 go build -o aurora-server .
```

### 2. 上传到服务器

上传以下文件到服务器目标目录（如 `/opt/aurora-chat/`）：
- `aurora-server` — 可执行文件
- `start_server.sh` — 启动脚本（可选）
- `deploy.sh` — 部署脚本（可选）

### 3. 启动服务

```bash
cd /opt/aurora-chat
chmod +x aurora-server start_server.sh

# 方式一：使用启动脚本
bash start_server.sh

# 方式二：直接 nohup 后台运行
nohup ./aurora-server > server.log 2>&1 &
```

### 4. 查看状态

```bash
# 查看进程
ps aux | grep aurora-server

# 查看日志
tail -f server.log

# 健康检查
curl http://localhost:5004/api/health
```

## 端口配置对照表

| 组件 | 默认端口 | 环境变量 | Android 端配置位置 |
|------|---------|---------|-------------------|
| HTTP API | 5004 | `SERVER_PORT` | `AuroraApi.kt` → `serverUrl` |
| TCP 推送 | 5005 | `TCP_PORT` | `TcpService.kt` → `TCP_PORT` |

**注意**：修改端口后，必须同时更新环境变量和 Android 端的对应配置。

## 数据目录

运行时数据默认保存在可执行文件同级的 `data/` 目录下：

```
data/
├── aurora_chat.db       # 主数据库
├── users/               # 用户独立数据库
├── tools/               # 工具 APK 文件
├── uploads/             # 上传的文件
├── jwt_secret           # JWT 密钥（自动生成）
└── server.key / server.crt  # TLS 证书（自动生成）
```

**注意**：`data/` 目录包含生产数据，请勿提交到版本库（已在 `.gitignore` 中排除）。

## 故障排除

### "连接被拒绝" / "Connection refused"
1. 检查服务器进程是否在运行：`ps aux | grep aurora-server`
2. 检查端口是否在监听：`ss -tlnp | grep 5004`
3. 检查防火墙/安全组是否放行端口

### "连接超时" / "Connection timed out"
1. 检查服务器是否可 ping 通
2. 检查端口是否可以从外部访问：`telnet <服务器IP> 5004`
3. 确认云服务商安全组规则已生效

### 登录一直转圈
1. 先用 `curl` 测试 API 是否可达
2. 检查 Android 端的 `serverUrl` 配置是否正确
3. 检查 Android `AndroidManifest.xml` 中是否有 `android:usesCleartextTraffic="true"`（HTTP 明文需要）
4. 查看 Android Logcat：`adb logcat -s AuroraApi`
