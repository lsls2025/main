package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// AiChatShare AI 对话分享记录
type AiChatShare struct {
	ID            int64  `json:"id"`
	UserID        int64  `json:"user_id"`
	Username      string `json:"username"`
	Title         string `json:"title"`
	Description   string `json:"description"`
	Content       string `json:"content"`
	Fields        string `json:"fields"`      // JSON: {"name":bool,"avatar":bool,"scene":bool,"scene_text":""}
	IsFree        int    `json:"is_free"`     // 1=免费 0=收费
	PriceTokens   int64  `json:"price_tokens"` // 收费时的 token 数量
	Screenshots   string `json:"screenshots"` // JSON 数组：文件名列表
	Status        string `json:"status"`
	DownloadCount int    `json:"download_count"`
	PurchaseCount int    `json:"purchase_count"`
	ViewCount     int    `json:"view_count"`
	CreatedAt     int64  `json:"created_at"`
}

// initAiChatShareTable 初始化 AI 对话分享相关数据表
func initAiChatShareTable() {
	db.Exec(`CREATE TABLE IF NOT EXISTS ai_chat_shares (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		user_id INTEGER NOT NULL,
		title TEXT NOT NULL DEFAULT '',
		description TEXT NOT NULL DEFAULT '',
		content TEXT NOT NULL DEFAULT '',
		fields TEXT NOT NULL DEFAULT '{}',
		is_free INTEGER NOT NULL DEFAULT 1,
		price_tokens BIGINT NOT NULL DEFAULT 0,
		screenshots TEXT NOT NULL DEFAULT '[]',
		status TEXT NOT NULL DEFAULT 'approved',
		download_count INTEGER NOT NULL DEFAULT 0,
		purchase_count INTEGER NOT NULL DEFAULT 0,
		created_at BIGINT NOT NULL DEFAULT 0
	)`)
	db.Exec(`CREATE TABLE IF NOT EXISTS ai_chat_purchases (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		user_id INTEGER NOT NULL,
		share_id INTEGER NOT NULL,
		created_at BIGINT NOT NULL DEFAULT 0,
		UNIQUE(user_id, share_id)
	)`)
	db.Exec("CREATE INDEX IF NOT EXISTS idx_ai_chat_shares_status ON ai_chat_shares(status)")
	db.Exec("CREATE INDEX IF NOT EXISTS idx_ai_chat_shares_created ON ai_chat_shares(created_at)")
	// 已存在旧库缺 view_count 列时兼容（列已存在则 ALTER 报错被忽略）
	db.Exec("ALTER TABLE ai_chat_shares ADD COLUMN view_count INTEGER NOT NULL DEFAULT 0")
	// 已存在旧库缺 comment_count 列时兼容（列已存在则 ALTER 报错被忽略）
	db.Exec("ALTER TABLE ai_chat_shares ADD COLUMN comment_count INTEGER NOT NULL DEFAULT 0")
	// AI 对话分享评论表（支持楼中楼回复）
	db.Exec(`CREATE TABLE IF NOT EXISTS ai_chat_comments (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		share_id INTEGER NOT NULL,
		user_id INTEGER NOT NULL,
		content TEXT NOT NULL,
		parent_id INTEGER NOT NULL DEFAULT 0,
		created_at INTEGER NOT NULL DEFAULT 0
	)`)
	db.Exec("CREATE INDEX IF NOT EXISTS idx_ai_chat_comments_share ON ai_chat_comments(share_id)")
	db.Exec("CREATE INDEX IF NOT EXISTS idx_ai_chat_comments_parent ON ai_chat_comments(parent_id)")
	log.Println("  [AI对话分享] 数据表初始化完成")
}

// ==================== 提交（multipart） ====================

// POST /api/ai_chat/submit — 提交一条 AI 对话分享（需登录）
func handleSubmitAiChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}

	// 频率/数量限制
	if ok, msg := checkShareRateLimit(userID); !ok {
		writeJSON(w, 429, msg, nil)
		return
	}

	if err := r.ParseMultipartForm(20 << 20); err != nil {
		writeJSON(w, 400, "请求数据解析失败: " + err.Error(), nil)
		return
	}
	title := strings.TrimSpace(r.FormValue("title"))
	description := strings.TrimSpace(r.FormValue("description"))
	content := r.FormValue("content")
	fields := r.FormValue("fields")
	isFreeStr := r.FormValue("is_free")
	priceStr := r.FormValue("price_tokens")

	if title == "" {
		writeJSON(w, 400, "标题为必填", nil)
		return
	}
	if content == "" {
		writeJSON(w, 400, "对话内容为必填", nil)
		return
	}

	isFree := 1
	if isFreeStr == "0" {
		isFree = 0
	}
	var priceTokens int64
	if isFree == 0 {
		fmt.Sscanf(priceStr, "%d", &priceTokens)
		if priceTokens <= 0 {
			writeJSON(w, 400, "收费内容需设置有效的 token 数量", nil)
			return
		}
	}
	if fields == "" {
		fields = "{}"
	}

	// 预取下一个自增 ID，用于截图文件名前缀（先保存截图再 INSERT，失败不留记录）
	var nextID int64
	db.QueryRow("SELECT IFNULL(MAX(id),0)+1 FROM ai_chat_shares").Scan(&nextID)
	shareID := nextID

	// 保存截图（后端支持最多 10 张，前端读取 max_screenshots 动态限制）
	execPath, _ := os.Executable()
	ssDir := filepath.Join(filepath.Dir(execPath), "data", "ai_chat", "screenshots")
	os.MkdirAll(ssDir, 0755)
	var ssPaths []string
	if r.MultipartForm != nil {
		ssFiles := r.MultipartForm.File["screenshots"]
		for idx, fh := range ssFiles {
			if idx >= 10 {
				break
			}
			file, e := fh.Open()
			if e != nil || file == nil {
				continue
			}
			ext := filepath.Ext(fh.Filename)
			if ext == "" {
				ext = ".png"
			}
			name := fmt.Sprintf("%d_%d%s", shareID, idx, ext)
			out, e2 := os.Create(filepath.Join(ssDir, name))
			if e2 == nil {
				io.Copy(out, file)
				out.Close()
				ssPaths = append(ssPaths, name)
			}
			file.Close()
		}
	}
	ssJSON := "[]"
	if len(ssPaths) > 0 {
		if b, e := json.Marshal(ssPaths); e == nil {
			ssJSON = string(b)
		}
	}

	now := time.Now().Unix()
	_, err := db.Exec("INSERT INTO ai_chat_shares (user_id, title, description, content, fields, is_free, price_tokens, screenshots, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'approved', ?)",
		userID, title, description, content, fields, isFree, priceTokens, ssJSON, now)
	if err != nil {
		writeJSON(w, 500, "提交失败", nil)
		return
	}

	writeJSON(w, 200, "提交成功", map[string]interface{}{"share_id": shareID, "max_screenshots": 10})
}

// ==================== 公开列表 / 我的 ====================

func scanAiChatShares(rows *sql.Rows) ([]map[string]interface{}, error) {
	defer rows.Close()
	var list []map[string]interface{}
	for rows.Next() {
		var s AiChatShare
		var preview string
		if err := rows.Scan(&s.ID, &s.UserID, &s.Username, &s.Title, &s.Description,
			&s.Fields, &s.IsFree, &s.PriceTokens, &s.Screenshots, &s.Status,
			&s.DownloadCount, &s.PurchaseCount, &s.CreatedAt, &preview); err != nil {
			return nil, err
		}
		list = append(list, map[string]interface{}{
			"id":            s.ID,
			"user_id":       s.UserID,
			"username":      s.Username,
			"title":         s.Title,
			"description":   s.Description,
			"fields":        json.RawMessage(s.Fields),
			"is_free":       s.IsFree,
			"price_tokens":  s.PriceTokens,
			"screenshots":   json.RawMessage(s.Screenshots),
			"status":        s.Status,
			"download_count": s.DownloadCount,
			"purchase_count": s.PurchaseCount,
			"created_at":    s.CreatedAt,
			"preview":       preview,
		})
	}
	if list == nil {
		list = []map[string]interface{}{}
	}
	return list, nil
}

// GET /api/ai_chat/list — 已通过列表（公开，支持 keyword 搜索）
func handleGetAiChatList(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	keyword := r.URL.Query().Get("keyword")
	isFree := r.URL.Query().Get("is_free") // "1" 免费, "0" 收费, "" 不限
	minTokens, _ := strconv.ParseInt(r.URL.Query().Get("min_tokens"), 10, 64)
	maxTokens, _ := strconv.ParseInt(r.URL.Query().Get("max_tokens"), 10, 64)
	sortBy := r.URL.Query().Get("sort") // "time" 最新, "download" 下载量最高
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if limit < 1 || limit > 50 {
		limit = 20
	}
	offset := (page - 1) * limit

	query := "SELECT acs.id, acs.user_id, COALESCE(u.username,''), acs.title, acs.description, acs.fields, acs.is_free, acs.price_tokens, acs.screenshots, acs.status, acs.download_count, acs.purchase_count, acs.created_at, substr(acs.content,1,160) FROM ai_chat_shares acs JOIN users u ON acs.user_id = u.id WHERE acs.status = 'approved'"
	args := []interface{}{}
	if keyword != "" {
		query += " AND (acs.title LIKE ? OR acs.description LIKE ?)"
		like := "%" + keyword + "%"
		args = append(args, like, like)
	}
	if isFree == "1" {
		query += " AND acs.is_free = 1"
	} else if isFree == "0" {
		query += " AND acs.is_free = 0"
	}
	// 价格区间：min_tokens=0 时表示从 0 开始（不跳过）
	if minTokens >= 0 {
		query += " AND acs.price_tokens >= ?"
		args = append(args, minTokens)
	}
	if maxTokens > 0 {
		query += " AND acs.price_tokens <= ?"
		args = append(args, maxTokens)
	}
	if sortBy == "download" {
		query += " ORDER BY acs.download_count DESC"
	} else {
		query += " ORDER BY acs.created_at DESC"
	}
	query += " LIMIT ? OFFSET ?"
	args = append(args, limit, offset)
	log.Printf("[AiChatList] is_free=%q min=%d max=%d sort=%s kw=%q", isFree, minTokens, maxTokens, sortBy, keyword)

	rows, err := db.Query(query, args...)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	list, err := scanAiChatShares(rows)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"shares": list, "page": page, "limit": limit})
}

// GET /api/ai_chat/my — 我提交的（需登录，含状态）
func handleGetMyAiChats(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	rows, err := db.Query("SELECT acs.id, acs.user_id, COALESCE(u.username,''), acs.title, acs.description, acs.fields, acs.is_free, acs.price_tokens, acs.screenshots, acs.status, acs.download_count, acs.purchase_count, acs.created_at, substr(acs.content,1,160) FROM ai_chat_shares acs JOIN users u ON acs.user_id = u.id WHERE acs.user_id = ? ORDER BY acs.created_at DESC", userID)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	list, err := scanAiChatShares(rows)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"shares": list})
}

// GET /api/ai_chat/pending — 待审核（需登录，开发者/管理员）
func handleGetPendingAiChats(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "apps.manage") {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	rows, err := db.Query("SELECT acs.id, acs.user_id, COALESCE(u.username,''), acs.title, acs.description, acs.fields, acs.is_free, acs.price_tokens, acs.screenshots, acs.status, acs.download_count, acs.purchase_count, acs.created_at, substr(acs.content,1,160) FROM ai_chat_shares acs JOIN users u ON acs.user_id = u.id WHERE acs.status = 'pending' ORDER BY acs.created_at DESC")
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	list, err := scanAiChatShares(rows)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"shares": list})
}

// ==================== 详情 / 下载 / 截图 ====================

// GET /api/ai_chat/detail/{id}
func handleGetAiChatDetail(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/ai_chat/detail/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	var s AiChatShare
	var commentCount int
	err := db.QueryRow(`SELECT acs.id, acs.user_id, COALESCE(u.username,''), acs.title, acs.description, acs.content, acs.fields, acs.is_free, acs.price_tokens, acs.screenshots, acs.status, acs.download_count, acs.purchase_count, acs.view_count, acs.created_at,
		(SELECT COUNT(*) FROM ai_chat_comments WHERE share_id = acs.id) AS comment_count
		FROM ai_chat_shares acs JOIN users u ON acs.user_id = u.id WHERE acs.id = ?`, id).
		Scan(&s.ID, &s.UserID, &s.Username, &s.Title, &s.Description, &s.Content, &s.Fields, &s.IsFree, &s.PriceTokens, &s.Screenshots, &s.Status, &s.DownloadCount, &s.PurchaseCount, &s.ViewCount, &s.CreatedAt, &commentCount)
	if err != nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	// 浏览量：每进入一次详情即 +1（每用户每次点入都计数）
	db.Exec("UPDATE ai_chat_shares SET view_count = view_count + 1 WHERE id = ?", id)
	s.ViewCount++
	requester := getCurrentUserID(r)
	purchased := false
	if requester == s.UserID {
		purchased = true
	} else if requester != 0 && s.IsFree == 0 {
		var cnt int
		db.QueryRow("SELECT COUNT(*) FROM ai_chat_purchases WHERE user_id = ? AND share_id = ?", requester, id).Scan(&cnt)
		purchased = cnt > 0
	}
	content := ""
	if s.IsFree == 1 || purchased {
		content = s.Content
	}
	writeJSON(w, 200, "ok", map[string]interface{}{
		"id":            s.ID,
		"user_id":       s.UserID,
		"username":      s.Username,
		"title":         s.Title,
		"description":   s.Description,
		"content":       content,
		"fields":        json.RawMessage(s.Fields),
		"is_free":       s.IsFree,
		"price_tokens":  s.PriceTokens,
		"screenshots":   json.RawMessage(s.Screenshots),
		"status":        s.Status,
		"download_count": s.DownloadCount,
		"purchase_count": s.PurchaseCount,
		"view_count":    s.ViewCount,
		"comment_count": commentCount,
		"size":          int64(len(s.Content)), // 整个对话内容的字节大小
		"created_at":    s.CreatedAt,
		"purchased":     purchased,
	})
}

// GET /api/ai_chat/download/{id} — 下载对话文本（免费直接下；收费需已购）
func handleGetAiChatDownload(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/ai_chat/download/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	var s AiChatShare
	err := db.QueryRow("SELECT id, user_id, content, is_free FROM ai_chat_shares WHERE id = ?", id).
		Scan(&s.ID, &s.UserID, &s.Content, &s.IsFree)
	if err != nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	requester := getCurrentUserID(r)
	allowed := s.IsFree == 1
	if !allowed && requester != 0 {
		if requester == s.UserID {
			allowed = true
		} else {
			var cnt int
			db.QueryRow("SELECT COUNT(*) FROM ai_chat_purchases WHERE user_id = ? AND share_id = ?", requester, id).Scan(&cnt)
			allowed = cnt > 0
		}
	}
	if !allowed {
		writeJSON(w, 403, "请先购买后下载", nil)
		return
	}
	db.Exec("UPDATE ai_chat_shares SET download_count = download_count + 1 WHERE id = ?", id)
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"ai_chat_%d.json\"", id))
	w.WriteHeader(200)
	w.Write([]byte(s.Content))
}

// POST /api/ai_chat/inc_download/{id} — 仅递增下载次数（App 本地保存 / 导入时调用）
// 与文件下载接口分离，保证“下载次数”统一在服务器端统计，避免 App 直接本地保存导致计数永远为 0。
func handleIncAiChatDownload(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/ai_chat/inc_download/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	res, err := db.Exec("UPDATE ai_chat_shares SET download_count = download_count + 1 WHERE id = ? AND status = 'approved'", id)
	if err != nil {
		log.Printf("[AI分享] 下载计数更新失败: id=%d, err=%v", id, err)
		writeJSON(w, 500, "更新失败", nil)
		return
	}
	if n, _ := res.RowsAffected(); n == 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	writeJSON(w, 200, "ok", nil)
}

// GET /api/ai_chat/comments/{id} — 评论列表（需登录）
func handleGetAiChatComments(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/ai_chat/comments/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	// 校验分享是否存在（且已通过）
	var exists int
	db.QueryRow("SELECT COUNT(*) FROM ai_chat_shares WHERE id = ? AND status = 'approved'", id).Scan(&exists)
	if exists == 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if limit < 1 || limit > 50 {
		limit = 20
	}
	offset := (page - 1) * limit
	rows, err := db.Query(`SELECT c.id, c.user_id, u.username, c.content, c.parent_id, c.created_at
		FROM ai_chat_comments c JOIN users u ON c.user_id = u.id
		WHERE c.share_id = ? ORDER BY c.created_at ASC LIMIT ? OFFSET ?`, id, limit, offset)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	defer rows.Close()
	type CommentItem struct {
		ID         int64  `json:"id"`
		UserID     int64  `json:"user_id"`
		Username   string `json:"username"`
		Content    string `json:"content"`
		ParentID   int64  `json:"parent_id"`
		CreatedAt  int64  `json:"created_at"`
		ReplyCount int    `json:"reply_count"`
	}
	var comments []CommentItem
	for rows.Next() {
		var c CommentItem
		rows.Scan(&c.ID, &c.UserID, &c.Username, &c.Content, &c.ParentID, &c.CreatedAt)
		db.QueryRow("SELECT COUNT(*) FROM ai_chat_comments WHERE parent_id = ?", c.ID).Scan(&c.ReplyCount)
		comments = append(comments, c)
	}
	if comments == nil {
		comments = []CommentItem{}
	}
	var total int
	db.QueryRow("SELECT COUNT(*) FROM ai_chat_comments WHERE share_id = ?", id).Scan(&total)
	writeJSON(w, 200, "ok", map[string]interface{}{"comments": comments, "total": total})
}

// POST /api/ai_chat/comment/add  body: {"share_id":, "content":, "parent_id":}
func handleAddAiChatComment(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var req struct {
		ShareID  int64  `json:"share_id"`
		Content  string `json:"content"`
		ParentID int64  `json:"parent_id"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	req.Content = strings.TrimSpace(req.Content)
	if req.Content == "" {
		writeJSON(w, 400, "评论内容不能为空", nil)
		return
	}
	if req.ShareID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var exists int
	db.QueryRow("SELECT COUNT(*) FROM ai_chat_shares WHERE id = ? AND status = 'approved'", req.ShareID).Scan(&exists)
	if exists == 0 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	// 评论频率限制（防灌水）
	if allowed, wait := checkCommentRateLimit(userID); !allowed {
		writeJSON(w, 429, fmt.Sprintf("评论过于频繁，请 %d 秒后再试", wait), nil)
		return
	}
	// 防 XSS
	req.Content = html.EscapeString(req.Content)
	if req.ParentID > 0 {
		var parentExists int
		db.QueryRow("SELECT COUNT(*) FROM ai_chat_comments WHERE id = ? AND share_id = ?", req.ParentID, req.ShareID).Scan(&parentExists)
		if parentExists == 0 {
			writeJSON(w, 400, "被回复的评论不存在", nil)
			return
		}
	}
	now := time.Now().Unix()
	result, err := db.Exec("INSERT INTO ai_chat_comments (share_id, user_id, content, parent_id, created_at) VALUES (?, ?, ?, ?, ?)",
		req.ShareID, userID, req.Content, req.ParentID, now)
	if err != nil {
		writeJSON(w, 500, "添加失败", nil)
		return
	}
	commentID, _ := result.LastInsertId()
	// 同步维护分享卡片的评论数（用于详情页/列表展示）
	db.Exec("UPDATE ai_chat_shares SET comment_count = (SELECT COUNT(*) FROM ai_chat_comments WHERE share_id = ?) WHERE id = ?", req.ShareID, req.ShareID)
	log.Printf("用户 %d 评论 AI 对话分享 %d (parent_id=%d, comment_id=%d)", userID, req.ShareID, req.ParentID, commentID)
	writeJSON(w, 200, "ok", map[string]interface{}{"comment_id": commentID})
}

// GET /api/ai_chat/screenshot/{id}/{filename}
func handleGetAiChatScreenshot(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/ai_chat/screenshot/")
	parts := strings.SplitN(path, "/", 2)
	if len(parts) != 2 {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	id, _ := strconv.ParseInt(parts[0], 10, 64)
	fileName := parts[1]
	if id <= 0 || fileName == "" {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	// 校验文件名归属，防止越权访问
	if !strings.HasPrefix(fileName, fmt.Sprintf("%d_", id)) {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	execPath, _ := os.Executable()
	fp := filepath.Join(filepath.Dir(execPath), "data", "ai_chat", "screenshots", fileName)
	if _, err := os.Stat(fp); os.IsNotExist(err) {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	http.ServeFile(w, r, fp)
}

// ==================== 购买（token 扣减） ====================

// POST /api/ai_chat/buy/{id}
func handleBuyAiChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	path := strings.TrimPrefix(r.URL.Path, "/api/ai_chat/buy/")
	id, _ := strconv.ParseInt(strings.SplitN(path, "/", 2)[0], 10, 64)
	if id <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var s AiChatShare
	err := db.QueryRow("SELECT id, user_id, is_free, price_tokens FROM ai_chat_shares WHERE id = ?", id).
		Scan(&s.ID, &s.UserID, &s.IsFree, &s.PriceTokens)
	if err != nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	if s.IsFree == 1 {
		writeJSON(w, 400, "该内容免费，无需购买", nil)
		return
	}
	if userID == s.UserID {
		writeJSON(w, 400, "不能购买自己的内容", nil)
		return
	}
	balance := getEffectiveTokenBalance(userID)
	if balance < s.PriceTokens {
		writeJSON(w, 400, "token 余额不足", map[string]interface{}{"balance": balance, "need": s.PriceTokens})
		return
	}
	// 幂等：已购买直接返回
	var cnt int
	db.QueryRow("SELECT COUNT(*) FROM ai_chat_purchases WHERE user_id = ? AND share_id = ?", userID, id).Scan(&cnt)
	if cnt > 0 {
		writeJSON(w, 200, "已购买", map[string]interface{}{"balance": balance})
		return
	}
	tx, err := db.Begin()
	if err != nil {
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	if _, e1 := tx.Exec("UPDATE users SET token_balance = token_balance - ? WHERE id = ? AND token_balance >= ?", s.PriceTokens, userID, s.PriceTokens); e1 != nil {
		tx.Rollback()
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	if _, e2 := tx.Exec("INSERT OR IGNORE INTO ai_chat_purchases (user_id, share_id, created_at) VALUES (?, ?, ?)", userID, id, time.Now().Unix()); e2 != nil {
		tx.Rollback()
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	if _, e3 := tx.Exec("UPDATE ai_chat_shares SET purchase_count = purchase_count + 1 WHERE id = ?", id); e3 != nil {
		tx.Rollback()
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	if err := tx.Commit(); err != nil {
		writeJSON(w, 500, "购买失败", nil)
		return
	}
	writeJSON(w, 200, "购买成功", map[string]interface{}{"balance": balance - s.PriceTokens})
}

// ==================== 管理端 ====================

// GET /api/admin/ai_chat/list
func handleAdminGetAiChatList(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		writeJSON(w, 405, "仅支持 GET", nil)
		return
	}
	if !checkDevOrPerm(r, "apps.manage") {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	rows, err := db.Query("SELECT acs.id, acs.user_id, COALESCE(u.username,''), acs.title, acs.description, acs.fields, acs.is_free, acs.price_tokens, acs.screenshots, acs.status, acs.download_count, acs.purchase_count, acs.created_at, substr(acs.content,1,160) FROM ai_chat_shares acs JOIN users u ON acs.user_id = u.id ORDER BY acs.created_at DESC")
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	list, err := scanAiChatShares(rows)
	if err != nil {
		writeJSON(w, 500, "查询失败", nil)
		return
	}
	writeJSON(w, 200, "ok", map[string]interface{}{"shares": list})
}

// POST /api/admin/ai_chat/review  body: {"share_id":, "action":"approve"|"reject"}
func handleAdminReviewAiChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "apps.manage") {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	var body struct {
		ShareID int64  `json:"share_id"`
		Action  string `json:"action"`
	}
	json.NewDecoder(r.Body).Decode(&body)
	if body.ShareID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	status := "approved"
	if body.Action == "reject" {
		status = "rejected"
	}
	if _, err := db.Exec("UPDATE ai_chat_shares SET status = ? WHERE id = ?", status, body.ShareID); err != nil {
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	writeJSON(w, 200, "ok", nil)
}

// POST /api/ai_chat/delete  body: {"share_id":}
// 普通用户只能删除自己上传的卡片；开发者（最高权限）可删除任意卡片。
func handleDeleteAiChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	userID := getCurrentUserID(r)
	if userID == 0 {
		writeJSON(w, 401, "未登录", nil)
		return
	}
	var body struct {
		ShareID int64 `json:"share_id"`
	}
	json.NewDecoder(r.Body).Decode(&body)
	if body.ShareID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	var ownerID int64
	if err := db.QueryRow("SELECT user_id FROM ai_chat_shares WHERE id = ?", body.ShareID).Scan(&ownerID); err != nil {
		writeJSON(w, 404, "不存在", nil)
		return
	}
	if ownerID != userID && !isDeveloperUser(userID) {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	if _, err := db.Exec("UPDATE ai_chat_shares SET status = 'deleted' WHERE id = ?", body.ShareID); err != nil {
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	writeJSON(w, 200, "ok", nil)
}

// POST /api/admin/ai_chat/delete  body: {"share_id":}
func handleAdminDeleteAiChat(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		writeJSON(w, 405, "仅支持 POST", nil)
		return
	}
	if !checkDevOrPerm(r, "apps.manage") {
		writeJSON(w, 403, "无权限", nil)
		return
	}
	var body struct {
		ShareID int64 `json:"share_id"`
	}
	json.NewDecoder(r.Body).Decode(&body)
	if body.ShareID <= 0 {
		writeJSON(w, 400, "参数错误", nil)
		return
	}
	if _, err := db.Exec("UPDATE ai_chat_shares SET status = 'deleted' WHERE id = ?", body.ShareID); err != nil {
		writeJSON(w, 500, "操作失败", nil)
		return
	}
	writeJSON(w, 200, "ok", nil)
}
