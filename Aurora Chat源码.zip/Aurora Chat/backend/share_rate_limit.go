package main

import "time"

// checkShareRateLimit 检查用户分享频率/数量限制（跨源码分享和 AI 对话分享）
// 返回 (是否允许, 错误消息)
func checkShareRateLimit(userID int64) (bool, string) {
	// 开发者不限次数
	if isDeveloperUser(userID) {
		return true, ""
	}
	now := time.Now().Unix()

	// 1 分钟内最多 1 个
	var count1min int
	db.QueryRow(
		"SELECT COUNT(*) FROM (SELECT created_at FROM source_code_shares WHERE user_id = ? UNION ALL SELECT created_at FROM ai_chat_shares WHERE user_id = ?) t WHERE created_at > ?",
		userID, userID, now-60,
	).Scan(&count1min)
	if count1min >= 1 {
		return false, "操作过于频繁，请 1 分钟后再试"
	}

	// 10 分钟内最多 3 个
	var count10min int
	db.QueryRow(
		"SELECT COUNT(*) FROM (SELECT created_at FROM source_code_shares WHERE user_id = ? UNION ALL SELECT created_at FROM ai_chat_shares WHERE user_id = ?) t WHERE created_at > ?",
		userID, userID, now-600,
	).Scan(&count10min)
	if count10min >= 3 {
		return false, "10 分钟内最多上传 3 个，请稍后再试"
	}

	// 1 小时内最多 5 个
	var count1hour int
	db.QueryRow(
		"SELECT COUNT(*) FROM (SELECT created_at FROM source_code_shares WHERE user_id = ? UNION ALL SELECT created_at FROM ai_chat_shares WHERE user_id = ?) t WHERE created_at > ?",
		userID, userID, now-3600,
	).Scan(&count1hour)
	if count1hour >= 5 {
		return false, "1 小时内最多上传 5 个，请稍后再试"
	}

	// 1 天内最多 10 个
	var count1day int
	db.QueryRow(
		"SELECT COUNT(*) FROM (SELECT created_at FROM source_code_shares WHERE user_id = ? UNION ALL SELECT created_at FROM ai_chat_shares WHERE user_id = ?) t WHERE created_at > ?",
		userID, userID, now-86400,
	).Scan(&count1day)
	if count1day >= 10 {
		return false, "一天最多上传 10 个，请明天再试"
	}

	return true, ""
}