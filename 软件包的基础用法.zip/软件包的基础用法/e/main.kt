package e

import xi.m

fun main() {
    val a : m = m()
    a.ww()
}